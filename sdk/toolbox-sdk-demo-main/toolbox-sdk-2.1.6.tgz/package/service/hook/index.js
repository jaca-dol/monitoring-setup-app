export * from './../../lib/module/service/hook/index.js';
