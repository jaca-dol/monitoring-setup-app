export * from './../../lib/module/service/DeviceManager/index.js';
