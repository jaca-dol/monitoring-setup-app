export * from './../../../lib/module/service/DeviceManager/ble/index.js';
