export * from './../../../lib/module/service/DeviceManager/container/index.js';
