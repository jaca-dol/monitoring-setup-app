export * from './../../lib/module/service/password/index.js';
