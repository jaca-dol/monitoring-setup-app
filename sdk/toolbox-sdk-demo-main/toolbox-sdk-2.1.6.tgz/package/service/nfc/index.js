export * from './../../lib/module/service/nfc/index.js';
