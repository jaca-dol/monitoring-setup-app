export * from './../../../lib/module/service/nfc/controller/index.js';
