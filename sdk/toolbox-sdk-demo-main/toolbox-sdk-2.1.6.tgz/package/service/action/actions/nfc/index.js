export * from './../../../../lib/module/service/action/actions/nfc/index.js';
