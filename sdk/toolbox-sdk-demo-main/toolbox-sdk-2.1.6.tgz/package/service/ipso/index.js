export * from './../../lib/module/service/ipso/index.js';
