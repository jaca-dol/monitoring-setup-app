export * from './../../lib/module/model/attribute/index.js';
