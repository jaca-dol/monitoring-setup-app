export * from './../../../../lib/module/model/attribute/definitions/tsl/index.js';
