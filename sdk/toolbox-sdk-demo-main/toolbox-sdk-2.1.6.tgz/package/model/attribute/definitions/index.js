export * from './../../../lib/module/model/attribute/definitions/index.js';
