export * from './../../lib/module/model/config/index.js';
