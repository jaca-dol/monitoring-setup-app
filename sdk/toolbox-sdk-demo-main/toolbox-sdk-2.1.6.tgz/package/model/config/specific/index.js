export * from './../../../lib/module/model/config/specific/index.js';
