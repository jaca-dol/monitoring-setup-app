export * from './../../lib/module/model/DataModel/index.js';
