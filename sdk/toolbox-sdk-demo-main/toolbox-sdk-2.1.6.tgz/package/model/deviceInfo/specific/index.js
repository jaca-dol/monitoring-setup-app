export * from './../../../lib/module/model/deviceInfo/specific/index.js';
