export * from './../../lib/module/model/deviceInfo/index.js';
