require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "ToolboxSdk"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => min_ios_version_supported }
  s.source       = { :git => "https://gitlab.milesight.com/zhengzg5702.git", :tag => "#{s.version}" }


  xcframework_path = File.join(__dir__, "libcodec.xcframework")

  if File.exist?(xcframework_path)
    s.source_files = [
        "ios/**/*.{h,m,mm}",
        "codec/**/*.h"
    ]
    s.vendored_frameworks = "libcodec.xcframework"
  else    
    s.source_files = [
        "ios/**/*.{h,m,mm}",
        "codec/**/*.{h,c}"
    ]
  end


# Use install_modules_dependencies helper to install the dependencies if React Native version >=0.71.0.
# See https://github.com/facebook/react-native/blob/febf6b7f33fdb4904669f99d795eba4c0f95d7bf/scripts/cocoapods/new_architecture.rb#L79.
if respond_to?(:install_modules_dependencies, true)
  install_modules_dependencies(s)
else
  s.dependency "React-Core"
end

hash = s.to_hash
current_config = hash["pod_target_xcconfig"] != nil ? hash["pod_target_xcconfig"] : {}
current_config['USE_HEADERMAP'] = 'NO'
s.pod_target_xcconfig = current_config  

end
