import { DeviceInfo } from '../deviceInfo/DeviceInfo';

import { DeviceTSLInfoKeys } from './DeviceSpecificTSLInfo';
import { TSLInfo, TSLInfoKeys } from './TSLInfo';

type BasicValueType = string | number | boolean | Array<any>;

type AttributeHistoryInfo = Record<string, any>;

/**
 * Attribute的定义
 */
export interface AttributeDefinition<Value = any> {
	/**
	 * 属性key
	 */
	key: string;

	/**
	 * 属性默认值
	 */
	default?: Value;

	/**
	 * 属性分组（目前支持以设备型号/型号系列作为分组）
	 * 
	 * 要使用此属性请在TestData中定义product_sn/sn，否则测试用例中该项会报错
	 * @example common: 通用属性
	 * @example GS601: GS601特有属性
	 * @example EM320-TH: EM320-TH特有属性
	 * @example WT30X: WT30X系列特有属性
	 * @example [WT30X, WT30X-TH]: WT30X和WT30X-TH特有属性
	 * @default common
	 */
	group?: string | string[];

	/**
	 * 对应data的路径
	 */
	path?: string | ((key: string) => string);

	/**
	 * 从data中提取属性值
	 */
	getValue?: (data: any, value: any) => Value;

	/**
	 * 从数据值转为属性值(data[path] -> value)
	 * @param value - 数据值
	 * @param data - 本次转换的所有数据
	 * @param context - 上下文
	 */
	transformValue?: (value: any, data: any, context: Record<string, any>) => Value;

	/**
	 * 从属性值转为数据值(value -> data[path])
	 * @param value - 属性值
	 * @param data - 本次转换的所有数据
	 * @param context - 上下文
	 */
	transformDataValue?: (value: Value, data: any, context: Record<string, any>) => any;

	/**
	 * 属性映射方向
	 * @example up: 单向映射 value -> data[path]
	 * @example down: data[path] -> value
	 * @example both: 双向映射
	 * @default both
	 */
	direction?: 'up' | 'down' | 'both';

	/**
	 * 属性值映射到数据的状态((value -> data.status[x]))
	 * 
	 * 若需要根据其他字段值动态决定是否映射，优先使用metric/definitions中的visible属性
	 */
	mapToStatus?: boolean | ((value: any, data: any) => boolean);

	/**
	 * 映射到状态的顺序\
	 * 0-99：设备基本状态\
	 * 100-199：传感器状态\
	 * 200-300：网络状态
	 */
	mapToStatusOrder?: number;

	/**
	 * 属性值映射到状态配置
	 */
	mapToStatusConfig?: {
		/**
		 * 状态名称
		 */
		name?: string;

		/**
		 * 状态值
		 */
		value?: BasicValueType | ((value: Value) => BasicValueType);

		/**
		 * 状态类型
		 */
		type?: string;

		/**
		 * 状态单位
		 */
		unit?: string | ((value: Value, data: any) => string);
	} | ((value: Value, data: any) => {
		name?: string;
		value?: BasicValueType | ((value: Value) => BasicValueType);
		type?: string;
		unit?: string | ((value: Value, data: any) => string);
	});

	/**
	 * 属性值映射到历史值((value -> data.history[x]))
	 */
	mapToHistory?: boolean;

	/**
	 * 映射到历史的配置
	 * @returns 返回的对象将会被合并到data.history中
	 * @example 
	 *{
	 *  temperature: 20,
	 *  humidity: 50,
	 * }
	 */
	mapToHistoryConfig?: AttributeHistoryInfo | ((value: Value, data: any) => AttributeHistoryInfo);
}

/**
 * TSL数据模型上下文
 */
export interface TSLDataModelContext<DeviceKey extends DeviceTSLInfoKeys = 'all'> {
	/**
	 * 当前全部物模型信息
	 */
	tslInfo?: TSLInfo<DeviceKey>;

	/**
	 * 当前全部设备信息
	 */
	deviceInfo?: DeviceInfo;

	/**
	 * 之前的设备信息
	 * 用于做前后数据对比，目前仅在写入配置、模板，导出预配置时有值
	 */
	prevDeviceInfo?: DeviceInfo;
}

/**
 * TSL属性定义
 */
export interface TSLAttributeDefinition<DeviceKey extends DeviceTSLInfoKeys = 'all'> extends AttributeDefinition {
	/**
	 * 对应物模型属性标识符
	 * @link key来源：物模型维护表 -> 物模型属性标识符：https://doc.weixin.qq.com/sheet/e3_AZQAcAZ2ANoNAw89Uy5Sly37GwHpi?tab=9gcxo4
	 */
	key: TSLInfoKeys<DeviceKey>;

	/**
	 * 对应DeviceInfo的key路径
	 * 
	 * @link path来源：DeviceInfo -> key路径：src/features/device/types/DeviceInfo.ts
	 */
	path?: string | ((key: string) => string);

	/**
	* 从DeviceInfo的值转为TSLInfo的值(deviceInfo[path] -> tslInfo[key])
	* @param value - 设备信息值
	* @param deviceInfo - 本次转换的设备信息
	* @param context - 上下文
	* @returns 返回值为对象时，会合并到tslInfo中
	*/
	transformValue?: (value: any, deviceInfo: DeviceInfo, context: TSLDataModelContext<DeviceKey>) => any;

	/**
	 * 从TSLInfo的值转为DeviceInfo的值(tslInfo[key] -> deviceInfo[path])
	 * @param value - 属性值
	 * @param data - 本次转换的所有数据
	 * @param context - 上下文
	 * @returns 返回值为对象时，会合并到deviceInfo中
	 */
	transformDataValue?: (value: any, data: TSLInfo<DeviceKey>, context: TSLDataModelContext<DeviceKey>) => any;

	/**
	 * 属性映射方向
	 * @example up: 单向映射 tslInfo[key] -> deviceInfo[path]
	 * @example down: 单向映射，deviceInfo[path] -> tslInfo[key]
	 * @example both: 双向映射
	 * @default both
	 */
	direction?: 'up' | 'down' | 'both';
}

/**
 * TSL属性值转换器
 */
export interface TSLAttributeTransformer {
	/**
	 * 从TSLInfo的值转为DeviceInfo的值(tslInfo[key] -> deviceInfo[path])
	 * @param value - 属性值
	 * @param data - 本次转换的所有数据
	 * @param context - 上下文
	 * @returns 返回值为对象时，会合并到deviceInfo中
	 */
	transformDataValue: (value: any, data: Record<string, any>, context: {
		tslInfo?: Record<string, any>;
		deviceInfo?: DeviceInfo;
	}) => any;

	/**
	* 从DeviceInfo的值转为TSLInfo的值(deviceInfo[path] -> tslInfo[key])
	* @param value - 设备信息值
	* @param deviceInfo - 本次转换的设备信息
	* @param context - 上下文
	* @returns 返回值为对象时，会合并到tslInfo中
	*/
	transformValue: (value: any, deviceInfo: DeviceInfo, context: {
		tslInfo?: Record<string, any>;
		deviceInfo?: Record<string, any>;
	}) => any;
}