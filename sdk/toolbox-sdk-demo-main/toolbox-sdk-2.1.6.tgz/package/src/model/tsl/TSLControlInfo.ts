/**
 * TSL通用控制块信息
 */
export interface TSLControlInfo {
	/**
	 * 序号校验
	 */
	request_check_sequence_number: {
		sequence_number: number;
	};

	/**
	 * 序号校验应答
	 */
	check_sequence_number_reply: {
		sequence_number: number;
	};

	/**
	 * 顺序校验
	 */
	request_check_order: {
		order: number;
	};

	/**
	 * 顺序校验应答
	 */
	check_order_reply: {
		order: number;
	};

	/**
	 * 密码校验
	 */
	request_password_check: {
		password: string;
	};

	/**
	 * 密码校验应答
	 * 0: 密码正确
	 * 1: 密码错误
	 */
	password_check_reply: {
		result: 0 | 1;
	};

	/**
	 * 修改密码请求
	 */
	request_password_change: {
		new_password: string;
	};

	/**
	 * 修改密码应答
	 * 0: 修改成功
	 * 1: 修改失败
	 */
	password_change_reply: {
		result: 0 | 1;
	};

	/**
	 * 密码校验
	 * @class_type 服务
	 */
	request_security_password_check?: {
		/**
		 * 密码长度
		 * @default 6
		 * @class_type 参数
		 * @max_value 255
		 * @min_value 0
		 */
		length?: number;

		/**
		 * 密码
		 * @default 123456
		 * @class_type 参数
		 * @string_length 255
		 * @character_encoding ascii
		 */
		password?: string;
	};

	/**
	 * 密码校验应答
	 * @class_type 事件
	 */
	security_password_check_reply?: {
		/**
		 * 校验结果 - 0：校验成功 1：校验错误
		 * @default 0
		 * @class_type 参数
		 * @is_one_of
		 */
		result?: 0 | 1;

		/**
		 * 校验成功信息
		 * @class_type 参数
		 */
		successful_message?: Record<string, any>;

		/**
		 * 校验失败信息
		 * @class_type 参数
		 */
		failed_message?: {
			/**
			 * 等待时间
			 * @class_type 参数
			 */
			locked_time?: number;
		};
	};

	/**
	 * 密码修改
	 * @class_type 服务
	 */
	request_security_password_change?: {
		/**
		 * 密码长度
		 * @default 6
		 * @class_type 参数
		 * @max_value 255
		 * @min_value 0
		 */
		length?: number;

		/**
		 * 密码
		 * @default 123456
		 * @class_type 参数
		 * @string_length 255
		 * @character_encoding ascii
		 */
		new_password?: string;
	};

	/**
	 * 密码修改应答
	 * @class_type 事件
	 */
	security_password_change_reply?: {
		/**
		 * 修改结果 - 0：修改成功 1：修改错误 2：长度错误
		 * @default 0
		 * @class_type 参数
		 */
		result?: 0 | 1 | 2;
	};

	/**
	 * 升级固件请求
	 */
	request_firmware_upgrade: {
		/**
		 * 升级固件请求
		 */
		start_upgrade?: {
			/**
			 * 升级请求类型
			 * 0：全量
			 * 1：差分
			 */
			type: 0 | 1 | 2;

			/**
			 * 升级请求长度
			 */
			length: number;

			/**
			 * 升级请求校验数据
			 */
			check_data: Array<number>;
		};

		/**
		 * 升级固件传输
		 */
		transmission?: {
			length: number;
			data: Array<number>;
		};

		/**
		 * 升级固件结束请求, 表示重启
		 */
		end_upgrade?: number;

		/**
		 * 固件升级继续
		 * @class_type 参数
		 */
		continue_upgrade?: number;

		/**
		 * 固件升级结束校验
		 * @class_type 参数
		 */
		completion_check?: {
			/**
			 * 传输长度
			 * @default 1024
			 * @class_type 参数
			 * @max_value 1024
			 * @min_value 1
			 */
			length?: number;

			/**
			 * 校验内容
			 * @class_type 参数
			 * @array_length 65535
			 */
			data?: any[];
		};
	};

	/**
	 * 升级固件应答
	 */
	firmware_upgrade_reply: {
		/**
		 * 升级固件请求应答
		 */
		start_upgrade?: {
			/**
			 * 升级固件应答
			 * 0: 校验成功
			 * 1: 等待重发
			 * 2: 校验失败
			 */
			result: 0 | 1 | 2;
			length: number;
		};

		/**
		 * 固件传输应答
		 */
		transmission?: {
			result: 0 | 1;
		};

		/**
		 * 升级固件结束应答
		 * 0: 升级成功
		 * 1: 长度错误
		 * 2: CRC错误
		 */
		end_upgrade?: {
			result: 0 | 1 | 2;
		};

		/**
		 * 固件升级继续应答
		 * @class_type 参数
		 */
		continue_upgrade?: {
			/**
			 * 固件升级继续应答 - 0：成功 1：失败
			 * @default 0
			 * @class_type 参数
			 */
			result?: 0 | 1;
		};

		/**
		 * 固件升级结束校验应答
		 * @class_type 参数
		 */
		completion_check?: {
			/**
			 * 固件升级结束校验应答 - 0：成功 1：失败
			 * @default 0
			 * @class_type 参数
			 */
			result?: 0 | 1;
		};
	};

	/**
	 * SDK特有的命令查询
	 * @example ['product_name', 'product_pn', 'product_sn', 'version', 'oem_id', 'sub_version']
	 */
	req: Array<string>;

	/**
	 * 命令查询
	 * @class_type 服务
	 */
	request_command_queries: {
		/**
		 * 查询信息
		 * @class_type 参数
		 */
		query_information: number;

		/**
		 * 命令长度
		 * @default 1
		 * @class_type 参数
		 * @max_value 15
		 * @min_value 1
		 */
		length: number;

		/**
		 * @class_type 参数
		 * @character_encoding hex
		 */
		object_command: string;
	};

	/**
	 * 命令应答
	 * @class_type 事件
	 */
	command_queries_reply: {
		/**
		 * 应答结果 - 0：成功 1：无法解析 2：顺序错误 3：密码错误 4：读参数错误 5：写参数错误 6：读执行错误 7：写执行错误 8：读应用错误 9：写应用错误
		 * @default 0
		 * @class_type 参数
		 */
		result: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

		/**
		 * 命令长度
		 * @default 1
		 * @class_type 参数
		 * @max_value 15
		 * @min_value 1
		 */
		length: number;

		/**
		 * 所应答的命令
		 * @class_type 参数
		 * @string_length 15
		 * @character_encoding hex
		 */
		the_command_in_reply: string;
	};

	/**
	 * 查询所有配置请求
	 */
	request_query_all_configurations: number;

	/**
	 * 请求所有配置下发
	 */
	all_configurations_request_by_device: number;

	/**
	 * 重置
	 */
	reset: number;

	/**
	 * 重启
	 */
	reboot: number;

	/**
	 * 清除历史记录
	 */
	clear_historical_data: number;

	/**
	 * 停止查询回传
	 */
	stop_historical_data_retrieval: number;

	/**
	 * 回传某个时间点的历史数据
	 */
	retrieve_historical_data_by_time: {
		/**
		 * 时间点
		 */
		time: number;
	};

	/**
	 * 历史记录导出
	 * @class_type 服务
	 */
	request_historical_data_export?: {
		/**
		 * 历史记录导出子命令
		 * @class_type 参数
		 */
		command?: number;

		/**
		 * 历史记录导出请求
		 * @class_type 参数
		 */
		start_exporting?: {
			/**
			 * 历史记录导出开始时间
			 * @class_type 参数
			 */
			start_timestamp?: number;

			/**
			 * 历史记录导出结束时间
			 * @class_type 参数
			 */
			end_timestamp?: number;

			/**
			 * 历史记录导出当前时间
			 * @class_type 参数
			 */
			current_timestamp?: number;
		};

		/**
		 * 历史记录导出数据
		 * @class_type 参数
		 */
		exported_data?: Record<string, any>;

		/**
		 * 历史记录导出结束
		 * @class_type 参数
		 */
		end_exporting?: Record<string, any>;

		/**
		 * 历史记录导出全部
		 * @class_type 参数
		 */
		exported_all_data?: Record<string, any>;

		/**
		 * 历史记录导出请求
		 * @class_type 参数
		 */
		start_exporting_with_type?: {
			/**
			 * 历史记录导出类型
			 * @class_type 参数
			 */
			type?: number;

			/**
			 * 历史记录导出开始时间
			 * @class_type 参数
			 */
			start_timestamp?: number;

			/**
			 * 历史记录导出结束时间
			 * @class_type 参数
			 */
			end_timestamp?: number;

			/**
			 * 历史记录导出当前时间
			 * @class_type 参数
			 */
			current_timestamp?: number;
		};
	};

	/**
	 * 历史记录导出应答
	 * @class_type 事件
	 */
	historical_data_export_reply?: {
		/**
		 * 历史记录导出应答子命令
		 * @class_type 参数
		 */
		command?: number;

		/**
		 * 历史记录导出请求应答
		 * @class_type 参数
		 */
		start_exporting?: {
			/**
			 * 历史记录导出个数
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			quantity_of_data?: number;

			/**
			 * 历史记录导出单条数据长度
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			length?: number;

			/**
			 * 历史记录导出传输最大长度
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			max_length?: number;
		};

		/**
		 * 历史记录导出数据应答
		 * @class_type 参数
		 */
		exported_data?: {
			/**
			 * 历史记录导出数据长度
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			length?: number;

			/**
			 * 历史记录导出数据
			 * @class_type 参数
			 * @array_length 65535
			 */
			data?: any[];
		};

		/**
		 * 历史记录导出结束应答
		 * @class_type 参数
		 */
		end_exporting?: {
			/**
			 * 历史记录导出结束应答 - 0：成功 1：失败
			 * @default 0
			 * @class_type 参数
			 */
			result?: 0 | 1;
		};

		/**
		 * 历史记录导出全部数据应答
		 * @class_type 参数
		 */
		exported_all_data?: Record<string, any>;

		/**
		 * 历史记录导出请求应答
		 * @class_type 参数
		 */
		start_exporting_with_type?: {
			/**
			 * 历史记录导出个数
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			quantity_of_data?: number;

			/**
			 * 历史记录导出长度
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			length?: number;

			/**
			 * 历史记录导出传输最大长度
			 * @default 1
			 * @class_type 参数
			 * @max_value 65535
			 * @min_value 1
			 */
			max_length?: number;
		};
	};

	/**
	 * 查询设备状态
	 */
	query_device_status: number;

	/**
	 * 触发时间同步
	 */
	synchronize_time: number;

	/**
	 * 设置时间请求
	 */
	set_time: {
		timestamp: number;
	};

	/**
	 * 重新连接网络
	 */
	reconnect: number;

	/**
	 * GPIO1调试
	 */
	gpio_1_debug: {
		/**
		 * 子命令
		 * @default 0
		 */
		command?: number;

		/**
		 * 开启计数
		 */
		start_count: Record<string, any>;

		/**
		 * 停止计数
		 */
		stop_count: Record<string, any>;

		/**
		 * 配置计数
		 * @default 0
		 */
		config_count: number;

		/**
		 * 切换GPIO状态
		 */
		switch_state: Record<string, any>;
	};

	/**
	 * GPIO2调试
	 */
	gpio_2_debug: {
		/**
		 * 子命令
		 * @default 0
		 */
		command?: number;

		/**
		 * 开启计数
		 */
		start_count: Record<string, any>;

		/**
		 * 停止计数
		 */
		stop_count: Record<string, any>;

		/**
		 * 配置计数
		 * @default 0
		 */
		config_count: number;

		/**
		 * 切换GPIO状态
		 */
		switch_state: Record<string, any>;
	};

	/**
	 * 上传证书
	 */
	upload_certificate: Record<string, any>;

	/**
	 * 采集Modbus所有通道
	 */
	collect_all_modbus_channels: number;

	/**
	 * 采集Modbus单个通道
	 */
	req_read_single_modbus: number;

	/**
	 * 采集SDI所有通道
	 */
	collect_all_sdi_channels: number;

	/**
	 * 采集SDI单个通道
	 */
	collect_single_sdi_channels: {
		/**
		 * 通道ID
		 */
		channel_id: number;
	};

	/**
	 * 采集AI1
	 */
	collect_ai1: number;

	/**
	 * 采集AI2
	 */
	collect_ai2: number;
	/** 开关机 */
	device_status_control: {
		/** 动作 - 0：关机 1：开机 */
		state: 0 | 1;
};

	/** 设备状态 - 0：关机 1：开机 */
	device_status: 0 | 1;

	/** 蓝牙配对信息 */
	ble_pair_info: {
		/** 地址类型 - 0：公共 1：随机 */
		addr_type: 0 | 1;

		/** 蓝牙地址 */
		address: string;

		/** 蓝牙名称 */
		name: string;
	};

	/**
	 * 蓝牙手机名称
	 * @class_type 属性
	 */
	ble_phone_name: {
		/**
		 * 名称长度
		 * @default 6
		 * @class_type 属性
		 * @max_value 64
		 * @min_value 1
		 */
		length: number;

		/**
		 * 手机名称
		 * @default 123456
		 * @class_type 属性
		 * @string_length 64
		 * @array_length 64
		 * @character_encoding ascii
		 */
		value: string;
	};

	/**
	 * 子模块信息
	 * @class_type 属性
	 */
	submodule_info: {
		/**
		 * 版本V1
		 * @class_type 属性
		 */
		version_1?: {
			/**
			 * 子模块内容
			 * @class_type 属性
			 */
			context: {
				/**
				 * 允许差分 - 0：不允许 1：允许
				 * @default 0
				 * @class_type 属性
				 */
				patch_enable: 0 | 1;

				/**
				 * 版本
				 * @class_type 属性
				 * @string_length 8
				 * @character_encoding ascii
				 */
				version: string;
			};
		};

		/**
		 * 版本V2
		 * @class_type 属性
		 */
		version_2?: {
			/**
			 * 子模块个数
			 * @default 1
			 * @class_type 属性
			 * @max_value 16
			 * @min_value 1
			 */
			length: number;

			/**
			 * 子模块内容
			 * @class_type 属性
			 * @array_length 16
			 */
			context: {
				/**
				 * 允许差分 - 0：不允许 1：允许
				 * @default 0
				 * @class_type 属性
				 */
				patch_enable: 0 | 1;

				/**
				 * 版本
				 * @class_type 属性
				 * @string_length 16
				 * @character_encoding ascii
				 */
				version: string;
			}[];
		};
	};
		/**
	 * 清除累计电能
	 * @class_type 服务
	 */
		reset_energy?: {
			/**
			 * 通道
			 * @default 0
			 * @class_type 参数
			 */
			channel?: number;
		};
	
		/**
		 * 清除历史记录
		 * @class_type 服务
		 */
		clear_data?: {
			/**
			 * 类型 - 0：告警数据 1：周期数据 2：月度能耗数据 3：月度最值数据
			 * @default 0
			 * @class_type 参数
			 */
			type?: 0 | 1 | 2 | 3;
		};
}
