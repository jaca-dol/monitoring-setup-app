import { SensorInfoList } from './sensors';

/**
 * 通用传感器信息
 */
export interface CommonSensorInfo {
	/**
	 * 电子烟指数
	 */
	vaping_index: number;

	/**
	 * 电子烟告警
	 */
	vaping_index_alarm: {
		/**
		 * 采集错误
		 */
		collection_error?: Record<string, any>;

		/**
		 * 超量程下限
		 */
		lower_range_error?: Record<string, any>;

		/**
		 * 超量程上限
		 */
		over_range_error?: Record<string, any>;

		/**
		 * 阈值告警解除
		 */
		alarm_deactivation?: {
			/**
			 * 电子烟指数
			 */
			vaping_index: number;
		};

		/**
		 * 阈值告警触发
		 */
		alarm_trigger?: {
			/**
			 * 电子烟指数
			 */
			vaping_index: number;
		};

		/**
		 * 水汽干扰告警解除
		 */
		interference_alarm_deactivation?: Record<string, any>;

		/**
		 * 水汽干扰告警触发
		 */
		interference_alarm_trigger?: Record<string, any>;
	};

	/**
	 * PM1.0
	 */
	pm1_0: number;

	/**
	 * PM1.0告警
	 */
	pm1_0_alarm: {
		/**
		 * 采集错误
		 */
		collection_error?: Record<string, any>;

		/**
		 * 超量程下限
		 */
		lower_range_error?: Record<string, any>;

		/**
		 * 超量程上限
		 */
		over_range_error?: Record<string, any>;

		/**
		 * PM1.0阈值告警解除
		 */
		alarm_deactivation?: {
			/**
			 * PM1.0
			 */
			pm1_0: number;
		};

		/**
		 * PM1.0阈值告警触发
		 */
		alarm_trigger?: {
			/**
			 * PM1.0
			 */
			pm1_0: number;
		};
	};

	/**
	 * PM2.5
	 */
	pm2_5: number;

	/**
	 * PM2.5告警
	 */
	pm2_5_alarm: {
		/**
		 * 采集错误
		 */
		collection_error?: Record<string, any>;

		/**
		 * 超量程下限
		 */
		lower_range_error?: Record<string, any>;

		/**
		 * 超量程上限
		 */
		over_range_error?: Record<string, any>;

		/**
		 * PM2.5阈值告警解除
		 */
		alarm_deactivation?: {
			/**
			 * PM2.5
			 */
			pm2_5: number;
		};

		/**
		 * PM2.5阈值告警触发
		 */
		alarm_trigger?: {
			/**
			 * PM2.5
			 */
			pm2_5: number;
		};
	};

	/**
	 * PM10
	 */
	pm10: number;

	/**
	 * PM10告警
	 */
	pm10_alarm: {
		/**
		 * 采集错误
		 */
		collection_error?: Record<string, any>;

		/**
		 * 超量程下限
		 */
		lower_range_error?: Record<string, any>;

		/**
		 * 超量程上限
		 */
		over_range_error?: Record<string, any>;

		/**
		 * PM10阈值告警解除
		 */
		alarm_deactivation?: {
			/**
			 * PM10
			 */
			pm10: number;
		};

		/**
		 * PM10阈值告警触发
		 */
		alarm_trigger?: {
			/**
			 * PM10
			 */
			pm10: number;
		};
	};

	/**
	 * 温度
	 */
	temperature: number;

	/** 温度告警 */
	temperature_alarm: {
		/** 告警类型 */
		type: number;

		/** 采集错误 */
		collection_error: Record<string, any>;

		/** 超量程下限 */
		lower_range_error: Record<string, any>;

		/** 超量程上限 */
		over_range_error: Record<string, any>;

		/** 无数据 */
		no_data: Record<string, any>;

		/**
		 * 温度阈值告警解除
		 */
		alarm_deactivation?: {
			/**
			 * 温度
			 */
			temperature: number;
		};

		/**
		 * 温度阈值告警触发
		 */
		alarm_trigger?: {
			/**
			 * 温度
			 */
			temperature: number;
		};

		/**
		 * 燃烧告警解除
		 */
		burning_alarm_deactivation?: Record<string, any>;

		/**
		 * 燃烧告警触发
		 */
		burning_alarm_trigger?: Record<string, any>;

		/** 低于阈值告警解除 */
		lower_range_alarm_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 低于阈值告警 */
		lower_range_alarm_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 高于阈值告警解除 */
		over_range_alarm_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 高于阈值告警 */
		over_range_alarm_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 介于阈值告警解除 */
		within_range_alarm_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 介于阈值告警 */
		within_range_alarm_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 之外阈值告警解除 */
		exceed_range_alarm_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 之外阈值告警 */
		exceed_range_alarm_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 持续低温告警解除 */
		persistent_low_temperature_alarm_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 持续低温告警 */
		persistent_low_temperature_alarm_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 持续高温告警解除 */
		persistent_high_alarm_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 持续高温告警 */
		persistent_high_alarm_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 防冻保护解除 */
		anti_freeze_protection_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 防冻保护告警 */
		anti_freeze_protection_trigger: {
			/** 温度 */
			temperature: number;
		};

		/** 开窗检测解除 */
		window_status_detection_deactivation: {
			/** 温度 */
			temperature: number;
		};

		/** 开窗检测告警 */
		window_status_detection_trigger: {
			/** 温度 */
			temperature: number;
		};
	};

	/** 持续高温告警设置 */
	high_temperature_alarm_settings: {
		/** 持续高温告警 - 0：禁用 1：启用 */
		enable: 0 | 1;

		/** 温度差值 */
		difference_in_temperature: number;

		/** 持续时间 */
		duration: number;
	};

	/** 持续低温告警设置 */
	low_temperature_alarm_settings: {
		/** 持续低温告警 - 0：禁用 1：启用 */
		enable: 0 | 1;

		/** 温度差值 */
		difference_in_temperature: number;

		/** 持续时间 */
		duration: number;
	};

	/**
	 * 湿度
	 */
	humidity: number;

  /**
     * 湿度告警
     * @class_type 事件
     */
	humidity_alarm?: {
		/**
		 * 告警类型
		 * @class_type 参数
		 * @is_one_of
		 */
		type?: number;

		/**
		 * 采集错误
		 * @class_type 参数
		 */
		collection_error?: Record<string, any>;

		/**
		 * 超量程下限
		 * @class_type 参数
		 */
		lower_range_error?: Record<string, any>;

		/**
		 * 超量程上限
		 * @class_type 参数
		 */
		over_range_error?: Record<string, any>;

		/**
		 * 无数据
		 * @class_type 参数
		 */
		no_data?: Record<string, any>;

		/**
		 * 低于阈值告警解除
		 * @class_type 参数
		 */
		lower_range_alarm_deactivation?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 低于阈值告警
		 * @class_type 参数
		 */
		lower_range_alarm_trigger?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 高于阈值告警解除
		 * @class_type 参数
		 */
		over_range_alarm_deactivation?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 高于阈值告警
		 * @class_type 参数
		 */
		over_range_alarm_trigger?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 介于阈值告警解除
		 * @class_type 参数
		 */
		within_range_alarm_deactivation?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 介于阈值告警
		 * @class_type 参数
		 */
		within_range_alarm_trigger?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 之外阈值告警解除
		 * @class_type 参数
		 */
		exceed_range_alarm_deactivation?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 之外阈值告警
		 * @class_type 参数
		 */
		exceed_range_alarm_trigger?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 突变告警触发
		 * @class_type 参数
		 */
		mutation_alarm_trigger_no_mutation?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;
		};

		/**
		 * 突变告警触发
		 * @class_type 参数
		 */
		mutation_alarm_trigger?: {
				/**
				 * 湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				humidity?: number;

				/**
				 * 突变湿度
				 * @class_type 参数
				 * @max_value 100
				 * @min_value 0
				 * @decimal_digits 1
				 */
				saltation?: number;
		};
};

	/**
	 * TVOC
	 */
	tvoc: number;

	/**
	 * TVOC告警
	 */
	tvoc_alarm: {
		/**
		 * 采集错误
		 */
		collection_error?: Record<string, any>;

		/**
		 * 超量程下限
		 */
		lower_range_error?: Record<string, any>;

		/**
		 * 超量程上限
		 */
		over_range_error?: Record<string, any>;

		/**
		 * TVOC阈值告警
		 */
		alarm_deactivation?: {
			/**
			 * TVOC
			 */
			tvoc: number;
		};

		/**
		 * TVOC阈值告警触发
		 */
		alarm_trigger?: {
			/**
			 * TVOC
			 */
			tvoc: number;
		};
	};

	/**
	 * 篡改状态
	 */
	tamper_status: 0 | 1;

	/**
	 * 篡改状态告警
	 */
	tamper_status_alarm: {
		/**
		 * 正常
		 */
		normal?: Record<string, any>;

		/**
		 * 触发
		 */
		trigger?: Record<string, any>;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_1: {
		rmox_0: number;
		rmox_1: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_2: {
		rmox_2: number;
		rmox_3: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_3: {
		rmox_4: number;
		rmox_5: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_4: {
		rmox_6: number;
		rmox_7: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_5: {
		rmox_8: number;
		rmox_9: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_6: {
		rmox_10: number;
		rmox_11: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_7: {
		rmox_12: number;
		zmod4510_rmox3: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_8: {
		log_rcda: number;
		rhtr: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_9: {
		temperature: number;
		iaq: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_10: {
		tvoc: number;
		etoh: number;
	};

	/**
	 * TVOC原始数据
	 */
	tvoc_raw_data_11: {
		co2: number;
		rel_iaq: number;
	};

	/**
	 * 温度单位
	 * 0: ℃
	 * 1: ℉
	 */
	temperature_unit: 0 | 1;

	/**
	 * TVOC原始数据上报
	 * 0: 禁用
	 * 1: 启用
	 */
	tvoc_raw_reporting_enable: 0 | 1;

	/**
	 * 温度阈值告警
	 */
	temperature_alarm_settings: {
		/**
		 * 温度阈值告警
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件
		 * 0: 无用
		 * 1: 条件：x<A
		 * 2: 条件：x>B
		 * 3: 条件：A<x<B
		 * 4: 条件：x<A或x>B
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 值A
		 */
		threshold_min: number;

		/**
		 * 值B
		 */
		threshold_max: number;
	};

	/**
	 * 湿度阈值告警配置
	 */
	humidity_alarm_settings: {
		/**
		 * 配置使能 - 0: 禁用 1: 启用
		 * @default 1
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件 - 0:禁用 1:条件：x<A 2:条件：x>B 3:条件：A<x<B 4:条件：x<A或x>B
		 * @default 0
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 最小阈值
		 * @default 12
		 */
		threshold_min: number;

		/**
		 * 最大阈值
		 * @default 30
		 */
		threshold_max: number;
	};

	/**
	 * PM1.0阈值告警
	 */
	pm1_0_alarm_settings: {
		/**
		 * PM1.0阈值告警
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件
		 * 0: 无用
		 * 1: 条件：x<A
		 * 2: 条件：x>B
		 * 3: 条件：A<x<B
		 * 4: 条件：x<A或x>B
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 值A
		 */
		threshold_min: number;

		/**
		 * 值B
		 */
		threshold_max: number;
	};

	/**
	 * PM2.5阈值告警
	 */
	pm2_5_alarm_settings: {
		/**
		 * PM2.5阈值告警
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件
		 * 0: 无用
		 * 1: 条件：x<A
		 * 2: 条件：x>B
		 * 3: 条件：A<x<B
		 * 4: 条件：x<A或x>B
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 值A
		 */
		threshold_min: number;

		/**
		 * 值B
		 */
		threshold_max: number;
	};

	/**
	 * PM10阈值告警
	 */
	pm10_alarm_settings: {
		/**
		 * PM10阈值告警
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件
		 * 0: 无用
		 * 1: 条件：x<A
		 * 2: 条件：x>B
		 * 3: 条件：A<x<B
		 * 4: 条件：x<A或x>B
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 值A
		 */
		threshold_min: number;

		/**
		 * 值B
		 */
		threshold_max: number;
	};

	/**
	 * TVOC阈值告警
	 */
	tvoc_alarm_settings: {
		/**
		 * TVOC阈值告警
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件
		 * 0: 无用
		 * 1: 条件：x<A
		 * 2: 条件：x>B
		 * 3: 条件：A<x<B
		 * 4: 条件：x<A或x>B
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 值A
		 */
		threshold_min: number;

		/**
		 * 值B
		 */
		threshold_max: number;
	};

	/**
	 * 电子烟阈值告警
	 */
	vaping_index_alarm_settings: {
		/**
		 * 电子烟阈值告警
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 阈值条件
		 * 0: 无用
		 * 1: 条件：x<A
		 * 2: 条件：x>B
		 * 3: 条件：A<x<B
		 * 4: 条件：x<A或x>B
		 */
		threshold_condition: 0 | 1 | 2 | 3 | 4;

		/**
		 * 值A
		 */
		threshold_min: number;

		/**
		 * 值B
		 */
		threshold_max: number;
	};

	/**
	 * 阈值告警次数
	 */
	alarm_reporting_times: number;

	/**
	 * 阈值解除告警使能
	 * 0: 禁用
	 * 1: 启用
	 */
	alarm_deactivation_enable: 0 | 1;

	/**
	 * 温度校准设置
	 */
	temperature_calibration_settings: {
		/**
		 * 温度
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * 湿度校准设置
	 */
	humidity_calibration_settings: {
		/**
		 * 湿度
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * PM1.0校准设置
	 */
	pm1_0_calibration_settings: {
		/**
		 * PM1.0
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * PM2.5校准设置
	 */
	pm2_5_calibration_settings: {
		/**
		 * PM2.5
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * PM10校准设置
	 */
	pm10_calibration_settings: {
		/**
		 * PM10
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * TVOC校准设置
	 */
	tvoc_calibration_settings: {
		/**
		 * TVOC
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * 电子烟指数校准设置
	 */
	vaping_index_calibration_settings: {
		/**
		 * 电子烟指数
		 * 0: 禁用
		 * 1: 启用
		 */
		enable: 0 | 1;

		/**
		 * 校准值
		 */
		calibration_value: number;
	};

	/**
	 * TVOC自清洁
	 */
	execute_tvoc_self_clean: number;

	/**
	 * 设置相对初始面
	 * @class_type 服务
	 */
	set_retrieval_initial_surface?: {
		/**
		 * 设置相对初始面 - 0:恢复以水平面作为相对初始面  1:以当前XY所在平面设置为相对初始面
		 * @class_type 服务
		 */
		operation?: 0 | 1;
	};

  /**
    * AT指令调试
    * @class_type 服务
     */
	debugging_commands?: {
		/**
		 * 指令长度
		 * @default 1
		 * @class_type 参数
		 * @max_value 512
		 * @min_value 1
		 */
		length?: number;

		/**
		 * 指令数据内容
		 * @class_type 参数
		 * @string_length 512
		 * @character_encoding ascii
		 */
		content?: string;
};

	/**
	 * 设置零点校准
	 */
	set_zero_calibration?: {
		/**
		 * 设置零点校准 - 0:恢复零点校准  1:以当前XY所在平面设置为零点校准
		 * @class_type 服务
		 */
		operation?: 0 | 1;
	};

    /**
     * 采集周期
     */
    collection_interval: {
			/**
			 * 采集周期单位 - 0：秒 1：分
			 * @default 1
			 */
			unit: 0 | 1;

			/**
			 * 采集周期
			 * @default 900
			 */
			seconds_of_time?: number;

			/**
			 * 采集周期
			 * @default 15
			 */
			minutes_of_time?: number;
	};

	/**
		* 传感器探针ID上报
		*/
	sensor_id: {
		/**
		 * 传感器探针ID类型 - 0: 无探针 1: SHT41      2: DS18B20
		 * @default 0
		 */
		type: 0 | 1 | 2;

		/**
		 * 传感器探针ID
		 */
		id: string;
	};

	/**
	 * 电机校准
	 */
	calibrate_motor: number;
}

export type TSLSensorInfo = CommonSensorInfo & SensorInfoList
