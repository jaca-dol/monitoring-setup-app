export interface UC711TSLInfo {
    /**
     * 湿度
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     * @decimal_digits 1
     */
    humidity: number;

    /**
     * 温控信息
     * @class_type 属性
     */
    temperature_control_info: {
        /**
         * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动 10：关闭 11：无效
         * @default 0
         * @class_type 属性
         */
        mode?: 0 | 1 | 2 | 3 | 10 | 11;

        /**
         * 温控状态 - 0：待机  1：一级制热  2：二级制热  3：三级制热  4：四级制热  5：紧急制热  6：一级制冷  7：二级制冷  8：五级制热
         * @default 0
         * @class_type 属性
         */
        status: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
    };

    /**
     * 风扇信息
     * @class_type 属性
     */
    fan_control_info: {
        /**
         * 风扇模式 - 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速 10：关闭 11：无效
         * @default 0
         * @class_type 属性
         */
        mode?: 0 | 1 | 2 | 3 | 4 | 5 | 10 | 11;

        /**
         * 风扇状态 - 0：关 1：开 2：低速 3：中速 4：高速
         * @default 0
         * @class_type 属性
         */
        status: 0 | 1 | 2 | 3 | 4;
    };

    /**
     * 计划
     * @default 0
     * @class_type 属性
     * @max_value 16
     * @min_value 0
     */
    execution_plan_id: number;

    /**
     * 目标温度
     * @class_type 属性
     * @max_value 35
     * @min_value 5
     * @decimal_digits 1
     */
    target_temperature?: number;

    /**
     * 双设定点制冷目标温度
     * @class_type 属性
     * @max_value 35
     * @min_value 5
     * @decimal_digits 1
     */
    cool_target_temperature?: number;

    /**
     * 温度告警
     * @class_type 事件
     */
    temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 低温阈值告警解除
         * @class_type 参数
         */
        lower_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 低温阈值告警
         * @class_type 参数
         */
        lower_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 高温阈值告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 高温阈值告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 持续低温告警解除
         * @class_type 参数
         */
        persistent_low_temperature_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 持续低温告警
         * @class_type 参数
         */
        persistent_low_temperature_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 持续高温告警解除
         * @class_type 参数
         */
        persistent_high_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 持续高温告警
         * @class_type 参数
         */
        persistent_high_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 防冻保护解除
         * @class_type 参数
         */
        anti_freeze_protection_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 防冻保护告警
         * @class_type 参数
         */
        anti_freeze_protection_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 开窗检测解除
         * @class_type 参数
         */
        window_status_detection_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 开窗检测告警
         * @class_type 参数
         */
        window_status_detection_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
    };

    /**
     * 湿度告警
     * @class_type 事件
     */
    humidity_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;
    };

    /**
     * 当前计划名称
     * @class_type 属性
     */
    plan_name: {
        /**
         * 名称ID
         * @class_type 属性
         */
        name_id?: number;

        /**
         * 命名前5B
         * @class_type 属性
         * @string_length 5
         * @character_encoding ascii
         */
        name_first: string;

        /**
         * 命名后5B
         * @class_type 属性
         * @string_length 5
         * @character_encoding ascii
         */
        name_last: string;
    };

    /**
     * 设备状态 - 0：关机 1：开机
     * @default 1
     * @class_type 属性
     */
    device_status: 0 | 1;

    /**
     * 随机密钥 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    random_key: 0 | 1;

    /**
     * 温度单位 - 0：℃ 1：℉
     * @default 0
     * @class_type 属性
     */
    temperature_unit: 0 | 1;

    /**
     * 温控数据来源
     * @class_type 属性
     */
    temperature_control_data_origin: {
        /**
         * 二级命令ID
         * @class_type 属性
         */
        cmd?: number;

        /**
         * 来源 - 0：NTC 1：LoRa 2：D2D 3：WT401
         * @default 3
         * @class_type 属性
         */
        origin: 0 | 1 | 2 | 3;

        /**
         * 超时时间
         * @default 10
         * @class_type 属性
         * @max_value 60
         * @min_value 1
         */
        time?: number;

        /**
         * 掉线模式 - 0：保持 1：断开 2：切成内部
         * @default 0
         * @class_type 属性
         */
        value?: 0 | 1 | 2;
    };

    /**
     * 数据同步 - 0:禁用 1:启用
     * @default 0
     * @class_type 属性
     */
    data_sync_to_peer: 0 | 1;

    /**
     * 系统开关 - 0：系统关 1：系统开
     * @default 0
     * @class_type 属性
     */
    system_status: 0 | 1;

    /**
     * 温控模式
     * @class_type 属性
     */
    temperature_control_mode: {
        /**
         * 二级命令ID
         * @default 0
         * @class_type 属性
         */
        cmd?: number;

        /**
         * 模式 - 0：制热 1：紧急制热 2：制冷 3：自动 13：禁用
         * @default 0
         * @class_type 属性
         */
        ctrl_mode: 0 | 1 | 2 | 3 | 13;

        /**
         * 计划温控模式启用 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        plan_enable?: 0 | 1;
    };

    /**
     * 目标温度模式 - 0：单设定点 1：双设定点
     * @default 0
     * @class_type 属性
     */
    target_temperature_mode: 0 | 1;

    /**
     * 目标温度分辨率 - 0：0.5 1：1
     * @default 0
     * @class_type 属性
     */
    target_temperature_resolution: 0 | 1;

    /**
     * 温控等级切换使能
     * @class_type 属性
     */
    temperature_control_level_switch?: {
        /**
         * 二级命令ID
         * @class_type 属性
         */
        cmd?: number;

        /**
         * SetEnable结构
         * @class_type 属性
         */
        set_enable: {
            /**
             * 保留掩码
             * @class_type 属性
             */
            reserved1: number;

            /**
             * setback掩码
             * @class_type 属性
             */
            setback_mask: number;

            /**
             * setforw掩码
             * @class_type 属性
             */
            setforw_mask: number;

            /**
             * 保留置位
             * @class_type 属性
             */
            reserved2: number;

            /**
             * setback - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            setback_value: 0 | 1;

            /**
             * setforw - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            setforw_value: 0 | 1;
        };

        /**
         * 制热切换结构
         * @class_type 属性
         */
        heat: {
            /**
             * 制热切换时间
             * @default 30
             * @class_type 属性
             */
            time: number;

            /**
             * 制热切换温差
             * @default 1
             * @class_type 属性
             * @decimal_digits 1
             */
            temp: number;
        };

        /**
         * 制冷切换结构
         * @class_type 属性
         */
        cool: {
            /**
             * 制冷切换时间
             * @default 30
             * @class_type 属性
             */
            time: number;

            /**
             * 制冷切换温差
             * @default 1
             * @class_type 属性
             * @decimal_digits 1
             */
            temp: number;
        };

        /**
         * 阈值结构
         * @class_type 属性
         */
        threshold: {
            /**
             * 一级阈值
             * @default 3
             * @class_type 属性
             * @decimal_digits 1
             */
            t1: number;

            /**
             * 二级阈值
             * @default 5
             * @class_type 属性
             * @decimal_digits 1
             */
            t2: number;
        };
    };

    /**
     * 模式启用
     * @class_type 属性
     */
    mode_enable?: {
        /**
         * 制热 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        heat: 0 | 1;

        /**
         * 紧急制热 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        em_heat: 0 | 1;

        /**
         * 制冷 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        cool: 0 | 1;

        /**
         * 自动 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        auto: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 目标温度设置
     * @class_type 属性
     */
    target_temperature_settings: {
        /**
         * 温控模式
         * @default 0
         * @class_type 属性
         */
        temperature_control_mode?: number;

        /**
         * 制热温度
         * @default 17
         * @class_type 属性
         * @max_value 35
         * @min_value 10
         */
        heat: number;

        /**
         * 紧急制热温度
         * @default 25
         * @class_type 属性
         * @max_value 35
         * @min_value 10
         */
        em_heat: number;

        /**
         * 制冷温度
         * @default 28
         * @class_type 属性
         * @max_value 35
         * @min_value 10
         */
        cool: number;

        /**
         * 自动温度
         * @default 23
         * @class_type 属性
         * @max_value 35
         * @min_value 10
         */
        auto: number;

        /**
         * 自动制热目标温度
         * @default 17
         * @class_type 属性
         * @max_value 35
         * @min_value 10
         */
        auto_heat: number;

        /**
         * 自动制冷目标温度
         * @default 28
         * @class_type 属性
         * @max_value 35
         * @min_value 10
         */
        auto_cool: number;
    };

    /**
     * 目标温度允差
     * @class_type 属性
     */
    target_temperature_tolerance: {
        /**
         * 目标温度允差ID
         * @default 0
         * @class_type 属性
         */
        id?: number;

        /**
         * 目标温度允差
         * @default 1
         * @class_type 属性
         * @max_value 5
         * @min_value 0.5
         */
        target_value: number;

        /**
         * 温度控制允差
         * @default 2
         * @class_type 属性
         * @max_value 10
         * @min_value 0.5
         */
        ctrl_value: number;

        /**
         * 制热目标温度允差
         * @default 1
         * @class_type 属性
         * @max_value 5
         * @min_value 0.5
         */
        heat_value: number;

        /**
         * 制冷目标温度允差
         * @default 1
         * @class_type 属性
         * @max_value 5
         * @min_value 0.5
         */
        cool_value: number;
    };

    /**
     * 控温除湿设置
     * @class_type 属性
     */
    temperature_control_dehumidification?: {
        /**
         * 控温除湿 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 控温除湿允差
         * @default 1
         * @class_type 属性
         * @max_value 5
         * @min_value 0.1
         * @decimal_digits 1
         */
        temperature_tolerance: number;
    };

    /**
     * 目标温度范围
     * @class_type 属性
     */
    target_temperature_range: {
        /**
         * 目标温度范围ID - 0：制热 1：紧急制热 2：制冷 3：自动
         * @default 0
         * @class_type 属性
         */
        id?: 0 | 1 | 2 | 3;

        /**
         * 制热目标温度范围
         * @class_type 属性
         */
        heat: {
            /**
             * 制热下限值
             * @default 10
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            min: number;

            /**
             * 制热上限值
             * @default 17
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            max: number;
        };

        /**
         * 紧急制热目标温度范围
         * @class_type 属性
         */
        em_heat: {
            /**
             * 紧急制热下限值
             * @default 10
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            min: number;

            /**
             * 紧急制热上限值
             * @default 28
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            max: number;
        };

        /**
         * 制冷目标温度范围
         * @class_type 属性
         */
        cool: {
            /**
             * 制冷下限值
             * @default 23
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            min: number;

            /**
             * 制冷上限值
             * @default 35
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            max: number;
        };

        /**
         * 自动温度范围
         * @class_type 属性
         */
        auto: {
            /**
             * 自动下限值
             * @default 10
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            min: number;

            /**
             * 自动上限值
             * @default 35
             * @class_type 属性
             * @max_value 35
             * @min_value 10
             * @decimal_digits 1
             */
            max: number;
        };
    };

    /**
     * 目标湿度调节范围
     * @class_type 属性
     */
    target_humidity_range: {
        /**
         * 下限值
         * @default 40
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 1
         */
        min: number;

        /**
         * 上限值
         * @default 80
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 1
         */
        max: number;
    };

    /**
     * 风扇模式 - 0：自动 1：通风 2：低速 3：中速 4：高速 13：禁用
     * @default 0
     * @class_type 属性
     */
    fan_control_mode: 0 | 1 | 2 | 3 | 4 | 13;

    /**
     * 风扇通风时间
     * @default 30
     * @class_type 属性
     * @max_value 55
     * @min_value 5
     */
    fan_circulate_setting: number;

    /**
     * 风扇调节湿度 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    fan_regulation_humidity_enable: 0 | 1;

    /**
     * 调节周期
     * @default 30
     * @class_type 属性
     * @max_value 55
     * @min_value 5
     */
    fan_regulation_humidity_period: number;

    /**
     * 风扇延迟关闭设置
     * @class_type 属性
     */
    fan_delay_close: {
        /**
         * 延迟关闭使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 延迟关闭时间
         * @default 60
         * @class_type 属性
         * @max_value 3600
         * @min_value 30
         */
        time: number;
    };

    /**
     * 开窗检测 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    window_opening_detection_enable: 0 | 1;

    /**
     * 开窗检测设置
     * @class_type 属性
     */
    window_opening_detection_settings: {
        /**
         * 开窗检测方式 - 0：温度 1：门磁
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        type: 0 | 1;

        /**
         * 温度检测
         * @class_type 属性
         */
        temperature_detection?: {
            /**
             * 温度变化
             * @default 3
             * @class_type 属性
             * @max_value 10
             * @min_value 1
             * @decimal_digits 1
             */
            difference_in_temperature: number;

            /**
             * 停止时间
             * @default 30
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            stop_time: number;
        };

        /**
         * 门磁检测
         * @class_type 属性
         */
        magnet_detection?: {
            /**
             * 检测持续时间
             * @default 10
             * @class_type 属性
             * @max_value 60
             * @min_value 1
             */
            duration: number;
        };
    };

    /**
     * 滤网清洁提醒
     * @class_type 属性
     */
    filter_clean_remainder: {
        /**
         * 使能 - 0：禁用 1：使能
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 周期
         * @default 90
         * @class_type 属性
         */
        period: number;
    };

    /**
     * 温度阈值告警设置
     * @class_type 属性
     */
    temperature_alarm_settings: {
        /**
         * 温度阈值告警 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 阈值条件 - 0:禁用 1:条件：x<A 2:条件：x>B 4:条件：x<A或x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 4;

        /**
         * 值A
         * @default 0
         * @class_type 属性
         * @max_value 60
         * @min_value -20
         * @decimal_digits 1
         */
        threshold_min: number;

        /**
         * 值B
         * @default 0
         * @class_type 属性
         * @max_value 60
         * @min_value -20
         * @decimal_digits 1
         */
        threshold_max: number;
    };

    /**
     * 持续高温告警设置
     * @class_type 属性
     */
    high_temperature_alarm_settings: {
        /**
         * 持续高温告警 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度差值
         * @default 3
         * @class_type 属性
         * @max_value 10
         * @min_value 1
         * @decimal_digits 1
         */
        difference_in_temperature: number;

        /**
         * 持续时间
         * @default 5
         * @class_type 属性
         * @max_value 60
         * @min_value 0
         */
        duration: number;
    };

    /**
     * 持续低温告警设置
     * @class_type 属性
     */
    low_temperature_alarm_settings: {
        /**
         * 持续低温告警 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度差值
         * @default 3
         * @class_type 属性
         * @max_value 10
         * @min_value 1
         * @decimal_digits 1
         */
        difference_in_temperature: number;

        /**
         * 持续时间
         * @default 5
         * @class_type 属性
         * @max_value 60
         * @min_value 0
         */
        duration: number;
    };

    /**
     * 温度校准设置
     * @class_type 属性
     */
    temperature_calibration_settings: {
        /**
         * 温度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 60
         * @min_value -60
         * @decimal_digits 1
         */
        calibration_value: number;
    };

    /**
     * 湿度校准设置
     * @class_type 属性
     */
    humidity_calibration_settings: {
        /**
         * 湿度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value -100
         * @decimal_digits 1
         */
        calibration_value: number;
    };

    /**
     * 计划配置
     * @class_type 属性
     * @array_length 8
     */
    schedule_settings: {
        /**
         * 计划序号
         * @default 0
         * @class_type 属性
         * @max_value 15
         * @min_value 0
         */
        id: number;

        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 计划使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 命名前5B
         * @class_type 属性
         * @string_length 5
         * @character_encoding ascii
         */
        name_first: string;

        /**
         * 命名后5B
         * @class_type 属性
         * @string_length 5
         * @character_encoding ascii
         */
        name_last: string;

        /**
         * 计划内容
         * @class_type 属性
         */
        content1: {
            /**
             * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动 10：关
             * @default 0
             * @class_type 属性
             */
            tstat_mode: 0 | 1 | 2 | 3 | 10;

            /**
             * 制热目标温度
             * @default 17
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            heat_target_temperature: number;

            /**
             * 紧急制热目标温度
             * @default 25
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            em_heat_target_temperature: number;

            /**
             * 制冷目标温度
             * @default 28
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            cool_target_temperature: number;
        };

        /**
         * 计划内容
         * @class_type 属性
         */
        content2: {
            /**
             * 风扇模式 - 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速 10：关
             * @default 0
             * @class_type 属性
             */
            fan_mode: 0 | 1 | 2 | 3 | 4 | 5 | 10;

            /**
             * 自动目标温度
             * @default 23
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            auto_target_temperature: number;

            /**
             * 自动制热目标温度
             * @default 17
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            auto_heat_target_temperature: number;

            /**
             * 自动制冷目标温度
             * @default 28
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            auto_cool_target_temperature: number;
        };

        /**
         * 计划内容
         * @class_type 属性
         */
        content3: {
            /**
             * 目标温度允差
             * @default 1
             * @class_type 属性
             * @max_value 5
             * @min_value 0.1
             * @decimal_digits 1
             */
            target_temperature_tolerance: number;

            /**
             * 温度控制允差
             * @default 2
             * @class_type 属性
             * @max_value 10
             * @min_value 0.1
             * @decimal_digits 1
             */
            temperature_control_tolerance: number;

            /**
             * 自动制热目标温度允差
             * @default 1
             * @class_type 属性
             * @max_value 5
             * @min_value 0.1
             * @decimal_digits 1
             */
            auto_heat_target_temperature_tolerance: number;

            /**
             * 自动制冷目标温度允差
             * @default 1
             * @class_type 属性
             * @max_value 5
             * @min_value 0.1
             * @decimal_digits 1
             */
            auto_cool_target_temperature_tolerance: number;
        };

        /**
         * 计划内容
         * @class_type 属性
         */
        wait_setting: {
            /**
             * 计划停留使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable?: 0 | 1;

            /**
             * 计划停留时间
             * @default 0
             * @class_type 属性
             */
            time: number;
        };

        /**
         * 时间
         * @class_type 属性
         * @array_length 16
         */
        cycle_settings: {
            /**
             * 时间序号
             * @default 0
             * @class_type 属性
             * @max_value 15
             * @min_value 0
             */
            id?: number;

            /**
             * 使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable: 0 | 1;

            /**
             * 触发时间
             * @default 0
             * @class_type 属性
             */
            execution_time_point: number;

            /**
             * 周日 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sun: 0 | 1;

            /**
             * 周一 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_mon: 0 | 1;

            /**
             * 周二 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_tues: 0 | 1;

            /**
             * 周三 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_wed: 0 | 1;

            /**
             * 周四 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_thu: 0 | 1;

            /**
             * 周五 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_fri: 0 | 1;

            /**
             * 周六 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sat: 0 | 1;

            /**
             * 预留
             * @class_type 属性
             */
            reserved: number;

            /**
             * 有效 - 0：删除 1：有效
             * @default 0
             * @class_type 属性
             */
            valid: 0 | 1;
        }[];
    }[];

    /**
     * 安装设置
     * @class_type 属性
     */
    install_configuration: {
        /**
         * 二级命令 - 0:接线配置 1：换向阀配置 2：联用功能配置 3：风扇控制权配置
         * @default 0
         * @class_type 属性
         */
        type?: 0 | 1 | 2 | 3;

        /**
         * 接线配置
         * @class_type 属性
         */
        wire: {
            /**
             * Y1 - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            y1_connected: 0 | 1;

            /**
             * GH - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            gh_connected: 0 | 1;

            /**
             * O/B - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            ob_connected: 0 | 1;

            /**
             * W1 - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            w1_connected: 0 | 1;

            /**
             * E状态 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            we_connected?: 0 | 1;

            /**
             * DI - 0：无接线 1：接线
             * @default 0
             * @class_type 属性
             */
            di_connected: 0 | 1;

            /**
             * PEK - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            pek_connected?: 0 | 1;

            /**
             * W2/AUX - 0：禁用 1：w2启用 2：aux启用
             * @default 0
             * @class_type 属性
             */
            w2_connected?: 0 | 1 | 2;

            /**
             * Y2/GL - 0：禁用 1：y2启用 2：gl启用
             * @default 2
             * @class_type 属性
             */
            y2_connected: 0 | 1 | 2;

            /**
             * GM - 0:禁用 1:启用
             * @default 1
             * @class_type 属性
             */
            gm_connected: 0 | 1;

            /**
             * NTC - 0:禁用 1:启用
             * @default 0
             * @class_type 属性
             */
            ntc_connected: 0 | 1;

            /**
             * 预留
             * @default 0
             * @class_type 属性
             */
            reserved?: number;
        };

        /**
         * 换向阀结构
         * @class_type 属性
         */
        reversing_valve: {
            /**
             * 换向阀模式 - 0：制冷模式 1：制热模式 2：保持配置
             * @default 0
             * @class_type 属性
             */
            mode: 0 | 1 | 2;
        };

        /**
         * 压缩机结构
         * @class_type 属性
         */
        y_combine_aux: {
            /**
             * 压缩机与辅助控制联用 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable: 0 | 1;
        };

        /**
         * 风扇控制结构
         * @class_type 属性
         */
        fan: {
            /**
             * 风扇控制权限 - 0：恒温器 1：HVAC系统
             * @default 1
             * @class_type 属性
             */
            owner: 0 | 1;
        };
    };

    /**
     * DI设置
     * @class_type 属性
     */
    di_settings: {
        /**
         * 控制对象 - 0：房卡 1：门磁
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        object: 0 | 1;

        /**
         * 房卡
         * @class_type 属性
         */
        card_control?: {
            /**
             * 房卡控制类型 - 0：系统控制 1：插入计划
             * @default 0
             * @class_type 属性
             * @is_one_of
             */
            type: 0 | 1;

            /**
             * 系统控制
             * @class_type 属性
             */
            system_control?: {
                /**
                 * 插卡 - 0：系统关 1：系统开
                 * @default 1
                 * @class_type 属性
                 */
                trigger_by_insertion: 0 | 1;
            };

            /**
             * 插入计划
             * @class_type 属性
             */
            insertion_plan?: {
                /**
                 * 插卡计划类型 - 0：插入计划一 1：插入计划二 2：插入计划三 3：插入计划四 4：插入计划五 5：插入计划六 6：插入计划七 7：插入计划八
                 * @default 0
                 * @class_type 属性
                 */
                trigger_by_insertion: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

                /**
                 * 拔卡计划类型 - 0：插入计划一 1：插入计划二 2：插入计划三 3：插入计划四 4：插入计划五 5：插入计划六 6：插入计划七 7：插入计划八
                 * @default 1
                 * @class_type 属性
                 */
                trigger_by_extraction: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;
            };
        };

        /**
         * 门磁
         * @class_type 属性
         */
        magnet_detection?: {
            /**
             * 门磁类型 - 0：常闭型 1：常开型
             * @default 0
             * @class_type 属性
             */
            magnet_type: 0 | 1;
        };
    };

    /**
     * 防冻保护设置
     * @class_type 属性
     */
    freeze_protection_settings: {
        /**
         * 防冻保护 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 防冻保护目标温度
         * @default 3
         * @class_type 属性
         * @max_value 5
         * @min_value 1
         * @decimal_digits 1
         */
        value: number;
    };

    /**
     * 通讯模式 - 0：BLE+LoRa 1：PowerBus+LoRa
     * @default 0
     * @class_type 属性
     */
    communication_mode: 0 | 1;

    /**
     * 采集周期
     * @class_type 属性
     */
    collection_interval: {
        /**
         * 采集周期 - 0：秒 1：分
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 采集周期
         * @default 30
         * @class_type 属性
         * @max_value 64800
         * @min_value 10
         */
        seconds_of_time?: number;

        /**
         * 采集周期
         * @default 1
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        minutes_of_time?: number;
    };

    /**
     * 上报周期
     * @class_type 属性
     */
    reporting_interval: {
        /**
         * 上报周期类型 - 0：BLE+LORA 1：POWERBUS+LORA
         * @default 0
         * @class_type 属性
         */
        type?: 0 | 1;

        /**
         * BLE_LORA上报周期
         * @class_type 属性
         */
        ble_lora: {
            /**
             * 上报单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * POWERBUS_LORA上报周期
         * @class_type 属性
         */
        power_lora: {
            /**
             * 上报单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            minutes_of_time?: number;
        };
    };

    /**
     * 改变上报 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    change_report_enable?: 0 | 1;

    /**
     * D2D配对启用 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    d2d_pairing_enable: 0 | 1;

    /**
     * D2D配对信息
     * @class_type 属性
     * @array_length 5
     */
    d2d_pairing_settings: {
        /**
         * 序号
         * @default 0
         * @class_type 属性
         * @max_value 4
         * @min_value 0
         */
        index?: number;

        /**
         * 类型
         * @default 0
         * @class_type 属性
         */
        type?: number;

        /**
         * 配对 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 设备id
         * @class_type 属性
         * @string_length 16
         * @character_encoding hex
         */
        deveui: string;

        /**
         * 设备名称前8B
         * @class_type 属性
         * @string_length 8
         * @character_encoding ascii
         */
        name_first: string;

        /**
         * 设备名称后8B
         * @class_type 属性
         * @string_length 8
         * @character_encoding ascii
         */
        name_last: string;
    }[];

    /**
     * D2D主控使能 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    d2d_master_enable: 0 | 1;

    /**
     * D2D主控
     * @class_type 属性
     * @array_length 10
     */
    d2d_master_settings: {
        /**
         * 触发方式 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 16：系统关 17：系统开
         * @default 0
         * @class_type 属性
         */
        trigger_condition: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 16 | 17;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * LoRa上行 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        uplink: 0 | 1;

        /**
         * 控制命令
         * @default 0
         * @class_type 属性
         * @string_length 4
         * @character_encoding hex
         */
        command: string;

        /**
         * 启用控制时间 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        control_time_enable: 0 | 1;

        /**
         * 控制时间
         * @default 5
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        control_time: number;
    }[];

    /**
     * D2D被控使能 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    d2d_slave_enable: 0 | 1;

    /**
     * D2D被控
     * @class_type 属性
     * @array_length 16
     */
    d2d_slave_settings: {
        /**
         * D2D被控序号
         * @default 0
         * @class_type 属性
         * @max_value 15
         * @min_value 0
         */
        index?: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 控制命令
         * @default 0
         * @class_type 属性
         * @string_length 4
         * @character_encoding hex
         */
        command: string;

        /**
         * 被控状态 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 16：系统关 17：系统开
         * @default 16
         * @class_type 属性
         */
        value: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 16 | 17;
    }[];

    /**
     * 系统控制保护
     * @class_type 属性
     */
    system_control_protect: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 时间
         * @default 5
         * @class_type 属性
         */
        time: number;
    };

    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     * @class_type 属性
     */
    time_zone: number;

    /**
     * 夏令时
     * @class_type 属性
     */
    daylight_saving_time: {
        /**
         * 夏令时 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 偏移时间
         * @default 60
         * @class_type 属性
         * @max_value 120
         * @min_value 0
         */
        daylight_saving_time_offset: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 3
         * @class_type 属性
         */
        start_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 2
         * @class_type 属性
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        start_hour_min: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 11
         * @class_type 属性
         */
        end_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 1
         * @class_type 属性
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        end_hour_min: number;
    };

    /**
     * 重传回传设置
     * @class_type 属性
     */
    data_storage_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 存储使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 重传使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        retransmission_enable: 0 | 1;

        /**
         * 重传周期
         * @default 600
         * @class_type 属性
         * @max_value 1200
         * @min_value 30
         */
        retransmission_interval?: number;

        /**
         * 回传周期
         * @default 60
         * @class_type 属性
         * @max_value 1200
         * @min_value 30
         */
        retrieval_interval?: number;
    };

    /**
     * 重置
     * @class_type 服务
     */
    reset?: Record<string, any>;

    /**
     * 重启
     * @class_type 服务
     */
    reboot?: Record<string, any>;

    /**
     * 清除历史记录
     * @class_type 服务
     */
    clear_historical_data?: Record<string, any>;

    /**
     * 停止查询回传
     * @class_type 服务
     */
    stop_historical_data_retrieval?: Record<string, any>;

    /**
     * 回传某个时间点的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time?: {
        /**
         * 时间点
         * @class_type 参数
         */
        time?: number;
    };

    /**
     * 回传某个时间段的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time_range?: {
        /**
         * 起始时间
         * @class_type 参数
         */
        start_time?: number;

        /**
         * 结束时间
         * @class_type 参数
         */
        end_time?: number;
    };

    /**
     * 查询设备状态
     * @class_type 服务
     */
    query_device_status?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    synchronize_time?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    set_time?: {
        /**
         * 时间戳
         * @class_type 参数
         */
        timestamp?: number;
    };

    /**
     * 重新连接网络
     * @class_type 服务
     */
    reconnect?: Record<string, any>;

    /**
     * 删除计划
     * @class_type 服务
     */
    delete_task_plan?: {
        /**
         * 删除计划 - 0：计划一 1：计划二 2：计划三 3：计划四 4：计划五 5：计划六 6：计划七 7：计划八 255：删除全部
         * @default 255
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 255;
    };

    /**
     * 蓝牙配对
     * @class_type 服务
     */
    bluetooth_pairing?: {
        /**
         * 动作 - 0：取消配对 1：重新配对
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 请求获取配置
     * @class_type 服务
     */
    request_device_config?: {
        /**
         * 类型 - 0：计划配置 1：接线配置 2：继电器状态
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2;
    };

    /**
     * 插入临时计划
     * @class_type 服务
     */
    insert_temporary_plan?: {
        /**
         * 计划ID
         * @default 0
         * @class_type 参数
         */
        id?: number;
    };

    /**
     * 滤网清洁提醒
     * @class_type 服务
     */
    filter_clean_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 开窗告警
     * @class_type 服务
     */
    open_window_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 系统状态控制
     * @class_type 服务
     */
    system_status_control?: {
        /**
         * 系统开关 - 0：系统关 1：系统开
         * @default 1
         * @class_type 参数
         */
        on_off?: 0 | 1;

        /**
         * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动 13：禁用
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1 | 2 | 3 | 13;

        /**
         * 制热目标温度
         * @default 17
         * @class_type 参数
         * @decimal_digits 1
         */
        temperature1?: number;

        /**
         * 制冷目标温度
         * @default 28
         * @class_type 参数
         * @decimal_digits 1
         */
        temperature2?: number;
    };

    /**
     * 蓝牙名称
     * @class_type 属性
     * @array_length 32
     * @character_encoding ascii
     */
    ble_name?: string;

    /**
     * 蓝牙配对信息
     * @class_type 属性
     */
    ble_pair_info: {
        /**
         * 地址类型 - 0：公共 1：随机
         * @default 0
         * @class_type 属性
         */
        addr_type: 0 | 1;

        /**
         * 蓝牙地址
         * @class_type 属性
         * @array_length 6
         * @character_encoding hex
         */
        address: string;

        /**
         * 蓝牙名称
         * @class_type 属性
         * @array_length 32
         * @character_encoding ascii
         */
        name: string;
    };
}
