export interface WT102TSLInfo {
    /**
     * 电池电量
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     */
    battery: number;

    /**
     * 温度
     * @class_type 属性
     * @max_value 60
     * @min_value -20
     * @decimal_digits 2
     */
    temperature: number;

    /**
     * 电机行程
     * @class_type 属性
     * @max_value 3028
     * @min_value 0
     */
    motor_total_stroke?: number;

    /**
     * 电机当前位置
     * @class_type 属性
     * @max_value 3028
     * @min_value 0
     */
    motor_position?: number;

    /**
     * 当前阀门开度
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     */
    valve_opening_degree: number;

    /**
     * 电机校准结果
     * @class_type 事件
     */
    motor_calibration_result_report?: {
        /**
         * 电机校准状态 - 0：未校准 1：校准成功 2：校准失败，超电机量程 3：校准失败，温度控制禁用 4：校准失败，设备拆卸
         * @class_type 参数
         */
        status?: 0 | 1 | 2 | 3 | 4;
    };

    /**
     * 目标温度
     * @class_type 属性
     * @max_value 35
     * @min_value 5
     * @decimal_digits 1
     */
    target_temperature: number;

    /**
     * 目标阀门开度
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     */
    target_valve_opening_degree?: number;

    /**
     * 低电量告警
     * @class_type 事件
     */
    low_battery_alarm?: {
        /**
         * 电池电量
         * @class_type 参数
         * @max_value 100
         * @min_value 0
         */
        value?: number;
    };

    /**
     * 温度告警
     * @class_type 事件
     */
    temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 值小于告警解除
         * @class_type 参数
         */
        lower_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 值小于告警
         * @class_type 参数
         */
        lower_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 值大于告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 值大于告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
    };

    /**
     * 防冻保护告警
     * @class_type 事件
     */
    anti_freeze_protection_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 防冻保护解除
         * @class_type 参数
         */
        lifted?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_status?: number;
        };

        /**
         * 防冻保护触发
         * @class_type 参数
         */
        trigger?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_status?: number;
        };
    };

    /**
     * 强制加热告警
     * @class_type 事件
     */
    mandatory_heating_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 退出强制加热
         * @class_type 参数
         */
        exit?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_status?: number;

            /**
             * 电池电量
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            battery_level?: number;
        };

        /**
         * 进入强制加热
         * @class_type 参数
         */
        enter?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_status?: number;

            /**
             * 电池电量
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            battery_level?: number;
        };
    };

    /**
     * 无人节能
     * @class_type 事件
     */
    auto_away_report?: {
        /**
         * 事件类型
         * @class_type 参数
         * @is_one_of
         */
        event_type?: number;

        /**
         * 无人节能释放
         * @class_type 参数
         */
        inactive_by_target_temperature?: {
            /**
             * 占用状态 - 0：非占用 1：占用
             * @class_type 参数
             */
            state?: 0 | 1;

            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 目标温度
             * @class_type 参数
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            target_temperature?: number;
        };

        /**
         * 无人节能触发
         * @class_type 参数
         */
        active_by_target_temperature?: {
            /**
             * 占用状态 - 0：非占用 1：占用
             * @class_type 参数
             */
            state?: 0 | 1;

            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 节能目标温度
             * @class_type 参数
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            target_temperature?: number;
        };

        /**
         * 无人节能释放
         * @class_type 参数
         */
        inactive_by_target_valve_opening?: {
            /**
             * 占用状态 - 0：非占用 1：占用
             * @class_type 参数
             */
            state?: 0 | 1;

            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 目标阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            target_valve_opening?: number;
        };

        /**
         * 无人节能触发
         * @class_type 参数
         */
        active_by_target_valve_opening?: {
            /**
             * 占用状态 - 0：非占用 1：占用
             * @class_type 参数
             */
            state?: 0 | 1;

            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 节能目标阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            target_valve_opening?: number;
        };
    };

    /**
     * 开窗告警
     * @class_type 事件
     */
    window_opening_alarm?: {
        /**
         * 告警类型
         * @default  
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 开窗解除
         * @class_type 参数
         */
        release?: {
            /**
             * 开窗状态 - 0：解除 1：开窗
             * @class_type 参数
             */
            state?: 0 | 1;

            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;
        };

        /**
         * 开窗触发
         * @class_type 参数
         */
        trigger?: {
            /**
             * 开窗状态 - 0：解除 1：开窗
             * @class_type 参数
             */
            state?: 0 | 1;

            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;
        };
    };

    /**
     * 周期上报
     * @class_type 事件
     */
    periodic_reporting?: {
        /**
         * 上报类型
         * @class_type 参数
         * @is_one_of
         */
        report_type?: number;

        /**
         * 非供暖期上报
         * @class_type 参数
         */
        non_heating_season?: {
            /**
             * 目标阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            target_valve_opening?: number;

            /**
             * 电池电量
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            battery_level?: number;
        };

        /**
         * 供暖期目标温度上报
         * @class_type 参数
         */
        target_temperature_for_heating?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_opening?: number;

            /**
             * 目标温度
             * @class_type 参数
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            target_temperature?: number;

            /**
             * 电池电量
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            battery_level?: number;
        };

        /**
         * 供暖期目标阀门开度上报
         * @class_type 参数
         */
        target_valve_opening_for_heating?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_opening?: number;

            /**
             * 目标阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            target_valve_opening?: number;

            /**
             * 电池电量
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            battery_level?: number;
        };

        /**
         * 供暖期综合上报
         * @class_type 参数
         */
        integrated_control_for_heating?: {
            /**
             * 环境温度
             * @class_type 参数
             * @max_value 60
             * @min_value -20
             * @decimal_digits 1
             */
            environment_temperature?: number;

            /**
             * 当前阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            current_valve_opening?: number;

            /**
             * 目标温度
             * @class_type 参数
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            target_temperature?: number;

            /**
             * 目标阀门开度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            target_valve_opening?: number;

            /**
             * 电池电量
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             */
            battery_level?: number;
        };
    };

    /**
     * 随机密钥 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    random_key: 0 | 1;

    /**
     * Auto-P - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    auto_p_enable?: 0 | 1;

    /**
     * 温度单位 - 0：℃ 1：℉
     * @default 0
     * @class_type 属性
     */
    temperature_unit: 0 | 1;

    /**
     * 环境温度来源设置
     * @class_type 属性
     */
    temperature_source_settings: {
        /**
         * 环境温度来源 - 0：内部NTC 1：外部NTC 2：LoRa接收
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        type: 0 | 1 | 2;

        /**
         * 外部NTC接收温度
         * @class_type 属性
         */
        external_ntc_reception?: {
            /**
             * 超时时间
             * @default 30
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            timeout: number;

            /**
             * 外部NTC掉线设置 - 0：保持当前状态控制 1：关闭阀门 2：切换内部NTC控制
             * @default 2
             * @class_type 属性
             */
            timeout_response: 0 | 1 | 2;
        };

        /**
         * LoRa接收温度
         * @class_type 属性
         */
        lorawan_reception?: {
            /**
             * 超时时间
             * @default 30
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            timeout: number;

            /**
             * LoRa接收掉线设置 - 0：保持当前状态控制 1：关闭阀门 2：切换内部NTC控制
             * @default 2
             * @class_type 属性
             */
            timeout_response: 0 | 1 | 2;
        };
    };

    /**
     * 环境温度显示使能 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    environment_temperature_display_enable: 0 | 1;

    /**
     * 供暖期设置
     * @class_type 属性
     */
    heating_period_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 供暖日期
         * @class_type 属性
         */
        heating_date_settings: {
            /**
             * 供暖起始月份
             * @default 1
             * @class_type 属性
             * @max_value 12
             * @min_value 1
             */
            start_mon: number;

            /**
             * 供暖起始日期
             * @default 1
             * @class_type 属性
             * @max_value 31
             * @min_value 1
             */
            start_day: number;

            /**
             * 供暖结束月份
             * @default 12
             * @class_type 属性
             * @max_value 12
             * @min_value 1
             */
            end_mon: number;

            /**
             * 供暖结束日期
             * @default 31
             * @class_type 属性
             * @max_value 31
             * @min_value 1
             */
            end_day: number;
        };

        /**
         * 供暖期上报周期
         * @class_type 属性
         */
        heating_period_reporting_interval: {
            /**
             * 供暖期上报周期单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 供暖期上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 供暖期上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 5
             */
            minutes_of_time?: number;
        };

        /**
         * 非供暖期上报周期
         * @class_type 属性
         */
        non_heating_period_reporting_interval: {
            /**
             * 非供暖期上报周期单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 非供暖期上报周期
             * @default 64800
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 非供暖期上报周期
             * @default 1440
             * @class_type 属性
             * @max_value 1440
             * @min_value 5
             */
            minutes_of_time?: number;
        };

        /**
         * 非供暖期阀门状态配置 - 0：全关 1：全开
         * @default 1
         * @class_type 属性
         */
        valve_status_control: 0 | 1;
    };

    /**
     * 温度控制
     * @class_type 属性
     */
    target_temperature_control_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 温度控制使能 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 目标温度分辨率 - 0：0.5 1：1
         * @default 0
         * @class_type 属性
         */
        target_temperature_resolution: 0 | 1;

        /**
         * 欠温侧死区
         * @default 0.1
         * @class_type 属性
         * @max_value 5
         * @min_value 0.1
         * @decimal_digits 1
         */
        under_temperature_side_deadband?: number;

        /**
         * 超温侧死区
         * @default 0.1
         * @class_type 属性
         * @max_value 5
         * @min_value 0.1
         * @decimal_digits 1
         */
        over_temperature_side_deadband?: number;

        /**
         * 目标温度调节范围最小值
         * @default 5
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         * @decimal_digits 1
         */
        target_temperature_adjustment_range_min: number;

        /**
         * 目标温度调节范围最大值
         * @default 35
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         * @decimal_digits 1
         */
        target_temperature_adjustment_range_max: number;

        /**
         * 温控模式配置
         * @class_type 属性
         */
        mode_settings: {
            /**
             * 温控模式 - 0：温度自动控制模式 1：阀门开度控制模式 2：综合控制模式
             * @default 0
             * @class_type 属性
             * @is_one_of
             */
            mode: 0 | 1 | 2;

            /**
             * 温度自动控制模式
             * @class_type 属性
             */
            auto_control?: {
                /**
                 * 目标温度
                 * @default 19
                 * @class_type 属性
                 * @max_value 35
                 * @min_value 5
                 * @decimal_digits 1
                 */
                target_temperature: number;
            };

            /**
             * 阀门开度控制模式
             * @class_type 属性
             */
            valve_control?: {
                /**
                 * 目标阀门开度
                 * @default 50
                 * @class_type 属性
                 * @max_value 100
                 * @min_value 0
                 */
                target_valve_status: number;
            };

            /**
             * 综合控制模式
             * @class_type 属性
             */
            intergrated_control?: {
                /**
                 * 目标温度
                 * @default 19
                 * @class_type 属性
                 * @max_value 35
                 * @min_value 5
                 * @decimal_digits 1
                 */
                target_temperature: number;
            };
        };
    };

    /**
     * 开窗检测
     * @class_type 属性
     */
    window_opening_detection_settings: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 降温速度
         * @default 3
         * @class_type 属性
         * @max_value 10
         * @min_value 2
         * @decimal_digits 1
         */
        cooling_rate: number;

        /**
         * 开窗阀门状态 - 0：保持不变 1：关闭阀门
         * @default 0
         * @class_type 属性
         */
        valve_status: 0 | 1;

        /**
         * 停止调温时间
         * @default 30
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        stop_temperature_control_time: number;
    };

    /**
     * 无人节能
     * @class_type 属性
     */
    auto_away_settings: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 开始时间
         * @default 0
         * @class_type 属性
         * @max_value 1439
         * @min_value 0
         */
        start_time: number;

        /**
         * 结束时间
         * @default 0
         * @class_type 属性
         * @max_value 1439
         * @min_value 0
         */
        end_time: number;

        /**
         * 周日 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_sun: 0 | 1;

        /**
         * 周一 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_mon: 0 | 1;

        /**
         * 周二 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_tues: 0 | 1;

        /**
         * 周三 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_wed: 0 | 1;

        /**
         * 周四 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_thur: 0 | 1;

        /**
         * 周五 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_fri: 0 | 1;

        /**
         * 周六 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        cycle_time_sat: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;

        /**
         * 节能设置
         * @class_type 属性
         */
        energy_saving_settings: {
            /**
             * 节能设置 - 0：节能温度 1：节能阀门开度
             * @default 0
             * @class_type 属性
             * @is_one_of
             */
            mode: 0 | 1;

            /**
             * 节能温度
             * @default 19
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            energy_saving_temperature?: number;

            /**
             * 节能阀门开度
             * @default 50
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             */
            energy_saving_valve_opening_degree?: number;
        };
    };

    /**
     * 防冻保护
     * @class_type 属性
     */
    anti_freeze_protection_setting: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 防冻温度
         * @default 3
         * @class_type 属性
         * @max_value 5
         * @min_value 1
         * @decimal_digits 1
         */
        temperature_value: number;
    };

    /**
     * 强制加热功能使能 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    mandatory_heating_enable: 0 | 1;

    /**
     * 儿童锁
     * @class_type 属性
     */
    child_lock: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 开关机 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        system_button: 0 | 1;

        /**
         * +/- - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        func_button: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 电机有效行程比例
     * @default 100
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     */
    motor_stroke_limit: number;

    /**
     * 温度校准
     * @class_type 属性
     */
    temperature_calibration_settings: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度校准值
         * @default 0
         * @class_type 属性
         * @max_value 60
         * @min_value -60
         * @decimal_digits 1
         */
        calibration_value: number;
    };

    /**
     * 温度阈值告警
     * @class_type 属性
     */
    temperature_alarm_settings: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 告警模式 - 0:禁用 1:条件：x<A 2:条件：x>B 4:条件：x<A或x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 4;

        /**
         * 低温阈值
         * @default 0
         * @class_type 属性
         * @max_value 60
         * @min_value -20
         * @decimal_digits 1
         */
        threshold_min: number;

        /**
         * 高温阈值
         * @default 0
         * @class_type 属性
         * @max_value 60
         * @min_value -20
         * @decimal_digits 1
         */
        threshold_max: number;
    };

    /**
     * 计划设置
     * @class_type 属性
     * @array_length 16
     */
    schedule_settings: {
        /**
         * 计划序号
         * @default 0
         * @class_type 属性
         * @max_value 15
         * @min_value 0
         */
        id: number;

        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 计划使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 开始时间
         * @default 0
         * @class_type 属性
         */
        start_time: number;

        /**
         * 计划重复周期
         * @class_type 属性
         */
        cycle_settings: {
            /**
             * 周日 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sun: 0 | 1;

            /**
             * 周一 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_mon: 0 | 1;

            /**
             * 周二 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_tues: 0 | 1;

            /**
             * 周三 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_wed: 0 | 1;

            /**
             * 周四 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_thur: 0 | 1;

            /**
             * 周五 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_fri: 0 | 1;

            /**
             * 周六 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sat: 0 | 1;

            /**
             * 预留
             * @class_type 属性
             */
            reserved: number;
        };

        /**
         * 温控模式 - 0：温度自动控制模式 1：阀门开度控制模式 2：综合控制模式
         * @default 0
         * @class_type 属性
         */
        temperature_control_mode: 0 | 1 | 2;

        /**
         * 目标温度
         * @default 19
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         * @decimal_digits 1
         */
        target_temperature: number;

        /**
         * 目标阀门开度
         * @default 50
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         */
        target_valve_status: number;

        /**
         * 提前预热使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        pre_heating_enable: 0 | 1;

        /**
         * 提前预热模式 - 0：自动 1：手动
         * @default 0
         * @class_type 属性
         */
        pre_heating_mode: 0 | 1;

        /**
         * 手动预热时长
         * @default 10
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        pre_heating_manual_time: number;

        /**
         * 上报周期
         * @default 10
         * @class_type 属性
         * @max_value 1440
         * @min_value 5
         */
        report_cycle: number;
    }[];

    /**
     * 本地修改上报 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    change_report_enable?: 0 | 1;

    /**
     * 电机可控距离
     * @class_type 属性
     */
    motor_controllable_range?: {
        /**
         * 电机可控距离使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 电机可控距离
         * @default 666
         * @class_type 属性
         * @max_value 666
         * @min_value 0
         * @decimal_digits 2
         */
        distance: number;
    };

    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     * @class_type 属性
     */
    time_zone: number;

    /**
     * 夏令时
     * @class_type 属性
     */
    daylight_saving_time: {
        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 偏移时间
         * @default 60
         * @class_type 属性
         * @max_value 120
         * @min_value 1
         */
        daylight_saving_time_offset: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         */
        start_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        start_hour_min: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         */
        end_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        end_hour_min: number;
    };

    /**
     * 数据存储设置
     * @class_type 属性
     */
    data_storage_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 数据存储使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 数据重传使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        retransmission_enable: 0 | 1;

        /**
         * 数据重传周期
         * @default 600
         * @class_type 属性
         * @max_value 1200
         * @min_value 30
         */
        retransmission_interval?: number;

        /**
         * 数据回传周期
         * @default 60
         * @class_type 属性
         * @max_value 1200
         * @min_value 30
         */
        retrieval_interval?: number;
    };

    /**
     * 重新连接网络
     * @class_type 服务
     */
    reconnect?: Record<string, any>;

    /**
     * 设备状态查询
     * @class_type 服务
     */
    query_device_status?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    synchronize_time?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    set_time?: {
        /**
         * 时间戳
         * @class_type 参数
         */
        timestamp?: number;
    };

    /**
     * 数据采集
     * @class_type 服务
     */
    collect_data?: Record<string, any>;

    /**
     * 清除历史记录
     * @class_type 服务
     */
    clear_historical_data?: Record<string, any>;

    /**
     * 停止查询回传
     * @class_type 服务
     */
    stop_historical_data_retrieval?: Record<string, any>;

    /**
     * 回传某个时间段的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time_range?: {
        /**
         * 起始时间
         * @class_type 参数
         */
        start_time?: number;

        /**
         * 结束时间
         * @class_type 参数
         */
        end_time?: number;
    };

    /**
     * 回传某个时间点的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time?: {
        /**
         * 时间点
         * @class_type 参数
         */
        time?: number;
    };

    /**
     * 电机行程和位置查询
     * @class_type 服务
     */
    query_motor_stroke_position?: Record<string, any>;

    /**
     * 电机校准
     * @class_type 服务
     */
    calibrate_motor?: Record<string, any>;

    /**
     * 目标阀门开度设置
     * @class_type 服务
     */
    set_target_valve_opening_degree?: {
        /**
         * 目标阀门开度
         * @default 0
         * @class_type 参数
         * @max_value 100
         * @min_value 0
         */
        value?: number;
    };

    /**
     * 目标温度设置
     * @class_type 服务
     */
    set_target_temperature?: {
        /**
         * 温度值
         * @default 0
         * @class_type 参数
         * @max_value 35
         * @min_value 5
         * @decimal_digits 1
         */
        value?: number;
    };

    /**
     * LoRa接收温度
     * @class_type 服务
     */
    set_temperature?: {
        /**
         * 温度值
         * @default 0
         * @class_type 参数
         * @max_value 60
         * @min_value -20
         * @decimal_digits 1
         */
        value?: number;
    };

    /**
     * 占用状态设置
     * @class_type 服务
     */
    set_occupancy_state?: {
        /**
         * 占用状态 - 0：非占用 1：占用
         * @default 0
         * @class_type 参数
         */
        state?: 0 | 1;
    };

    /**
     * 开窗状态设置
     * @class_type 服务
     */
    set_opening_window?: {
        /**
         * 开窗状态 - 0：解除 1：开窗
         * @default 0
         * @class_type 参数
         */
        state?: 0 | 1;
    };

    /**
     * 删除计划
     * @class_type 服务
     */
    delete_schedule?: {
        /**
         * 选择计划 - 0：计划一 1：计划二 2：计划三 3：计划四 4：计划五 5：计划六 6：计划七 7：计划八 8：计划九 9：计划十 10：计划十一 11：计划十二 12：计划十三 13：计划十四 14：计划十五 15：计划十六 255：全部重置
         * @default 255
         * @class_type 参数
         */
        type?: number;
    };

    /**
     * 重置
     * @class_type 服务
     */
    reset?: Record<string, any>;

    /**
     * 重启
     * @class_type 服务
     */
    reboot?: Record<string, any>;

    /**
     * 命令查询
     * @class_type 服务
     */
    request_command_queries?: {
        /**
         * 查询信息
         * @class_type 参数
         */
        query_information?: number;

        /**
         * 命令长度
         * @default 1
         * @class_type 参数
         * @max_value 15
         * @min_value 1
         */
        length?: number;

        /**
         * 所查询的命令 - 0XDA:产品版本 0X00:电池电量 0X02:电机行程 0X04:当前阀门开度 0X60:温度单位 0X61:环境温度来源设置 0X62:环境温度显示使能 0X6300:供暖日期设置 0X6301:供暖期上报周期 0X6302:非供暖期上报周期 0X6303:非供暖期阀门状态配置 0X6500:温度控制使能 0X6501:目标温度分辨率 0X6504:目标温度调节范围最小值 0X6505:目标温度调节范围最大值 0X6506:温控模式配置 0X66:开窗检测 0X68:防冻保护 0X69:强制加热功能使能 0X6A:儿童锁 0X6B:电机有效行程比例 0X6C:温度校准 0X6D:温度阈值告警 0X6E00:计划使能 0X6E01:计划开始时间 0X6E02:计划重复周期 0X6E03:计划温控模式 0X6E04:计划目标温度 0X6E05:计划目标阀门开度 0X6E09:计划上报周期 0X6F:本地修改上报 0XC7:时区 0XC6:夏令时 0XC500:数据存储使能 0XC501:数据重传使能 0XC502:数据重传周期 0XC503:数据回传周期
         * @class_type 参数
         * @character_encoding hex
         */
        object_command?: string;
    };
}
