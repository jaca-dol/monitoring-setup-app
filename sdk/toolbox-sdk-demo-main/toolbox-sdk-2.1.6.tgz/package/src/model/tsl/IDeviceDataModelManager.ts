import { DeviceInfo } from '../deviceInfo/DeviceInfo';

import { ModelData, DataType, IDeviceDataModel } from './IDeviceDataModel';

export type DataModelConstructor<Data extends ModelData = ModelData> = new () => IDeviceDataModel<Data>;

/**
 * 设备数据模型管理器
 */
export interface IDeviceDataModelManager {
	/**
	 * 注册设备数据模型
	 */
	register(name: string, constructor: DataModelConstructor): void;

	/**
	 * 获取设备数据模型
	 */
	get(name: string): IDeviceDataModel;

	/**
	 * 从数据中加载，生成模型实例
	 */
	load(data: ModelData, dataType: DataType, context?: Record<string, any>): IDeviceDataModel;

	/**
	 * 从设备信息中加载，生成模型实例
	 */
	loadDeviceInfo(info: DeviceInfo, dataType: DataType, context?: Record<string, any>): IDeviceDataModel;
}