export interface TS601_L0DLATSLInfo {
    /**
     * 电池电量
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     */
    battery: number;

    /**
     * 传感器ID
     * @class_type 属性
     */
    sensor_id?: {
        /**
         * 传感器类型 - 0: 无探针 1: PT100 2: SHT41      3: DS18B20
         * @default 0
         * @class_type 属性
         */
        type: 0 | 1 | 2 | 3;

        /**
         * 传感器ID
         * @class_type 属性
         * @string_length 16
         * @character_encoding hex
         */
        id: string;
    };

    /**
     * 温度
     * @class_type 属性
     * @max_value 800
     * @min_value -200
     * @decimal_digits 1
     */
    temperature: number;

    /**
     * 湿度
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     * @decimal_digits 1
     */
    humidity: number;

    /**
     * 基站定位
     * @class_type 属性
     */
    base_station_position: {
        /**
         * 纬度
         * @class_type 属性
         * @max_value 90
         * @min_value -90
         * @decimal_digits 6
         */
        latitude: number;

        /**
         * 经度
         * @class_type 属性
         * @max_value 180
         * @min_value -180
         * @decimal_digits 6
         */
        longitude: number;
    };

    /**
     * 飞行模式状态 - 0：退出飞行模式状态  1：进入飞行模式状态
     * @default 0
     * @class_type 属性
     */
    airplane_mode_state: 0 | 1;

    /**
     * 温度报警类型 - 0：采集错误 1：超量程下限 2：超量程上限 3：无数据 16：温度值小于告警解除 17：温度值小于告警 18：温度值大于告警解除 19：温度值大于告警 20：温度值介于告警解除 21：温度值介于告警 22：温度值之外告警解除 23：温度值之外告警 48：温度突变阈值告警 32：突变阈值告警
     * @default 3
     * @class_type 属性
     */
    temperature_alarm_types?: number;

    /**
     * 电量告警
     * @class_type 事件
     */
    battery_alarm?: {
        /**
         * 电量告警类型
         * @class_type 参数
         */
        type?: number;

        /**
         * 低电量告警
         * @class_type 参数
         */
        lower_battery_alarm?: {
            /**
             * 低电量
             * @class_type 参数
             */
            battery?: number;
        };
    };

    /**
     * 温度告警
     * @class_type 事件
     */
    temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;

        /**
         * 温度值小于告警解除
         * @class_type 参数
         */
        lower_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值小于告警
         * @class_type 参数
         */
        lower_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值大于告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值大于告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值介于告警解除
         * @class_type 参数
         */
        within_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值介于告警
         * @class_type 参数
         */
        within_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值之外告警解除
         * @class_type 参数
         */
        exceed_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度值之外告警
         * @class_type 参数
         */
        exceed_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 温度突变阈值告警
         * @class_type 参数
         */
        mutation_alarm_trigger_no_mutation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;
        };

        /**
         * 突变阈值告警
         * @class_type 参数
         */
        mutation_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            temperature?: number;

            /**
             * 突变温度
             * @class_type 参数
             * @max_value 800
             * @min_value -200
             * @decimal_digits 1
             */
            saltation?: number;
        };
    };

    /**
     * 湿度报警类型 - 0：采集错误 1：超量程下限 2：超量程上限 3：无数据 16：湿度值小于告警解除 17：湿度值小于告警 18：湿度值大于告警解除 19：湿度值大于告警 20：湿度值介于告警解除 21：湿度值介于告警 22：湿度值之外告警解除 23：湿度值之外告警 48：湿度突变阈值告警 32：突变阈值告警
     * @default 3
     * @class_type 属性
     */
    humidity_alarm_types?: number;

    /**
     * 湿度告警
     * @class_type 事件
     */
    humidity_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;

        /**
         * 湿度值小于告警解除
         * @class_type 参数
         */
        lower_range_alarm_deactivation?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值小于告警
         * @class_type 参数
         */
        lower_range_alarm_trigger?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值大于告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值大于告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值介于告警解除
         * @class_type 参数
         */
        within_range_alarm_deactivation?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值介于告警
         * @class_type 参数
         */
        within_range_alarm_trigger?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值之外告警解除
         * @class_type 参数
         */
        exceed_range_alarm_deactivation?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度值之外告警
         * @class_type 参数
         */
        exceed_range_alarm_trigger?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 湿度突变阈值告警
         * @class_type 参数
         */
        mutation_alarm_trigger_no_mutation?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;
        };

        /**
         * 突变阈值告警
         * @class_type 参数
         */
        mutation_alarm_trigger?: {
            /**
             * 湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            humidity?: number;

            /**
             * 突变湿度
             * @class_type 参数
             * @max_value 100
             * @min_value 0
             * @decimal_digits 1
             */
            saltation?: number;
        };
    };

    /**
     * 倾斜告警报警类型 - 0：采集错误 1：超量程下限 2：超量程上限 3：无数据 16：倾斜告警解除 17：倾斜告警触发 33：跌落告警
     * @default 3
     * @class_type 属性
     */
    tilt_alarm_types?: 0 | 1 | 2 | 3 | 16 | 17 | 33;

    /**
     * 设备倾斜告警
     * @class_type 事件
     */
    tilt_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;

        /**
         * 倾斜告警解除
         * @class_type 参数
         */
        threshold_alarm_deactivation?: Record<string, any>;

        /**
         * 倾斜告警触发
         * @class_type 参数
         */
        threshold_alarm_trigger?: Record<string, any>;

        /**
         * 跌落告警
         * @class_type 参数
         */
        falling_alarm_trigger?: Record<string, any>;
    };

    /**
     * 光照告警报警类型 - 0：采集错误 1：超量程下限 2：超量程上限 3：无数据 16：光照由亮变暗 17：光照由暗变亮
     * @default 3
     * @class_type 属性
     */
    light_alarm_types?: 0 | 1 | 2 | 3 | 16 | 17;

    /**
     * 光照告警
     * @class_type 事件
     */
    light_alarm?: {
        /**
         * 光照告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;

        /**
         * 光照由亮变暗
         * @class_type 参数
         */
        threshold_alarm_deactivation?: Record<string, any>;

        /**
         * 光照由暗变亮
         * @class_type 参数
         */
        threshold_alarm_trigger?: Record<string, any>;
    };

    /**
     * 探针连接状态告警 - 0：未连接 1：已连接
     * @class_type 属性
     */
    probe_connect_status?: 0 | 1;

    /**
     * 获取相对初始面角度值
     * @class_type 属性
     */
    relative_surface_info: {
        /**
         * X轴角度
         * @class_type 属性
         * @max_value 90
         * @min_value -90
         * @decimal_digits 2
         */
        angle_x: number;

        /**
         * Y轴角度
         * @class_type 属性
         * @max_value 90
         * @min_value -90
         * @decimal_digits 2
         */
        angle_y: number;

        /**
         * Z轴角度
         * @class_type 属性
         * @max_value 90
         * @min_value -90
         * @decimal_digits 2
         */
        angle_z: number;
    };

    /**
     * 上报包类型 - 0：正常周期包 1：按键产生的周期包
     * @class_type 属性
     */
    report_package_type: 0 | 1;

    /**
     * 文件传输
     * @class_type 属性
     */
    request_root_file_transfer?: {
        /**
         * 文件传输操作类型 - 0：写入文件 1：擦除文件
         * @default 0
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        operate_type: 0 | 1;

        /**
         * 证书类型 - 3：AWS  4：MQTT
         * @default 4
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        cert_type: 3 | 4;

        /**
         * 传输长度
         * @default 1
         * @class_type 属性
         * @max_value 4088
         * @min_value 1
         */
        length: number;

        /**
         * 文件内容
         * @class_type 属性
         * @string_length 4088
         * @character_encoding utf8
         */
        data: string;
    };

    /**
     * 文件传输
     * @class_type 属性
     */
    request_dev_file_transfer?: {
        /**
         * 文件传输操作类型 - 0：写入文件 1：擦除文件
         * @default 0
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        operate_type: 0 | 1;

        /**
         * 证书类型 - 3：AWS  4：MQTT
         * @default 4
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        cert_type: 3 | 4;

        /**
         * 传输长度
         * @default 1
         * @class_type 属性
         * @max_value 4088
         * @min_value 1
         */
        length: number;

        /**
         * 文件内容
         * @class_type 属性
         * @string_length 4088
         * @character_encoding utf8
         */
        data: string;
    };

    /**
     * 文件传输
     * @class_type 属性
     */
    request_private_file_transfer?: {
        /**
         * 文件传输操作类型 - 0：写入文件 1：擦除文件
         * @default 0
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        operate_type: 0 | 1;

        /**
         * 证书类型 - 3：AWS  4：MQTT
         * @default 4
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        cert_type: 3 | 4;

        /**
         * 传输长度
         * @default 1
         * @class_type 属性
         * @max_value 4088
         * @min_value 1
         */
        length: number;

        /**
         * 文件内容
         * @class_type 属性
         * @string_length 4088
         * @character_encoding utf8
         */
        data: string;
    };

    /**
     * AT指令调试
     * @class_type 服务
     */
    debugging_commands?: {
        /**
         * 指令长度
         * @default 1
         * @class_type 参数
         * @max_value 65535
         * @min_value 1
         */
        length?: number;

        /**
         * 指令数据内容
         * @class_type 参数
         * @string_length 65535
         * @character_encoding ascii
         */
        content?: string;
    };

    /**
     * 上报周期
     * @class_type 属性
     */
    reporting_interval: {
        /**
         * 上报单位 - 0：秒 1：分
         * @default 1
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 上报周期
         * @default 1800
         * @class_type 属性
         */
        seconds_of_time?: number;

        /**
         * 上报周期
         * @default 30
         * @class_type 属性
         */
        minutes_of_time?: number;
    };

    /**
     * 累计次数
     * @default 8
     * @class_type 属性
     * @max_value 20
     * @min_value 1
     */
    cumulative_times: number;

    /**
     * 采集周期
     * @class_type 属性
     */
    collection_interval: {
        /**
         * 采集周期单位 - 0：秒 1：分
         * @default 1
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 采集周期
         * @default 900
         * @class_type 属性
         * @max_value 64800
         * @min_value 10
         */
        seconds_of_time?: number;

        /**
         * 采集周期
         * @default 15
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        minutes_of_time?: number;
    };

    /**
     * 告警次数
     * @default 1
     * @class_type 属性
     * @max_value 1000
     * @min_value 1
     */
    alarm_reporting_times: number;

    /**
     * 阈值告警解除 - 0: 禁用 1: 启用
     * @default 0
     * @class_type 属性
     */
    alarm_deactivation_enable: 0 | 1;

    /**
     * 温度单位切换 - 0：℃ 1：℉
     * @default 0
     * @class_type 属性
     */
    temperature_unit: 0 | 1;

    /**
     * AutoP使能 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    auto_p_enable: 0 | 1;

    /**
     * 基站定位 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    base_station_position_enable: 0 | 1;

    /**
     * 定位鉴权令牌
     * @class_type 属性
     * @string_length 16
     * @character_encoding ascii
     */
    base_station_position_auth_token: string;

    /**
     * 飞行模式时间段
     * @class_type 属性
     */
    airplane_mode_time_period_settings: {
        /**
         * 子命令
         * @class_type 属性
         */
        command?: number;

        /**
         * 飞行模式 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 开始时间
         * @class_type 属性
         */
        start_timestamp: {
            /**
             * 开始年
             * @default 0
             * @class_type 属性
             * @max_value 255
             * @min_value 0
             */
            year: number;

            /**
             * 开始月
             * @default 1
             * @class_type 属性
             * @max_value 12
             * @min_value 1
             */
            month: number;

            /**
             * 开始日
             * @default 1
             * @class_type 属性
             * @max_value 31
             * @min_value 1
             */
            day: number;

            /**
             * 开始时
             * @default 0
             * @class_type 属性
             * @max_value 23
             * @min_value 0
             */
            hour: number;

            /**
             * 开始分
             * @default 0
             * @class_type 属性
             * @max_value 59
             * @min_value 0
             */
            minute: number;

            /**
             * 开始秒
             * @default 0
             * @class_type 属性
             * @max_value 59
             * @min_value 0
             */
            second: number;
        };

        /**
         * 结束时间
         * @class_type 属性
         */
        end_timestamp: {
            /**
             * 结束年
             * @default 0
             * @class_type 属性
             * @max_value 255
             * @min_value 0
             */
            year: number;

            /**
             * 结束月
             * @default 1
             * @class_type 属性
             * @max_value 12
             * @min_value 1
             */
            month: number;

            /**
             * 结束日
             * @default 1
             * @class_type 属性
             * @max_value 31
             * @min_value 1
             */
            day: number;

            /**
             * 结束时
             * @default 0
             * @class_type 属性
             * @max_value 23
             * @min_value 0
             */
            hour: number;

            /**
             * 结束分
             * @default 0
             * @class_type 属性
             * @max_value 59
             * @min_value 0
             */
            minute: number;

            /**
             * 结束秒
             * @default 0
             * @class_type 属性
             * @max_value 59
             * @min_value 0
             */
            second: number;
        };
    };

    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     * @class_type 属性
     */
    time_zone: number;

    /**
     * 夏令时
     * @class_type 属性
     */
    daylight_saving_time: {
        /**
         * 夏令时 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 偏移时间
         * @default 60
         * @class_type 属性
         * @max_value 120
         * @min_value 1
         */
        daylight_saving_time_offset: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         */
        start_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        start_hour_min: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         */
        end_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        end_hour_min: number;
    };

    /**
     * 数据存储设置
     * @class_type 属性
     */
    data_storage_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 数据存储 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 数据重传 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        retransmission_enable: 0 | 1;

        /**
         * 重传周期
         * @default 600
         * @class_type 属性
         * @max_value 1200
         * @min_value 30
         */
        retransmission_interval: number;

        /**
         * 回传周期
         * @default 60
         * @class_type 属性
         * @max_value 1200
         * @min_value 30
         */
        retrieval_interval?: number;
    };

    /**
     * 按键锁
     * @class_type 属性
     */
    button_lock: {
        /**
         * 使能 - 0: 禁用 1: 启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 关机 - 0: 禁用锁关机 1: 启用锁关机
         * @default 1
         * @class_type 属性
         */
        power_off_enable: 0 | 1;

        /**
         * 采集上报 - 0: 禁用锁采集上报 1: 启用锁采集上报
         * @default 0
         * @class_type 属性
         */
        collect_report_enable: 0 | 1;

        /**
         * 预留 - 0: 禁用锁采集上报 1: 启用锁采集上报
         * @default 0
         * @class_type 属性
         */
        reserve: 0 | 1;
    };

    /**
     * 温度阈值告警配置
     * @class_type 属性
     */
    temperature_alarm_settings: {
        /**
         * 温度阈值告警 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 阈值条件 - 0:禁用 1:条件：x<A 2:条件：x>B 3:条件：A<x<B 4:条件：x<A或x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;

        /**
         * 值A
         * @default 0
         * @class_type 属性
         * @max_value 800
         * @min_value -200
         * @decimal_digits 1
         */
        threshold_min: number;

        /**
         * 值B
         * @default 0
         * @class_type 属性
         * @max_value 800
         * @min_value -200
         * @decimal_digits 1
         */
        threshold_max: number;
    };

    /**
     * 温度突变阈值
     * @class_type 属性
     */
    temperature_mutation_alarm_settings: {
        /**
         * 温度突变阈值 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度突变值大于
         * @default 10
         * @class_type 属性
         * @max_value 100
         * @min_value 0.1
         * @decimal_digits 1
         */
        mutation_max: number;
    };

    /**
     * 湿度阈值告警
     * @class_type 属性
     */
    humidity_alarm_settings: {
        /**
         * 湿度阈值告警 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 阈值条件 - 0:禁用 1:条件：x<A 2:条件：x>B 3:条件：A<x<B 4:条件：x<A或x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;

        /**
         * 值A
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 1
         */
        threshold_min: number;

        /**
         * 值B
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 1
         */
        threshold_max: number;
    };

    /**
     * 湿度突变告警配置
     * @class_type 属性
     */
    humidity_mutation_alarm_settings: {
        /**
         * 湿度突变阈值 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 湿度突变值大于
         * @default 10
         * @class_type 属性
         * @max_value 100
         * @min_value 0.1
         * @decimal_digits 1
         */
        mutation_max: number;
    };

    /**
     * 温度数值校准
     * @class_type 属性
     */
    temperature_calibration_settings: {
        /**
         * 校准使能 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 1000
         * @min_value -1000
         * @decimal_digits 1
         */
        calibration_value: number;
    };

    /**
     * 湿度数值校准
     * @class_type 属性
     */
    humidity_calibration_settings: {
        /**
         * 校准使能 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value -100
         * @decimal_digits 1
         */
        calibration_value: number;
    };

    /**
     * 光照采集周期
     * @class_type 属性
     */
    light_collection_interval: {
        /**
         * 光照采集周期单位 - 0：秒 1：分
         * @default 1
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 光照采集周期值(秒)
         * @default 60
         * @class_type 属性
         * @max_value 64800
         * @min_value 10
         */
        seconds_of_time?: number;

        /**
         * 光照采集周期值(分)
         * @default 1
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        minutes_of_time?: number;
    };

    /**
     * 光照阈值告警配置
     * @class_type 属性
     */
    light_alarm_settings: {
        /**
         * 阈值告警使能 - 0: 禁用 1: 启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 阈值条件 - 0:禁用 2:条件：x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 2;

        /**
         * 告警阈值
         * @default 10
         * @class_type 属性
         * @max_value 600
         * @min_value 0
         */
        threshold_max: number;
    };

    /**
     * 光照抖动阈值
     * @default 5
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     */
    light_tolerance_value?: number;

    /**
     * 倾斜阈值告警配置
     * @class_type 属性
     */
    tilt_alarm_settings: {
        /**
         * 阈值告警使能 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 阈值条件 - 0:禁用 2:条件：x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 2;

        /**
         * 告警阈值
         * @default 20
         * @class_type 属性
         * @max_value 90
         * @min_value 1
         */
        threshold_max: number;

        /**
         * 持续时间
         * @default 10
         * @class_type 属性
         * @max_value 60
         * @min_value 1
         */
        duration: number;
    };

    /**
     * 跌落告警配置
     * @class_type 属性
     */
    falling_alarm_settings: {
        /**
         * 跌落检测使能 - 0: 禁用 1: 启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
    };

    /**
     * 跌落告警配置
     * @class_type 属性
     */
    falling_threshold_alarm_settings: {
        /**
         * 跌落加速度阈值 - 0: FREE_FALL_LEVEL_156 1: FREE_FALL_LEVEL_219 2: FREE_FALL_LEVEL_250 3: FREE_FALL_LEVEL_312 4: FREE_FALL_LEVEL_344 5: FREE_FALL_LEVEL_406 6: FREE_FALL_LEVEL_469 7: FREE_FALL_LEVEL_500 
         * @default 7
         * @class_type 属性
         */
        threshold_level: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 跌落持续时间等级
         * @default 32
         * @class_type 属性
         * @max_value 32
         * @min_value 1
         */
        time_level: number;
    };

    /**
     * 探针ID重传次数
     * @default 1
     * @class_type 属性
     * @max_value 10
     * @min_value 1
     */
    probe_id_retransmit_count?: number;

    /**
     * 重置
     * @class_type 服务
     */
    reset?: Record<string, any>;

    /**
     * 重启
     * @class_type 服务
     */
    reboot?: Record<string, any>;

    /**
     * 清除历史记录
     * @class_type 服务
     */
    clear_historical_data?: Record<string, any>;

    /**
     * 停止查询回传
     * @class_type 服务
     */
    stop_historical_data_retrieval?: Record<string, any>;

    /**
     * 回传某个时间点的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time?: {
        /**
         * 时间点
         * @class_type 参数
         */
        time?: number;
    };

    /**
     * 回传某个时间段的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time_range?: {
        /**
         * 起始时间
         * @class_type 参数
         */
        start_time?: number;

        /**
         * 结束时间
         * @class_type 参数
         */
        end_time?: number;
    };

    /**
     * 立即采集上报
     * @class_type 服务
     */
    query_device_status?: Record<string, any>;

    /**
     * 请求时间同步
     * @class_type 服务
     */
    synchronize_time?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    set_time?: {
        /**
         * 时间戳
         * @class_type 参数
         */
        timestamp?: number;
    };

    /**
     * 清除告警图标
     * @class_type 服务
     */
    clear_alarm_item?: Record<string, any>;

    /**
     * 零点校准
     * @class_type 服务
     */
    set_zero_calibration?: {
        /**
         * 零点校准 - 0:清除零点校准 1:进行零点校准
         * @default 1
         * @class_type 参数
         */
        operation?: 0 | 1;
    };

    /**
     * 设置相对初始面
     * @class_type 服务
     */
    set_retrieval_initial_surface?: {
        /**
         * 设置相对初始面 - 0:恢复以水平面作为相对初始面  1:以当前XY所在平面设置为相对初始面
         * @class_type 参数
         */
        operation?: 0 | 1;
    };

    /**
     * 获取传感器ID
     * @class_type 服务
     */
    get_sensor_id?: Record<string, any>;

    /**
     * 设备屏幕温湿度显示切换
     * @class_type 服务
     */
    temperature_humidity_display_switch?: {
        /**
         * 设备屏幕温湿度显示切换 - 0: 温度 1：湿度
         * @class_type 参数
         */
        switch?: 0 | 1;
    };

    /**
     * 蜂窝状态信息
     * @class_type 属性
     */
    cellular_status?: {
        /**
         * 蜂窝状态信息
         * @class_type 属性
         */
        command?: number;

        /**
         * 驻网状态 - 0:驻网失败 1:驻网成功
         * @class_type 属性
         */
        register_status: 0 | 1;

        /**
         * SIM卡状态 - 0:卡状态预留 1:SIM卡识别成功 2:SIM卡未识别 3:需要PIN码 4:PIN码错误 5:需要PUK码 6:未插入SIM卡
         * @class_type 属性
         */
        sim_status: 0 | 1 | 2 | 3 | 4 | 5 | 6;

        /**
         * IMEI
         * @class_type 基本信息
         * @string_length 15
         * @character_encoding ascii
         */
        imei?: string;

        /**
         * IMSI
         * @class_type 基本信息
         * @string_length 15
         * @character_encoding ascii
         */
        imsi?: string;

        /**
         * ICCID
         * @class_type 基本信息
         * @string_length 20
         * @character_encoding ascii
         */
        iccid?: string;

        /**
         * 信号强度
         * @class_type 基本信息
         */
        csq?: number;

        /**
         * 服务器连接状态 - 0:连接失败 1:连接成功
         * @class_type 属性
         */
        connected_status: 0 | 1;

        /**
         * Milesight MQTT 状态 - 0:连接失败 1:连接成功
         * @class_type 属性
         */
        milesight_mqtt_status: 0 | 1;

        /**
         * Milesight DTLS 状态 - 0:连接失败 1:连接成功
         * @class_type 属性
         */
        milesight_dtls_status: 0 | 1;
    };

    /**
     * 蜂窝设置
     * @class_type 属性
     */
    cellular_settings?: {
        /**
         * 蜂窝设置指令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 工作模式 - 0: 低功耗模式
         * @default 0
         * @class_type 属性
         */
        work_mode: 0;

        /**
         * 传输类型 - 1:UDP 2:TCP 3:AWS 4:MQTT 7:开发者平台-DTLS
         * @default 7
         * @class_type 属性
         */
        transport_type: 1 | 2 | 3 | 4 | 7;

        /**
         * 网络配置
         * @class_type 属性
         */
        network: {
            /**
             * 网络配置指令
             * @default 0
             * @class_type 属性
             */
            command?: number;

            /**
             * APN
             * @class_type 属性
             * @string_length 31
             * @character_encoding ascii
             */
            apn: string;

            /**
             * 认证方式 - 0：不认证 1：PAP 2：CHAP
             * @default 0
             * @class_type 属性
             */
            auth_mode: 0 | 1 | 2;

            /**
             * 用户名
             * @class_type 属性
             * @string_length 63
             * @character_encoding ascii
             */
            auth_username: string;

            /**
             * 密码
             * @class_type 属性
             * @string_length 63
             * @character_encoding ascii
             */
            password: string;

            /**
             * PIN码
             * @class_type 属性
             * @string_length 8
             * @character_encoding ascii
             */
            pin: string;

            /**
             * 网络类型 - 0：自动 1：Cat-M 2：NB-IOT
             * @default 0
             * @class_type 属性
             */
            type: 0 | 1 | 2;
        };

        /**
         * MQTT设置
         * @class_type 属性
         */
        mqtt_settings: {
            /**
             * MQTT设置指令
             * @default 0
             * @class_type 属性
             */
            command?: number;

            /**
             * 服务器地址
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            server_address: string;

            /**
             * 端口
             * @default 1883
             * @class_type 属性
             * @max_value 65535
             * @min_value 1
             */
            server_port: number;

            /**
             * 保活间隔
             * @default 300
             * @class_type 属性
             * @max_value 65535
             * @min_value 10
             */
            keepalive_interval: number;

            /**
             * 客户端ID
             * @default [sn]
             * @class_type 属性
             * @string_length 63
             * @character_encoding ascii
             */
            client_id: string;

            /**
             * 用户凭证使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            auth_enable: 0 | 1;

            /**
             * 用户名
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            auth_username: string;

            /**
             * 密码
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            auth_password: string;

            /**
             * TLS使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_tls: 0 | 1;

            /**
             * 根文件使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_ca_certificate: 0 | 1;

            /**
             * 根文件长度
             * @default 0
             * @class_type 属性
             */
            ca_certificate_length: number;

            /**
             * 根文件
             * @class_type 属性
             * @string_length 160
             * @character_encoding ascii
             */
            ca_certificate: string;

            /**
             * 客户端证书使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_client_certificate: 0 | 1;

            /**
             * 客户端证书长度
             * @default 0
             * @class_type 属性
             */
            client_certificate_length: number;

            /**
             * 客户端证书
             * @class_type 属性
             * @string_length 160
             * @character_encoding ascii
             */
            client_certificate: string;

            /**
             * 客户端密钥使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_key_certificate: 0 | 1;

            /**
             * 客户端密钥长度
             * @default 0
             * @class_type 属性
             */
            key_certificate_length: number;

            /**
             * 客户端密钥
             * @class_type 属性
             * @string_length 160
             * @character_encoding ascii
             */
            key_certificate: string;

            /**
             * 数据上行主题
             * @default ts/[sn]/uplink
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            uplink_topic: string;

            /**
             * 数据上行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             * @class_type 属性
             */
            uplink_qos: 0 | 1 | 2;

            /**
             * 数据下行主题
             * @default ts/[sn]/downlink
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            downlink_topic: string;

            /**
             * 数据下行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             * @class_type 属性
             */
            downlink_qos: 0 | 1 | 2;

            /**
             * MQTT状态 - 0：连接失败 1：连接成功
             * @class_type 属性
             */
            mqtt_status: 0 | 1;
        };

        /**
         * AWS设置
         * @class_type 属性
         */
        aws_settings: {
            /**
             * AWS设置指令
             * @default 0
             * @class_type 属性
             */
            command?: number;

            /**
             * 服务器地址
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            server_address: string;

            /**
             * 端口
             * @default 8883
             * @class_type 属性
             * @max_value 65535
             * @min_value 1
             */
            server_port: number;

            /**
             * 保活间隔
             * @default 300
             * @class_type 属性
             * @max_value 65535
             * @min_value 10
             */
            keepalive_interval: number;

            /**
             * 根文件使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_ca_certificate: 0 | 1;

            /**
             * 根文件长度
             * @default 0
             * @class_type 属性
             */
            ca_certificate_length: number;

            /**
             * 根文件
             * @class_type 属性
             * @string_length 160
             * @character_encoding ascii
             */
            ca_certificate: string;

            /**
             * 客户端证书使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_client_certificate: 0 | 1;

            /**
             * 客户端证书长度
             * @default 0
             * @class_type 属性
             */
            client_certificate_length: number;

            /**
             * 客户端证书
             * @class_type 属性
             * @string_length 160
             * @character_encoding ascii
             */
            client_certificate: string;

            /**
             * 客户端密钥使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable_key_certificate: 0 | 1;

            /**
             * 客户端密钥长度
             * @default 0
             * @class_type 属性
             */
            key_certificate_length: number;

            /**
             * 客户端密钥
             * @class_type 属性
             * @string_length 160
             * @character_encoding ascii
             */
            key_certificate: string;

            /**
             * AWS状态 - 0：连接失败 1：连接成功
             * @class_type 属性
             */
            aws_status: 0 | 1;
        };

        /**
         * TCP设置
         * @class_type 属性
         * @array_length 1
         */
        tcp_settings: {
            /**
             * TCP设置序号
             * @default 0
             * @class_type 属性
             */
            id: number;

            /**
             * TCP设置指令
             * @class_type 属性
             */
            command?: number;

            /**
             * 启用服务器 - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            enable: 0 | 1;

            /**
             * 服务器地址
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            server_address: string;

            /**
             * 端口
             * @default 1000
             * @class_type 属性
             * @max_value 65535
             * @min_value 1
             */
            server_port: number;

            /**
             * 重连次数
             * @default 1
             * @class_type 属性
             * @max_value 3
             * @min_value 0
             */
            retry_count: number;

            /**
             * 重连间隔
             * @default 5
             * @class_type 属性
             * @max_value 60
             * @min_value 1
             */
            retry_interval: number;

            /**
             * 保活间隔
             * @default 5
             * @class_type 属性
             * @max_value 120
             * @min_value 1
             */
            keepalive_interval: number;

            /**
             * TCP状态 - 0：连接失败 1：连接成功
             * @class_type 属性
             */
            tcp_status: 0 | 1;
        }[];

        /**
         * UDP设置
         * @class_type 属性
         * @array_length 1
         */
        udp_settings: {
            /**
             * UDP设置序号
             * @default 0
             * @class_type 属性
             */
            id: number;

            /**
             * UDP设置指令
             * @class_type 属性
             */
            command?: number;

            /**
             * 启用服务器 - 0：禁用 1：启用
             * @default 1
             * @class_type 属性
             */
            enable: 0 | 1;

            /**
             * 服务器地址
             * @class_type 属性
             * @string_length 127
             * @character_encoding ascii
             */
            server_address: string;

            /**
             * 端口
             * @default 1000
             * @class_type 属性
             * @max_value 65535
             * @min_value 1
             */
            server_port: number;

            /**
             * UDP状态 - 0：连接失败 1：连接成功
             * @class_type 属性
             */
            udp_status: 0 | 1;
        }[];

        /**
         * Milesight MQTT设置
         * @class_type 属性
         */
        milesight_mqtt_settings: {
            /**
             * Milesight MQTT设置指令
             * @default 33
             * @class_type 属性
             */
            command?: number;

            /**
             * Milesight MQTT 状态 - 0：连接失败 1：连接成功
             * @class_type 属性
             */
            status: 0 | 1;
        };

        /**
         * Milesight DTLS设置
         * @class_type 属性
         */
        milesight_dtls_settings: {
            /**
             * Milesight DTLS设置指令
             * @default 0
             * @class_type 属性
             */
            command?: number;

            /**
             * Milesight DTLS 状态 - 0：连接失败 1：连接成功
             * @class_type 属性
             */
            status: 0 | 1;
        };
    };

    /**
     * OTA升级
     * @class_type 服务
     */
    ipso_device_upgrade?: {
        /**
         * 固件列表
         * @class_type 参数
         * @array_length 5
         */
        firmwares: {
            /**
             * 起始版本
             * @class_type 参数
             * @string_length 6
             * @character_encoding ascii
             */
            base_version?: string;

            /**
             * 目标版本
             * @class_type 参数
             * @string_length 6
             * @character_encoding ascii
             */
            target_version?: string;

            /**
             * 文件大小
             * @default 0
             * @class_type 参数
             */
            size?: number;

            /**
             * CRC校验值
             * @default 0
             * @class_type 参数
             * @string_length 8
             */
            crc32?: number;

            /**
             * URL长度
             * @default 0
             * @class_type 参数
             */
            url_length?: number;

            /**
             * URL
             * @class_type 参数
             * @string_length 160
             * @character_encoding ascii
             */
            url?: string;
        }[];
    };

    /**
     * OTA响应
     * @class_type 事件
     */
    ipso_device_upgrade_result?: {
        /**
         * OTA响应 - 0: Upgrade Successfully 1: URL Error 2: Download Failed 3: Packet Too Big 4: Version Error 5: Device Error 6: Patch Format Error 7: CRC Check Failed 8: Product Error 9: Patch Upgrade Failed 255: Upgrade Pending
         * @default 0
         * @class_type 参数
         */
        value?: number;
    };

    /**
     * 命令查询
     * @class_type 服务
     */
    request_command_queries?: {
        /**
         * 查询信息
         * @class_type 参数
         */
        query_information?: number;

        /**
         * 命令长度
         * @default 1
         * @class_type 参数
         * @max_value 15
         * @min_value 1
         */
        length?: number;

        /**
         * 所查询的命令 - 0XDF:物模型版本 0XDB:SN 0XDA:产品版本 0XD9:OEM ID 0XC8:设备状态 0X01:电池电量 0X03:传感器ID 0X04:温度 0X05:湿度 0X06:基站定位 0X07:飞行模式状态 0X1A:温度报警类型 0X1110:电量告警低电量告警 0X1B:湿度报警类型 0X1C:倾斜告警报警类型 0X1D:光照告警报警类型 0X0C:探针连接状态告警 0X0D:获取相对初始面角度值 0X0E:上报包类型 0X60:上报周期 0X61:累计次数 0X62:采集周期 0X63:告警次数 0X75:阈值告警解除 0X65:温度单位切换 0XC4:AutoP使能 0X71:基站定位 0X7300:飞行模式时间段飞行模式 0X7301:飞行模式时间段开始时间 0X7302:飞行模式时间段结束时间 0XC7:时区 0XC6:夏令时 0XC500:数据存储设置数据存储 0XC501:数据存储设置数据重传 0XC502:数据存储设置重传周期 0X76:按键锁 0X77:温度阈值告警配置 0X78:温度突变阈值 0X79:湿度阈值告警 0X7A:湿度突变告警配置 0X7B:温度数值校准 0X7C:湿度数值校准 0X7D:光照阈值告警配置 0X7E:光照抖动阈值 0X7F:倾斜阈值告警配置 0X80:跌落告警配置 0X82:探针ID重传次数 0XBE00:蜂窝状态信息驻网状态 0XBE01:蜂窝状态信息SIM卡状态 0XBE02:蜂窝状态信息IMEI 0XBE03:蜂窝状态信息IMSI 0XBE04:蜂窝状态信息ICCID 0XBE05:蜂窝状态信息信号强度 0XBE06:蜂窝状态信息服务器连接状态 0XBE11:蜂窝状态信息Milesight MQTT 状态 0XBE15:蜂窝状态信息Milesight DTLS 状态 0XCE3F:蜂窝设置工作模式 0XCE42:蜂窝设置传输类型 0XCE4100:蜂窝设置APN 0XCE4101:蜂窝设置认证方式 0XCE4102:蜂窝设置用户名 0XCE4103:蜂窝设置密码 0XCE4104:蜂窝设置PIN码 0XCE4105:蜂窝设置网络类型 0XCE0000:蜂窝设置服务器地址 0XCE0001:蜂窝设置端口 0XCE0002:蜂窝设置保活间隔 0XCE0003:蜂窝设置客户端ID 0XCE0004:蜂窝设置用户凭证使能 0XCE0005:蜂窝设置用户名 0XCE0006:蜂窝设置密码 0XCE0007:蜂窝设置TLS使能 0XCE0008:蜂窝设置根文件使能 0XCE0009:蜂窝设置根文件长度 0XCE000A:蜂窝设置根文件 0XCE000B:蜂窝设置客户端证书使能 0XCE000C:蜂窝设置客户端证书长度 0XCE000D:蜂窝设置客户端证书 0XCE000E:蜂窝设置客户端密钥使能 0XCE000F:蜂窝设置客户端密钥长度 0XCE0010:蜂窝设置客户端密钥 0XCE0011:蜂窝设置数据上行主题 0XCE0012:蜂窝设置数据上行QoS 0XCE0013:蜂窝设置数据下行主题 0XCE0014:蜂窝设置数据下行QoS 0XCE0021:蜂窝设置MQTT状态 0XCE0200:蜂窝设置服务器地址 0XCE0201:蜂窝设置端口 0XCE0202:蜂窝设置保活间隔 0XCE0209:蜂窝设置根文件长度 0XCE020A:蜂窝设置根文件 0XCE020C:蜂窝设置客户端证书长度 0XCE020D:蜂窝设置客户端证书 0XCE020F:蜂窝设置客户端密钥长度 0XCE0210:蜂窝设置客户端密钥 0XCE0221:蜂窝设置AWS状态 0XCE0121:蜂窝设置Milesight MQTT 状态 0XCE1900:蜂窝设置Milesight DTLS 状态
         * @class_type 参数
         * @character_encoding hex
         */
        object_command?: string;
    };
}
