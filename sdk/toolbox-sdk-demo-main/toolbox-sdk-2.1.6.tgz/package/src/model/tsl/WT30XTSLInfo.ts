export interface WT30XTSLInfo {
    /**
     * 电池电量
     * @class_type 属性
     */
    battery: number;

    /**
     * 数据来源 - 0：内部 1：外部NTC 2：LoRaWAN接收 3：D2D接收
     * @default 0
     * @class_type 属性
     */
    data_source: 0 | 1 | 2 | 3;

    /**
     * 温度
     * @class_type 属性
     */
    temperature: number;

    /**
     * 湿度
     * @class_type 属性
     */
    humidity: number;

    /**
     * 目标温度
     * @class_type 属性
     */
    target_temperature: number;

    /**
     * 温控信息
     * @class_type 属性
     */
    temperature_control_info: {
        /**
         * 温控模式 - 0：通风 1：制热 2：制冷
         * @default 1
         * @class_type 属性
         */
        mode: 0 | 1 | 2;

        /**
         * 温控状态 - 0：待机 1：制热 2：制冷
         * @default 0
         * @class_type 属性
         */
        status: 0 | 1 | 2;
    };

    /**
     * 阀门状态
     * @default 0
     * @class_type 属性
     */
    temperature_control_valve_status: number;

    /**
     * 风扇状态
     * @class_type 属性
     */
    fan_control_info: {
        /**
         * 风扇模式 - 0：自动 1：低速 2：中速 3：高速
         * @default 0
         * @class_type 属性
         */
        mode: 0 | 1 | 2 | 3;

        /**
         * 风扇状态 - 0：关 1：低速 2：中速 3：高速
         * @default 0
         * @class_type 属性
         */
        status: 0 | 1 | 2 | 3;
    };

    /**
     * 计划 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 8：计划9 9：计划10 10：计划11 11：计划12 12：计划13 13：计划14 14：计划15 15：计划16 255：未执行
     * @default 255
     * @class_type 属性
     */
    execution_plan_id: number;

    /**
     * 温度告警
     * @class_type 事件
     */
    temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;

        /**
         * 值小于告警解除
         * @class_type 参数
         */
        lower_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值小于告警
         * @class_type 参数
         */
        lower_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值大于告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值大于告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值介于告警解除
         * @class_type 参数
         */
        within_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值介于告警
         * @class_type 参数
         */
        within_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值之外告警解除
         * @class_type 参数
         */
        exceed_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 值之外告警
         * @class_type 参数
         */
        exceed_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 持续低温告警解除
         * @class_type 参数
         */
        persistent_low_temperature_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 持续低温告警
         * @class_type 参数
         */
        persistent_low_temperature_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 持续高温告警解除
         * @class_type 参数
         */
        persistent_high_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 持续高温告警
         * @class_type 参数
         */
        persistent_high_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 防冻保护解除
         * @class_type 参数
         */
        anti_freeze_protection_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 防冻保护告警
         * @class_type 参数
         */
        anti_freeze_protection_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 开窗解除
         * @class_type 参数
         */
        window_status_detection_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };

        /**
         * 开窗告警
         * @class_type 参数
         */
        window_status_detection_trigger?: {
            /**
             * 温度
             * @class_type 参数
             */
            temperature?: number;
        };
    };

    /**
     * 湿度告警
     * @class_type 事件
     */
    humidity_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;
    };

    /**
     * 目标温度告警
     * @class_type 事件
     */
    target_temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;
    };

    /**
     * 继电器/阀门状态
     * @class_type 属性
     */
    relay_status: {
        /**
         * 低速风扇 - 0：断开 1：闭合
         * @default 0
         * @class_type 属性
         */
        low_status: 0 | 1;

        /**
         * 中速风扇 - 0：断开 1：闭合
         * @default 0
         * @class_type 属性
         */
        mid_status: 0 | 1;

        /**
         * 高速风扇 - 0：断开 1：闭合
         * @default 0
         * @class_type 属性
         */
        high_status: 0 | 1;

        /**
         * 阀1 - 0：断开 1：闭合
         * @default 0
         * @class_type 属性
         */
        valve_1_status: 0 | 1;

        /**
         * 阀2 - 0：断开 1：闭合
         * @default 0
         * @class_type 属性
         */
        valve_2_status: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 随机密钥 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    random_key: 0 | 1;

    /**
     * 设备状态 - 0：关机 1：开机
     * @default 1
     * @class_type 属性
     */
    device_status: 0 | 1;

    /**
     * 采集周期
     * @class_type 属性
     */
    collection_interval: {
        /**
         * 采集周期单位 - 0：秒 1：分
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 采集周期
         * @default 30
         * @class_type 属性
         */
        seconds_of_time?: number;

        /**
         * 采集周期
         * @default 1
         * @class_type 属性
         */
        minutes_of_time?: number;
    };

    /**
     * 上报周期
     * @class_type 属性
     */
    reporting_interval: {
        /**
         * 上报周期单位 - 0：秒 1：分
         * @default 1
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 上报周期
         * @default 600
         * @class_type 属性
         */
        seconds_of_time?: number;

        /**
         * 上报周期
         * @default 10
         * @class_type 属性
         */
        minutes_of_time?: number;
    };

    /**
     * Auto-P - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    auto_p_enable: 0 | 1;

    /**
     * 继电器/阀门变更上报 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    relay_changes_report_enable: 0 | 1;

    /**
     * 温度单位 - 0：℃ 1：℉
     * @default 0
     * @class_type 属性
     */
    temperature_unit: 0 | 1;

    /**
     * 温度数据来源
     * @class_type 属性
     */
    temperature_source: {
        /**
         * 温度来源 - 0：内部温度 1：外部NTC 2：LoRa接收 3：D2D接收
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        type: 0 | 1 | 2 | 3;

        /**
         * LoRa接收
         * @class_type 属性
         */
        lorawan_reception?: {
            /**
             * 超时时间
             * @default 10
             * @class_type 属性
             */
            timeout: number;

            /**
             * 设备掉线设置 - 0：保持控制 1：关闭控制 2：切换内部温度
             * @default 0
             * @class_type 属性
             */
            timeout_response: 0 | 1 | 2;
        };

        /**
         * D2D接收
         * @class_type 属性
         */
        d2d_reception?: {
            /**
             * 超时时间
             * @default 10
             * @class_type 属性
             */
            timeout: number;

            /**
             * 设备掉线设置 - 0：保持控制 1：关闭控制 2：切换内部温度
             * @default 0
             * @class_type 属性
             */
            timeout_response: 0 | 1 | 2;
        };
    };

    /**
     * 系统开关控制 - 0：关 1：开
     * @default 0
     * @class_type 属性
     */
    system_status: 0 | 1;

    /**
     * 模式启用 - 7：通风、制热、制冷 3：通风、制热 5：通风、制冷
     * @default 7
     * @class_type 属性
     */
    mode_enable: 7 | 3 | 5;

    /**
     * 温控模式 - 0：通风 1：制热 2：制冷
     * @default 1
     * @class_type 属性
     */
    temperature_control_mode: 0 | 1 | 2;

    /**
     * 目标温度分辨率 - 0：0.5 1：1
     * @default 0
     * @class_type 属性
     */
    target_temperature_resolution: 0 | 1;

    /**
     * 制热目标温度
     * @default 17
     * @class_type 属性
     */
    heating_target_temperature: number;

    /**
     * 制冷目标温度
     * @default 28
     * @class_type 属性
     */
    cooling_target_temperature: number;

    /**
     * 目标温度允差
     * @default 1
     * @class_type 属性
     */
    target_temperature_tolerance: number;

    /**
     * 制热目标温度调节范围
     * @class_type 属性
     */
    heating_target_temperature_range: {
        /**
         * 下限值
         * @default 10
         * @class_type 属性
         */
        min: number;

        /**
         * 上限值
         * @default 19
         * @class_type 属性
         */
        max: number;
    };

    /**
     * 制冷目标温度调节范围
     * @class_type 属性
     */
    cooling_target_temperature_range: {
        /**
         * 下限值
         * @default 23
         * @class_type 属性
         */
        min: number;

        /**
         * 上限值
         * @default 35
         * @class_type 属性
         */
        max: number;
    };

    /**
     * 目标湿度调节范围
     * @class_type 属性
     */
    target_humidity_range: {
        /**
         * 下限值
         * @default 40
         * @class_type 属性
         */
        min: number;

        /**
         * 上限值
         * @default 80
         * @class_type 属性
         */
        max: number;
    };

    /**
     * 控温除湿设置
     * @class_type 属性
     */
    temperature_control_dehumidification: {
        /**
         * 控温除湿 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 除湿温度允差
         * @default 1
         * @class_type 属性
         */
        temperature_tolerance: number;
    };

    /**
     * 风扇模式 - 0：自动 1：低速 2：中速 3：高速
     * @default 0
     * @class_type 属性
     */
    fan_control_mode: 0 | 1 | 2 | 3;

    /**
     * 风扇延迟
     * @class_type 属性
     */
    fan_delay_close: {
        /**
         * 风扇延迟 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 延迟关闭时间
         * @default 60
         * @class_type 属性
         */
        time: number;
    };

    /**
     * 自动风扇等级切换设置
     * @class_type 属性
     */
    fan_auto_mode_temperature_range: {
        /**
         * ΔT1
         * @default 3
         * @class_type 属性
         */
        speed_range_1: number;

        /**
         * ΔT2
         * @default 5
         * @class_type 属性
         */
        speed_range_2: number;
    };

    /**
     * 定时系统开关
     * @class_type 属性
     */
    timed_system_control: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 定时开关使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 定时开
         * @class_type 属性
         * @array_length 4
         */
        start_cycle_settings: {
            /**
             * 时间序号
             * @default 0
             * @class_type 属性
             */
            id: number;

            /**
             * 使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable: 0 | 1;

            /**
             * 时间
             * @default 0
             * @class_type 属性
             */
            execution_time_point: number;

            /**
             * 周日 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sun: 0 | 1;

            /**
             * 周一 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_mon: 0 | 1;

            /**
             * 周二 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_tues: 0 | 1;

            /**
             * 周三 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_wed: 0 | 1;

            /**
             * 周四 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_thu: 0 | 1;

            /**
             * 周五 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_fri: 0 | 1;

            /**
             * 周六 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sat: 0 | 1;

            /**
             * 预留
             * @class_type 属性
             */
            reserved: number;
        }[];

        /**
         * 定时关
         * @class_type 属性
         * @array_length 4
         */
        end_cycle_settings: {
            /**
             * 时间序号
             * @default 0
             * @class_type 属性
             */
            id: number;

            /**
             * 使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable: 0 | 1;

            /**
             * 时间
             * @default 0
             * @class_type 属性
             */
            execution_time_point: number;

            /**
             * 周日 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sun: 0 | 1;

            /**
             * 周一 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_mon: 0 | 1;

            /**
             * 周二 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_tues: 0 | 1;

            /**
             * 周三 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_wed: 0 | 1;

            /**
             * 周四 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_thu: 0 | 1;

            /**
             * 周五 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_fri: 0 | 1;

            /**
             * 周六 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sat: 0 | 1;

            /**
             * 预留
             * @class_type 属性
             */
            reserved: number;
        }[];
    };

    /**
     * 智能显示 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    intelligent_display_enable: 0 | 1;

    /**
     * 屏幕显示设置
     * @class_type 属性
     */
    screen_object_settings: {
        /**
         * 屏幕显示 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 环境温度 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        environmental_temperature: 0 | 1;

        /**
         * 环境湿度 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        environmental_humidity: 0 | 1;

        /**
         * 目标温度 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        target_temperature: 0 | 1;

        /**
         * 计划 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        schedule_name: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 儿童锁
     * @class_type 属性
     */
    child_lock: {
        /**
         * 儿童锁使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 系统开关 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        system_button: 0 | 1;

        /**
         * 温度+/- - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        temperature_button: 0 | 1;

        /**
         * 风扇模式 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        fan_button: 0 | 1;

        /**
         * 温控模式 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        temperature_control_button: 0 | 1;

        /**
         * 重启&重置 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        reboot_reset_button: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 解锁按键设置
     * @class_type 属性
     */
    temporary_unlock_settings: {
        /**
         * 解锁功能启用 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 系统开关 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        system: 0 | 1;

        /**
         * 温度+ - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        temperature_up: 0 | 1;

        /**
         * 温度- - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        temperature_down: 0 | 1;

        /**
         * 风扇模式 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        fan: 0 | 1;

        /**
         * 温控模式 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        temperature_control: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;

        /**
         * 解除时长
         * @default 30
         * @class_type 属性
         */
        unlocking_duration: number;
    };

    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     * @class_type 属性
     */
    time_zone: number;

    /**
     * 夏令时
     * @class_type 属性
     */
    daylight_saving_time: {
        /**
         * 夏令时 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 偏移时间
         * @default 60
         * @class_type 属性
         */
        daylight_saving_time_offset: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         */
        start_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        start_hour_min: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         */
        end_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         * @class_type 属性
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        end_hour_min: number;
    };

    /**
     * 数据存储设置
     * @class_type 属性
     */
    data_storage_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 数据存储 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 重传 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        retransmission_enable: 0 | 1;

        /**
         * 重传周期
         * @default 600
         * @class_type 属性
         */
        retransmission_interval: number;

        /**
         * 回传周期
         * @default 60
         * @class_type 属性
         */
        retrieval_interval: number;
    };

    /**
     * 温度校准设置
     * @class_type 属性
     */
    temperature_calibration_settings: {
        /**
         * 温度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         */
        calibration_value: number;
    };

    /**
     * 湿度校准设置
     * @class_type 属性
     */
    humidity_calibration_settings: {
        /**
         * 湿度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         */
        calibration_value: number;
    };

    /**
     * 温度阈值告警设置
     * @class_type 属性
     */
    temperature_alarm_settings: {
        /**
         * 温度阈值告警 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 阈值模式 - 0:禁用 1:条件：x<A 2:条件：x>B 3:条件：A≤x≤B 4:条件：x<A或x>B
         * @default 0
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;

        /**
         * 值A
         * @default 0
         * @class_type 属性
         */
        threshold_min: number;

        /**
         * 值B
         * @default 0
         * @class_type 属性
         */
        threshold_max: number;
    };

    /**
     * 持续高温告警设置
     * @class_type 属性
     */
    high_temperature_alarm_settings: {
        /**
         * 持续高温告警 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度差值
         * @default 3
         * @class_type 属性
         */
        difference_in_temperature: number;

        /**
         * 持续时间
         * @default 5
         * @class_type 属性
         */
        duration: number;
    };

    /**
     * 持续低温告警设置
     * @class_type 属性
     */
    low_temperature_alarm_settings: {
        /**
         * 持续低温告警 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度差值
         * @default 3
         * @class_type 属性
         */
        difference_in_temperature: number;

        /**
         * 持续时间
         * @default 5
         * @class_type 属性
         */
        duration: number;
    };

    /**
     * 计划设置
     * @class_type 属性
     * @array_length 3
     */
    schedule_settings: {
        /**
         * 计划序号
         * @default 0
         * @class_type 属性
         */
        id: number;

        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 计划使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 命名前6B
         * @class_type 属性
         * @string_length 6
         */
        name_first: string;

        /**
         * 命名后4B
         * @class_type 属性
         * @string_length 4
         */
        name_last: string;

        /**
         * 计划内容
         * @class_type 属性
         */
        content: {
            /**
             * 风扇模式 - 0：自动 1：低速 2：中速 3：高速
             * @default 0
             * @class_type 属性
             */
            fan_mode: 0 | 1 | 2 | 3;

            /**
             * 制热目标温度使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            heat_target_temperature_enable: 0 | 1;

            /**
             * 制热目标温度
             * @default 17
             * @class_type 属性
             */
            heat_target_temperature: number;

            /**
             * 制冷目标温度使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            cool_target_temperature_enable: 0 | 1;

            /**
             * 制冷目标温度
             * @default 26
             * @class_type 属性
             */
            cool_target_temperature: number;

            /**
             * 温度允差使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            temperature_tolerance_enable: 0 | 1;

            /**
             * 温度允差
             * @default 2
             * @class_type 属性
             */
            temperature_tolerance: number;
        };

        /**
         * 时间
         * @class_type 属性
         * @array_length 16
         */
        cycle_settings: {
            /**
             * 时间序号
             * @default 0
             * @class_type 属性
             */
            id: number;

            /**
             * 使能 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            enable: 0 | 1;

            /**
             * 时间
             * @default 0
             * @class_type 属性
             */
            execution_time_point: number;

            /**
             * 周日 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sun: 0 | 1;

            /**
             * 周一 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_mon: 0 | 1;

            /**
             * 周二 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_tues: 0 | 1;

            /**
             * 周三 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_wed: 0 | 1;

            /**
             * 周四 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_thu: 0 | 1;

            /**
             * 周五 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_fri: 0 | 1;

            /**
             * 周六 - 0：禁用 1：启用
             * @default 0
             * @class_type 属性
             */
            execution_day_sat: 0 | 1;

            /**
             * 预留
             * @class_type 属性
             */
            reserved: number;
        }[];
    }[];

    /**
     * 接口设置
     * @class_type 属性
     */
    interface_settings: {
        /**
         * 系统类型
         * @default 1
         * @class_type 属性
         * @is_one_of
         */
        object: number;

        /**
         * 四管两线阀+三速风机
         * @class_type 属性
         */
        valve_4_pipe_2_wire?: {
            /**
             * 冷水阀 - 1：V1/ NO 2：V2/ NC
             * @default 1
             * @class_type 属性
             */
            cooling: 1 | 2;

            /**
             * 热水阀 - 1：V1/ NO 2：V2/ NC
             * @default 2
             * @class_type 属性
             */
            heating: 1 | 2;
        };

        /**
         * 两管两线阀+三速风机
         * @class_type 属性
         */
        valve_2_pipe_2_wire?: {
            /**
             * 控制阀 - 1：V1/ NO 2：V2/ NC
             * @default 1
             * @class_type 属性
             */
            control: 1 | 2;
        };

        /**
         * 两管三线阀+三速风机
         * @class_type 属性
         */
        valve_2_pipe_3_wire?: {
            /**
             * NO - 1：V1/ NO 2：V2/ NC
             * @default 1
             * @class_type 属性
             */
            no: 1 | 2;

            /**
             * NC - 1：V1/ NO 2：V2/ NC
             * @default 2
             * @class_type 属性
             */
            nc: 1 | 2;
        };

        /**
         * 四管0~10V阀+三速风机
         * @class_type 属性
         */
        valve_4_pipe_10_v?: {
            /**
             * 冷水阀 - 1：AO1 2：AO2
             * @default 1
             * @class_type 属性
             */
            cooling: 1 | 2;

            /**
             * 热水阀 - 1：AO1 2：AO2
             * @default 2
             * @class_type 属性
             */
            heating: 1 | 2;
        };

        /**
         * 两管0~10V阀+三速风机
         * @class_type 属性
         */
        valve_2_pipe_10_v?: {
            /**
             * 控制阀 - 1：AO1 2：AO2
             * @default 1
             * @class_type 属性
             */
            control: 1 | 2;
        };

        /**
         * 两管0~10V阀+EC风机
         * @class_type 属性
         */
        valve_2_pipe_10_v_fan_ec?: {
            /**
             * 控制阀 - 1：AO1 2：AO2
             * @default 1
             * @class_type 属性
             */
            control: 1 | 2;

            /**
             * EC风机 - 1：AO1 2：AO2
             * @default 2
             * @class_type 属性
             */
            fan: 1 | 2;

            /**
             * 风机电源 - 0：无 3：Q1 4：Q2 5：Q3
             * @default 5
             * @class_type 属性
             */
            fan_power: 0 | 3 | 4 | 5;
        };

        /**
         * 四管两线阀+EC风机
         * @class_type 属性
         */
        valve_4_pipe_2_wire_fan_ec?: {
            /**
             * 冷水阀 - 3：Q1 4：Q2 5：Q3
             * @default 3
             * @class_type 属性
             */
            cooling: 3 | 4 | 5;

            /**
             * 热水阀 - 3：Q1 4：Q2 5：Q3
             * @default 4
             * @class_type 属性
             */
            heating: 3 | 4 | 5;

            /**
             * EC风机 - 1：AO1 2：AO2
             * @default 2
             * @class_type 属性
             */
            fan: 1 | 2;

            /**
             * 风机电源 - 0：无 3：Q1 4：Q2 5：Q3
             * @default 5
             * @class_type 属性
             */
            fan_power: 0 | 3 | 4 | 5;
        };

        /**
         * 两管两线阀+EC风机
         * @class_type 属性
         */
        valve_2_pipe_2_wire_fan_ec?: {
            /**
             * 控制阀 - 3：Q1 4：Q2 5：Q3
             * @default 3
             * @class_type 属性
             */
            control: 3 | 4 | 5;

            /**
             * EC风机 - 1：AO1 2：AO2
             * @default 2
             * @class_type 属性
             */
            fan: 1 | 2;

            /**
             * 风机电源 - 0：无 3：Q1 4：Q2 5：Q3
             * @default 5
             * @class_type 属性
             */
            fan_power: 0 | 3 | 4 | 5;
        };

        /**
         * 两管三线阀+EC风机
         * @class_type 属性
         */
        valve_2_pipe_3_wire_fan_ec?: {
            /**
             * NO - 3：Q1 4：Q2 5：Q3
             * @default 3
             * @class_type 属性
             */
            no: 3 | 4 | 5;

            /**
             * NC - 3：Q1 4：Q2 5：Q3
             * @default 4
             * @class_type 属性
             */
            nc: 3 | 4 | 5;

            /**
             * EC风机 - 1：AO1 2：AO2
             * @default 2
             * @class_type 属性
             */
            fan: 1 | 2;

            /**
             * 风机电源 - 0：无 3：Q1 4：Q2 5：Q3
             * @default 5
             * @class_type 属性
             */
            fan_power: 0 | 3 | 4 | 5;
        };
    };

    /**
     * 阀门控制设置
     * @class_type 属性
     */
    valve_control_settings: {
        /**
         * 控制内容
         * @default 0
         * @class_type 属性
         */
        type?: number;

        /**
         * 阀门控制周期
         * @default 30
         * @class_type 属性
         */
        control_interval: number;

        /**
         * 阀门控制调节范围
         * @default 10
         * @class_type 属性
         */
        control_adjustment_range: number;

        /**
         * 阀门开度范围
         * @class_type 属性
         */
        opening_range: {
            /**
             * 下限值
             * @default 0
             * @class_type 属性
             */
            min: number;

            /**
             * 上限值
             * @default 100
             * @class_type 属性
             */
            max: number;
        };
    };

    /**
     * EC风速设置
     * @class_type 属性
     */
    fan_ec_control_settings: {
        /**
         * 控制内容
         * @default 0
         * @class_type 属性
         */
        type?: number;

        /**
         * 低速
         * @default 50
         * @class_type 属性
         */
        low_threshold: number;

        /**
         * 中速
         * @default 80
         * @class_type 属性
         */
        mid_threshold: number;

        /**
         * 高速
         * @default 100
         * @class_type 属性
         */
        high_threshold: number;
    };

    /**
     * 风扇停止设置 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    fan_stop_enable: 0 | 1;

    /**
     * 阀门输出0%设置 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    valve_output_0v_enable: 0 | 1;

    /**
     * DI使能 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    di_enable: 0 | 1;

    /**
     * DI设置
     * @class_type 属性
     */
    di_settings: {
        /**
         * DI 接口
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        object: number;

        /**
         * 房卡
         * @class_type 属性
         */
        card_control?: {
            /**
             * 控制内容
             * @default 0
             * @class_type 属性
             * @is_one_of
             */
            type: number;

            /**
             * 系统控制
             * @class_type 属性
             */
            system_control?: {
                /**
                 * 插卡 - 0：系统关 1：系统开
                 * @default 1
                 * @class_type 属性
                 */
                trigger_by_insertion: 0 | 1;
            };

            /**
             * 插入计划
             * @class_type 属性
             */
            insertion_plan?: {
                /**
                 * 插卡 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 255：无动作
                 * @default 0
                 * @class_type 属性
                 */
                trigger_by_insertion: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 255;

                /**
                 * 拔卡 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 255：无动作
                 * @default 1
                 * @class_type 属性
                 */
                trigger_by_extraction: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 255;
            };
        };

        /**
         * 门磁传感器
         * @class_type 属性
         */
        magnet_detection?: {
            /**
             * 传感器类型 - 0：常闭型 1：常开型
             * @default 0
             * @class_type 属性
             */
            magnet_type: 0 | 1;
        };
    };

    /**
     * 开窗检测 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    window_opening_detection_enable: 0 | 1;

    /**
     * 开窗检测
     * @class_type 属性
     */
    window_opening_detection_settings: {
        /**
         * 检测方式
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        type: number;

        /**
         * 温度检测
         * @class_type 属性
         */
        temperature_detection?: {
            /**
             * 温度变化
             * @default 3
             * @class_type 属性
             */
            difference_in_temperature: number;

            /**
             * 停止调温时间
             * @default 30
             * @class_type 属性
             */
            stop_time: number;
        };

        /**
         * 门磁检测
         * @class_type 属性
         */
        magnet_detection?: {
            /**
             * 持续时间
             * @default 10
             * @class_type 属性
             */
            duration: number;
        };
    };

    /**
     * 防冻保护
     * @class_type 属性
     */
    freeze_protection_settings: {
        /**
         * 防冻保护 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 保护温度
         * @default 3
         * @class_type 属性
         */
        target_temperature: number;
    };

    /**
     * D2D配对启用 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    d2d_pairing_enable: 0 | 1;

    /**
     * D2D配对信息
     * @class_type 属性
     * @array_length 5
     */
    d2d_pairing_settings: {
        /**
         * 序号
         * @default 0
         * @class_type 属性
         */
        index: number;

        /**
         * 类型
         * @default 0
         * @class_type 属性
         */
        type?: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 设备EUI
         * @class_type 属性
         * @string_length 16
         */
        deveui: string;

        /**
         * 设备名称前8B
         * @class_type 属性
         * @string_length 8
         */
        name_first: string;

        /**
         * 设备名称后8B
         * @class_type 属性
         * @string_length 8
         */
        name_last: string;
    }[];

    /**
     * D2D主控使能 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    d2d_master_enable: 0 | 1;

    /**
     * D2D主控
     * @class_type 属性
     * @array_length 10
     */
    d2d_master_settings: {
        /**
         * 触发方式 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 16：系统关 17：系统开
         * @default 0
         * @class_type 属性
         */
        trigger_condition: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 16 | 17;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 控制命令
         * @default 0000
         * @class_type 属性
         * @string_length 4
         */
        command: string;

        /**
         * LoRa上行 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        uplink: 0 | 1;

        /**
         * 启用控制时间 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        control_time_enable: 0 | 1;

        /**
         * 控制时间
         * @default 5
         * @class_type 属性
         */
        control_time: number;
    }[];

    /**
     * D2D被控使能 - 0：禁用 1：启用
     * @default 0
     * @class_type 属性
     */
    d2d_slave_enable: 0 | 1;

    /**
     * D2D被控
     * @class_type 属性
     * @array_length 16
     */
    d2d_slave_settings: {
        /**
         * D2D被控序号
         * @default 0
         * @class_type 属性
         */
        index: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 控制命令
         * @default 0000
         * @class_type 属性
         * @string_length 4
         */
        command: string;

        /**
         * 被控状态 - 0：计划1 1：计划2 2：计划3 3：计划4 4：计划5 5：计划6 6：计划7 7：计划8 16：系统关 17：系统开
         * @default 16
         * @class_type 属性
         */
        value: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 16 | 17;
    }[];

    /**
     * 屏幕显示预配置
     * @class_type 属性
     * @array_length 25
     */
    screen_content_settings: {
        /**
         * 预配置对象 - 0：重启 1：重置 2：过温保护 3：通风图标 4：通风文字 5：制热图标 6：制热文字 7：制冷图标 8：制冷文字 9：风扇自动图标 10：风扇自动文字 11：风扇低速图标 12：风扇低速文字 13：风扇中速图标 14：风扇中速文字 15：风扇高速图标 16：风扇高速文字 17：温度设定 18：计划图标 19：计划1名称 20：计划2名称 21：计划3名称 22：计划4名称 23：计划5名称 24：计划6名称 25：计划7名称 26：计划8名称 27：计划9名称 28：计划10名称 29：计划11名称 30：计划12名称 31：计划13名称 32：计划14名称 33：计划15名称 34：计划16名称
         * @default 0
         * @class_type 属性
         */
        object: number;

        /**
         * 图片长度
         * @default 0
         * @class_type 属性
         */
        length: number;

        /**
         * 内容
         * @default 0
         * @class_type 属性
         * @string_length 65535
         */
        data: string;
    }[];

    /**
     * 查询设备状态
     * @class_type 服务
     */
    query_device_status?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    synchronize_time?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    set_time?: {
        /**
         * 时间戳
         * @class_type 参数
         */
        timestamp?: number;
    };

    /**
     * 清除历史记录
     * @class_type 服务
     */
    clear_historical_data?: Record<string, any>;

    /**
     * 停止查询回传
     * @class_type 服务
     */
    stop_historical_data_retrieval?: Record<string, any>;

    /**
     * 回传某个时间段的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time_range?: {
        /**
         * 起始时间
         * @class_type 参数
         */
        start_time?: number;

        /**
         * 结束时间
         * @class_type 参数
         */
        end_time?: number;
    };

    /**
     * 回传某个时间点的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time?: {
        /**
         * 时间点
         * @class_type 参数
         */
        time?: number;
    };

    /**
     * 重新连接网络
     * @class_type 服务
     */
    reconnect?: Record<string, any>;

    /**
     * 设置外部温度
     * @class_type 服务
     */
    send_temperature?: {
        /**
         * 外部温度值
         * @default 0
         * @class_type 参数
         */
        temperature?: number;
    };

    /**
     * 设置外部湿度
     * @class_type 服务
     */
    send_humidity?: {
        /**
         * 外部湿度值
         * @default 0
         * @class_type 参数
         */
        humidity?: number;
    };

    /**
     * 开窗状态控制
     * @class_type 服务
     */
    update_open_windows_state?: {
        /**
         * 开窗状态控制 - 0：解除 1：开窗
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1;
    };

    /**
     * 温控计划控制
     * @class_type 服务
     */
    insert_schedule?: {
        /**
         * 温控计划控制 - 0：计划一 1：计划二 2：计划三 3：计划四 4：计划五 5：计划六 6：计划七 7：计划八
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;
    };

    /**
     * 删除计划列表
     * @class_type 服务
     */
    delete_schedule?: {
        /**
         * 删除计划 - 0：计划一 1：计划二 2：计划三 3：计划四 4：计划五 5：计划六 6：计划七 7：计划八 255：全部重置
         * @default 255
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 255;
    };

    /**
     * 重置
     * @class_type 服务
     */
    reset?: Record<string, any>;

    /**
     * 重启
     * @class_type 服务
     */
    reboot?: Record<string, any>;
}
