export interface WT401TSLInfo {
    /**
     * 温度
     * @class_type 属性
     * @max_value 60
     * @min_value -20
     * @decimal_digits 2
     */
    temperature: number;

    /**
     * 湿度
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     * @decimal_digits 1
     */
    humidity: number;

    /**
     * 占用状态 - 0：空闲 1：占用 2：夜间占用
     * @default 0
     * @class_type 属性
     * @max_value 2
     * @min_value 0
     */
    pir_status: 0 | 1 | 2;

    /**
     * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动 10：关闭 11：无效
     * @default 0
     * @class_type 属性
     */
    temperature_mode?: 0 | 1 | 2 | 3 | 10 | 11;

    /**
     * 目标温度1
     * @class_type 属性
     * @max_value 35
     * @min_value 5
     * @decimal_digits 1
     */
    target_temperature1?: number;

    /**
     * 目标温度2
     * @class_type 属性
     * @max_value 35
     * @min_value 5
     * @decimal_digits 1
     */
    target_temperature2?: number;

    /**
     * 风扇模式 - 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速 10：关闭 11：空/保持
     * @default 0
     * @class_type 属性
     */
    fan_mode?: 0 | 1 | 2 | 3 | 4 | 5 | 10 | 11;

    /**
     * 计划 - 0:计划1 1:计划2 2:计划3 3:计划4 4:计划5 5:计划6 6:计划7 7:计划8 8:计划9 9:计划10 10:计划11 11:计划12 12:计划13 13:计划14 14:计划15 15:计划16 255:未执行
     * @default 0
     * @class_type 属性
     * @max_value 16
     * @min_value 0
     */
    execution_plan_id: number;

    /**
     * 温度告警
     * @class_type 事件
     */
    temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;
    };

    /**
     * 湿度告警
     * @class_type 事件
     */
    humidity_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;

        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;

        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;

        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;
    };

    /**
     * 蓝牙事件
     * @class_type 事件
     */
    ble_event?: {
        /**
         * 事件类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 无
         * @class_type 参数
         */
        none?: Record<string, any>;

        /**
         * 配对取消
         * @class_type 参数
         */
        pair_cancel?: Record<string, any>;

        /**
         * 连接断开
         * @class_type 参数
         */
        disconnect?: Record<string, any>;
    };

    /**
     * Powerbus事件
     * @class_type 事件
     */
    power_bus_event?: {
        /**
         * 事件类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 无
         * @class_type 参数
         */
        none?: Record<string, any>;

        /**
         * 通讯异常
         * @class_type 参数
         */
        disconnect?: Record<string, any>;
    };

    /**
     * 按键上报
     * @class_type 事件
     */
    key_event?: {
        /**
         * 事件类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 按键上报1
         * @class_type 参数
         */
        f1?: Record<string, any>;

        /**
         * 按键上报2
         * @class_type 参数
         */
        f2?: Record<string, any>;

        /**
         * 按键上报3
         * @class_type 参数
         */
        f3?: Record<string, any>;
    };

    /**
     * 电池事件
     * @class_type 事件
     */
    battery_event?: {
        /**
         * 事件类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;

        /**
         * 恢复正常
         * @class_type 参数
         */
        recover?: Record<string, any>;

        /**
         * 低电压
         * @class_type 参数
         */
        low_volt?: Record<string, any>;
    };

    /**
     * 设备状态 - 0：关机 1：开机
     * @default 0
     * @class_type 属性
     */
    device_status: 0 | 1;

    /**
     * 温度单位 - 0：℃ 1：℉
     * @default 0
     * @class_type 属性
     */
    temperature_unit: 0 | 1;

    /**
     * 温湿度数据源 - 0:内部数据 1:外部接收
     * @default 0
     * @class_type 属性
     */
    data_sync_to_peer: 0 | 1;

    /**
     * 外部数据超时时间
     * @default 10
     * @class_type 属性
     * @max_value 60
     * @min_value 1
     */
    data_sync_timeout: number;

    /**
     * 蓝牙使能 - 0:禁用 1:启用
     * @default 1
     * @class_type 属性
     */
    ble_enable: 0 | 1;

    /**
     * 蓝牙配对获取
     * @class_type 属性
     */
    ble_pair_fetch: {
        /**
         * 地址类型 - 0：公共 1：随机
         * @default 0
         * @class_type 属性
         */
        addr_type: 0 | 1;

        /**
         * 蓝牙地址
         * @class_type 属性
         * @array_length 6
         * @character_encoding hex
         */
        address: string;

        /**
         * 蓝牙名称
         * @class_type 属性
         * @array_length 32
         * @character_encoding ascii
         */
        name: string;
    };

    /**
     * 系统开关 - 0：关 1：开
     * @default 0
     * @class_type 属性
     */
    system_status: 0 | 1;

    /**
     * 温控模式启用
     * @class_type 属性
     */
    mode_enable: {
        /**
         * 制热 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        heat: 0 | 1;

        /**
         * 紧急制热 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        em_heat: 0 | 1;

        /**
         * 制冷 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        cool: 0 | 1;

        /**
         * 自动 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        auto: 0 | 1;

        /**
         * 预留
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 风扇模式启用
     * @class_type 属性
     */
    fan_enable: {
        /**
         * 自动 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        auto: 0 | 1;

        /**
         * 通风 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        circul: 0 | 1;

        /**
         * 常开 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        on: 0 | 1;

        /**
         * 低 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        low: 0 | 1;

        /**
         * 中 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        medium: 0 | 1;

        /**
         * 高 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        high: 0 | 1;

        /**
         * 预留
         * @default 0
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 温控模式
     * @class_type 属性
     */
    temperature_control_mode: {
        /**
         * 二级命令ID
         * @default 0
         * @class_type 属性
         */
        subcmd?: number;

        /**
         * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动
         * @default 0
         * @class_type 属性
         * @max_value 3
         * @min_value 0
         */
        mode: 0 | 1 | 2 | 3;

        /**
         * 计划温控模式启用 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        plan_mode_enable: 0 | 1;
    };

    /**
     * 目标温度模式 - 0：单设定点 1：双设定点
     * @default 0
     * @class_type 属性
     */
    target_temperature_mode: 0 | 1;

    /**
     * 目标温度分辨率 - 0：0.5 1：1
     * @default 0
     * @class_type 属性
     */
    target_temperature_resolution: 0 | 1;

    /**
     * 目标温度设置
     * @class_type 属性
     */
    target_temperature_settings: {
        /**
         * 温控模式
         * @default 0
         * @class_type 属性
         */
        temperature_control_mode?: number;

        /**
         * 制热目标温度
         * @default 17
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         */
        heat: number;

        /**
         * 紧急制热目标温度
         * @default 25
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         */
        em_heat: number;

        /**
         * 制冷目标温度
         * @default 28
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         */
        cool: number;

        /**
         * 自动目标温度
         * @default 23
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         */
        auto: number;

        /**
         * 自动-制热温度
         * @default 17
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         */
        auto_heat: number;

        /**
         * 自动-制冷温度
         * @default 28
         * @class_type 属性
         * @max_value 35
         * @min_value 5
         */
        auto_cool: number;
    };

    /**
     * 最小死区
     * @default 5
     * @class_type 属性
     * @max_value 30
     * @min_value 1
     * @decimal_digits 1
     */
    minimum_dead_zone: number;

    /**
     * 目标温度范围
     * @class_type 属性
     */
    target_temperature_range: {
        /**
         * 目标温度范围ID - 0：制热 1：紧急制热 2：制冷 3：自动 
         * @default 0
         * @class_type 属性
         */
        id?: 0 | 1 | 2 | 3;

        /**
         * 制热目标温度范围
         * @class_type 属性
         */
        heat: {
            /**
             * 下限值
             * @default 10
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            min: number;

            /**
             * 上限值
             * @default 17
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            max: number;
        };

        /**
         * 紧急制热目标温度范围
         * @class_type 属性
         */
        em_heat: {
            /**
             * 下限值
             * @default 10
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            min: number;

            /**
             * 上限值
             * @default 28
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            max: number;
        };

        /**
         * 制冷目标温度范围
         * @class_type 属性
         */
        cool: {
            /**
             * 下限值
             * @default 23
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            min: number;

            /**
             * 上限值
             * @default 35
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            max: number;
        };

        /**
         * 自动目标温度范围
         * @class_type 属性
         */
        auto: {
            /**
             * 下限值
             * @default 10
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            min: number;

            /**
             * 上限值
             * @default 35
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            max: number;
        };
    };

    /**
     * 风扇模式 - 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速
     * @default 0
     * @class_type 属性
     * @max_value 5
     * @min_value 0
     */
    fan_control_mode: 0 | 1 | 2 | 3 | 4 | 5;

    /**
     * 占用检测
     * @class_type 属性
     */
    pir_common: {
        /**
         * 二级命令ID
         * @default 0
         * @class_type 属性
         */
        cmd?: number;

        /**
         * 占用检测 - 0:禁用 1:启用
         * @default 1
         * @class_type 属性
         * @max_value 1
         * @min_value 0
         */
        enable: 0 | 1;

        /**
         * 空闲时间
         * @default 30
         * @class_type 属性
         * @max_value 360
         * @min_value 1
         */
        release_time: number;

        /**
         * 节能检测模式 - 0:立即触发 1:规则触发
         * @class_type 属性
         */
        mode: 0 | 1;

        /**
         * 节能触发条件
         * @class_type 属性
         */
        check: {
            /**
             * 节能持续时间
             * @default 5
             * @class_type 属性
             * @max_value 60
             * @min_value 1
             */
            period: number;

            /**
             * 节能触发比例
             * @default 50
             * @class_type 属性
             * @max_value 100
             * @min_value 1
             */
            rate: number;
        };
    };

    /**
     * 节能设置
     * @class_type 属性
     */
    pir_energy: {
        /**
         * 二级命令ID
         * @default 0
         * @class_type 属性
         */
        cmd?: number;

        /**
         * 节能设置 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         * @max_value 1
         * @min_value 0
         */
        enable: 0 | 1;

        /**
         * 节能计划
         * @class_type 属性
         */
        plan: {
            /**
             * 占用执行
             * @default 0
             * @class_type 属性
             * @max_value 255
             * @min_value 0
             */
            occupied: number;

            /**
             * 空闲执行
             * @default 1
             * @class_type 属性
             * @max_value 255
             * @min_value 0
             */
            unoccupied: number;
        };
    };

    /**
     * 夜间占用设置
     * @class_type 属性
     */
    pir_night: {
        /**
         * 二级命令ID
         * @default 1
         * @class_type 属性
         */
        cmd?: number;

        /**
         * 夜间占用设置 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         * @max_value 1
         * @min_value 0
         */
        enable: 0 | 1;

        /**
         * 夜间时间
         * @class_type 属性
         */
        night_time: {
            /**
             * 开始时间
             * @default 1260
             * @class_type 属性
             * @max_value 1439
             * @min_value 0
             */
            start: number;

            /**
             * 结束时间
             * @default 480
             * @class_type 属性
             * @max_value 1439
             * @min_value 0
             */
            stop: number;
        };

        /**
         * 夜间占用执行
         * @default 2
         * @class_type 属性
         * @max_value 255
         * @min_value 0
         */
        occupied: number;

        /**
         * 夜间检测模式 - 0:立即触发 1:规则触发
         * @default 0
         * @class_type 属性
         */
        mode: 0 | 1;

        /**
         * 夜间触发条件
         * @class_type 属性
         */
        check: {
            /**
             * 夜间持续时间
             * @default 5
             * @class_type 属性
             * @max_value 60
             * @min_value 1
             */
            period: number;

            /**
             * 夜间触发比例
             * @default 50
             * @class_type 属性
             * @max_value 100
             * @min_value 1
             */
            rate: number;
        };
    };

    /**
     * 屏幕显示设置
     * @class_type 属性
     */
    screen_display_settings: {
        /**
         * 计划名称 - 0:禁用 1:启用
         * @default 1
         * @class_type 属性
         */
        plan_name: 0 | 1;

        /**
         * 环境温度 - 0:禁用 1:启用
         * @default 1
         * @class_type 属性
         */
        ambient_temp: 0 | 1;

        /**
         * 环境湿度 - 0:禁用 1:启用
         * @default 1
         * @class_type 属性
         */
        ambient_humi: 0 | 1;

        /**
         * 目标温度 - 0:禁用 1:启用
         * @default 1
         * @class_type 属性
         */
        target_temp: 0 | 1;

        /**
         * 预留
         * @default 0
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 按键自定义功能
     * @class_type 属性
     */
    button_custom_function: {
        /**
         * 二级命令ID
         * @default 0
         * @class_type 属性
         */
        subcmd?: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 按键1功能 - 1：温控模式 2：风扇模式 3：计划切换 4：状态上报 5：滤网清洁告警解除 6：按键上报 7：温度单位切换 
         * @default 1
         * @class_type 属性
         */
        mode1: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 按键2功能 - 1：温控模式 2：风扇模式 3：计划切换 4：状态上报 5：滤网清洁告警解除 6：按键上报 7：温度单位切换  
         * @default 2
         * @class_type 属性
         */
        mode2: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 按键3功能 -  0：系统开关 3：计划切换 4：状态上报 5：滤网清洁告警解除 6：按键上报 7：温度单位切换 
         * @default 0
         * @class_type 属性
         */
        mode3: 0 | 3 | 4 | 5 | 6 | 7;
    };

    /**
     * 儿童锁
     * @class_type 属性
     */
    children_lock_settings: {
        /**
         * 使能 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 温度+ - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        temp_up: 0 | 1;

        /**
         * 温度- - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        temp_down: 0 | 1;

        /**
         * 系统开关 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        system_on_off: 0 | 1;

        /**
         * 风扇模式 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        fan_mode: 0 | 1;

        /**
         * 温控模式 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        temperature_control_mode: 0 | 1;

        /**
         * 重置&重启 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        reboot_reset: 0 | 1;

        /**
         * 开关机 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        power_on_off: 0 | 1;

        /**
         * 取消配对 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        cancel_pair: 0 | 1;

        /**
         * 计划切换 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        plan_switch: 0 | 1;

        /**
         * 状态上报 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        status_report: 0 | 1;

        /**
         * 滤网清洁告警解除 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        filter_clean_alarm_release: 0 | 1;

        /**
         * 按键上报1 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        button1_event: 0 | 1;

        /**
         * 按键上报2 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        button2_event: 0 | 1;

        /**
         * 按键上报3 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        button3_event: 0 | 1;

        /**
         * 温度单位切换 - 0:禁用 1:启用
         * @default 0
         * @class_type 属性
         */
        temperature_unit_switch: 0 | 1;

        /**
         * 预留
         * @default 0
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 临时解锁
     * @class_type 属性
     */
    unlock_button: {
        /**
         * 临时解锁使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 临时解锁时间
         * @default 30
         * @class_type 属性
         * @max_value 3600
         * @min_value 1
         */
        timeout: number;
    };

    /**
     * 临时解锁组合键
     * @class_type 属性
     */
    unlock_combination_button_settings: {
        /**
         * 按键1 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        button1: 0 | 1;

        /**
         * 按键2 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        button2: 0 | 1;

        /**
         * 按键3 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        button3: 0 | 1;

        /**
         * 按键4 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        button4: 0 | 1;

        /**
         * 按键5 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        button5: 0 | 1;

        /**
         * 预留
         * @default 0
         * @class_type 属性
         */
        reserved: number;
    };

    /**
     * 智能显示 - 0：禁用 1：启用
     * @default 1
     * @class_type 属性
     */
    intelligent_display_enable: 0 | 1;

    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     * @class_type 属性
     * @max_value 32767
     * @min_value -32768
     */
    time_zone: number;

    /**
     * 夏令时
     * @class_type 属性
     */
    daylight_saving_time: {
        /**
         * 夏令时 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 偏移时间
         * @default 60
         * @class_type 属性
         * @max_value 120
         * @min_value 1
         */
        daylight_saving_time_offset: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         * @max_value 12
         * @min_value 1
         */
        start_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         * @max_value 2
         * @min_value 1
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 1
         * @class_type 属性
         * @max_value 7
         * @min_value 1
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         * @max_value 1380
         * @min_value 0
         */
        start_hour_min: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 1
         * @class_type 属性
         * @max_value 12
         * @min_value 1
         */
        end_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         * @max_value 5
         * @min_value 1
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 1
         * @class_type 属性
         * @max_value 7
         * @min_value 1
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         * @max_value 1380
         * @min_value 0
         */
        end_hour_min: number;
    };

    /**
     * 温度校准设置
     * @class_type 属性
     */
    temperature_calibration_settings: {
        /**
         * 温度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 80
         * @min_value -80
         * @decimal_digits 2
         */
        calibration_value: number;
    };

    /**
     * 湿度校准设置
     * @class_type 属性
     */
    humidity_calibration_settings: {
        /**
         * 湿度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value -100
         * @decimal_digits 1
         */
        calibration_value: number;
    };

    /**
     * 计划配置
     * @class_type 属性
     * @array_length 8
     */
    schedule_settings: {
        /**
         * 计划序号
         * @default 0
         * @class_type 属性
         * @max_value 15
         * @min_value 0
         */
        id: number;

        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;

        /**
         * 计划使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;

        /**
         * 命名前6B
         * @class_type 属性
         * @string_length 6
         * @character_encoding ascii
         */
        name_first: string;

        /**
         * 命名后4B
         * @class_type 属性
         * @string_length 4
         * @character_encoding ascii
         */
        name_last: string;

        /**
         * 计划内容
         * @class_type 属性
         */
        content1: {
            /**
             * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动 10：关
             * @default 0
             * @class_type 属性
             * @max_value 255
             * @min_value 0
             */
            tstat_mode: 0 | 1 | 2 | 3 | 10;

            /**
             * 制热目标温度
             * @default 17
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            heat_target_temperature: number;

            /**
             * 紧急制热目标温度
             * @default 25
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            em_heat_target_temperature: number;

            /**
             * 制冷目标温度
             * @default 28
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            cool_target_temperature: number;
        };

        /**
         * 计划内容
         * @class_type 属性
         */
        content2: {
            /**
             * 风扇模式 - 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速 10：关
             * @default 0
             * @class_type 属性
             * @max_value 255
             * @min_value 0
             */
            fan_mode: 0 | 1 | 2 | 3 | 4 | 5 | 10;

            /**
             * 自动目标温度
             * @default 23
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            auto_target_temperature: number;

            /**
             * 自动制热目标温度
             * @default 17
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            auto_heat_target_temperature: number;

            /**
             * 自动制冷目标温度
             * @default 28
             * @class_type 属性
             * @max_value 35
             * @min_value 5
             * @decimal_digits 1
             */
            auto_cool_target_temperature: number;
        };
    }[];

    /**
     * 采集周期
     * @class_type 属性
     */
    collection_interval?: {
        /**
         * 采集周期单位 - 0：秒 1：分
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;

        /**
         * 采集周期
         * @default 30
         * @class_type 属性
         * @max_value 3600
         * @min_value 1
         */
        seconds_of_time?: number;

        /**
         * 采集周期
         * @default 1
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        minutes_of_time?: number;
    };

    /**
     * 通讯模式 - 0：BLE 1：LoRa 2：BLE+LoRa 3：PowerBus+LoRa
     * @default 1
     * @class_type 属性
     * @max_value 3
     * @min_value 0
     */
    communication_mode: 0 | 1 | 2 | 3;

    /**
     * 上报周期
     * @class_type 属性
     */
    reporting_interval: {
        /**
         * 上报周期类型 - 0：BLE 1：LORA 2：BLE+LORA 3：POWERBUS+lora
         * @default 0
         * @class_type 属性
         */
        type?: 0 | 1 | 2 | 3;

        /**
         * BLE上报周期
         * @class_type 属性
         */
        ble?: {
            /**
             * 上报单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * LORA上报周期
         * @class_type 属性
         */
        lora: {
            /**
             * 上报单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * BLE_LORA上报周期
         * @class_type 属性
         */
        ble_lora: {
            /**
             * 上报单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * POWERBUS_LORA上报周期
         * @class_type 属性
         */
        power_lora: {
            /**
             * 上报单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 上报周期
             * @default 600
             * @class_type 属性
             * @max_value 64800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 上报周期
             * @default 10
             * @class_type 属性
             * @max_value 1440
             * @min_value 1
             */
            minutes_of_time?: number;
        };
    };

    /**
     * 通讯周期
     * @class_type 属性
     */
    communicate_interval: {
        /**
         * 通讯周期ID - 0:BLE 1:LORA 2:BLE+LORA 3:POWERBUS+LORA
         * @default 0
         * @class_type 属性
         */
        id?: 0 | 1 | 2 | 3;

        /**
         * BLE通讯周期
         * @class_type 属性
         */
        ble: {
            /**
             * 通讯单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 通讯周期
             * @default 600
             * @class_type 属性
             * @max_value 1800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 通讯周期
             * @default 1
             * @class_type 属性
             * @max_value 30
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * LORA通讯周期
         * @class_type 属性
         */
        lora?: {
            /**
             * 通讯单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 通讯周期
             * @default 600
             * @class_type 属性
             * @max_value 1800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 通讯周期
             * @default 1
             * @class_type 属性
             * @max_value 30
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * BLE_LORA通讯周期
         * @class_type 属性
         */
        ble_lora: {
            /**
             * 通讯单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 通讯周期
             * @default 600
             * @class_type 属性
             * @max_value 1800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 通讯周期
             * @default 1
             * @class_type 属性
             * @max_value 30
             * @min_value 1
             */
            minutes_of_time?: number;
        };

        /**
         * POWERBUS通讯周期
         * @class_type 属性
         */
        power_bus: {
            /**
             * 通讯单位 - 0：秒 1：分
             * @default 1
             * @class_type 属性
             * @is_one_of
             */
            unit: 0 | 1;

            /**
             * 通讯周期
             * @default 600
             * @class_type 属性
             * @max_value 1800
             * @min_value 10
             */
            seconds_of_time?: number;

            /**
             * 通讯周期
             * @default 1
             * @class_type 属性
             * @max_value 30
             * @min_value 1
             */
            minutes_of_time?: number;
        };
    };

    /**
     * 蓝牙配对名称
     * @class_type 属性
     * @array_length 32
     * @character_encoding ascii
     */
    ble_name: string;

    /**
     * 蓝牙配对信息
     * @class_type 属性
     */
    ble_pair_info: {
        /**
         * 地址类型 - 0：公共 1：随机
         * @default 0
         * @class_type 属性
         */
        addr_type: 0 | 1;

        /**
         * 蓝牙地址
         * @class_type 属性
         * @array_length 6
         * @character_encoding hex
         */
        address: string;

        /**
         * 蓝牙名称
         * @class_type 属性
         * @array_length 32
         * @character_encoding ascii
         */
        name: string;
    };

    /**
     * 系统状态控制
     * @class_type 属性
     */
    system_status_control?: {
        /**
         * 系统开关 - 0：系统关 1：系统开
         * @default 1
         * @class_type 参数
         */
        on_off?: 0 | 1;

        /**
         * 温控模式 - 0：制热 1：紧急制热 2：制冷 3：自动
         * @default 0
         * @class_type 参数
         * @max_value 3
         * @min_value 0
         */
        mode?: 0 | 1 | 2 | 3;

        /**
         * 制热目标温度
         * @default 17
         * @class_type 参数
         * @max_value 35
         * @min_value 5
         * @decimal_digits 1
         */
        temperature1?: number;

        /**
         * 制冷目标温度
         * @default 28
         * @class_type 参数
         * @decimal_digits 1
         */
        temperature2?: number;
    };

    /**
     * 外部温度
     * @class_type 服务
     * @max_value 60
     * @min_value -20
     * @decimal_digits 1
     */
    origin_temperature?: number;

    /**
     * 外部湿度
     * @class_type 服务
     * @max_value 100
     * @min_value 0
     * @decimal_digits 1
     */
    origin_humidity?: number;

    /**
     * 插入临时计划
     * @class_type 服务
     */
    insert_temporary_plan?: {
        /**
         * 计划ID
         * @default 0
         * @class_type 参数
         * @max_value 15
         * @min_value 0
         */
        id?: number;
    };

    /**
     * 风扇故障告警
     * @class_type 服务
     */
    fan_error_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 滤网清洁提醒
     * @class_type 服务
     */
    filter_clean_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 防冻保护告警
     * @class_type 服务
     */
    frost_protection_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 开窗告警
     * @class_type 服务
     */
    open_window_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 未接线告警
     * @class_type 服务
     */
    not_wired_alarm?: {
        /**
         * 动作 - 0：清除告警 1：触发告警
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 蓝牙配对
     * @class_type 服务
     */
    bluetooth_pairing?: {
        /**
         * 动作 - 0：取消配对 1：重新配对
         * @default 0
         * @class_type 参数
         */
        mode?: 0 | 1;
    };

    /**
     * 重置蓝牙名称
     * @class_type 服务
     */
    reset_ble_name?: Record<string, any>;

    /**
     * 重置
     * @class_type 服务
     */
    reset?: Record<string, any>;

    /**
     * 重启
     * @class_type 服务
     */
    reboot?: Record<string, any>;

    /**
     * 清除历史记录
     * @class_type 服务
     */
    clear_historical_data?: Record<string, any>;

    /**
     * 停止查询回传
     * @class_type 服务
     */
    stop_historical_data_retrieval?: Record<string, any>;

    /**
     * 回传某个时间点的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time?: {
        /**
         * 时间点
         * @class_type 参数
         */
        time?: number;
    };

    /**
     * 回传某个时间段的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time_range?: {
        /**
         * 起始时间
         * @class_type 参数
         */
        start_time?: number;

        /**
         * 结束时间
         * @class_type 参数
         */
        end_time?: number;
    };

    /**
     * 查询设备状态
     * @class_type 服务
     */
    query_device_status?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    synchronize_time?: Record<string, any>;

    /**
     * 时间同步
     * @class_type 服务
     */
    set_time?: {
        /**
         * 时间戳
         * @class_type 参数
         */
        timestamp?: number;
    };

    /**
     * 重新连接网络
     * @class_type 服务
     */
    reconnect?: Record<string, any>;

    /**
     * 删除计划
     * @class_type 服务
     */
    delete_task_plan?: {
        /**
         * 删除计划 - 0：计划一 1：计划二 2：计划三 3：计划四 4：计划五 5：计划六 6：计划七 7：计划八 255：重置计划
         * @default 255
         * @class_type 参数
         * @max_value 255
         * @min_value 0
         */
        type?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 255;
    };

    /**
     * 屏幕显示预配置
     * @class_type 属性
     * @array_length 25
     */
    screen_content_settings: {
        /**
         * 预配置对象 - 0：重启 1：重置 2：过温保护 3：通风图标 4：通风文字 5：制热图标 6：制热文字 7：制冷图标 8：制冷文字 9：风扇自动图标 10：风扇自动文字 11：风扇低速图标 12：风扇低速文字 13：风扇中速图标 14：风扇中速文字 15：风扇高速图标 16：风扇高速文字 17：温度设定 18：计划图标 19：计划1名称 20：计划2名称 21：计划3名称 22：计划4名称 23：计划5名称 24：计划6名称 25：计划7名称 26：计划8名称 27：计划9名称 28：计划10名称 29：计划11名称 30：计划12名称 31：计划13名称 32：计划14名称 33：计划15名称 34：计划16名称
         * @default 0
         * @class_type 属性
         * @max_value 34
         * @min_value 0
         */
        object: number;

        /**
         * 图片长度
         * @default 0
         * @class_type 属性
         * @max_value 65535
         * @min_value 0
         */
        length: number;

        /**
         * 内容
         * @default 0
         * @class_type 属性
         * @string_length 65535
         * @character_encoding hex
         */
        data: string;
    }[];
}
