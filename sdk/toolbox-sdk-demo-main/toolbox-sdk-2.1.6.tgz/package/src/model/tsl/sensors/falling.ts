
export interface FallingSensorInfo {
  /**
   * 跌落告警配置
   * @class_type 属性
   */
  falling_alarm_settings: {
    /**
     * 跌落检测使能 - 0: 禁用 1: 启用
     * @default 0
     * @class_type 属性
     */
    enable: 0 | 1;
  };
  /**
  * 跌落告警配置
  * @class_type 属性
  */
  falling_threshold_alarm_settings?: {
    /**
     * 跌落加速度阈值 - 0: FREE_FALL_LEVEL_156 1: FREE_FALL_LEVEL_219 2: FREE_FALL_LEVEL_250 3: FREE_FALL_LEVEL_312 4: FREE_FALL_LEVEL_344 5: FREE_FALL_LEVEL_406 6: FREE_FALL_LEVEL_469 7: FREE_FALL_LEVEL_500 
     * @default 7
     * @class_type 属性
     */
    threshold_level: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

    /**
     * 跌落持续时间等级
     * @default 32
     * @class_type 属性
     * @max_value 32
     * @min_value 1
     */
    time_level: number;
  };
}
