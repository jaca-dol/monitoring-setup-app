import { FallingSensorInfo } from './falling';
import { LightSensorInfo } from './light';
import { TiltSensorInfo } from './tilt';

export * from './falling';
export * from './light';
export * from './tilt';

export type SensorInfoList = TiltSensorInfo & LightSensorInfo & FallingSensorInfo;
