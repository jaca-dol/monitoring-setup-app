
export interface TiltSensorInfo {
  /**
    * 倾斜阈值告警配置
    * @class_type 属性
    */
  tilt_alarm_settings: {
    /**
     * 阈值告警使能 - 0: 禁用 1: 启用
     * @default 0
     * @class_type 属性
     */
    enable: 0 | 1;

    /**
     * 阈值条件 - 0:禁用 1:条件：x<A 2:条件：x>B 3:条件：A<x<B 4:条件：x<A或x>B
     * @default 0
     * @class_type 属性
     */
    threshold_condition: 0 | 1 | 2 | 3 | 4;

    /**
     * 告警阈值
     * @default 10
     * @class_type 属性
     * @max_value 90
     * @min_value 1
     */
    threshold_max: number;

    /**
     * 持续时间
     * @default 2
     * @class_type 属性
     * @max_value 60
     * @min_value 1
     */
    duration: number;
  };

  /**
     * 设备倾斜告警
     * @class_type 事件
     */
  tilt_alarm?: {
    /**
     * 告警类型
     * @class_type 参数
     * @is_one_of
     */
    type?: number;

    /**
     * 采集错误
     * @class_type 参数
     */
    collection_error?: Record<string, any>;

    /**
     * 超量程下限
     * @class_type 参数
     */
    lower_range_error?: Record<string, any>;

    /**
     * 超量程上限
     * @class_type 参数
     */
    over_range_error?: Record<string, any>;

    /**
     * 无数据
     * @class_type 参数
     */
    no_data?: Record<string, any>;

    /**
     * 倾斜告警解除
     * @class_type 参数
     */
    threshold_alarm_deactivation?: Record<string, any>;

    /**
     * 倾斜告警触发
     * @class_type 参数
     */
    threshold_alarm_trigger?: Record<string, any>;

    /**
     * 跌落告警
     * @class_type 参数
     */
    falling_alarm_trigger?: Record<string, any>;
  };
}
