
export interface LightSensorInfo {
  /**
    * 光照告警
    * @class_type 事件
    */
  light_alarm?: {
    /**
     * 告警类型
     * @class_type 参数
     * @is_one_of
     */
    type?: number;

    /**
     * 采集错误
     * @class_type 参数
     */
    collection_error?: Record<string, any>;

    /**
     * 超量程下限
     * @class_type 参数
     */
    lower_range_error?: Record<string, any>;

    /**
     * 超量程上限
     * @class_type 参数
     */
    over_range_error?: Record<string, any>;

    /**
     * 无数据
     * @class_type 参数
     */
    no_data?: Record<string, any>;

    /**
     * 光照由亮变暗
     * @class_type 参数
     */
    threshold_alarm_deactivation?: Record<string, any>;

    /**
     * 光照由暗变亮
     * @class_type 参数
     */
    threshold_alarm_trigger?: Record<string, any>;
  };

  /**
     * 光照阈值告警配置
     * @class_type 属性
     */
  light_alarm_settings: {
    /**
     * 阈值告警使能 - 0: 禁用 1: 启用
     * @default 1
     * @class_type 属性
     */
    enable: 0 | 1;

    /**
     * 阈值条件 - 0:禁用 1:条件：x<A 2:条件：x>B 3:条件：A<x<B 4:条件：x<A或x>B
     * @default 2
     * @class_type 属性
     */
    threshold_condition: 0 | 1 | 2 | 3 | 4;

    /**
     * 告警阈值
     * @default 50
     * @class_type 属性
     * @max_value 600
     * @min_value 0
     */
    threshold_max: number;
  };

  /**
    * 光照采集周期
    * @class_type 属性
    */
  light_collection_interval: {
    /**
     * 光照采集周期单位 - 0：秒 1：分
     * @default 1
     * @class_type 属性
     * @is_one_of
     */
    unit?: 0 | 1;

    /**
     * 光照采集周期值(秒)
     * @default 60
     * @class_type 属性
     * @max_value 64800
     * @min_value 10
     */
    seconds_of_time?: number;

    /**
     * 光照采集周期值(分)
     * @default 1
     * @class_type 属性
     * @max_value 1440
     * @min_value 1
     */
    minutes_of_time?: number;
  };

  /**
   * 光照抖动阈值
   * @default 50
   */
  light_tolerance_value: number;
}
