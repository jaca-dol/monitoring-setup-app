export interface UC50XCAT1TSLInfo {
    /**
     * 上报周期
     */
    reporting_interval: {
        /**
         * 上报周期单位 - 0：秒 1：分
         * @default 1
         */
        unit: 0 | 1;

        /**
         * 上报周期
         * @default 21600
         */
        seconds_of_time?: number;

        /**
         * 上报周期
         * @default 360
         */
        minutes_of_time?: number;
    };

    /**
     * 采集周期
     */
    collection_interval: {
        /**
         * 采集周期单位 - 0：秒 1：分
         * @default 0
         */
        unit: 0 | 1;

        /**
         * 采集周期
         * @default 3600
         */
        seconds_of_time?: number;

        /**
         * 采集周期
         * @default 60
         */
        minutes_of_time?: number;
    };

    /**
     * 累计次数
     * @default 2
     */
    cumulative_times: number;

    /**
     * AutoP使能 - 0：禁用 1：启用
     * @default 1
     */
    auto_p_enable: 0 | 1;

    /**
     * 重置
     */
    reset: Record<string, any>;

    /**
     * 重启
     */
    reboot: Record<string, any>;

    /**
     * 时间同步
     */
    synchronize_time: Record<string, any>;

    /**
     * 时间同步
     */
    set_time: {
        /**
         * 时间戳
         */
        timestamp: number;
    };

    /**
     * 清除历史记录
     */
    clear_historical_data: Record<string, any>;

    /**
     * 停止查询回传
     */
    stop_historical_data_retrieval: Record<string, any>;

    /**
     * 回传某个时间段的历史数据
     */
    retrieve_historical_data_by_time_range: {
        /**
         * 起始时间
         */
        start_time: number;

        /**
         * 结束时间
         */
        end_time: number;
    };

    /**
     * 回传某个时间点的历史数据
     */
    retrieve_historical_data_by_time: {
        /**
         * 时间点
         */
        time: number;
    };

    /**
     * 随机密钥 - 0：禁用 1：启用
     * @default 0
     */
    random_key: 0 | 1;

    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     */
    time_zone: number;

    /**
     * 夏令时
     */
    daylight_saving_time: {
        /**
         * 夏令时 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 偏移时间
         * @default 60
         */
        daylight_saving_time_offset: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 3
         */
        start_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 2
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 7
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         */
        start_hour_min: number;

        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月 
         * @default 11
         */
        end_month: number;

        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;

        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 1
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;

        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         */
        end_hour_min: number;
    };

    /**
     * 电池电量
     */
    battery: number;

    /**
     * 上报时间戳
     */
    timestamp: number;

    /**
     * 数字量输入1 - 0:低电平 1:高电平
     */
    digital_input_1: 0 | 1;

    /**
     * 数字量输出1 - 0:低电平 1:高电平
     */
    digital_output_1: 0 | 1;

    /**
     * 计数1
     */
    counter_1: number;

    /**
     * 数字量输入2 - 0:低电平 1:高电平
     */
    digital_input_2: 0 | 1;

    /**
     * 数字量输出2 - 0:低电平 1:高电平
     */
    digital_output_2: 0 | 1;

    /**
     * 计数2
     */
    counter_2: number;

    /**
     * 模拟输入量1
     */
    analog_input_1: {
        /**
         * 信号类型 - 0:4-20mA 1:0-10V
         */
        signal_type: 0 | 1;

        /**
         * 上报类型 - 0:当前值 1:所有值
         */
        report_type: 0 | 1;

        /**
         * 预留
         */
        reserved: number;

        /**
         * 当前值
         */
        current_value: any;

        /**
         * 最小值
         */
        min: any;

        /**
         * 最大值
         */
        max: any;

        /**
         * 平均值
         */
        average: any;
    };

    /**
     * 模拟输入量2
     */
    analog_input_2: {
        /**
         * 信号类型 - 0:4-20mA 1:0-10V
         */
        signal_type: 0 | 1;

        /**
         * 上报类型 - 0:当前值 1:所有值
         */
        report_type: 0 | 1;

        /**
         * 预留
         */
        reserved: number;

        /**
         * 当前值
         */
        current_value: any;

        /**
         * 最小值
         */
        min: any;

        /**
         * 最大值
         */
        max: any;

        /**
         * 平均值
         */
        average: any;
    };

    /**
     * SDI-12
     */
    sdi: {
        /**
         * SDI-12通道ID
         */
        id: number;

        /**
         * SDI-12数据长度
         */
        data_length: number;

        /**
         * SDI-12的数据
         */
        data: string;
    }[];

    /**
     * Modbus
     */
    modbus: {
        /**
         * 通道ID
         */
        id: number;

        /**
         * 寄存器ID
         */
        register_id: number;

        /**
         * 数据类型
         */
        data_type: number;

        /**
         * BOOL
         */
        bool: {
            /**
             * 值 - 0:False 1:True
             */
            value: 0 | 1;
        };

        /**
         * INT16
         */
        int16: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * UINT16
         */
        uint16: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * INT32
         */
        int32: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * UINT32
         */
        uint32: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * FLOAT
         */
        float: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * INT64
         */
        int64: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * UINT64
         */
        uint64: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * DOUBLE
         */
        double: {
            /**
             * 值
             */
            value: number;
        };
    }[];

    /**
     * 模拟量输入1报警
     */
    analog_input_1_alarm: {
        /**
         * 信号类型 - 0:4-20mA 1:0-10V
         */
        signal_type?: 0 | 1;

        /**
         * 报警状态 - 0:解除报警 1:触发报警
         */
        state?: 0 | 1;

        /**
         * 报警类型
         */
        alarm_type: number;

        /**
         * 阈值报警
         */
        threshold?: {
            /**
             * 当前值
             */
            value: any;
        };

        /**
         * 突变报警
         */
        mutation?: {
            /**
             * 当前值
             */
            value: any;

            /**
             * 变化值
             */
            diff_value: any;
        };

        /**
         * 采集失败报警
         */
        error?: Record<string, any>;
    };

    /**
     * 模拟量输入2报警
     */
    analog_input_2_alarm: {
        /**
         * 信号类型 - 0:4-20mA 1:0-10V
         */
        signal_type?: 0 | 1;

        /**
         * 报警状态 - 0:解除报警 1:触发报警
         */
        state?: 0 | 1;

        /**
         * 报警类型
         */
        alarm_type: number;

        /**
         * 阈值报警
         */
        threshold?: {
            /**
             * 当前值
             */
            value: any;
        };

        /**
         * 突变报警
         */
        mutation?: {
            /**
             * 当前值
             */
            value: any;

            /**
             * 变化值
             */
            diff_value: any;
        };

        /**
         * 采集失败报警
         */
        error?: Record<string, any>;
    };

    /**
     * GPIO1计数阈值报警
     */
    counter_1_threshold_alarm: {
        /**
         * 报警状态 - 0:解除报警 1:触发报警
         */
        alarm_state?: 0 | 1;

        /**
         * 报警类型
         */
        alarm_type: number;

        /**
         * 阈值报警
         */
        threshold?: {
            /**
             * 计数值
             */
            value: number;
        };

        /**
         * 突变报警
         */
        mutation?: {
            /**
             * 计数值
             */
            value: number;

            /**
             * 突变值
             */
            diff_value: number;
        };

        /**
         * 采集错误报警
         */
        error?: Record<string, any>;
    };

    /**
     * GPIO2计数阈值报警
     */
    counter_2_threshold_alarm: {
        /**
         * 报警状态 - 0:解除报警 1:触发报警
         */
        alarm_state?: 0 | 1;

        /**
         * 报警类型
         */
        alarm_type: number;

        /**
         * 阈值报警
         */
        threshold?: {
            /**
             * 计数值
             */
            value: number;
        };

        /**
         * 突变报警
         */
        mutation?: {
            /**
             * 计数值
             */
            value: number;

            /**
             * 突变值
             */
            diff_value: number;
        };

        /**
         * 采集错误报警
         */
        error?: Record<string, any>;
    };

    /**
     * Modbus报警
     */
    modbus_alarm: {
        /**
         * 通道ID
         */
        channel_id?: number;

        /**
         * 寄存器ID
         */
        register_id?: number;

        /**
         * 告警类型 - 0: 采集异常 1: 值大于触发告警 2: 值大于解除告警 3: 值小于触发告警 4: 值大于解除告警 5: 值介于触发告警 6: 值介于解除告警 7: 值不介于触发告警 8: 值不介于解除告警 9: 值等于触发告警 (值真值假) 10: 值等于解除告警 (值真值假) 11: 值突变触发告警 12: 值突变解除告警 13: 值突变触发告警突变值 14: 值突变解除告警突变值
         */
        alarm_type?: number;

        /**
         * 数据类型 - 0: bool 1: int16 2: uint16 3: int32 4: uint32 5: float 6: int64 7: uint64 8: double
         */
        data_type: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

        /**
         * BOOL
         */
        data_bool?: {
            /**
             * 值 - 0:False 1:True
             */
            value: 0 | 1;
        };

        /**
         * INT16
         */
        data_int16?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * UINT16
         */
        data_uint16?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * INT32
         */
        data_int32?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * UINT32
         */
        data_uint32?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * FLOAT
         */
        data_float?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * INT64
         */
        data_int64?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * UINT64
         */
        data_uint64?: {
            /**
             * 值
             */
            value: number;
        };

        /**
         * DOUBLE
         */
        data_double?: {
            /**
             * 值
             */
            value: number;
        };
    };

    /**
     * GPIO1调试
     */
    gpio_1_debug: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 开启计数
         */
        start_count: Record<string, any>;

        /**
         * 停止计数
         */
        stop_count: Record<string, any>;

        /**
         * 配置计数
         * @default 0
         */
        config_count: number;

        /**
         * 切换GPIO状态
         */
        switch_state: Record<string, any>;
    };

    /**
     * GPIO2调试
     */
    gpio_2_debug: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 开启计数
         */
        start_count: Record<string, any>;

        /**
         * 停止计数
         */
        stop_count: Record<string, any>;

        /**
         * 配置计数
         * @default 0
         */
        config_count: number;

        /**
         * 切换GPIO状态
         */
        switch_state: Record<string, any>;
    };

    /**
     * 文件传输
     */
    request_file_transfer: {
        /**
         * 文件类型 - 1：根证书 2：用户证书 3：私有密钥
         * @default 1
         */
        file_type: 1 | 2 | 3;

        /**
         * 文件传输操作类型 - 0：写入文件 1：擦除文件
         * @default 0
         */
        operate_type: 0 | 1;

        /**
         * 证书类型 - 3：AWS  4：MQTT 
         * @default 4
         */
        cert_type: 3 | 4;

        /**
         * 传输长度
         * @default 1
         */
        length: number;

        /**
         * 文件内容
         */
        data: string;
    };

    /**
     * 采集Modbus所有通道
     */
    collect_all_modbus_channels: Record<string, any>;

    /**
     * 采集Modbus单个通道
     */
    collect_single_modbus_channels: number;

    /**
     * 采集SDI所有通道
     */
    collect_all_sdi_channels: Record<string, any>;

    /**
     * 采集SDI单个通道
     */
    collect_single_sdi_channels: number;

    /**
     * 采集AI1
     */
    collect_ai1: Record<string, any>;

    /**
     * 采集AI2
     */
    collect_ai2: Record<string, any>;

    /**
     * 数据存储设置
     */
    data_storage_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 数据存储 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 重传 - 0：禁用 1：启用
         * @default 0
         */
        retransmission_enable: 0 | 1;

        /**
         * 重传周期
         * @default 600
         */
        retransmission_interval: number;

        /**
         * 回传周期
         * @default 60
         */
        retrieval_interval: number;
    };

    /**
     * AI输出接口配置
     */
    ai_output_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 12V供电使能 - 0：禁用 1：启用
         * @default 0
         */
        v12_enable: 0 | 1;

        /**
         * 12V供电电流
         * @default 0
         */
        v12_power_current: number;

        /**
         * 采集前供电时长
         * @default 10
         */
        v12_power_time: number;

        /**
         * 3.3V供电使能 - 0：禁用 1：启用
         * @default 0
         */
        v33_enable: 0 | 1;

        /**
         * 3.3V供电方式 - 0：持续供电 1：可配置供电
         * @default 0
         */
        v33_power_mode: 0 | 1;

        /**
         * 3.3V供电电流
         * @default 0
         */
        v33_power_current: number;

        /**
         * 采集前供电时长
         * @default 10
         */
        v33_power_time: number;
    };

    /**
     * AI1接口配置
     */
    ai_1_interface_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * AI1使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 信号类型 - 0: 4-20mA 1: 0-10V
         * @default 0
         */
        signal_type: 0 | 1;

        /**
         * 电流Osh
         * @default 20
         */
        current_osh: number;

        /**
         * 电流Osl
         * @default 4
         */
        current_osl: number;

        /**
         * 电流测量单位
         * @default mA
         */
        current_unit: string;

        /**
         * 电压Osh
         * @default 10
         */
        voltage_osh: number;

        /**
         * 电压Osl
         * @default 0
         */
        voltage_osl: number;

        /**
         * 电压测量单位
         * @default V
         */
        voltage_unit: string;
    };

    /**
     * AI2接口配置
     */
    ai_2_interface_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * AI2使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 信号类型 - 0: 4-20mA 1: 0-10V
         * @default 0
         */
        signal_type: 0 | 1;

        /**
         * 电流Osh
         * @default 20
         */
        current_osh: number;

        /**
         * 电流Osl
         * @default 4
         */
        current_osl: number;

        /**
         * 电流测量单位
         * @default mA
         */
        current_unit: string;

        /**
         * 电压Osh
         * @default 10
         */
        voltage_osh: number;

        /**
         * 电压Osl
         * @default 0
         */
        voltage_osl: number;

        /**
         * 电压测量单位
         * @default V
         */
        voltage_unit: string;
    };

    /**
     * 串口基础配置
     */
    serial_base_config: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 串口使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 串口模式 - 0：RS485 1：RS232
         * @default 0
         */
        mode: 0 | 1;
    };

    /**
     * 串口输出配置
     */
    serial_output_config: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 12V供电使能 - 0：禁用 1：启用
         * @default 0
         */
        v12_enable: 0 | 1;

        /**
         * 12V供电电流
         * @default 0
         */
        v12_power_current: number;

        /**
         * 采集前供电时长
         * @default 10
         */
        v12_power_time: number;

        /**
         * 3.3V供电使能 - 0：禁用 1：启用
         * @default 0
         */
        v33_enable: 0 | 1;

        /**
         * 3.3V供电方式 - 0：持续供电 1：可配置供电
         * @default 0
         */
        v33_power_mode: 0 | 1;

        /**
         * 3.3V供电电流
         * @default 0
         */
        v33_power_current: number;

        /**
         * 采集前供电时长
         * @default 10
         */
        v33_power_time: number;
    };

    /**
     * RS485配置
     */
    serial_rs485_config: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 波特率 - 1200: 1200 2400: 2400 4800: 4800 9600: 9600 14400: 14400 19200: 19200 38400: 38400 57600: 57600 115200: 115200
         * @default 9600
         */
        baud_rate: 1200 | 2400 | 4800 | 9600 | 14400 | 19200 | 38400 | 57600 | 115200;

        /**
         * 数据位长度 - 7: 7 8: 8
         * @default 8
         */
        data_bit: 7 | 8;

        /**
         * 停止位长度 - 1: 1 2: 2
         * @default 1
         */
        stop_bit: 1 | 2;

        /**
         * 奇偶校验位 - 0: 无校验 1: 奇校验 2: 偶校验
         * @default 0
         */
        parity: 0 | 1 | 2;

        /**
         * 指令执行间隔
         * @default 50
         */
        cmd_interval: number;

        /**
         * 指令超时时间
         * @default 500
         */
        cmd_timeout: number;

        /**
         * 指令重试次数
         * @default 3
         */
        retry_time: number;

        /**
         * 开启RS485透传 - 0：禁用 1：启用
         * @default 0
         */
        enable_passthrough: 0 | 1;

        /**
         * 透传服务器类型 - 1: UDP 2: TCP 4: MQTT
         * @default 4
         */
        passthrough_server_type: 1 | 2 | 4;
    };

    /**
     * TCP设置
     */
    serial_rs485_config_tcp_settings: {
        /**
         * TCP设置序号
         * @default 0
         */
        id: number;

        /**
         * TCP设置指令
         * @default 0
         */
        command?: number;

        /**
         * 启用服务器 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 服务器地址
         */
        server_address: string;

        /**
         * 端口
         * @default 1000
         */
        server_port: number;

        /**
         * 重连次数
         * @default 0
         */
        retry_count: number;

        /**
         * 重连间隔
         * @default 5
         */
        retry_interval: number;

        /**
         * 保活间隔
         * @default 300
         */
        keepalive_interval: number;

        /**
         * TCP状态 - 0：连接失败 1：连接成功
         */
        tcp_status: 0 | 1;
    }[];

    /**
     * UDP设置
     */
    serial_rs485_config_udp_settings: {
        /**
         * UDP设置序号
         * @default 0
         */
        id: number;

        /**
         * UDP设置指令
         * @default 0
         */
        command?: number;

        /**
         * 启用服务器 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 服务器地址
         */
        server_address: string;

        /**
         * 端口
         * @default 1000
         */
        server_port: number;

        /**
         * UDP状态 - 0：连接失败 1：连接成功
         */
        udp_status: 0 | 1;
    }[];

    /**
     * RS232配置
     */
    serial_rs232_config: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 波特率 - 1200: 1200 2400: 2400 4800: 4800 9600: 9600 14400: 14400 19200: 19200 38400: 38400 57600: 57600 115200: 115200
         * @default 9600
         */
        baud_rate: 1200 | 2400 | 4800 | 9600 | 14400 | 19200 | 38400 | 57600 | 115200;

        /**
         * 数据位长度 - 7: 7 8: 8
         * @default 8
         */
        data_bit: 7 | 8;

        /**
         * 停止位长度 - 1: 1 2: 2
         * @default 1
         */
        stop_bit: 1 | 2;

        /**
         * 奇偶校验位 - 0: 无校验 1: 奇校验 2: 偶校验
         * @default 0
         */
        parity: 0 | 1 | 2;

        /**
         * 透传服务器类型 - 1: UDP 2: TCP 4: MQTT
         * @default 4
         */
        passthrough_server_type: 1 | 2 | 4;

        /**
         * 串口分帧长度
         * @default 256
         */
        frame_length: number;

        /**
         * 串口分帧间隔
         * @default 100
         */
        frame_interval: number;
    };

    /**
     * TCP设置
     */
    serial_rs232_config_tcp_settings: {
        /**
         * TCP设置序号
         * @default 0
         */
        id: number;

        /**
         * TCP设置指令
         * @default 0
         */
        command?: number;

        /**
         * 启用服务器 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 服务器地址
         */
        server_address: string;

        /**
         * 端口
         * @default 1000
         */
        server_port: number;

        /**
         * 重连次数
         * @default 0
         */
        retry_count: number;

        /**
         * 重连间隔
         * @default 5
         */
        retry_interval: number;

        /**
         * 保活间隔
         * @default 300
         */
        keepalive_interval: number;

        /**
         * TCP状态 - 0：连接失败 1：连接成功
         */
        tcp_status: 0 | 1;
    }[];

    /**
     * UDP设置
     */
    serial_rs232_config_udp_settings: {
        /**
         * UDP设置序号
         * @default 0
         */
        id: number;

        /**
         * UDP设置指令
         * @default 0
         */
        command?: number;

        /**
         * 启用服务器 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 服务器地址
         */
        server_address: string;

        /**
         * 端口
         * @default 1000
         */
        server_port: number;

        /**
         * UDP状态 - 0：连接失败 1：连接成功
         */
        udp_status: 0 | 1;
    }[];

    /**
     * Modbus通道配置
     */
    modbus_channel_settings: {
        /**
         * 通道号
         * @default 0
         */
        id: number;

        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 通道使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 从设备ID
         * @default 1
         */
        slave_id: number;

        /**
         * 寄存器数量
         * @default 1
         */
        quantity: number;

        /**
         * 数据类型 - 0: Coil 1: Discrete 2: Input Register(INT16_AB) 3: Input Register(INT16_BA) 4: Input Register(INT32_ABCD) 5: Input Register(INT32_BADC) 6: Input Register(INT32_CDAB) 7: Input Register(INT32_DCBA) 8: Input Register(INT32_AB) 9: Input Register(INT32_CD) 10: Input Register(FLOAT_ABCD) 11: Input Register(FLOAT_BADC) 12: Input Register(FLOAT_CDAB) 13: Input Register(FLOAT_DCBA) 14: Hold Register(INT16_AB) 15: Hold Register(INT16_BA) 16: Hold Register(INT32_ABCD) 17: Hold Register(INT32_BADC) 18: Hold Register(INT32_CDAB) 19: Hold Register(INT32_DCBA) 20: Hold Register(INT32_AB) 21: Hold Register(INT32_CD) 22: Hold Register(FLOAT_ABCD) 23: Hold Register(FLOAT_BADC) 24: Hold Register(FLOAT_CDAB) 25: Hold Register(FLOAT_DCBA) 26: Input Register(DOUBLE_ABCDEFGH) 27: Input Register(DOUBLE_GHEFCDAB) 28: Input Register(DOUBLE_BADCFEHG) 29: Input Register(DOUBLE_HGFEDCBA) 30: Input Register(INT64_ABCDEFGH) 31: Input Register(INT64_GHEFCDAB) 32: Input Register(INT64_BADCFEHG) 33: Input Register(INT64_HGFEDCBA) 34: Hold Register(DOUBLE_ABCDEFGH) 35: Hold Register(DOUBLE_GHEFCDAB) 36: Hold Register(DOUBLE_BADCFEHG) 37: Hold Register(DOUBLE_HGFEDCBA) 38: Hold Register(INT64_ABCDEFGH) 39: Hold Register(INT64_GHEFCDAB) 40: Hold Register(INT64_BADCFEHG) 41: Hold Register(INT64_HGFEDCBA)
         * @default 0
         */
        data_type: number;

        /**
         * 是否有符号 - 0：无符号 1：有符号
         * @default 0
         */
        sign: 0 | 1;

        /**
         * 寄存器地址
         * @default 0
         */
        register_address: number;

        /**
         * 通道名称
         */
        name: string;
    }[];

    /**
     * GPIO1设置
     */
    gpio_1_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 模式 - 0: 输入 1: 输出 2: 计数
         * @default 0
         */
        mode: 0 | 1 | 2;

        /**
         * 开始计数 - 0：禁用 1：启用
         * @default 0
         */
        start_counter: 0 | 1;

        /**
         * 输入状态 - 0：无 1：拉高 2：拉低
         * @default 0
         */
        input_state: 0 | 1 | 2;

        /**
         * 开启滤波 - 0：禁用 1：启用
         * @default 0
         */
        enable_filter: 0 | 1;

        /**
         * 滤波速率
         * @default 1
         */
        filter_rate: number;

        /**
         * 滤波单位 - 0：us 1：ms
         * @default 0
         */
        filter_unit: 0 | 1;
    };

    /**
     * GPIO2设置
     */
    gpio_2_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 模式 - 0: 输入 1: 输出 2: 计数
         * @default 0
         */
        mode: 0 | 1 | 2;

        /**
         * 开始计数 - 0：禁用 1：启用
         * @default 0
         */
        start_counter: 0 | 1;

        /**
         * 输入状态 - 0：无 1：拉高 2：拉低
         * @default 0
         */
        input_state: 0 | 1 | 2;

        /**
         * 开启滤波 - 0：禁用 1：启用
         * @default 0
         */
        enable_filter: 0 | 1;

        /**
         * 滤波速率
         * @default 1
         */
        filter_rate: number;

        /**
         * 滤波单位 - 0：us 1：ms
         * @default 0
         */
        filter_unit: 0 | 1;
    };

    /**
     * SDI-12设置
     */
    sdi_settings: {
        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 输出接口使能 - 0：禁用 1：启用
         * @default 0
         */
        enable_output: 0 | 1;

        /**
         * 供电电流
         * @default 0
         */
        power_supply_current: number;

        /**
         * 供电时长
         * @default 1
         */
        power_time: number;

        /**
         * 波特率 - 1200: 1200 2400: 2400 4800: 4800 9600: 9600 14400: 14400 19200: 19200 38400: 38400 57600: 57600 115200: 115200
         * @default 1200
         */
        baud_rate: 1200 | 2400 | 4800 | 9600 | 14400 | 19200 | 38400 | 57600 | 115200;

        /**
         * 数据位长度 - 7: 7 8: 8
         * @default 7
         */
        data_bit: 7 | 8;

        /**
         * 停止位长度 - 1: 1 2: 2
         * @default 1
         */
        stop_bit: 1 | 2;

        /**
         * 奇偶校验位 - 0: 无校验 1: 奇校验 2: 偶校验
         * @default 0
         */
        parity: 0 | 1 | 2;

        /**
         * 重试次数
         * @default 0
         */
        retry_time: number;

        /**
         * 开启透传 - 0：禁用 1：启用
         * @default 0
         */
        enable_passthrough: 0 | 1;

        /**
         * 透传服务器类型 - 1: UDP 2: TCP 4: MQTT
         * @default 4
         */
        passthrough_server_type: 1 | 2 | 4;
    };

    /**
     * TCP设置
     */
    sdi_settings_tcp_settings: {
        /**
         * TCP设置序号
         * @default 0
         */
        id: number;

        /**
         * TCP设置指令
         * @default 0
         */
        command?: number;

        /**
         * 启用服务器 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 服务器地址
         */
        server_address: string;

        /**
         * 端口
         * @default 1000
         */
        server_port: number;

        /**
         * 重连次数
         * @default 0
         */
        retry_count: number;

        /**
         * 重连间隔
         * @default 5
         */
        retry_interval: number;

        /**
         * 保活间隔
         * @default 300
         */
        keepalive_interval: number;

        /**
         * TCP状态 - 0：连接失败 1：连接成功
         */
        tcp_status: 0 | 1;
    }[];

    /**
     * UDP设置
     */
    sdi_settings_udp_settings: {
        /**
         * UDP设置序号
         * @default 0
         */
        id: number;

        /**
         * UDP设置指令
         * @default 0
         */
        command?: number;

        /**
         * 启用服务器 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 服务器地址
         */
        server_address: string;

        /**
         * 端口
         * @default 1000
         */
        server_port: number;

        /**
         * UDP状态 - 0：连接失败 1：连接成功
         */
        udp_status: 0 | 1;
    }[];

    /**
     * SDI-12通道配置
     */
    sdi_channel_settings: {
        /**
         * 通道号
         * @default 0
         */
        id: number;

        /**
         * 子命令
         * @default 0
         */
        command?: number;

        /**
         * 通道使能 - 0：禁用 1：启用
         * @default 0
         */
        enable: 0 | 1;

        /**
         * 通道名称
         */
        name: string;

        /**
         * 从设备地址
         * @default 0
         */
        address: number;

        /**
         * 采集指令
         * @default aM!;aD0!;
         */
        collect_command: string;
    }[];

    /**
     * 蜂窝状态信息
     */
    cellular_status: {
        /**
         * 蜂窝状态信息
         */
        command?: number;

        /**
         * 驻网状态 - 0:驻网失败 1:驻网成功
         */
        register_status: 0 | 1;

        /**
         * SIM卡状态 - 0:卡状态预留 1:SIM卡识别成功 2:SIM卡未识别 3:需要PIN码 4:PIN码错误 5:需要PUK码 6:未插入SIM卡
         */
        sim_status: 0 | 1 | 2 | 3 | 4 | 5 | 6;

        /**
         * IMEI
         */
        imei: string;

        /**
         * IMSI
         */
        imsi: string;

        /**
         * ICCID
         */
        iccid: string;

        /**
         * 信号强度
         */
        csq: number;

        /**
         * 服务器连接状态 - 0:连接失败 1:连接成功
         */
        connected_status: 0 | 1;

        /**
         * Milesight MQTT 状态 - 0:连接失败 1:连接成功
         */
        milesight_mqtt_status: 0 | 1;

        /**
         * Milesight DTLS 状态 - 0:连接失败 1:连接成功
         */
        milesight_dtls_status: 0 | 1;
    };

    /**
     * 蜂窝设置
     */
    cellular_settings: {
        /**
         * 蜂窝设置指令
         * @default 0
         */
        command?: number;

        /**
         * 工作模式 - 0: 低功耗模式 3: 低延时模式
         * @default 0
         */
        work_mode: 0 | 3;

        /**
         * 传输类型 - 1:UDP 2:TCP 3:AWS 4:MQTT 6:开发者平台-MQTT 7:开发者平台-DTLS
         * @default 4
         */
        transport_type: 1 | 2 | 3 | 4 | 6 | 7;

        /**
         * 网络配置
         */
        network: {
            /**
             * 网络配置指令
             * @default 0
             */
            command?: number;

            /**
             * APN
             */
            apn: string;

            /**
             * 认证方式 - 0：不认证 1：PAP 2：CHAP
             * @default 0
             */
            auth_mode: 0 | 1 | 2;

            /**
             * 用户名
             */
            auth_username: string;

            /**
             * 密码
             */
            password: string;

            /**
             * PIN码
             */
            pin: string;

            /**
             * 网络类型 - 0：自动 1：Cat-M 2：NB-IOT
             * @default 0
             */
            type: 0 | 1 | 2;
        };

        /**
         * MQTT设置
         */
        mqtt_settings: {
            /**
             * MQTT设置指令
             * @default 0
             */
            command?: number;

            /**
             * 服务器地址
             */
            server_address: string;

            /**
             * 端口
             * @default 8883
             */
            server_port: number;

            /**
             * 保活间隔
             * @default 300
             */
            keepalive_interval: number;

            /**
             * 客户端ID
             * @default [sn]
             */
            client_id: string;

            /**
             * 用户凭证使能 - 0：禁用 1：启用
             * @default 0
             */
            auth_enable: 0 | 1;

            /**
             * 用户名
             */
            auth_username: string;

            /**
             * 密码
             */
            auth_password: string;

            /**
             * TLS使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_tls: 0 | 1;

            /**
             * 根文件使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_ca_certificate: 0 | 1;

            /**
             * 根文件长度
             * @default 0
             */
            ca_certificate_length: number;

            /**
             * 根文件
             */
            ca_certificate: string;

            /**
             * 客户端证书使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_client_certificate: 0 | 1;

            /**
             * 客户端证书长度
             * @default 0
             */
            client_certificate_length: number;

            /**
             * 客户端证书
             */
            client_certificate: string;

            /**
             * 客户端密钥使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_key_certificate: 0 | 1;

            /**
             * 客户端密钥长度
             * @default 0
             */
            key_certificate_length: number;

            /**
             * 客户端密钥
             */
            key_certificate: string;

            /**
             * 数据上行主题
             */
            uplink_topic: string;

            /**
             * 数据上行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            uplink_qos: 0 | 1 | 2;

            /**
             * 数据下行主题
             */
            downlink_topic: string;

            /**
             * 数据下行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            downlink_qos: 0 | 1 | 2;

            /**
             * RS485上行主题
             */
            rs485_uplink_topic: string;

            /**
             * RS485上行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            rs485_uplink_qos: 0 | 1 | 2;

            /**
             * RS485下行主题
             */
            rs485_downlink_topic: string;

            /**
             * RS485下行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            rs485_downlink_qos: 0 | 1 | 2;

            /**
             * RS232上行主题
             */
            rs232_uplink_topic: string;

            /**
             * RS232上行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            rs232_uplink_qos: 0 | 1 | 2;

            /**
             * RS232下行主题
             */
            rs232_downlink_topic: string;

            /**
             * RS232下行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            rs232_downlink_qos: 0 | 1 | 2;

            /**
             * SDI-12上行主题
             */
            sdi_uplink_topic: string;

            /**
             * SDI-12上行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            sdi_uplink_qos: 0 | 1 | 2;

            /**
             * SDI-12下行主题
             */
            sdi_downlink_topic: string;

            /**
             * SDI-12下行QoS - 0：QoS0 1：QoS1 2：QoS2
             * @default 0
             */
            sdi_downlink_qos: 0 | 1 | 2;

            /**
             * MQTT状态 - 0：连接失败 1：连接成功
             */
            mqtt_status: 0 | 1;
        };

        /**
         * AWS设置
         */
        aws_settings: {
            /**
             * AWS设置指令
             * @default 0
             */
            command?: number;

            /**
             * 服务器地址
             */
            server_address: string;

            /**
             * 端口
             * @default 8883
             */
            server_port: number;

            /**
             * 保活间隔
             * @default 300
             */
            keepalive_interval: number;

            /**
             * 根文件使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_ca_certificate: 0 | 1;

            /**
             * 根文件长度
             * @default 0
             */
            ca_certificate_length: number;

            /**
             * 根文件
             */
            ca_certificate: string;

            /**
             * 客户端证书使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_client_certificate: 0 | 1;

            /**
             * 客户端证书长度
             * @default 0
             */
            client_certificate_length: number;

            /**
             * 客户端证书
             */
            client_certificate: string;

            /**
             * 客户端密钥使能 - 0：禁用 1：启用
             * @default 0
             */
            enable_key_certificate: 0 | 1;

            /**
             * 客户端密钥长度
             * @default 0
             */
            key_certificate_length: number;

            /**
             * 客户端密钥
             */
            key_certificate: string;

            /**
             * AWS状态 - 0：连接失败 1：连接成功
             */
            aws_status: 0 | 1;
        };

        /**
         * TCP设置
         */
        tcp_settings: {
            /**
             * TCP设置序号
             * @default 0
             */
            id: number;

            /**
             * TCP设置指令
             * @default 0
             */
            command?: number;

            /**
             * 启用服务器 - 0：禁用 1：启用
             * @default 0
             */
            enable: 0 | 1;

            /**
             * 服务器地址
             */
            server_address: string;

            /**
             * 端口
             * @default 1000
             */
            server_port: number;

            /**
             * 重连次数
             * @default 0
             */
            retry_count: number;

            /**
             * 重连间隔
             * @default 5
             */
            retry_interval: number;

            /**
             * 保活间隔
             * @default 300
             */
            keepalive_interval: number;

            /**
             * TCP状态 - 0：连接失败 1：连接成功
             */
            tcp_status: 0 | 1;
        }[];

        /**
         * UDP设置
         */
        udp_settings: {
            /**
             * UDP设置序号
             * @default 0
             */
            id: number;

            /**
             * UDP设置指令
             * @default 0
             */
            command?: number;

            /**
             * 启用服务器 - 0：禁用 1：启用
             * @default 0
             */
            enable: 0 | 1;

            /**
             * 服务器地址
             */
            server_address: string;

            /**
             * 端口
             * @default 1000
             */
            server_port: number;

            /**
             * UDP状态 - 0：连接失败 1：连接成功
             */
            udp_status: 0 | 1;
        }[];

        /**
         * Milesight MQTT设置
         */
        milesight_mqtt_settings: {
            /**
             * Milesight MQTT设置指令
             * @default 33
             */
            command?: number;

            /**
             * Milesight MQTT 状态 - 0：连接失败 1：连接成功
             */
            status: 0 | 1;
        };

        /**
         * Milesight DTLS设置
         */
        milesight_dtls_settings: {
            /**
             * Milesight DTLS设置指令
             * @default 0
             */
            command?: number;

            /**
             * Milesight DTLS 状态 - 0：连接失败 1：连接成功
             */
            status: 0 | 1;
        };
    };

    /**
     * OTA升级
     */
    ipso_device_upgrade: {
        /**
         * 起始版本
         */
        base_version: string;

        /**
         * 目标版本
         */
        target_version: string;

        /**
         * 文件大小
         * @default 0
         */
        size: number;

        /**
         * CRC校验值
         * @default 0
         */
        crc32: number;

        /**
         * URL长度
         * @default 0
         */
        url_length: number;

        /**
         * URL
         */
        url: string;
    };

    /**
     * OTA响应
     */
    ipso_device_upgrade_result: {
        /**
         * OTA响应 - 0: Upgrade Successfully 1: URL Error 2: Download Failed 3: Packet Too Big 4: Version Error 5: Device Error 6: Patch Format Error 7: CRC Check Failed 8: Product Error 9: Patch Upgrade Failed 255: Upgrade Pending
         * @default 0
         */
        value: number;
    };
}
