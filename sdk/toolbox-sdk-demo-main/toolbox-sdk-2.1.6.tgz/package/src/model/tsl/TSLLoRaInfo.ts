/**
 * TSL LoRa 信息
 */
export interface TSLLoRaInfo {
	/**
	 * LORAWAN状态信息
	 */
	lorawan_status: {
		/**
		 * LORAWAN状态子命令
		 */
		command: string;
		
		/**
		 * EUI
		 */
		eui: string;

		/**
		 * 入网状态
		 * 0: 未入网
		 * 1: 已入网
		 */
		join_status: 0 | 1;

		signal: {
			/**
			 * 信号强度
			 */
			rssi: number;

			/**
			 * 信噪比
			 */
			snr: number;
		};

		/**
		* 通道掩码
		*/
		channel_mask: string;

		frame_counter: {
			/**
			 * 上行帧计数
			 */
			uplink: number;

			/**
			 * 下行帧计数
			 */
			downlink: number;
		};
	};

	/**
	 * LORAWAN配置
	 */
	lorawan_configuration_settings: {
		/**
		 * LORAWAN配置子命令
		 */
		command?: string;

		/**
		 * 工作模式
		 * 0: CLASSA
		 * 1: CLASSB
		 * 2: CLASSC
		 */
		mode: 0 | 1 | 2;

		/**
		 * 入网类型
		 * 0: ABP
		 * 1: OTAA
		 */
		join_type: 0 | 1;

		/**
		 * 自适应速率
		 * 0: 禁用
		 * 1: 启用
		 */
		adr_mode: 0 | 1;

		/**
		 * 网络ID
		 */
		netid: string;

		/**
		 * 设备地址
		 */
		devaddr: string;

		/**
		 * 设备EUI
		 */
		deveui: string;

		/**
		 * 应用EUI
		 */
		appeui: string;

		/**
		 * 网络密钥
		 */
		nwkskey: string;

		/**
		 * 应用程序会话密钥
		 */
		appskey: string;

		/**
		 * 应用程序密钥
		 */
		appkey: string;

		/**
		 * 接收窗口1打开延时
		 */
		rx1_open_delay: number;

		/**
		 * 接收窗口2打开延时
		 */
		rx2_open_delay: number;

		/**
		 * 入网窗口一打开延时
		 */
		join_rx1_open_delay: number;

		/**
		 * 入网窗口二打开延时
		 */
		join_rx2_open_delay: number;

		/**
		 * 发射功率
		 * 0: TXPOWER0-16dBm
		 * 1: TXPOWER1-14dBm
		 * 2: TXPOWER2-12dBm
		 * 3: TXPOWER3-10dBm
		 * 4: TXPOWER4-8dBm
		 * 5: TXPOWER5-6dBm
		 * 6: TXPOWER6-4dBm
		 * 7: TXPOWER7-2dBm
		 */
		tx_power: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

		/**
		 * 应用端口
		 */
		app_port: number;

		/**
		 * 确认包模式
		 * 0: 非确认包
		 * 1: 确认包
		 */
		confirmed_mode: 0 | 1;

		/**
		 * 通道掩码
		 */
		channel_mask: string;

		/**
		 * 信道设置
		 */
		channels_settings: {
			/**
			 * 信道使能
			 */
			enable: 0 | 1;

			/**
			 * 信道索引
			 */
			index: number;

			/**
			 * 信道频率
			 */
			frequency: number;

			/**
			 * 信道速率最小值
			 * 0: DR0(SF12,125kHz)
			 * 1: DR1(SF11,125kHz)
			 * 2: DR2(SF10,125kHz)
			 * 3: DR3(SF9,125kHz)
			 * 4: DR4(SF8,125kHz)
			 * 5: DR5(SF7,125kHz)
			 */
			data_rate_min: number;

			/**
			 * 信道速率最大值
			 * 0: DR0(SF12,125kHz)
			 * 1: DR1(SF11,125kHz)
			 * 2: DR2(SF10,125kHz)
			 * 3: DR3(SF9,125kHz)
			 * 4: DR4(SF8,125kHz)
			 * 5: DR5(SF7,125kHz)
			 */
			data_rate_max: number;
		}[];

		/**
		 * 发射速率
		 * 0: DR0(SF12,125kHz)
		 * 1: DR1(SF11,125kHz)
		 * 2: DR2(SF10,125kHz)
		 * 3: DR3(SF9,125kHz)
		 * 4: DR4(SF8,125kHz)
		 * 5: DR5(SF7,125kHz)
		 */
		tx_data_rate: 0 | 1 | 2 | 3 | 4 | 5;

		/**
		 * 窗口二频率
		 */
		rx2_frequency: number;

		/**
		 * 窗口二速率
		 * 0: DR0(SF12,125kHz)
		 * 1: DR1(SF11,125kHz)
		 * 2: DR2(SF10,125kHz)
		 * 3: DR3(SF9,125kHz)
		 * 4: DR4(SF8,125kHz)
		 * 5: DR5(SF7,125kHz)
		 */
		rx2_data_rate: 0 | 1 | 2 | 3 | 4 | 5;

		/**
		 * 占空比
		 */
		duty_cycle: number;

		/**
		 * 占空比启用
		 * 0: 禁用
		 * 1: 启用
		 */
		duty_cycle_enable: 0 | 1;

		/**
		 * ACK发送次数
		 */
		ack_retry_times: number;

		/**
		 * 频段
		 * 0: CN470
		 * 2: AS923
		 * 3: AU915
		 * 4: EU868
		 * 5: KR920
		 * 6: IN865
		 * 7: US915
		 * 10: RU864
		 */
		frequency_band: 0 | 2 | 3 | 4 | 5 | 6 | 7 | 10;

		/**
		 * 版本
		 * 1: 1.0.2
		 * 2: 1.0.3
		 * 3: 1.0.3
		 */
		version: 1 | 2 | 3;

		/**
		 * 重新入网次数
		 */
		number_of_link_detection_signals: number;

		/**
		 * 重新入网模式
		 * 0: 禁用
		 * 1: 启用
		 */
		rejoin_mode_enable: 0 | 1;

		/**
		 * AS923子频段
		 * 0: AS923-1
		 * 1: AS923-2
		 * 2: AS923-3
		 * 3: AS923-4
		 */
		AS923_frequency_band_in_use: 0 | 1 | 2 | 3;

		/**
		 * CLASSB时隙
		 * 0: 1s
		 * 1: 2s
		 * 2: 4s
		 * 3: 8s
		 * 4: 16s
		 * 5: 32s
		 * 6: 64s
		 * 7: 128s
		 */
		pingslot_periodicity: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

		/**
		 * D2D密钥
		 */
		d2d_key: string;

		/**
		 * LORAWAN组播配置
		 */
		multicast_group_settings: {
			/**
			 * LORAWAN扩展配置子命令
			 */
			command: string;

			/**
			 * 组播1使能
			 * 0: 禁用
			 * 1: 启用
			 */
			group_1_enable: 0 | 1;

			/**
			 * 组播1时隙
			 * 0: 1s
			 * 1: 2s
			 * 2: 4s
			 * 3: 8s
			 * 4: 16s
			 * 5: 32s
			 * 6: 64s
			 * 7: 128s
			 */
			group_1_pingslot_periodicity: number;

			/**
			 * 组播1速率
			 * 0: DR0(SF12,125kHz)
			 * 1: DR1(SF11,125kHz)
			 * 2: DR2(SF10,125kHz)
			 * 3: DR3(SF9,125kHz)
			 * 4: DR4(SF8,125kHz)
			 * 5: DR5(SF7,125kHz)
			 */
			group_1_data_rate: number;

			/**
			 * 组播1频率
			 */
			group_1_frequency: number;

			/**
			 * 组播1设备地址
			 */
			group_1_devaddr: string;

			/**
			 * 组播1网络密钥
			 */
			group_1_nwkskey: string;

			/**
			 * 组播1应用密钥
			 */
			group_1_appskey: string;

			/**
			 * 组播2使能
			 * 0: 禁用
			 * 1: 启用
			 */
			group_2_enable: 0 | 1;

			/**
			 * 组播2时隙
			 * 0: 1s
			 * 1: 2s
			 * 2: 4s
			 * 3: 8s
			 * 4: 16s
			 * 5: 32s
			 * 6: 64s
			 * 7: 128s
			 */
			group_2_pingslot_periodicity: number;

			/**
			 * 组播2速率
			 * 0: DR0(SF12,125kHz)
			 * 1: DR1(SF11,125kHz)
			 * 2: DR2(SF10,125kHz)
			 * 3: DR3(SF9,125kHz)
			 * 4: DR4(SF8,125kHz)
			 * 5: DR5(SF7,125kHz)
			 */
			group_2_data_rate: number;

			/**
			 * 组播2频率
			 */
			group_2_frequency: number;

			/**
			 * 组播2设备地址
			 */
			group_2_devaddr: string;

			/**
			 * 组播2网络密钥
			 */
			group_2_nwkskey: string;

			/**
			 * 组播2应用密钥
			 */
			group_2_appskey: string;

			/**
			 * 组播3使能
			 * 0: 禁用
			 * 1: 启用
			 */
			group_3_enable: 0 | 1;

			/**
			 * 组播3时隙
			 * 0: 1s
			 * 1: 2s
			 * 2: 4s
			 * 3: 8s
			 * 4: 16s
			 * 5: 32s
			 * 6: 64s
			 * 7: 128s
			 */
			group_3_pingslot_periodicity: number;

			/**
			 * 组播3速率
			 * 0: DR0(SF12,125kHz)
			 * 1: DR1(SF11,125kHz)
			 * 2: DR2(SF10,125kHz)
			 * 3: DR3(SF9,125kHz)
			 * 4: DR4(SF8,125kHz)
			 * 5: DR5(SF7,125kHz)
			 */
			group_3_data_rate: number;

			/**
			 * 组播3频率
			 */
			group_3_frequency: number;

			/**
			 * 组播3设备地址
			 */
			group_3_devaddr: string;

			/**
			 * 组播3网络密钥
			 */
			group_3_nwkskey: string;

			/**
			 * 组播3应用密钥
			 */
			group_3_appskey: string;

			/**
			 * 组播4使能
			 * 0: 禁用
			 * 1: 启用
			 */
			group_4_enable: 0 | 1;

			/**
			 * 组播4时隙
			 * 0: 1s
			 * 1: 2s
			 * 2: 4s
			 * 3: 8s
			 * 4: 16s
			 * 5: 32s
			 * 6: 64s
			 * 7: 128s
			 */
			group_4_pingslot_periodicity: number;

			/**
			 * 组播4速率
			 * 0: DR0(SF12,125kHz)
			 * 1: DR1(SF11,125kHz)
			 * 2: DR2(SF10,125kHz)
			 * 3: DR3(SF9,125kHz)
			 * 4: DR4(SF8,125kHz)
			 * 5: DR5(SF7,125kHz)
			 */
			group_4_data_rate: number;

			/**
			 * 组播4频率
			 */
			group_4_frequency: number;

			/**
			 * 组播4设备地址
			 */
			group_4_devaddr: string;

			/**
			 * 组播4网络密钥
			 */
			group_4_nwkskey: string;

			/**
			 * 组播4应用密钥
			 */
			group_4_appskey: string;
		};
	};

	/** D2D配对启用 - 0：禁用 1：启用 */
	d2d_pairing_enable: 0 | 1;

	/** D2D配对信息 */
	d2d_pairing_settings: {
			/** 序号 */
			index: number;

			/** 类型 */
			type?: number;

			/** 配对 - 0：禁用 1：启用 */
			enable: 0 | 1;

			/** 设备id */
			deveui: string;

			/** 设备名称前8B */
			name_first: string;

			/** 设备名称后8B */
			name_last: string;
	}[];

	/**
	 * D2D主控使能 - 0：禁用 1：启用
	 * @default 0
	 */
	d2d_master_enable: 0 | 1;

	/**
	 * D2D被控使能 - 0：禁用 1：启用
	 * @default 0
	 */
	d2d_slave_enable: 0 | 1;
}
