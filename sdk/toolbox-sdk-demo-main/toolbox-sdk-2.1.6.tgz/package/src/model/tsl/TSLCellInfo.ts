/**
 * TSL 蜂窝 信息
 */
export interface TSLCellInfo {
	/**
	 * 蜂窝状态信息
	 */
	cellular_status: {
		/**
		 * 蜂窝状态信息
		 */
		command?: number;

		/**
		 * 驻网状态 - 0:驻网失败 1:驻网成功
		 */
		register_status: 0 | 1;

		/**
		 * SIM卡状态 - 0:卡状态预留 1:SIM卡识别成功 2:SIM卡未识别 3:需要PIN码 4:PIN码错误 5:需要PUK码 6:未插入SIM卡
		 */
		sim_status: 0 | 1 | 2 | 3 | 4 | 5 | 6;

		/**
		 * IMEI
		 */
		imei: string;

		/**
		 * IMSI
		 */
		imsi: string;

		/**
		 * ICCID
		 */
		iccid: string;

		/**
		 * 信号强度
		 */
		csq: number;

		/**
		 * 服务器连接状态 - 0:连接失败 1:连接成功
		 */
		connected_status: 0 | 1;

		/**
		 * Milesight MQTT 状态 - 0:连接失败 1:连接成功
		 */
		milesight_mqtt_status: 0 | 1;

		/**
		 * Milesight DTLS 状态 - 0:连接失败 1:连接成功
		 */
		milesight_dtls_status: 0 | 1;
	};

	/**
	 * 蜂窝设置
	 */
	cellular_settings: {
		/**
		 * 蜂窝设置指令
		 * @default 0
		 */
		command?: number;

		/**
		 * 工作模式 - 0: 低功耗模式 3: 低延时模式
		 * @default 0
		 */
		work_mode: 0 | 3;

		/**
		 * 传输类型 - 1:UDP 2:TCP 3:AWS 4:MQTT 6:开发者平台-MQTT 7:开发者平台-DTLS
		 * @default 4
		 */
		transport_type: 1 | 2 | 3 | 4 | 6 | 7;

		/**
		 * 网络配置
		 */
		network: {
			/**
			 * 网络配置指令
			 * @default 0
			 */
			command?: number;

			/**
			 * APN
			 */
			apn: string;

			/**
			 * 认证方式 - 0：不认证 1：PAP 2：CHAP
			 * @default 0
			 */
			auth_mode: 0 | 1 | 2;

			/**
			 * 用户名
			 */
			auth_username: string;

			/**
			 * 密码
			 */
			password: string;

			/**
			 * PIN码
			 */
			pin: string;

			/**
			 * 网络类型 - 0：自动 1：Cat-M 2：NB-IOT
			 * @default 0
			 */
			type: 0 | 1 | 2;
		};

		/**
		 * MQTT设置
		 */
		mqtt_settings: {
			/**
			 * MQTT设置指令
			 * @default 0
			 */
			command?: number;

			/**
			 * 服务器地址
			 */
			server_address: string;

			/**
			 * 端口
			 * @default 8883
			 */
			server_port: number;

			/**
			 * 保活间隔
			 * @default 300
			 */
			keepalive_interval: number;

			/**
			 * 客户端ID
			 * @default [sn]
			 */
			client_id: string;

			/**
			 * 用户凭证使能 - 0：禁用 1：启用
			 * @default 0
			 */
			auth_enable: 0 | 1;

			/**
			 * 用户名
			 */
			auth_username: string;

			/**
			 * 密码
			 */
			auth_password: string;

			/**
			 * TLS使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_tls: 0 | 1;

			/**
			 * 根文件使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_ca_certificate: 0 | 1;

			/**
			 * 根文件长度
			 * @default 0
			 */
			ca_certificate_length: number;

			/**
			 * 根文件
			 */
			ca_certificate: string;

			/**
			 * 客户端证书使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_client_certificate: 0 | 1;

			/**
			 * 客户端证书长度
			 * @default 0
			 */
			client_certificate_length: number;

			/**
			 * 客户端证书
			 */
			client_certificate: string;

			/**
			 * 客户端密钥使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_key_certificate: 0 | 1;

			/**
			 * 客户端密钥长度
			 * @default 0
			 */
			key_certificate_length: number;

			/**
			 * 客户端密钥
			 */
			key_certificate: string;

			/**
			 * 数据上行主题
			 */
			uplink_topic: string;

			/**
			 * 数据上行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			uplink_qos: 0 | 1 | 2;

			/**
			 * 数据下行主题
			 */
			downlink_topic: string;

			/**
			 * 数据下行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			downlink_qos: 0 | 1 | 2;

			/**
			 * RS485上行主题
			 */
			rs485_uplink_topic: string;

			/**
			 * RS485上行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			rs485_uplink_qos: 0 | 1 | 2;

			/**
			 * RS485下行主题
			 */
			rs485_downlink_topic: string;

			/**
			 * RS485下行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			rs485_downlink_qos: 0 | 1 | 2;

			/**
			 * RS232上行主题
			 */
			rs232_uplink_topic: string;

			/**
			 * RS232上行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			rs232_uplink_qos: 0 | 1 | 2;

			/**
			 * RS232下行主题
			 */
			rs232_downlink_topic: string;

			/**
			 * RS232下行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			rs232_downlink_qos: 0 | 1 | 2;

			/**
			 * SDI-12上行主题
			 */
			sdi_uplink_topic: string;

			/**
			 * SDI-12上行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			sdi_uplink_qos: 0 | 1 | 2;

			/**
			 * SDI-12下行主题
			 */
			sdi_downlink_topic: string;

			/**
			 * SDI-12下行QoS - 0：QoS0 1：QoS1 2：QoS2
			 * @default 0
			 */
			sdi_downlink_qos: 0 | 1 | 2;

			/**
			 * MQTT状态 - 0：连接失败 1：连接成功
			 */
			mqtt_status: 0 | 1;
		};

		/**
		 * AWS设置
		 */
		aws_settings: {
			/**
			 * AWS设置指令
			 * @default 0
			 */
			command?: number;

			/**
			 * 服务器地址
			 */
			server_address: string;

			/**
			 * 端口
			 * @default 8883
			 */
			server_port: number;

			/**
			 * 保活间隔
			 * @default 300
			 */
			keepalive_interval: number;

			/**
			 * 根文件使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_ca_certificate: 0 | 1;

			/**
			 * 根文件长度
			 * @default 0
			 */
			ca_certificate_length: number;

			/**
			 * 根文件
			 */
			ca_certificate: string;

			/**
			 * 客户端证书使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_client_certificate: 0 | 1;

			/**
			 * 客户端证书长度
			 * @default 0
			 */
			client_certificate_length: number;

			/**
			 * 客户端证书
			 */
			client_certificate: string;

			/**
			 * 客户端密钥使能 - 0：禁用 1：启用
			 * @default 0
			 */
			enable_key_certificate: 0 | 1;

			/**
			 * 客户端密钥长度
			 * @default 0
			 */
			key_certificate_length: number;

			/**
			 * 客户端密钥
			 */
			key_certificate: string;

			/**
			 * AWS状态 - 0：连接失败 1：连接成功
			 */
			aws_status: 0 | 1;
		};

		/**
		 * TCP设置
		 */
		tcp_settings: {
			/**
			 * TCP设置序号
			 * @default 0
			 */
			id: number;

			/**
			 * TCP设置指令
			 * @default 0
			 */
			command?: number;

			/**
			 * 启用服务器 - 0：禁用 1：启用
			 * @default 0
			 */
			enable: 0 | 1;

			/**
			 * 服务器地址
			 */
			server_address: string;

			/**
			 * 端口
			 * @default 1000
			 */
			server_port: number;

			/**
			 * 重连次数
			 * @default 0
			 */
			retry_count: number;

			/**
			 * 重连间隔
			 * @default 5
			 */
			retry_interval: number;

			/**
			 * 保活间隔
			 * @default 300
			 */
			keepalive_interval: number;

			/**
			 * TCP状态 - 0：连接失败 1：连接成功
			 */
			tcp_status?: 0 | 1;
		}[];

		/**
		 * UDP设置
		 */
		udp_settings: {
			/**
			 * UDP设置序号
			 * @default 0
			 */
			id: number;

			/**
			 * UDP设置指令
			 * @default 0
			 */
			command?: number;

			/**
			 * 启用服务器 - 0：禁用 1：启用
			 * @default 0
			 */
			enable: 0 | 1;

			/**
			 * 服务器地址
			 */
			server_address: string;

			/**
			 * 端口
			 * @default 1000
			 */
			server_port: number;

			/**
			 * UDP状态 - 0：连接失败 1：连接成功
			 */
			udp_status?: 0 | 1;
		}[];

		/**
		 * Milesight MQTT设置
		 */
		milesight_mqtt_settings: {
			/**
			 * Milesight MQTT设置指令
			 * @default 33
			 */
			command?: number;

			/**
			 * Milesight MQTT 状态 - 0：连接失败 1：连接成功
			 */
			status: 0 | 1;
		};

		/**
		 * Milesight DTLS设置
		 */
		milesight_dtls_settings: {
			/**
			 * Milesight DTLS设置指令
			 * @default 0
			 */
			command?: number;

			/**
			 * Milesight DTLS 状态 - 0：连接失败 1：连接成功
			 */
			status: 0 | 1;
		};
	};

	/**
 * 文件传输
 * @class_type 属性
 */
	request_root_file_transfer: {
		/**
		 * 文件传输操作类型 - 0：写入文件 1：擦除文件
		 * @default 0
		 * @class_type 属性
		 * @max_value 255
		 * @min_value 0
		 */
		operate_type: 0 | 1;

		/**
		 * 证书类型 - 3：AWS  4：MQTT
		 * @default 4
		 * @class_type 属性
		 * @max_value 255
		 * @min_value 0
		 */
		cert_type: 3 | 4;

		/**
		 * 传输长度
		 * @default 1
		 * @class_type 属性
		 * @max_value 4088
		 * @min_value 1
		 */
		length: number;

		/**
		 * 文件内容
		 * @class_type 属性
		 * @string_length 4088
		 * @character_encoding utf8
		 */
		data: string;
	};

	/**
	 * 文件传输
	 * @class_type 属性
	 */
	request_dev_file_transfer: {
		/**
		 * 文件传输操作类型 - 0：写入文件 1：擦除文件
		 * @default 0
		 * @class_type 属性
		 * @max_value 255
		 * @min_value 0
		 */
		operate_type: 0 | 1;

		/**
		 * 证书类型 - 3：AWS  4：MQTT
		 * @default 4
		 * @class_type 属性
		 * @max_value 255
		 * @min_value 0
		 */
		cert_type: 3 | 4;

		/**
		 * 传输长度
		 * @default 1
		 * @class_type 属性
		 * @max_value 4088
		 * @min_value 1
		 */
		length: number;

		/**
		 * 文件内容
		 * @class_type 属性
		 * @string_length 4088
		 * @character_encoding utf8
		 */
		data: string;
	};

	/**
	 * 文件传输
	 * @class_type 属性
	 */
	request_private_file_transfer: {
		/**
		 * 文件传输操作类型 - 0：写入文件 1：擦除文件
		 * @default 0
		 * @class_type 属性
		 * @max_value 255
		 * @min_value 0
		 */
		operate_type: 0 | 1;

		/**
		 * 证书类型 - 3：AWS  4：MQTT
		 * @default 4
		 * @class_type 属性
		 * @max_value 255
		 * @min_value 0
		 */
		cert_type: 3 | 4;

		/**
		 * 传输长度
		 * @default 1
		 * @class_type 属性
		 * @max_value 4088
		 * @min_value 1
		 */
		length: number;

		/**
		 * 文件内容
		 * @class_type 属性
		 * @string_length 4088
		 * @character_encoding utf8
		 */
		data: string;
	};
}