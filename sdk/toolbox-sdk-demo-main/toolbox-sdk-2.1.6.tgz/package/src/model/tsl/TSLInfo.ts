import { PartialDeep, Paths } from 'type-fest';

import { DeviceTSLInfo, DeviceTSLInfoKeys } from './DeviceSpecificTSLInfo';
import { TSLBasicInfo } from './TSLBasicInfo';
import { TSLCellInfo } from './TSLCellInfo';
import { TSLControlInfo } from './TSLControlInfo';
import { TSLLoRaInfo } from './TSLLoRaInfo';
import { TSLSensorInfo } from './TSLSensorInfo';

/**
 * TSL通用信息
 */
export type CommonTSLInfo = TSLBasicInfo & TSLLoRaInfo & TSLCellInfo & TSLControlInfo & TSLSensorInfo;

/**
 * TSL信息
 */
export type TSLInfo<DeviceKey extends DeviceTSLInfoKeys = 'all'> = DeviceKey extends 'all'
	? CommonTSLInfo
	: CommonTSLInfo & DeviceTSLInfo<Exclude<DeviceKey, 'all'>>;

/**
 * TSL信息Key
 */
export type TSLInfoKeys<DeviceKey extends DeviceTSLInfoKeys = 'all'> = NonNullable<Paths<TSLInfo<DeviceKey>>>;

export type PartialTSLInfo<DeviceKey extends DeviceTSLInfoKeys = 'all'> = PartialDeep<TSLInfo<DeviceKey>>;