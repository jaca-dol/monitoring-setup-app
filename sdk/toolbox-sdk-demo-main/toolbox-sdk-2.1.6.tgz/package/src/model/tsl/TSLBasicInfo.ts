/**
 * TSL通用上下行信息
 */
export interface TSLBasicInfo {
	/**
	 * 物模型版本
	 */
	tsl_version: string;

	/**
	 * 产品名称
	 */
	product_name: string;

	/**
	 * 产品PN码
	 */
	product_pn: string;
	

	/**
	 * 产品SN码
	 */
	product_sn: string;

	/**
	 * 产品版本
	 */
	version: {
		/**
		 * 硬件版本
		 */
		hardware_version: string;

		/**
		 * 软件版本
		 */
		firmware_version: string;
	};

	/**
	 * 产品OEM号
	 */
	oem_id: string;

	/**
	 * 设备信息
	 */
	device_info: {
		/**
		 * 型号（最原始的型号，去掉频段，子型号、pn等信息）
		 */
		model: string;

		/**
		 * 子型号1
		 */
		submodel_1: string;

		/**
		 * 子型号2
		 */
		submodel_2: string;

		/**
		 * 子型号3
		 */
		submodel_3: string;

		/**
		 * 子型号4
		 */
		submodel_4: string;

		/**
		 * PN1
		 */
		pn_1: string;

		/**
		 * PN2
		 */
		pn_2: string;

		/**
		 * PN3
		 */
		pn_3: string;

		/**
		 * PN4
		 */
		pn_4: string;
	};

	/**
	 * 产品频段
	 */
	product_frequency_band: string;

	/**
	 * 设备时间
	 */
	device_time: {
		/**
		 * 当前时间
		 */
		current_time: number;

		/**
		 * 运行时间
		 */
		running_time: number;

		/**
		 * 上电时间
		 */
		power_on_time: number;
	};

	/**
	 * 电池电量
	 */
	battery: number;

	/**
	 * 电池信息
	 */
	battery_info: {
		/**
		 * 电池总量
		 */
		battery_capacity: number;

		/**
		 * 电池消耗
		 */
		battery_consumption: number;

		/**
		 * 当前电量
		 */
		battery_left: number;

		/**
		 * 当前电压
		 */
		battery_voltage: number;

		/**
		 * 当前状态
		 */
		current_battery_status: string;
	};

	/**
	 * 随机密钥
	 * 0: 禁用
	 * 1: 启用
	 */
	random_key: number;

	/**
	 * 开关机状态
	 * 0: 关机
	 * 1: 开机
	 */
	device_status: number;

	/**
	 * 上报周期
	 */
	reporting_interval: {
		/**
		 * 上报周期单位
		 * 0: 秒
		 * 1: 分
		 */
		unit: 0 | 1;

		/**
		 * 上报周期
		 */
		seconds_of_time: number;

		/**
		 * 上报周期
		 */
		minutes_of_time: number;
	};

	/** 采集周期 */
	collection_interval: {
		/** 采集周期单位 - 0：秒 1：分 */
		unit: 0 | 1;

		/** 采集周期 */
		seconds_of_time: number;

		/** 采集周期 */
		minutes_of_time: number;
	};

	/**
	 * 时区
	 * -720: UTC-12(IDLW)
	 * -660: UTC-11(SST)
	 * -600: UTC-10(HST)
	 * -570: UTC-9:30(MIT)
	 * -540: UTC-9(AKST)
	 * -480: UTC-8(PST)
	 * -420: UTC-7(MST)
	 * -360: UTC-6(CST)
	 * -300: UTC-5(EST)
	 * -240: UTC-4(AST)
	 * -210: UTC-3:30(NST)
	 * -180: UTC-3(BRT)
	 * -120: UTC-2(FNT)
	 * -60: UTC-1(CVT)
	 * 0: UTC(WET)
	 * 60: UTC+1(CET)
	 * 120: UTC+2(EET)
	 * 180: UTC+3(MSK)
	 * 210: UTC+3:30(IRST)
	 * 240: UTC+4(GST)
	 * 270: UTC+4:30(AFT)
	 * 300: UTC+5(PKT)
	 * 330: UTC+5:30(IST)
	 * 345: UTC+5:45(NPT)
	 * 360: UTC+6(BHT)
	 * 390: UTC+6:30(MMT)
	 * 420: UTC+7(ICT)
	 * 480: UTC+8(CT/CST)
	 * 540: UTC+9(JST)
	 * 570: UTC+9:30(ACST)
	 * 600: UTC+10(AEST)
	 * 630: UTC+10:30(LHST)
	 * 660: UTC+11(VUT)
	 * 720: UTC+12(NZST)
	 * 765: UTC+12:45(CHAST)
	 * 780: UTC+13(PHOT)
	 * 840: UTC+14(LINT)
	 */
	time_zone: number;

	/**
	 * 夏令时
	 */
	daylight_saving_time: {
		/**
		 * 夏令时 - 0：禁用 1：启用
		 * @default 0
		 */
		enable: 0 | 1;

		/**
		 * 偏移时间
		 */
		daylight_saving_time_offset: number;

		/**
		 * 月份
		 * 1: 一月
		 * 2: 二月
		 * 3: 三月
		 * 4: 四月
		 * 5: 五月
		 * 6: 六月
		 * 7: 七月
		 * 8: 八月
		 * 9: 九月
		 * 10: 十月
		 * 11: 十一月
		 * 12: 十二月
		 */
		start_month: number;

		/**
		 * 周数
		 * 1: 首个
		 * 2: 第二个
		 * 3: 第三个
		 * 4: 第四个
		 * 5: 末个
		 */
		start_week_num: number;

		/**
		 * 星期
		 * 1: 星期一
		 * 2: 星期二
		 * 3: 星期三
		 * 4: 星期四
		 * 5: 星期五
		 * 6: 星期六
		 * 7: 星期日
		 */
		start_week_day: number;

		/**
		 * 时间
		 */
		start_hour_min: number;

		/**
		 * 月份
		 * 1: 一月
		 * 2: 二月
		 * 3: 三月
		 * 4: 四月
		 * 5: 五月
		 * 6: 六月
		 * 7: 七月
		 * 8: 八月
		 * 9: 九月
		 * 10: 十月
		 * 11: 十一月
		 * 12: 十二月
		 */
		end_month: number;

		/**
		 * 周数
		 * 1: 首个
		 * 2: 第二个
		 * 3: 第三个
		 * 4: 第四个
		 * 5: 末个
		 */
		end_week_num: number;

		/**
		 * 星期
		 * 1: 星期一
		 * 2: 星期二
		 * 3: 星期三
		 * 4: 星期四
		 * 5: 星期五
		 * 6: 星期六
		 * 7: 星期日
		 */
		end_week_day: number;

		/**
		 * 时间
		 */
		end_hour_min: number;
	};

	/**
	 * 数据存储设置
	 */
	data_storage_settings: {
		/**
		 * 子命令
		 * @default 0
		 */
		command?: number;

		/**
		 * 数据存储 - 0：禁用 1：启用
		 * @default 0
		 */
		enable: 0 | 1;

		/**
		 * 重传 - 0：禁用 1：启用
		 * @default 0
		 */
		retransmission_enable: 0 | 1;

		/**
		 * 重传周期
		 * @default 600
		 */
		retransmission_interval: number;

		/**
		 * 回传周期
		 * @default 60
		 */
		retrieval_interval: number;
	};

	/**
	 * 时间戳
	 * 通常只用在历史数据中
	 */
	timestamp: number;

	/**
	 * 累计次数
	 */
	cumulative_times: number;

	/**
	 * 按键锁
	 */
	button_lock: {
		/**
		 * 功能开关 - 0: 禁用 1: 启用
		 * @default 0
		 */
		enable: 0 | 1;

		/**
		 * 锁功能 - 0: 锁关机 1: 锁采集上报 2：锁关机和采集上报
		 * @default 0
		 */
		lock_type: 0 | 1 | 2;
	};


	/**
	 * 工作模式 - 0:低功耗模式 3:低延时模式
	 * @default 0
	 */
	work_mode: 0 | 3;


	/**
	 * 历史数据
	 * 由协议库接口生成，实际物模型定义无该字段
	 */
	history: Array<Record<string, any>>;


	/**
	 * 子模块版本
	 * @class_type 属性
	 */
	sub_version: {
		/**
	 	 * 允许差分 - 0：不允许 1：允许
	 	 * @default 0
	 	 * @class_type 属性
	 	 */
		patch_enable: 0 | 1;
		/**
		  * 子模块序号
		  * @default 0
		  * @class_type 属性
		  * @string_length 8
		  * @max_value 255
		  * @min_value 0
		  */
		sub_id: number;
		/**
		  * 子模块版本
		  * @class_type 属性
		  * @string_length 8
		  * @character_encoding ascii
		  */
		version: string;
	};
}
