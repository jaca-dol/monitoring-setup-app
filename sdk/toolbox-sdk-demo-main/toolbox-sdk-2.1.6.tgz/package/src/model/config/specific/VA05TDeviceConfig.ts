import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('VA05-T')
export class VA05TDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			reset: {
				isSupport: () => false
			},
			deviceStateSwitch: {
				isSupport: () => false
			},
			deviceStateDisplay: {
				isSupport: () => false
			},
			templateEnable: {
				isSupport: () => false,
			}
		};
	}
}