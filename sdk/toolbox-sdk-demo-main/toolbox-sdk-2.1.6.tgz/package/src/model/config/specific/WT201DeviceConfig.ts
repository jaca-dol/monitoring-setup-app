import { Version } from '../../../utils/util/Version';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('WT2X1')
export class WT201DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			keyd2d: {
				isSupport: () => true,
			},
			humidity: {
				isSupport: (_model, _modelSeries, deviceInfo) => {
					const status = deviceInfo.status ?? [];

					return status.some(s => s.name === 'humidity') || deviceInfo.humidity != null;
				}
			},
			tstatOwner: {
				isSupport: (_model, _modelSeries, deviceInfo) => {
					if(Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, '2.0') && deviceInfo.tstatOwner != null) {
						return true;
					} else if (Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.3') && deviceInfo.tstatOwner != null) {
						return true;
					}
					return false;
				}
			},
			buttonLockMask: {
				isSupport(_model, _modelSeries, deviceInfo) {
					if (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, '2.0') && deviceInfo.buttonLockMask != null) {
						return true;
					} else if (Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.5') && deviceInfo.buttonLockMask != null) {
						return true;
					}
					return false;
				}
			},
			targetResolution: {
				isSupport(_model, _modelSeries, deviceInfo) {
					if (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, '2.0') && deviceInfo.targetResolution != null) {
						return true;
					} else if (Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.5') && deviceInfo.targetResolution != null) {
						return true;
					}
					return false;
				}
			},
			doubleSetPoint: {
				isSupport(_model, _modelSeries, deviceInfo) {
					if (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, '2.0') && deviceInfo.doubleSetPoint != null) {
						return true;
					} else if (Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.5') && deviceInfo.doubleSetPoint != null) {
						return true;
					}
					return false;
				}
			},
			yaux: {
				isSupport: (_model, _modelSeries, deviceInfo) => {
					if (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, '2.0') && deviceInfo.yauxEnable != null) {
						return true;
					} else if (Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.5') && deviceInfo.yauxEnable != null) {
						return true;
					}
					return false;
				}
			}
		};
	}
}