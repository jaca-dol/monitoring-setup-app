import { ClassTypeOption, SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('WT401')
export class IUCWT401DeviceConfigService extends BasicDeviceConfigService {	
	getClassTypeOptions(): ClassTypeOption[] | undefined {
		return [
			{ label: 'ClassC', value: 2 },
			{ label: 'ClassA', value: 0 }            
		];
	}

	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			multicast: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			},
			fullUpgradeNoListenTag: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			preconfig: {
				isSupport: () => true
			},

			bleNameWildcards: {
				isSupport: () => false
			}
		};
	}
}