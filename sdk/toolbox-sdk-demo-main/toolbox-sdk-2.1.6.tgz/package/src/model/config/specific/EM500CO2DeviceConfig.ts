import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { identify } from '../../identify';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('EM500-CO2')
export class EM500CO2DeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isEM500_0200_0105 = (model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return identify(model).isEM5XXv2(deviceInfo.hardwareVersion) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5');
		};
		const isEM500_0200_0107 = (model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return identify(model).isEM500_0200_0107(deviceInfo.hardwareVersion, deviceInfo.firmwareVersion);
		};
		return {
			altitudeCalEnable: {
				isSupport: isEM500_0200_0105,
			},
			autoBackgroundCalibration: {
				isSupport: isEM500_0200_0107,
			}
		};
	}
}