import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, ClassTypeOption, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('WT102')
export class WT102DeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			patchUpgrade: {
				isSupport: () => true,
			},
			retransmitEnable: {
				isSupport: () => true,
			},
			restart: {
				isSupport: () => true,
			},
			exportData: {
				isSupport: () => true,
			},
			// 支持Class B组播功能，默认禁用
			multicast: {
				isSupport: () => true,
			},
			// 预配置
			preconfig: {
				isSupport: () => true,
			},
			pingSlotPeriod: {
				isSupport: () => true,
			},
		};
	}

	getClassTypeOptions(): ClassTypeOption[] | undefined {
		return [
			{ label: 'ClassA', value: 0 },
			{ label: 'ClassB', value: 1 },
		];
	}
}