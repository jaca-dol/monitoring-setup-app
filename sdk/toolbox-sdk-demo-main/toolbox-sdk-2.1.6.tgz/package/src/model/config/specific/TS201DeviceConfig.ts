import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('TS201')
export class TS201DeviceConfigService extends BasicDeviceConfigService {

	isVersion2_0(deviceInfo: DeviceInfo) {					
		if (deviceInfo) {
			return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
		}

		return false;        
	}

	getSupportSettingMap(): SupportSettingMap | undefined {
		const _isVersion2_0 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {            
			return this.isVersion2_0(deviceInfo);
            
		};

		const needHumidity = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {		
			if (deviceInfo) {
				return deviceInfo.sn.length >= 2 && deviceInfo.sn[deviceInfo.sn.length - 2] == '1';
			}

			return false;			
		};
		return {
			clearData: {
				isSupport: () => true,
			},
			exportData: {
				isSupport: () => true,
			},
			patchUpgrade: {
				isSupport: () => true,
			},
			restart: {
				isSupport: () => true,
			},
			retransmitEnable: {
				isSupport: () => true,
			},
			keyd2d: {
				isSupport: _isVersion2_0,
			},
			d2dMasterAndSlave: {
				isSupport: _isVersion2_0,
			},
			multicast: {
				isSupport: _isVersion2_0,
			},			 
			deviceStateSwitch: {
				isSupport: _isVersion2_0,
			},
			humidity: {
				isSupport: needHumidity,
			},
			buttonLock: {
				isSupport: _isVersion2_0
			},
			buttonLockId: {
				isSupport: _isVersion2_0
			},
			loraUplink: {
				isSupport: _isVersion2_0
			}         
		};

	}
}