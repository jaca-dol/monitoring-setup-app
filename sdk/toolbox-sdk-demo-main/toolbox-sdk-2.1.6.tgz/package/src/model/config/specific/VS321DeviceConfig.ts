import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('VS321')
export class VS321DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			loraUplink: {
				isSupport: () => true,
			},
			controlTime: {
				isSupport: () => true,
			},
			patchUpgrade: {
				isSupport: () => true,
			},
			keyd2d: {
				isSupport: () => true,
			},
			humidity: {
				isSupport: (_model, _modelSeries, deviceInfo) => {
					const status = deviceInfo.status ?? [];

					return status.some(s => s.name === 'humidity') || deviceInfo.humidity != null;
				}
			},
			reportingMode: {
				isSupport: () => true,
			},
			retransmitEnable: {
				isSupport: () => true
			},
			singleChannelMode: {
				isSupport: () => true
			},
			imageVerification: {
				isSupport: () => true
			},
			deviceStateSwitch: {
				isSupport: () => false
			},
			activatedState: {
				isSupport: (_model, _modelSeries, deviceInfo) => {
					return deviceInfo.activatedState != null;
				}
			},
			restart: {
				isSupport: () => true
			},
			exportData: {
				isSupport: () => true
			}
		};
	}
}