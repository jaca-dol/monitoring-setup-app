import { ClassTypeOption, SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('WT30X')
export class WT30XDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			deviceStateSwitch: {
				isSupport: () => false
			},
			battery: {
				isSupport: () => false
			},
			restart: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			multicast: {
				isSupport: () => true
			},
			preconfig: {
				isSupport: () => true
			},
			d2dMasterAndSlave: {
				isSupport: () => true
			},
			keyd2d: {
				isSupport: () => true
			},
			loraUplink: {
				isSupport: () => true
			},
			d2dSlave: {
				isSupport: () => true
			},
		};
	}

	getClassTypeOptions(): ClassTypeOption[] | undefined {
		return [
			{ label: 'ClassC', value: 2 }
		];
	}
}