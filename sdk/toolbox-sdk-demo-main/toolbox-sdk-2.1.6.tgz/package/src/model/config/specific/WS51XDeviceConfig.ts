import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('WS51X')
export class WS51XDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		//覆写默认的判断逻辑或者添加额外的配置判断
		return {
			patchUpgrade: {
				isSupport(_model, _modelSeries, deviceInfo) {
					const { firmwareVersion} = deviceInfo;
					return Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.9');
				}
			},
		};
	}
}