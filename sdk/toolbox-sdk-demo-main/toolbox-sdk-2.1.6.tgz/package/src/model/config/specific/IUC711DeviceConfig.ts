import { ClassTypeOption, SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('UC711')
export class IUC711DeviceConfigService extends BasicDeviceConfigService {	
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			retransmitEnable: {
				isSupport: () => true
			},
			d2dMasterAndSlave: {
				isSupport: () => true
			},
			keyd2d: {
				isSupport: () => true
			},
			loraUplink: {
				isSupport: () => true
			},
			d2dSlave: {
				isSupport: () => true
			},
			deviceStateSwitch: {
				isSupport: () => false
			},
			restart: {
				isSupport: () => true
			}
		};
	}


	getClassTypeOptions(): ClassTypeOption[] | undefined {
		return [
			{ label: 'ClassC', value: 2 }
		];
	}
}