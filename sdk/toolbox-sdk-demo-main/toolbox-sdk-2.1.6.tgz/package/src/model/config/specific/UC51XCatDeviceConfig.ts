import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('UC51X-CAT')
export class UC51XCatDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		//覆写默认的判断逻辑
		return {
			restart: {
				isSupport: ()=> true
			},
			collectInterval: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			powerSupplyState: {
				isSupport: () => true
			},
			rpsPreConfig: {
				isSupport: () => false
			},
			sensorErrorCode: {
				isSupport: () => true
			}
		};
	}
}