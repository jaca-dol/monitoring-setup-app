import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('AM304L')
export class AM304LDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			retransmitEnable: {
				isSupport: () => true
			},
			exportData: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			},
			d2dMasterAndSlave: {
				isSupport: () => true
			},
			keyd2d: {
				isSupport: () => true
			},
			loraUplink: {
				isSupport: () => true
			},
		};
	}
}
