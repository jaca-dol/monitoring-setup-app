import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('UC50XCAT1')
export class UC50XCAT1DeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			exportData: {
				isSupport: () => true
			},
			retransmitEnable: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			preconfig: {
				isSupport: () => true
			}
		};
	}
}