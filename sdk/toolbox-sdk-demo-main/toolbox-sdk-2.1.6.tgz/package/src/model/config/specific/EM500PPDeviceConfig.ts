import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { identify } from '../../identify';

@DeviceConfigManager.register('EM500-PP')
export class EM500PPDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isEM500_0200_0107 = (model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return identify(model).isEM500_0200_0107(deviceInfo.hardwareVersion, deviceInfo.firmwareVersion);
		};
		return {
			keyd2d: {
				isSupport: isEM500_0200_0107,
			},
			loraUplink: {
				isSupport: isEM500_0200_0107,
			}
		};

	}
}