import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('SCT01')
export class SCT01DeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			clearData: {
				isSupport: () => true,
			},
			exportData: {
				isSupport: () => true,
			},
			patchUpgrade: {
				isSupport: () => false,
			},
			deviceStateSwitch: {
				isSupport: () => false,
			},
			templateEnable: {
				isSupport: () => false,
			}
		};
	}
}