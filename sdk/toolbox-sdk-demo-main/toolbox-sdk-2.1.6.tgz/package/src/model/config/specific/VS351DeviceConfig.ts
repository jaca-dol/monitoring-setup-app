import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('VS351')
export class VS351DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isVersion_0101_0104 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v1.1') && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
		};
		return {
			setMountingScene: {
				isSupport: isVersion_0101_0104,
			},
			reportingMode: {
				isSupport: isVersion_0101_0104,
			}
		};
	}
}