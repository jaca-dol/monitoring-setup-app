import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('UC521')
export class UC521DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isFirmwareGreaterThanOrEqualTo1_2 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			const { firmwareVersion } = deviceInfo;
			return Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.2');
		};
		const isFirmwareLessThan1_2 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			const { firmwareVersion } = deviceInfo;
			return Version.isLessThan(firmwareVersion, 'v1.2');
		};
		return {
			restart: {
				isSupport: ()=> true
			},
			// 规则引擎显示阀门
			ruleEngineValveStatus: {
				isSupport: isFirmwareLessThan1_2
			},
			collectInterval: {
				isSupport: isFirmwareLessThan1_2
			},
			openDelayCollectTime: {
				isSupport: isFirmwareGreaterThanOrEqualTo1_2
			},
			autoConfirmed: {
				isSupport: isFirmwareGreaterThanOrEqualTo1_2
			},
			// 灌溉时采集周期
			irrigationPeriod: {
				isSupport: isFirmwareGreaterThanOrEqualTo1_2
			},
			// 非灌溉时采集周期
			nonIrrigationPeriod: {
				isSupport: isFirmwareGreaterThanOrEqualTo1_2
			},
			// 阀门绑定  压力表0/1/2
			valveBindPressureGauge: {
				isSupport: isFirmwareGreaterThanOrEqualTo1_2
			},
			patchUpgrade: {
				isSupport: () => true
			},
			reportValveChange: {
				isSupport: () => true
			},
			classType: {
				isSupport: () => true
			},
			multicast: {
				isSupport: () => true
			},
			sensorErrorCode: {
				isSupport: () => true
			},
			pingSlotPeriod: {
				isSupport: () => true
			}
		};
	}
}