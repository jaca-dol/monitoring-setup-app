import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('EM300-TH')
export class EM300THDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			loraUplink: {
				isSupport: () => true
			}
		};
	}
}