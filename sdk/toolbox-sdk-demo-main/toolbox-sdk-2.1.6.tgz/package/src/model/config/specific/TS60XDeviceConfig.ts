import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('TS60X')
export class TS60XDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			retransmitEnable: {
				isSupport: () => true
			},
			exportData: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			preconfig: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			}
		};
	}
}