import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('CTH01')
export class CTH01DeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			classType: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true // 差分升级
			},
			retransmitEnable: {
				isSupport: () => true // 数据重传
			},
			exportData: {
				isSupport: () => true // 导出数据
			},
			preconfig: {
				isSupport: () => true // 预配置
			},
			deviceStateSwitch: {
				isSupport: () => false
			},
			restart: {
				isSupport: () => true
			},
		};
	}
}