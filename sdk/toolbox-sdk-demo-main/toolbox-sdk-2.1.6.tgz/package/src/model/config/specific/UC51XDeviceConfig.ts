import { Version } from '../../../utils/util/Version';
import { DeviceInfo } from '../../deviceInfo';
import { identify } from '../../identify';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('UC51X')
export class UC51XDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		//覆写默认的判断逻辑
		const isUC51Xv4_DI = (
			model: string,
			_modelSeries: string,
			deviceInfo: DeviceInfo
		) => {
			return (
				identify(model).isUC51Xv4(deviceInfo.hardwareVersion) &&
				model?.includes('DI') &&
				// v4硬件 v1.4固件才支持
				Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4')
			);
		};
		return {
			classType: {
				isSupport(model, _modelSeries, deviceInfo) {
					return identify(model).isUC51Xv4(deviceInfo.hardwareVersion);
				}
			},
			exportData: {
				isSupport(model, _modelSeries, deviceInfo) {
					// v4硬件 v1.4固件开始不支持导出数据
					return !(
						identify(model).isUC51Xv4(deviceInfo.hardwareVersion) &&
						Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4')
					);
				}
			},
			openDelayCollectTime: { isSupport: isUC51Xv4_DI },
			irrigationPeriod: { isSupport: isUC51Xv4_DI },
			nonIrrigationPeriod: { isSupport: isUC51Xv4_DI },
			patchUpgrade: { isSupport: isUC51Xv4_DI },
			gpioMode: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
				}
			},
			//预配置v4硬件 v2固件才支持
			gpioInvert: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0') && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.2');
				}
			}
		};
	}
}
