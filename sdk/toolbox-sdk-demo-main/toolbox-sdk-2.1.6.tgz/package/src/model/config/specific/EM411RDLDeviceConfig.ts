import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('EM411-RDL')
export class EM411RDLDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			retransmitEnable: {
				isSupport: () => true
			},
			exportData: {
				isSupport: () => true
			},
			deviceUpgrade: {
				isSupport: (_model, _modelSeries, deviceInfo) => deviceInfo?.readMode === 'ble'
			},
			patchUpgrade: {
				isSupport: (_model, _modelSeries, deviceInfo) => deviceInfo?.readMode === 'ble'
			},
			clearData: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			},
			deviceStateSwitch: {
				isSupport: () => false
			}
		};
	}
}