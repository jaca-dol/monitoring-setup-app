import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('GS601')
export class GS601DeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			deviceStateSwitch: {
				isSupport: () => false
			},
			restart: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			multicast: {
				isSupport: () => true
			},
			preconfig: {
				isSupport: () => true
			},
			tvocClear: {
				isSupport: () => true
			}
		};
	}
}