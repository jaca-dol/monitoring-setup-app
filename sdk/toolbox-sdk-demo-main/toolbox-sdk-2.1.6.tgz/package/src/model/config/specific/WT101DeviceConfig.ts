import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('WT101')
export class WT101DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			patchUpgrade: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.3');
				}
			},
			timezonePicker: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.3');
				}
			},
			daylightSaveTime: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.3');
				}
			},
			ambientDisplay: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.3');
				}
			},
			validRange: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, '1.3');
				}
			}
		};
	}
}