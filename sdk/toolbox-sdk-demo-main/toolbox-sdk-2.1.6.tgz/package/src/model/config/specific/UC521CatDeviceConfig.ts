import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('UC521-L0ACN')
export class UC521CatDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		//覆写默认的判断逻辑
		return {
			restart: {
				isSupport: ()=> true
			},
			collectInterval: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			powerSupplyState: {
				isSupport: () => false
			},
			rpsPreConfig: {
				isSupport: () => false
			},
			reportValveChange: {
				isSupport: () => true
			},
			sensorErrorCode: {
				isSupport: () => true
			}
		};
	}
}