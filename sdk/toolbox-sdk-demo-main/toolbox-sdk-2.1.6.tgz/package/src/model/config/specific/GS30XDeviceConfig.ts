import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('GS30X')
export class GS30XDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {	
		const isV1_2 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {			
			let version = '';
			if (deviceInfo.sensorID && deviceInfo.sensorID.length > 0)  {
				const versions = deviceInfo.sensorID.split('-');
				if (versions.length > 0) {
					version = versions[versions.length - 1] ?? '';
				}
			}
			if (Version.isGreaterThanOrEqualTo(version, '01010207')) {
				return true;
			}			
			return false;
		};
		return {
			nh3Calibration: {
				isSupport: isV1_2
			},		
		};

	}
}