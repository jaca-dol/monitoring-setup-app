import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';

@DeviceConfigManager.register('VS370')
export class VS370DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			loraUplink: {
				isSupport: () => true,
			},
			controlTime: {
				isSupport: () => true,
			},
			patchUpgrade: {
				isSupport: () => true,
			},
			singleChannelMode: {
				isSupport: () => true,
			},
			restart: {
				isSupport: () => true,
			},
			deviceStateSwitch: {
				isSupport: () => false,
			},
			keyd2d: {
				isSupport: () => true,
			},
			fullUpgradeNoListenTag: {
				isSupport: () => true,
			}
		};
	}
}