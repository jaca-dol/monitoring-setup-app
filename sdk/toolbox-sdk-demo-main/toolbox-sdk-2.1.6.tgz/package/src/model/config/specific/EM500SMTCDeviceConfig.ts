import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { identify } from '../../identify';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('EM500-SMTC')
export class EM500SMTCDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isEM500_0200_0107 = (model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return identify(model).isEM500_0200_0107(deviceInfo.hardwareVersion, deviceInfo.firmwareVersion);
		};

		const isEM500_0200_0110 = (_: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.10') && Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
		};
		return {
			keyd2d: {
				isSupport: isEM500_0200_0107,
			},
			loraUplink: {
				isSupport: isEM500_0200_0107,
			},
			humidity: {
				isSupport: isEM500_0200_0110                
			}
		};

	}
}