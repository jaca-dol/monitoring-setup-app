import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { Version } from '../../../utils/util/Version';
import { Platform } from 'react-native';

@DeviceConfigManager.register('VS360')
export class VS360DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isFirmwareVersion1_2 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => 
			deviceInfo ? Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.2') : false;
		return {
			patchUpgrade: {
				isSupport: () => Platform.OS !== 'ios'
			},
			hourReportingMode: {
				isSupport: isFirmwareVersion1_2
			}
		};

	}
}