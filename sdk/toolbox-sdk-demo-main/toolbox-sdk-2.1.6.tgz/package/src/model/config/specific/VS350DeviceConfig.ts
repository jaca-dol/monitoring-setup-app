import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { Version } from '../../../utils/util/Version';

@DeviceConfigManager.register('VS350')
export class VS350DeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			patchUpgrade: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
				}
			},
			reportingMode: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0');
				}
			},
			installCfg: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0');
				}
			},
			minuteReportingMode: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0') && Version.isLessThan(deviceInfo.hardwareVersion, 'v3.0');
				}
			},
			beforeReportingMode: {
				isSupport(_model, _modelSeries, deviceInfo) {
					return Version.isLessThan(deviceInfo.hardwareVersion, 'v2.0');
				}
			}
		};
	}
}