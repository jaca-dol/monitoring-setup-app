import { Platform } from 'react-native';

import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('UC500NB')
export class UC50XNBDeviceConfigService extends BasicDeviceConfigService {			
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			retransmitEnable: {
				isSupport: () => true
			},
			serialSettings: {
				isSupport: () => true
			},
			gpioSettings: {
				isSupport: () => true
			},
			aiSettings: {
				isSupport: () => true
			},
			cellularSettings: {
				isSupport: () => true
			},
			applicationModeSettings: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			},
			exportData: {
				isSupport: () => Platform.OS === 'android'
			},
			clearData: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			ruleEngine: {
				isSupport: () => true
			},
			sdi12Setting: {
				isSupport: () => true
			},
			supplyCurrent: {
				isSupport: () => true
			},
			clientId: {
				isSupport: () => true
			},
			receipt: {
				isSupport: () => true
			},
			receiptUsername: {
				isSupport: () => true
			},
			receiptPassword: {
				isSupport: () => true
			},
			TLS: {
				isSupport: () => true
			},
			rootCert: {
				isSupport: () => true
			},
			clientCert: {
				isSupport: () => true
			},
			clientKey: {
				isSupport: () => true
			},
			serverPort: {
				isSupport: () => true
			},
			serverIp: {
				isSupport: () => true
			}
		};
	}
}