import { SupportSettingMap } from '../IDeviceConfigService';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService } from '../IDeviceConfigService';
import { DeviceInfo } from '../../deviceInfo';
import { Version } from '../../../utils/util/Version';
import { Identify } from '../../identify';

@DeviceConfigManager.register('WS500')
export class WS50XDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		const isWS50XCN_0100_0103 = (model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return Identify.isWS50XCN(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3');
		};
		return {
			timezonePicker: {
				isSupport: isWS50XCN_0100_0103,
			},
		};
	}
}