import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, ClassTypeOption, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('WS50XW')
export class WS50XWDeviceConfigService extends BasicDeviceConfigService {
	getSupportSettingMap(): SupportSettingMap | undefined {
		return {
			retransmitEnable: {
				isSupport: () => true
			},
			d2dMasterAndSlave: {
				isSupport: () => true
			},
			keyd2d: {
				isSupport: () => true
			},
			enableStatus: {
				isSupport: () => true
			},
			loraUplink: {
				isSupport: () => true
			},
			buttonLockId: {
				isSupport: () => true
			},
			restart: {
				isSupport: () => true
			},
			pingSlotPeriod: {
				isSupport: () => true
			},
			patchUpgrade: {
				isSupport: () => true
			},
			multicast: {
				isSupport: () => true
			},
			sensorErrorCode: {
				isSupport: () => true
			}
		};
	}

	getClassTypeOptions(): ClassTypeOption[] | undefined {
		return [{ label: 'ClassC', value: 2 }];
	}
}