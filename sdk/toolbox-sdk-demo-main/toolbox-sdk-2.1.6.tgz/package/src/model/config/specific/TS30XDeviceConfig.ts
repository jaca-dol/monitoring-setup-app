import { Version } from '../../../utils/util/Version';
import { DeviceInfo } from '../../deviceInfo';
import { DeviceConfigManager } from '../DeviceConfigManager';
import { BasicDeviceConfigService, SupportSettingMap } from '../IDeviceConfigService';

@DeviceConfigManager.register('TS30X')
export class TS30XDeviceConfigService extends BasicDeviceConfigService {	
	isVersion2_0(deviceInfo: DeviceInfo) {
		return deviceInfo ? Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0') : false;
	}
	getSupportSettingMap(): SupportSettingMap | undefined {
		const _isVersion2_0 = (_model: string, _modelSeries: string, deviceInfo: DeviceInfo) => {
			return this.isVersion2_0(deviceInfo);
		};
		return {
			deviceUpgrade: {
				isSupport: _isVersion2_0
			},
			patchUpgrade: {
				isSupport: _isVersion2_0
			},
			d2dMasterAndSlave: {
				isSupport: _isVersion2_0
			},
			keyd2d: {
				isSupport: _isVersion2_0
			},
			loraUplink: {
				isSupport: _isVersion2_0
			}
		};
	}
}