import { injectable } from 'inversify';

import { IDeviceConfigService } from "./IDeviceConfigService";
import { Models, getModelSeries } from "../";
import { deviceContainer } from '../../service/DeviceManager/device_container';

const DEVICE_CONFIG_SERVICE_SYMBOL = Symbol.for('DeviceConfigService');


/**
 * 设备配置服务管理器
 */
export class DeviceConfigManager {
	/**
	 * 安全获取设备设置服务的实例
	 * @param serviceName - 服务名称
	 * @returns - 设备设置服务的实例 | undefined
	 */
	private static getServiceSafely(serviceName: string): IDeviceConfigService | undefined {
		try {
			return deviceContainer.getNamed<IDeviceConfigService>(
				DEVICE_CONFIG_SERVICE_SYMBOL,
				serviceName
			);
		} catch (error) {
			return undefined;
		}
	}

	/**
	 * 获取设备设置服务的实例
	 * @param model - 设备型号
	 * @returns - 设备设置服务的实例 | undefined
	 */
	public static getDeviceConfigService(model: string): IDeviceConfigService | undefined {
		let service = this.getServiceSafely(model);
		
		if (!service) {
			const modelSeries = getModelSeries(model);
			service = this.getServiceSafely(modelSeries);
		}

		return service;
	}

	/**
	 * 注册设备设置服务
	 * @param models - 设备型号/系列
	 * @returns - 设备设置服务的装饰器
	 */
	public static register(models: Models): ClassDecorator {
		return (target: any) => {
			injectable()(target); // 使服务类可以被 InversifyJS 注入
			deviceContainer.bind<IDeviceConfigService>(DEVICE_CONFIG_SERVICE_SYMBOL).to(target)
				.inSingletonScope()
				.whenTargetNamed(models);
		};
	}
}