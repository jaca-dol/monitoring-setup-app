import _ from 'lodash';

import { MODEL_SERIES, MODELS, NEUTRAL_MODEL_SET } from './constants';
import { identify } from './identify';

/**
 * SN前缀 -> 型号前缀的映射
 */
export const SnModelMap: { [sn: string]: string | undefined; } = {
	6126: "EM500",
	6127: "AM104",
	6128: "AM107",
	6136: "EM300",
	6138: "EM300_NB",
	6141: "WS301",
	6145: "WS501",
	6146: "WS502",
	6147: "WS503",
	6148: "WS52X",
	6329: "EM400",
	6406: "WT30X",
	6408: "WT201",
	6411: "UC502",
	6412: "UC501",
	6413: "UC502", //UC502（不可充电）
	6414: "UC511",
	6415: "UC512",
	6443: "VS321",
	6447: "TS601_L0DEU",
	6448: "TS602_L0DEU",
	6454: "UC50X",
	6460: "UC51X",
	6643: "TS601_L0FNA",
	6644: "TS602_L0FNA",
	6645: "TS601_L0DLA",
	6646: "TS602_L0DLA",
	6805: "UC51X_CAT",
	6830: "UC521_CAT",
	6831: "UC521_CAT",
	6832: "UC521",
	6535: "WS101",
	6538: "WS202",
	6592: "WS1XX",
	6598: "WS51X",
	6601: "DS3604",
	6602: "DS3604",
	6617: "VS3XX",
	6619: "AM319",
	6626: "EM411",
	6696: "AM304L",
	6699: "AM305L",
	6701: "WS558",
	6707: "AM307",
	6710: "AM319",
	6713: "EM310",
	6714: "WT101",
	6527: "WT102",
	6715: "WT201",
	6716: "VS350",
	6717: "VS350",
	6723: "TS30X",
	6508: "TS30X", // TS30Xv2
	6725: "AM103",
	6732: "TS101",
	6743: "WS302",
	6745: "AT101",
	6747: "JX",
	6748:"EM400_NB",
	6749:"EM400_NB",
	6756: "WS558", //WS558v2
	6758: "WT211",
	6762: "WS51X",
	6771: "WS50XEU",
	6772: "UC50X_NB",
	6773: "VS370",
	6777: "WS50XUS",
	6782: "WS50XEUD", //WS50XEUD(CN与EU共用外壳和PCB，所以内部代号使用EUD)
	6785: "EM320",
	6787: "VS34X",
	6791: "WS203",
	6798: "GS301",
	6799: "VS351",	
	6809: "TS201",
	6822: "UC50XCAT1",
	6824: "VS360",	
	6850: "GS601",
	6861: "SCT01",
	6862: "EM410",
	6983: "WS201",
	6984: "WS201",
	6993: "WS303",
	6409: "WT401",
	6407: "UC711",
	6704: "VA05_T",
	6433: "TS201",
	6607: "WS501W",
	6640: "WS502W",
	6641: "WS503W",
	6637: "CTH01",
};

/**
 * PN -> Model/MODEL_SERIES的映射
 */
export const PnModelMap: { [model: string]: { [pn: string]: string }; } = {
	"EM300": {
		"100": MODELS.EM300_TH,
		"200": MODELS.EM300_WL,
		"210": MODELS.EM300_ZLD,
		"220": MODELS.EM300_SLD,
		"230": MODELS.EM300_MLD,
		"310": MODELS.EM300_MCS,
		"320": MODELS.EM300_SW,
		"430": MODELS.EM300_DI,
		"431": MODELS.EM300_DI,
		"432": MODELS.EM300_DI_HALL,
		"540": MODELS.EM300_CL,
	},
	"TS30X": {
		"000": MODELS.TS301,
		"001": MODELS.TS302
	},
	"EM310": {
		"000": MODELS.EM310_UDL,
		"001": MODELS.EM310_TILT
	},
	"EM320": {
		"000": MODELS.EM320_TH,
		"001": MODELS.EM320_TILT,
		"002": MODELS.EM320_TH,
		"003": MODELS.EM320_TH,
		"004": MODELS.EM320_TH,
	},
	"EM300_NB": {
		"100": MODELS.EM300_TH_N00CN,
		"210": MODELS.EM300_ZLD_N00CN,
		"220": MODELS.EM300_SLD_N00CN,
		"310": MODELS.EM300_MCS_N00CN,
		"320": MODELS.EM300_SW_N00CN
	},
	"EM400": {
		'000': MODELS.EM400_TLD,
		'001': MODELS.EM400_TLD,
		'002': MODELS.EM400_MUD_B045,
		'003': MODELS.EM400_UDL_C050,
		'004': MODELS.EM400_UDL_C100,
		'005': MODELS.EM400_UDL_W050,
		'006': MODELS.EM400_UDL_W100,
		'007': MODELS.EM400_UDL_S050,
		'008': MODELS.EM400_MUD_B045
	},
	"EM400_NB": {
		'000': MODELS.EM400_TLD_N03GL,
		'001': MODELS.EM400_MUD_N03GL,
		'002': MODELS.EM400_MUD_N03GL,
		'003': MODELS.EM400_UDL_C050_N03GL,
		'004': MODELS.EM400_UDL_C100_N03GL,
		'005': MODELS.EM400_UDL_W050_N03GL,
		'006': MODELS.EM400_UDL_W100_N03GL,
		'007': MODELS.EM400_UDL_S050_N03GL,
	},
	"EM410":{
		'000': MODELS.EM410_RDL,
		'001': MODELS.EM410_RDL,
		'002': MODELS.EM410_RDL_L0CEU,
		'003': MODELS.EM410_RDL_L0CEU,
		'004': MODELS.EM410_RDL,
		'005': MODELS.EM410_RDL,
		'006': MODELS.EM410_RDL_L0CEU,
		'007': MODELS.EM410_RDL_L0CEU,
	},
	"EM411":{
		'001': MODELS.EM411_RDL,
		'002': MODELS.EM411_RDL,
		'003': MODELS.EM411_RDL,
		'004': MODELS.EM411_RDL,
	},
	"EM500": {
		//旧sn定义
		"001": MODELS.EM500_UDL_W050,
		"002": MODELS.EM500_UDL_W100,
		"003": MODELS.EM500_SMT_EC5,
		"004": MODELS.EM500_PT100_T200,
		"005": MODELS.EM500_PT100_T500,
		"006": MODELS.EM500_PT100_T800,
		"007": MODELS.EM500_PAR,
		"008": MODELS.EM500_SWL_L003,
		"009": MODELS.EM500_SWL_L005,
		"00A": MODELS.EM500_SWL_L010,
		"00B": MODELS.EM500_CO2,
		"00C": MODELS.EM500_PM25,
		"00D": MODELS.EM500_PT100_T050,
		"00F": MODELS.EM500_UDL_S050,
		"010": MODELS.EM500_UDL_S100,
		//新sn定义
		"100": MODEL_SERIES.EM500_PT100,
		"200": MODELS.EM500_SMT_EC5,
		"201": MODELS.EM500_SMT_MT10,
		"202": MODELS.EM500_SMTC_MEC20,
		"203": MODELS.EM500_SMT_MT05,
		"300": MODEL_SERIES.EM500_UDL,
		"301": MODEL_SERIES.EM500_UDL,
		"303": MODELS.EM500_UDL_C050,
		"304": MODELS.EM500_UDL_C100,
		"400": MODEL_SERIES.EM500_SWL,
		"401": MODELS.EM500_SWL_L003,
		"402": MODELS.EM500_SWL_L005,
		"403": MODELS.EM500_SWL_L010,
		"404": MODELS.EM500_SWL_KZ,
		"500": MODELS.EM500_PP_G1_2M_P300,
		"501": MODELS.EM500_PP_G1_2M_1002,
		"502": MODELS.EM500_PP_G1_2M_4780,
		"503": MODELS.EM500_PP_G1_2M_4842,
		"504": MODELS.EM500_PP_KZ,
		"600": MODELS.EM500_CO2,
		"700": MODELS.EM500_LGT,
		"800": MODELS.EM500_CO,
		"810": MODELS.EM500_NH3,
		"820": MODELS.EM500_H2S,
		"821": MODELS.EM500_H2S
	},
	//UC50Xv2
	"UC50X": {
		"000": MODELS.UC501,
		"001": MODELS.UC502,
		"002": MODELS.WTS_305,
		"003": MODELS.WTS_505,
		"004": MODELS.WTS_506,
		"005": MODELS.UC501,
		"006": MODELS.UC502,
	},
	// UC50XNB通过SN无法定义最终具体型号，后续逻辑具体定义
	"UC50X_NB": {
		"000": 'UC501NB', 
		"001": 'UC502NB',
	},
	"UC50XCAT1": {
		"000": MODELS.UC501_L0CEU,
		"001": MODELS.UC502_L0CEU
	},
	"UC511": {
		"001": MODELS.UC511,
		"002": MODELS.UC511_DI
	},
	//UC51X V2.0
	"UC51X": {
		"000": MODELS.UC511_DI,
		"001": MODELS.UC512_DI,
		"002": MODELS.UC511_DI,
		"003": MODELS.UC512_DI,
		"004": MODELS.UC512_DI,
		"005": MODELS.UC512_DI,
		"006": MODELS.UC511_DI,
		"007": MODELS.UC511_DI,
	},
	"UC51X_CAT": {
		"000": MODELS.UC511_DI_L0ACN,
		"001": MODELS.UC511_DI_L0ACN,
		"002": MODELS.UC511_DI_L0ACN,
		"003": MODELS.UC511_DI_L0ACN,
	},
	"UC521": {
		"000": MODELS.UC521,
	},
	"UC521_CAT": {
		"001": MODELS.UC521_L0ACN,
	},
	"UC512": {
		"001": MODELS.UC512,
		"002": MODELS.UC512_DI
	},
	"WS1XX": {
		"000": MODELS.WS136,
		"001": MODELS.WS156
	},
	"WS203": {
		"000": MODELS.WS203
	},
	"WS302": {
		"000": MODELS.WS302
	},
	"WS50XEU": {
		'131': MODELS.WS501EU,
		'132': MODELS.WS502EU,
		'133': MODELS.WS503EU
	},
	"WS50XEUD": {
		'121': MODELS.WS501EUD,
		'122': MODELS.WS502EUD,
		'123': MODELS.WS503EUD
	},
	"WS50XUS": {
		'231': MODELS.WS501US,
		'232': MODELS.WS502US,
		'233': MODELS.WS503US
	},
	"WS50XW": {
		'021': MODELS.WS501W_2W,
		'022': MODELS.WS502W_2W,
		'023': MODELS.WS503W_2W,
		'031': MODELS.WS501W_3W,
		'032': MODELS.WS502W_3W,
		'033': MODELS.WS503W_3W
	},
	"WS51X": {
		"105": MODELS.WS515,
		"203": MODELS.WS513
	},
	"WS52X": {
		"105": MODELS.WS525_10A_CN,
		"203": MODELS.WS523_16A_CN,
		"113": MODELS.WS525_10A_US,
		"123": MODELS.WS525_10A_AU,
		"132": MODELS.WS522_10A_EU,
		"343": MODELS.WS523_13A_UK,
		"413": MODELS.WS523_15A_US,
		"232": MODELS.WS525_16A_EU,
		"233": MODELS.WS523_16A_EU,
		"243": MODELS.WS523_16A_FR,
	},
	"WS558": {
		"000": MODELS.WS558,
		"001": MODELS.WS558
	},
	"AM102": {
		"002": MODELS.AM102,
		"003": MODELS.AM102L
	},
	"AM103": {
		"000": MODELS.AM103L,
		"001": MODELS.AM103,
		"002": MODELS.AM102L,
		"003": MODELS.AM102
	},
	"AM304L": {
		"000": MODELS.AM304L
	},
	"AM305L": {
		"000": MODELS.AM305L
	},
	"AM307": {
		"070": MODELS.AM307,
		"270": MODELS.AM307L,
		"080": MODELS.AM308,
		"280": MODELS.AM308L,
	},
	"AM319": {
		"191": MODELS.AM319_HCHO,
		"192": MODELS.AM319_O3,
		"193": MODELS.AM319_HCHO_IR,
		"194": MODELS.AM319_HCHO_IR_W,
		"391": MODELS.AM319L_HCHO_IR,
		"392": MODELS.AM319L_O3        
	},
	"JX": {
		"000": MODELS.JT_GS101
	},
	"GS301": {
		"000": MODELS.GS301
	},
	"VS3XX": {
		"000": MODELS.VS330
	},
	"VS34X":{
		"000": MODELS.VS340,
		"001": MODELS.VS341
	},
	"DS3604": {
		"000": MODELS.DS3604
	},
	"TS101": {
		"000": MODELS.TS101
	},
	"TS201": {
		"000": MODELS.TS201,	
		"001": MODELS.TS201,		
	},
	"TS601_L0DEU": {
		"000": MODELS.TS601_L0DEU
	},
	"TS602_L0DEU": {
		"000": MODELS.TS602_L0DEU
	},
	"TS601_L0FNA": {
		"000": MODELS.TS601_L0FNA
	},
	"TS602_L0FNA": {
		"000": MODELS.TS602_L0FNA
	},
	"TS601_L0DLA": {
		"000": MODELS.TS601_L0DLA
	},
	"TS602_L0DLA": {
		"000": MODELS.TS602_L0DLA
	},
	"SCT01": {
		"000": MODELS.SCT01
	},
	"VS350": {
		"000": MODELS.VS350
	},
	"VS351": {
		"000": MODELS.VS351
	},
	"WT201": {
		"000": MODELS.WT201
	},
	"WT211": {
		"000": MODELS.WT211
	},
	"WT401": {
		"000": MODELS.WT401
	},
	"WT30X": {
		"001": MODELS.WT303,
		"002": MODELS.WT304,
		"003": MODELS.WT303_ZH,
		"004": MODELS.WT304_ZH
	},
	"VS360": {
		"000": MODELS.VS360
	},
	"VS370": {
		"000": MODELS.VS370
	},
	"GS601": {
		"000": MODELS.GS601
	},
	"UC711": {
		"000": MODELS.UC711
	},
	"VA05_T": {
		"000": MODELS.VA05_T
	},
	"VS321": {
		"001": MODELS.VS321
	},
	"WT102": {
		"000": MODELS.WT102
	},
	"CTH01": {
		"000": MODELS.CTH01
	},
};

/**
 * 型号前缀/具体型号 -> SN前缀的映射
 * @example
 * {
 *	"EM300": "6136",
 *	"EM500": "6126",
 *	'EM300-TH': '6136',
 *	'EM300-WL': '6136',
 *	'EM500-SWL-L003': '6126',
 * }
 */
export const ModelSnMap: { [key: string]: string; } = getModelSnMap(SnModelMap, PnModelMap);

/**
* 型号前缀 -> SN前缀的映射
* 用于处理相同model拥有不同的sn前缀和pn后缀的情况
* @example
* {
*	"EM300": "6136",
*	'EM400': '6329',
*	"EM500": "6126",
*	"WS52X": "6148"
* }
*/
export const ModelPrefixSnMap: { [key: string]: string; } = getModelPrefixSnMap(SnModelMap);

/**
 * 具体型号 -> PN的映射
 * @example
 * {
 *	'EM300-TH': '100',
 *	'EM300-WL': '200',
 *	'WS525-10A-CN': '105',
 * }
 */
export const ModelPnMap: { [key: string]: string; } = getModelPnMap(PnModelMap);

/**
 * 具体型号 -> 型号前缀的映射
 * @example
 * {
 *	'EM300-TH': 'EM300',
 *	'EM300-WL': 'EM300',
 *	'WS525-10A-CN': 'WS52X',
 *	'EM400-UDL-C050': 'EM400',
 *	'EM400_TLD_N03GL': 'EM400_NB'
 * }
 */
export const ModelPrefixMap: { [key: string]: string; } = getModelPrefixMap(PnModelMap);

/**
 * 获取型号前缀/具体型号 -> SN前缀的映射
 * @param snModelMap - SN前缀 -> 型号的映射
 * @param pnModelMap - PN -> 型号的映射
 * @returns 
 */
export function getModelSnMap(snModelMap: typeof SnModelMap, pnModelMap: typeof PnModelMap) {
	const modelSnMap: { [key: string]: string; } = {};

	_.forEach(snModelMap, (model, snPrefix) => {
		if (model) {
			modelSnMap[model] = snPrefix;
		}
	});

	_.forEach(pnModelMap, (cache, type) => {
		const snPrefix = modelSnMap[type];
		if (snPrefix) {
			_.forEach(cache, v => {
				if (v) {
					modelSnMap[v] = snPrefix;
				}
			});
		}
	});

	return modelSnMap;
}

/**
 * 获取具体型号 -> SN前缀的映射
 * @param snModelMap - SN前缀 -> 型号的映射
 * @returns 
 */
export function getModelPrefixSnMap(snModelMap: typeof SnModelMap) {
	const modelPrefixSnMap: { [key: string]: string; } = {};

	_.forEach(snModelMap, (model, snPrefix) => {
		if (model) {
			modelPrefixSnMap[model] = snPrefix;
		}
	});

	return modelPrefixSnMap;
}

/**
 * 获取具体型号 -> PN的映射
 * @param pnModelMap - PN -> 型号的映射
 * @returns 
 */
export function getModelPnMap(pnModelMap: typeof PnModelMap) {
	const modelPnMap: { [key: string]: string; } = {};

	_.forEach(pnModelMap, (cache, _prefix) => _.forEach(cache, (model, pn) => {
		if (model) {
			modelPnMap[model] = pn;
		}
	}));

	return modelPnMap;
}

/**
 * 获取具体型号 -> 型号前缀的映射
 * @param pnModelMap - PN -> 型号的映射
 * @returns 
 */
export function getModelPrefixMap(pnModelMap: typeof PnModelMap) {
	const modelPrefixMap: { [key: string]: string; } = {};

	_.forEach(pnModelMap, (cache, prefix) => _.forEach(cache, (model, _pn) => {
		if (model) {
			modelPrefixMap[model] = prefix;
		}
	}));

	return modelPrefixMap;
}

/**
 * 获取设备型号
 * @param sn - 设备sn
 * @param model - 设备model（设备传过来的model带有频段）
 * @param pn - 设备pn
 * @param subModel - 设备型号频段
 * @returns - 设备型号(无频段)
 */
export function getDeviceModel(sn = '', model?: string, pn = '', subModel = '') {
	const trimFreqModel = _.isString(model) && _.chain(model).split('-').dropRight(1).join('-').value(); //去掉频率之后的model
	const prefix = sn.slice(0, 4);
	const suffix = sn.slice(sn.length - 4, sn.length - 1);
	let generateModel = SnModelMap[prefix];

	//部分设备判断具体型号需要依据频段字段
	const isFreqModel = [ 'EM400_NB', 'UC50X_NB', 'UC51X_CAT', 'EM410', 'UC521', 'WT30X', 'UC50XCAT1' ].includes(generateModel ?? '');

	if(trimFreqModel && !isFreqModel) {
		//FIXME: 这里会导致部分型号如：WT303-ZH被误判为WT303，而无法正确判断为WT303-ZH的型号
		if(_.has(MODELS, trimFreqModel)) {
			console.debug('get model with trimFreqModel: ', `${trimFreqModel}`);
			return trimFreqModel;
		}

		if(_.has(MODELS, `${trimFreqModel}-${pn}`)) {
			console.debug('get model with trimFreqModel and pn: ', `${trimFreqModel}-${pn}`);
			return `${trimFreqModel}-${pn}`;
		}
	}

	if (sn.length === 16) {
		generateModel = _.get(PnModelMap, [ generateModel as string, suffix ], generateModel) as string;
	}

	const isWS = _.includes([ 'WS501', 'WS502', 'WS503', MODELS['WS501EUD'], MODELS['WS502EUD'], MODELS['WS503EUD'] ], generateModel);
	const isUC50XNB = _.includes([ 'UC501NB', 'UC502NB' ], generateModel);
	const isWS50XW = _.includes([ 'WS501W', 'WS502W', 'WS503W' ], generateModel);

	// 如果是UC50XNB，需要根据model的频段判断其具体型号
	if (isUC50XNB) {
		const modelMappings = {
			'N03GL': {
				'UC501NB': MODELS['UC501-N03GL'],
				'UC502NB': MODELS['UC502-N03GL']
			},
			'L0ACN': {
				'UC501NB': MODELS['UC501-L0ACN'],
				'UC502NB': MODELS['UC502-L0ACN']
			},
			'N04GL': {
				'UC501NB': MODELS['UC501-N04GL'],
				'UC502NB': MODELS['UC502-N04GL']
			}
		} as const;

		const freqKey = Object.keys(modelMappings).find(key => subModel?.includes(key)) as keyof typeof modelMappings;
		if (freqKey) {
			const mapping = modelMappings[freqKey];
			const curModel = mapping[generateModel as keyof typeof mapping];
			if (mapping && curModel) {
				const mappedModel = curModel;
				generateModel = MODELS[mappedModel];
			}
		}
	}

	//如果是开关面板，需要根据pn去判断其是单火还是零火版本
	if(isWS || isWS50XW) {
		const pnInfo = _.get(pn.split('-'), [0], '');
		const isValidPn = _.includes([ '2W', '3W' ], pnInfo);
		generateModel = isValidPn 
			? generateModel + '-' + pnInfo 
			: generateModel;
	}
	
	return generateModel;
}

/**
 * 仅根据前四位判断设备类型, 不校验SN完整性
 * @param sn
 */
export function getMainModelBySnPrefix(sn: string) {
	return SnModelMap[sn?.slice(0, 4)];
}

/**
 * 通过sn获取设备型号, 如果sn不符合规则返回undefined
 * @param sn
 * @param swallowError
 */
export function getModelBySN(sn: string, swallowError?: false): string;
// eslint-disable-next-line no-redeclare
export function getModelBySN(sn: string, swallowError: true): string | undefined;
// eslint-disable-next-line no-redeclare
export function getModelBySN(sn: string, swallowError = true): string | undefined {
	let type: string | undefined;
	
	try {
		type = getMainModelBySnPrefix(sn);
		
		if (sn.length === 16) {
			type = PnModelMap[type || ""]?.[sn.slice(12, 15)];
		} else if (sn.length !== 12) {
			throw new Error(`Invalid SN: ${sn}`);
		}
		
		if (type && PnModelMap[type] && sn.length !== 16) {
			throw new Error(`Invalid SN: ${sn}`);
		}
		
		if (!type) {
			throw new Error(`Invalid SN: ${sn}`);
		}
	} catch (e) {
		if (swallowError) {
			if (e instanceof Error) {
				console.warn(e.message);
			} else {
				console.warn(e);
			}

			return undefined;
		} else {
			throw e;
		}
	}

	return type;
}

/**
 * 获取设备型号系列
 * @param {string} model - 设备型号
 */
export const getModelSeries = _.memoize(model => {
	
	
	if(!_.isString(model)) {
		return '';
	}
	if(_.has(MODEL_SERIES, model)) {
		return model;
	}
	if(model.startsWith('UC71')) {
		return MODEL_SERIES['UC711'];
	}

	if([ 'WS501W', 'WS502W', 'WS503W' ].some(m=>model.startsWith(m))) {
		return MODEL_SERIES['WS50XW'];
	}

	if(model.startsWith('AM102')) {
		return MODEL_SERIES['AM102'];
	}

	if(model.startsWith('AM103')) {
		return MODEL_SERIES['AM103'];
	}

	if(model.startsWith('AM3')) {
		return MODEL_SERIES['AM300'];
	}

	if(/^UC50[1-9]-(L(?!0ACN)[A-Z0-9]{4})$/.test(model)) {
		return MODEL_SERIES['UC50XCAT1'];
	}

	if (identify(model).isUC50XNB()) {
		return MODEL_SERIES['UC500NB'];
	}

	if (model.startsWith('UC50')) {
		return MODEL_SERIES['UC500'];
	}

	if(_.includes([ MODELS['UC511'], MODELS['UC511-DI'], MODELS['UC512'], MODELS['UC512-DI'] ], model)) {
		return MODEL_SERIES['UC51X'];
	}

	if(_.includes([MODELS['UC511-DI-L0ACN']], model)) {
		return MODEL_SERIES['UC51X-CAT'];
	}
	if(_.includes([ MODELS['UC521'], MODELS['UC521-L0ACN'] ], model)) {
		return MODEL_SERIES['UC521'];
	}

	if(model.startsWith('WS10')) {
		return MODEL_SERIES['WS100'];
	}

	if(model.startsWith('WS13')) {
		return MODEL_SERIES['WS130'];
	}

	if(model.startsWith('WS15')) {
		return MODEL_SERIES['WS150'];
	}

	if (_.includes([ MODELS['WS202'], MODELS['WS203'] ], model)) {
		return MODEL_SERIES['WS200'];
	}

	if(model.startsWith('WS30')) {
		return MODEL_SERIES['WS300'];
	}

	if(model.startsWith('WS50')) {
		return MODEL_SERIES['WS500'];
	}

	if(model.startsWith('WS52')) {
		return MODEL_SERIES['WS520'];
	}

	if(model.startsWith('WS51')) {
		return MODEL_SERIES['WS51X'];
	}

	if(model.startsWith('WS55')) {
		return MODEL_SERIES['WS550'];
	}

	if(model === MODEL_SERIES['EM500-PT100']) {
		return MODEL_SERIES['EM500-PT100'];
	}

	if(model.startsWith('EM400-UDL') || model.startsWith('EM400-MUD')){
		return MODEL_SERIES['EM400-UDL'];
	}

	if(model.startsWith('J') && model.includes('GS')) {
		return MODEL_SERIES['JX'];
	}

	if(model.startsWith('WTS')) {
		return MODEL_SERIES['WTS'];
	}

	if(model.startsWith('GS30')) {
		return MODEL_SERIES['GS30X'];
	}

	if(model.startsWith('VS')) {
		return MODEL_SERIES['VS'];
	}

	if(model.startsWith('DS')) {
		return MODEL_SERIES['DS'];
	}

	if(model.startsWith('TS60')) {
		return MODEL_SERIES['TS60X'];
	}

	if(model.startsWith('TS')) {
		if (model === MODELS['TS301'] || model === MODELS['TS302']) {
			return MODEL_SERIES['TS30X'];
		}
		return MODEL_SERIES['TS'];
	}

	if(model.startsWith('AT')) {
		return MODEL_SERIES['AT'];
	}

	if(model.startsWith('WT30')) {
		return MODEL_SERIES['WT30X'];
	}

	if([ 'WT201', 'WT211' ].some(m=>model.startsWith(m))) {
		return MODEL_SERIES['WT2X1'];
	}

	if(!Object.keys(MODELS).includes(model)) {
		return '';
	}

	const splitModel = model.split('-', 2).join('-');

	if(!_.has(MODEL_SERIES, splitModel)) {
		return model;
	}

	return splitModel;
});

/**
 * 传感器设备是否为中性版本
 * @param oem - 设备oem
 */
export const getDeviceIsNeutral = (oem?: string) => {
	if(!oem) {
		return false;
	}

	return [ '0010', '1086' ].includes(oem);
};

/**
 * 获取设备分组的中性
 */
export const getNeutralDeviceModelGroup = (group: string, _oem?: string) => {
	let neutralGroup = group;

	NEUTRAL_MODEL_SET.forEach(m => {
		if(group.startsWith(m.sPrefix)) {
			neutralGroup = group.replace(m.sPrefix, m.nPrefix);
		}
	});

	return neutralGroup;
};

/**
* 获取设备的中性型号
*/
export const getNeutralDeviceModel = (model: string, _oem?: string) => {
	let neutralModel = model;

	NEUTRAL_MODEL_SET.forEach(m => {
		if(model.startsWith(m.sPrefix)) {
			neutralModel = model.replace(m.sPrefix, m.nPrefix);
		}
	});

	return neutralModel;
};

/**
 * 判断型号或子型号是否包含频段信息
 * @param modelOrSubModel
 */
export const getIsIncludesFrequencyBand = (modelOrSubModel: string) => {
	const frequencyList = [ '868M', '915M', '470M', '868M/915M', 'L0CEU', 'L0ACN' ];

	return frequencyList.some(frequency => modelOrSubModel.includes(frequency));
};