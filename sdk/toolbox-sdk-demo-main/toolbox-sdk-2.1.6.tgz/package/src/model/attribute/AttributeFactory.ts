import { isFunction } from 'lodash';

import { AttributeConstructor, AttributeDefinition, IAttribute } from '../tsl';
import { isAttributeDirectionMatch, isAttributeGroupMatch } from '../utils';

export class AttributeFactory {
	/**
	 * 默认的 attribute 定义分组
	 */
	static defaultAttributeDefinitionGroup = 'common';

	/**
	 * 按照分组来缓存attribute定义
	 */
	private static groupAttributeDefinitionCache = new Map<string, {
		/**
		 * 分组的元信息（预留）
		 */
		meta: {
			name: string;
			tslVersion: string;
		};
		/**
		 * 分组的attribute定义
		 */
		definitions: Map<string, AttributeDefinition>;
	}>();

	/**
	 * Attribute构造函数缓存
	 */
	private static attributeConstructorCache = new Map<string, AttributeConstructor>();

	/**
	 * Attribute路径到Attribute key的索引
	 */
	private static attributePathToKeyIndex = new Map<string, {
		key: string;
		group: string;
	}[]>();

	/**
	 * 注册Attribute构造函数
	 * @param key - attribute的key
	 */
	public static register(key: string) {
		return (target: any) => {
			this.attributeConstructorCache.set(key, target);
		};
	}

	/**
	 * 删除Attribute定义
	 * @param key - attribute的key
	 * @param group - 要删除的分组，如果不指定则删除所有分组中的该定义
	 */
	public static removeDefinition(key: string, group?: string | string[]) {
		// 如果指定了分组，则只删除指定分组中的定义
		if (group) {
			const groups = Array.isArray(group) ? group : [group];
			
			groups.forEach(g => {
				const groupCache = this.groupAttributeDefinitionCache.get(g);
				if (groupCache) {
					const definition = groupCache.definitions.get(key);
					groupCache.definitions.delete(key);
					
					// 清理 path 索引
					if (definition?.path) {
						this.removePathIndex(key, g, definition);
					}
				}
			});
		} else {
			// 如果没有指定分组，则删除所有分组中的该定义
			this.groupAttributeDefinitionCache.forEach((groupCache, groupName) => {
				const definition = groupCache.definitions.get(key);
				groupCache.definitions.delete(key);
				
				// 清理 path 索引
				if (definition?.path) {
					this.removePathIndex(key, groupName, definition);
				}
			});
		}
	}

	/**
	 * 清理路径索引
	 * @param key - attribute key
	 * @param group - 分组名
	 * @param definition - 定义对象
	 */
	private static removePathIndex(key: string, group: string, definition: AttributeDefinition) {
		if (!definition.path) return;
		
		const path = isFunction(definition.path)
			? definition.path(definition.key)
			: definition.path;
			
		const indexEntries = this.attributePathToKeyIndex.get(path);
		if (indexEntries) {
			// 删除指定 key 和 group 的索引项
			const filteredEntries = indexEntries.filter(entry => 
				!(entry.key === key && entry.group === group)
			);
			
			if (filteredEntries.length === 0) {
				// 如果没有其他索引项，则删除整个路径索引
				this.attributePathToKeyIndex.delete(path);
			} else {
				// 否则更新索引
				this.attributePathToKeyIndex.set(path, filteredEntries);
			}
		}
	}

	/**
	 * 注册Attribute定义
	 * @param key - key
	 * @param definition - Attribute的定义
	 */
	public static definition(key: string, definition: AttributeDefinition) {
		const definitionGroup = definition.group ?? this.defaultAttributeDefinitionGroup;

		// 如果定义了多个分组，则依次注册
		if(Array.isArray(definitionGroup)) {
			definitionGroup.forEach(group => {
				// 如果分组已经存在，则更新分组定义
				if(this.groupAttributeDefinitionCache.has(group)) {
					const groupCache = this.groupAttributeDefinitionCache.get(group);
					groupCache?.definitions.set(key, definition);
				} else { //不存在则创建分组
					this.groupAttributeDefinitionCache.set(group, {
						meta: {
							name: group,
							tslVersion: 'V1.0'
						},
						definitions: new Map([[ key, definition ]])
					});
				}
			});

			return;
		}

		// 如果分组已经存在，则更新分组定义
		if(this.groupAttributeDefinitionCache.has(definitionGroup)) {
			const group = this.groupAttributeDefinitionCache.get(definitionGroup);
			group?.definitions.set(key, definition);
		} else { //不存在则创建分组
			this.groupAttributeDefinitionCache.set(definitionGroup, {
				meta: {
					name: definitionGroup,
					tslVersion: 'V1.0'
				},
				definitions: new Map([[ key, definition ]])
			});
		}

		// 更新 path 到 key 的索引
		if (definition.path) {
			const path = isFunction(definition.path)
				? definition.path(definition.key)
				: definition.path;

			if(this.attributePathToKeyIndex.has(path)) {
				const keys = this.attributePathToKeyIndex.get(path);
				keys?.push({ key, group: definitionGroup });
			} else {
				this.attributePathToKeyIndex.set(path, [{ key, group: definitionGroup }]);
			}
		}
	}

	/**
	 * 根据Attribute的key获取Attribute的构造函数
	 */
	public static getConstructor(key: string) {
		return this.attributeConstructorCache.get(key);
	}

	/**
	 * 获取Attribute的定义
	 * @param key - attribute key
	 * @param group - attribute group
	 * @param fallbackGroup - 如果group不存在，则使用fallbackGroup
	 */
	public static getDefinition(key: string, group: string | string[], fallbackGroup = this.defaultAttributeDefinitionGroup) {
		const groupDefinition = Array.isArray(group)
			// 根据group数组，依次获取定义，直到获取到定义为止
			? group.map(g => this.groupAttributeDefinitionCache.get(g)).find(d => d != null)
			: this.groupAttributeDefinitionCache.get(group);

		// 如果group不存在，则使用fallbackGroup
		if (!groupDefinition) {
			return this.groupAttributeDefinitionCache.get(fallbackGroup)?.definitions.get(key);
		}

		// 如果 group的定义中存在，则返回，否则返回fallbackGroup的定义
		return groupDefinition.definitions.get(key) ?? this.groupAttributeDefinitionCache.get(fallbackGroup)?.definitions.get(key);
	}

	/**
	 * 根据查询条件获取Attribute定义
	 * @param query - 查询条件
	 */
	public static getDefinitionBy(query: {
		key?: string;
		path?: string;
		direction?: AttributeDefinition['direction'];
		group?: string | string[];
	}): AttributeDefinition | undefined {
		const group = query.group ?? this.defaultAttributeDefinitionGroup;

		// 优先使用key进行查找
		if (query.key) {
			const definition = this.getDefinition(query.key, group);
			
			if (definition) {
				// 如果有方向限制，则根据方向进行查找
				if(query.direction) {
					if(isAttributeDirectionMatch(definition.direction ?? 'both', query.direction)) {
						return definition;
					} else {
						console.log(`Attribute ${definition.key} direction not match`, definition.direction, query.direction);
						return undefined;
					}
				}

				return definition;
			}
		}

		// 使用path进行查找
		if (query.path) {
			const attributes = this.attributePathToKeyIndex.get(query.path);

			if (attributes) {
				// 如果有方向限制，则根据方向进行查找
				if(query.direction) {
					const definitions = attributes.map(attribute => this.getDefinition(attribute.key, attribute.group));
                    
					let result: AttributeDefinition | undefined = undefined;

					for ( const definition of definitions) {
						if(!definition) {
							continue;
						}

						const isDirectionMatch = isAttributeDirectionMatch(definition?.direction ?? 'both', query.direction);
						// 如果有指定group，则进行group匹配，否则不进行group匹配                        
						const isGroupMatch = definition?.group != null
							? isAttributeGroupMatch(definition.group, group)
							: true;

						if(isGroupMatch && isDirectionMatch) {
							result = definition;
							//对于group不为空，且相等的definition，直接返回
							if (definition?.group) {
								break;
							}                            
						}
					}
					return result;
				}

								
				return this.getDefinition(attributes[0]!.key, group);
			}
		}

		return undefined;
	}

	/**
	 * 加载一个Attribute实例
	 * @param definition
	 * @param device
	 */
	public static load<T extends IAttribute = IAttribute>(key: string, definition?: AttributeDefinition): T {
		const attributeKey = key;
		const attributeDefinition: AttributeDefinition = definition ?? this.getDefinition(attributeKey, this.defaultAttributeDefinitionGroup) ?? {
			key: attributeKey,
			group: this.defaultAttributeDefinitionGroup
		};

		if (!attributeDefinition.key) {
			throw new Error("attribute key is required");
		}

		//如果用key找不到对应的构造函数，就使用通用的构造函数
		const Constructor = this.getConstructor(attributeDefinition.key) ?? this.getConstructor('common') as AttributeConstructor;
		const attribute = new Constructor(attributeDefinition) as T;

		return attribute;
	}
}