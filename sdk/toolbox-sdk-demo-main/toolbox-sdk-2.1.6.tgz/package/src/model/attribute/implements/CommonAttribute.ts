import { isFunction } from 'lodash';

import { AttributeFactory } from '../AttributeFactory';

import type { IAttribute, AttributeDefinition, NormalizeDataStatusResult, NormalizeDataHistoryResult } from '../../tsl';

@AttributeFactory.register('common')
export class CommonAttribute<Value = any> implements IAttribute<Value> {
	key: string;

	path: string;

	value: Value;

	definition: AttributeDefinition;

	constructor(definition: AttributeDefinition) {
		this.key = definition.key;
		this.path = isFunction(definition.path)
			? definition.path(this.key)
			: definition.path ?? this.key;
		this.definition = definition;
		this.value = this.getDefaultValue();
	}

	getDefaultValue() {
		let defaultValue = this.definition.default;
		
		if (isFunction(defaultValue)) {
			defaultValue = defaultValue();
		}

		return defaultValue;
	}
	
	normalizeValue(value: any, data: any, context: Record<string, any>) {
		const transform = this.definition.transformValue;
		let nextValue = value;
		// 如果为空则使用默认值
		nextValue = value === undefined ? this.getDefaultValue() : value;
		// 标准化类型值
		nextValue = isFunction(transform) ? transform(nextValue, data, context) : nextValue;

		this.value = nextValue;

		return nextValue;
	}
	
	normalizeDataValue(value: any, data: any, context: Record<string, any>) {
		const transform = this.definition.transformDataValue;
		let nextValue = value;
		// 如果为空则使用默认值
		nextValue = value === undefined ? this.getDefaultValue() : value;
		// 标准化类型值
		nextValue = isFunction(transform) ? transform(nextValue, data, context) : nextValue;

		return nextValue;
	}

	normalizeDataStatus(value: any, data: any) {
		const { mapToStatus } = this.definition;
		
		// 判断是否需要映射到状态
		let shouldMapToStatus = false;
		if (typeof mapToStatus === 'function') {
			// 如果是函数，调用函数来判断
			shouldMapToStatus = mapToStatus(value, data);
		} else {
			// 如果是布尔值，直接使用
			shouldMapToStatus = Boolean(mapToStatus);
		}

		// 如果不需要映射到状态，则直接返回
		if (!shouldMapToStatus) {
			return;
		}

		const status = {} as NonNullable<NormalizeDataStatusResult>;
		const mapToStatusConfig: AttributeDefinition['mapToStatusConfig'] = isFunction(this.definition.mapToStatusConfig)
			? this.definition.mapToStatusConfig(value, data)
			: this.definition.mapToStatusConfig ?? {
				name: this.path,
				value: (value: any) => value,
			};
		const statusName = mapToStatusConfig.name;
		const statusValue = isFunction(mapToStatusConfig.value) ? mapToStatusConfig.value(value) : mapToStatusConfig.value ?? value;
		const statusType = mapToStatusConfig.type;
		const statusUnit = isFunction(mapToStatusConfig.unit) ? mapToStatusConfig.unit(value, data) : mapToStatusConfig.unit;
		const statusOrder = this.definition.mapToStatusOrder ?? 100;

		status.order = statusOrder;
		
		if(statusName) {
			status.name = statusName as any;
		}

		if(statusValue != null) {
			status.value = statusValue;
		}

		if(statusType) {
			status.type = statusType;
		}

		if(statusUnit) {
			status.unit = statusUnit;
		}

		return status;
	}

	normalizeDataHistory(value: Value, data: any) {
		// 如果不需要映射到历史数据，则直接返回
		if(!this.definition.mapToHistory) {
			return;
		}

		if(this.definition.mapToHistoryConfig == null) {
			return {
				[this.path]: value,
			};
		}

		const history = {} as NonNullable<NormalizeDataHistoryResult>;
		const mapToHistoryConfig: Record<string, any> = isFunction(this.definition.mapToHistoryConfig)
			? this.definition.mapToHistoryConfig(value, data)
			: this.definition.mapToHistoryConfig;

		if(mapToHistoryConfig) {
			Object.keys(mapToHistoryConfig).forEach((key: string) => {
				history[key] = mapToHistoryConfig[key];
			});
		}

		return history;
	}
}