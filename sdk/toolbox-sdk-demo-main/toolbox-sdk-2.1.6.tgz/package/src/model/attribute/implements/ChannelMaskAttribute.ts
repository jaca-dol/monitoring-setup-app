import { isFunction } from 'lodash';

import type { AttributeDefinition } from '../../tsl';

import { AttributeFactory } from '../AttributeFactory';
import { channelMaskToEnableFreqIndex, enableFreqIndexToChannelMask } from '../../utils';

import { CommonAttribute } from './CommonAttribute';


@AttributeFactory.register('lorawan_configuration_settings.channel_mask')
export class ChannelMask extends CommonAttribute<string> {
	constructor(definition: AttributeDefinition) {
		super(definition);
	}

	getDefaultValue() {
		return '000000000000000000000000';
	}

	normalizeValue(value: string, data: any, context: Record<string, any>) {
		const transform = this.definition.transformValue;
		let nextValue = value;
		// 如果为空则使用默认值
		nextValue = value === undefined ? this.getDefaultValue() : value;
		// enableFreqIndex -> channelMask
		nextValue = isFunction(transform)
			? transform(nextValue, data, context)
			: enableFreqIndexToChannelMask(nextValue);
		
		this.value = nextValue;

		return nextValue;
	}
	
	normalizeDataValue(value: any, data: any, context: Record<string, any>) {
		const transform = this.definition.transformDataValue;
		let nextValue = value;
		// 如果为空则使用默认值
		nextValue = value === undefined ? this.getDefaultValue() : value;
		// channelMask -> enableFreqIndex
		nextValue = isFunction(transform)
			? transform(nextValue, data, context)
			: channelMaskToEnableFreqIndex(nextValue);

		return nextValue;
	}
}