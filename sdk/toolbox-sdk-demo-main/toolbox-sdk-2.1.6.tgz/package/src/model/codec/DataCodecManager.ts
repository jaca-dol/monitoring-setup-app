import DeviceUtils from '../DeviceUtils';
import { IPSOService } from '../../service/ipso';

import { IDeviceDataCodec, IDeviceDataCodecManager } from './types';
import { FlashDataCodec } from './FlashDataCodec';
import { IPSODataCodec } from './IPSODataCodec';

export interface DataCodecTypeMap {
  'flash': InstanceType<typeof FlashDataCodec>;
  'ipso': InstanceType<typeof IPSODataCodec>;
}

export class DeviceDataCodecManager implements IDeviceDataCodecManager {

	codecs: Map<string, IDeviceDataCodec<any>>;

	constructor() {
		this.codecs = new Map();
		this.register('flash', new FlashDataCodec(DeviceUtils));
		this.register('ipso', new IPSODataCodec(IPSOService));
	}

	register<T>(name: IDeviceDataCodec['type'], codec: IDeviceDataCodec<T>): void {
		this.codecs.set(name, codec);
	}

	get<K extends IDeviceDataCodec['type']>(name: K): DataCodecTypeMap[K] {
		return this.codecs.get(name) as DataCodecTypeMap[K];
	}
}

export const DataCodecManager = new DeviceDataCodecManager();