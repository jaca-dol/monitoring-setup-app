import { FlashInfo } from '../deviceInfo/DeviceInfo';

import { DeviceData, PartialTSLInfo } from '../tsl';

type DataType = 'ipso' | 'flash';

/**
 * 编解码器
 * 提供设备数据的解析功能
 */
export interface IDeviceDataCodec<T = any> {
	/**
	 * 设备数据类型
	 */
	type: DataType;

	/**
	 * 获取设备信息
	 */
	getInfo(data: DeviceData): Promise<T>;

	/**
	 * 设置设备信息
	 */
	setInfo(settingData: T | string, deviceData: number[]): Promise<{
		/**
		 * 返回码
		 * @example 1: 成功
		 * @example 4: 写入失败
		 * @example 5: 型号不匹配
		 * @example 6: crc错误
		 */
		code: number;

		/**
		 * 设置的数据\
		 * flash数据：只有一段数据([ [xx] ])\
		 * ipso数据：通常只有一段数据([ [xx] ])，如果数据量较大，可能超过一帧，则会有多段数据([ [xx], [xx], [xx] ])
		 */
		data: number[][];

		/**
		 * 设置的数据大小
		 */
		dataSize: number;

		/**
		 * 设置的数据对象
		 */
		info: T;
	}>;

	/**
	 * 获取历史信息
	 */
	getHistoryInfo(data: DeviceData, model: string, firmwareVersion: string, hardwareVersion: string): Promise<Array<{
		timestamp: number;
		[key: string]: any;
	}>>;
}

/**
 * 设备数据编解码器管理器
 * 提供设备数据编解码器的注册、获取功能
 */
export interface IDeviceDataCodecManager {
	/**
	 * 注册编解码器
	 */
	register(type: DataType, codec: IDeviceDataCodec): void;

	/**
	 * 获取编解码器
	 */
	get(type: DataType): IDeviceDataCodec;
}

/**
 * 设备数据编解码器的数据映射
 */
export interface DataCodecDataMap {
	'flash': FlashInfo;
	'ipso': PartialTSLInfo;
}