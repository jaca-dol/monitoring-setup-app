import { has, isEmpty, isNil } from 'lodash';

import { DeviceData } from '../tsl';
import { PartialTSLInfo } from '../tsl';
import { IIPSOService, IPSOProtocolError, IPSOServiceResourceLoader } from '../../service/ipso';
import { IDeviceDataCodec } from './types';

export class IPSODataCodec implements IDeviceDataCodec<PartialTSLInfo> {
	type = 'ipso' as const;
	
	codec: IIPSOService;

	/**
	 * 需要在下发时进行分帧发送的tsl字段
	 * 某些字段下所占用的字节数较大（例如：蜂窝设置、规则引擎设置等），如果全部集中在一帧内是发送不完的
	 * 需要筛选出这些字段，分段处理，方便发送时可以进行分帧发送
	 */
	private segmentedTSLKeys = [
		'cellular_settings',
	];

	constructor(codec: IIPSOService) {
		this.codec = codec;
	}

	async getInfo(data: DeviceData) {
		try {
			const readResult = this.codec.read(data) as PartialTSLInfo;
			console.log("IPSODataCodec | getInfo | readResult:", readResult);
			return readResult;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	async setInfo(writeTslInfo: PartialTSLInfo, ipsoData: number[], writeContext?: PartialTSLInfo): ReturnType<IDeviceDataCodec['setInfo']> {
		try {
			const handleResult = this.handleWriteTslInfo(writeTslInfo, ipsoData, writeContext);
			const allSetTslInfo = handleResult.allTslInfo;
			const setTslInfo = handleResult.writeTslInfo;
			const primaryTslInfo: Record<string, any> = {};
			const data: number[][] = [];
			let dataSize = 0;

			// 1. 准备主要配置数据 (非分段)
			Object.keys(setTslInfo).forEach(key => {
				if (!this.segmentedTSLKeys.includes(key)) {
					primaryTslInfo[key] = setTslInfo[key];
				}
			});

			// 2. 编码并添加主要配置数据（如果存在）
			if (!isEmpty(primaryTslInfo)) {
				const primaryDataChunk = this.codec.write(primaryTslInfo, allSetTslInfo);
				data.push(primaryDataChunk);
				dataSize += primaryDataChunk.length;
			}

			// 3. 逐个编码并添加次要的分段数据
			this.segmentedTSLKeys.forEach(segmentedKey => {
				if (has(setTslInfo, segmentedKey) && !isNil(setTslInfo[segmentedKey])) {
					const segmentedDataChunk = this.codec.write({
						[segmentedKey]: setTslInfo[segmentedKey],
					}, allSetTslInfo);

					data.push(segmentedDataChunk);
					dataSize += segmentedDataChunk.length;
				}
			});

			return Promise.resolve({
				code: 1,
				data,
				dataSize,
				info: handleResult.writeTslInfo,
			});
		} catch (error: any) {
			if(IPSOProtocolError.isIPSOProtocolError(error)) {
				return Promise.reject(error);
			}

			return Promise.reject(IPSOProtocolError.getErrorByIotIpsoProtocolError(error));
		}
	}

	async getHistoryInfo(data: DeviceData, _model: string, _firmwareVersion: string, _hardwareVersion: string): Promise<any> {
		try {
			const readResult = this.codec.read(data);

			return readResult;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 设置编解码器上下文，加载设备解析资源
	 * 避免在没读设备时要做编解码，无法解析的问题
	 * @param model - 设备型号
	 * @param tslVersion - 物模型版本
	 */
	setCodecContext({model, tslVersion}: {model: string; tslVersion: string;}) {
		const commonResourceMeta = {
			name: 'common',
			tslVer: tslVersion.toLowerCase(),
		};
		const deviceResourceMeta = {
			name: model,
			tslVer: tslVersion.toLowerCase(),
		};
		const commonResource = IPSOServiceResourceLoader.getResourceByMeta(commonResourceMeta);
		const deviceResource = IPSOServiceResourceLoader.getResourceByMeta(deviceResourceMeta);

		if(commonResource == null || deviceResource == null) {
			throw IPSOProtocolError.create('PARSE_ERROR', {
				name: 'setCodecContextError',
				message: 'resource not found',
				meta: {
					commonResourceMeta,
					deviceResourceMeta,
				}
			});
		}

		this.codec.setResource([
			commonResource,
			deviceResource,
		]);
	}

	/**
	 * 处理要写入的TSL信息 
	 * @param writeTslInfo - 要写入的TSL信息
	 * @param ipsoData - 读取的原始ipso数据
	 * @param writeContext - 写入上下文
	 */
	private handleWriteTslInfo(writeTslInfo: Record<string, any>, ipsoData: number[], writeContext?: PartialTSLInfo) {
		const allTslInfo = writeContext != null
			? writeContext
			: ipsoData.length > 0
				? this.codec.read(ipsoData) as PartialTSLInfo
				: undefined;
		const ability = this.codec.getAbilities();
		const nextTslInfo: Record<string, any> = {};
		const omitTslKey: Array<{key: string; omitReason: string}> = [];

		for (const key in writeTslInfo) {
			//如果写入的值不为空且设备有这个属性
			if (writeTslInfo[key] !== undefined) {
				if(ability[key]) {
					const abilityItem = ability[key]!;
					//只有属性且是可写的属性才可以写入
					const canWrite = abilityItem.type === 'property' &&  abilityItem.access === 'write' || abilityItem.access === 'rw';
	
					if(canWrite) {
						nextTslInfo[key] = writeTslInfo[key];
					} else {
						omitTslKey.push({
							key,
							omitReason: `type: ${abilityItem.type} access: ${abilityItem.access} not support write`,
						});
					}
				} else {
					omitTslKey.push({
						key,
						omitReason: `not support key: ${key}`,
					});
				}
			} else {
				omitTslKey.push({
					key,
					omitReason: `value is undefined`,
				});
			}
		}

		if(omitTslKey.length > 0) {
			console.log(`IPSODataCodec | handleWriteTslInfo | the following properties will be omit:`, omitTslKey);
		}

		if(isEmpty(nextTslInfo) && omitTslKey.length > 0 && omitTslKey.some(item => item.omitReason.includes('not support write'))) {
			throw IPSOProtocolError.create('NOT_SUPPORT_WRITE', omitTslKey);
		}

		return {
			writeTslInfo: nextTslInfo,
			allTslInfo,
		};
	}
}