import { FlashInfo } from '../deviceInfo/DeviceInfo';

import { DeviceData } from '../tsl';
import { IDeviceUtils } from '../DeviceUtils';
import { IDeviceDataCodec } from './types';

export class FlashDataCodec implements IDeviceDataCodec<FlashInfo> {
	type = 'flash' as const;

	codec: IDeviceUtils;

	constructor(codec: IDeviceUtils) {
		this.codec = codec;
	}
	
	async getInfo(data: DeviceData): Promise<FlashInfo> {
		try {
			const jsonString = await this.codec.getFlashInfo(data);
			const parseFlashInfo = JSON.parse(jsonString) as FlashInfo;

			return parseFlashInfo;
		} catch (error) {
			return Promise.reject(error);
		}
	}
	
	async setInfo(settingData: any, deviceData: number[]): ReturnType<IDeviceDataCodec['setInfo']> {
		try {
			const settingJSON = JSON.stringify(settingData);
			const setResult = await this.codec.setFlashInfo(deviceData, settingJSON);
			const dataSize = JSON.parse(setResult.result).datasize;

			return {
				code: setResult.code,
				data: [setResult.rawData],
				dataSize: dataSize,
				info: settingData,
			};
		} catch (error) {
			return Promise.reject(error);
		}
	}
	
	async getHistoryInfo(data: DeviceData, model: string, firmwareVersion: string, hardwareVersion: string): Promise<{ [key: string]: any; timestamp: number; }[]> {
		try {
			const historyDataJson = await this.codec.getHistoryData(data, model, firmwareVersion, hardwareVersion);

			return JSON.parse(historyDataJson);
		} catch (error) {
			return Promise.reject(error);
		}
	}
}