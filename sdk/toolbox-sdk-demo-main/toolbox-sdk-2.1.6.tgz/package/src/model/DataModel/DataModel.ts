import { forOwn, get, isArray, isEmpty, isPlainObject, mapValues, merge, omit, set } from 'lodash';

import { AttributeFactory } from '../attribute/AttributeFactory';
import { DeviceInfo } from '../deviceInfo/DeviceInfo';
import { getDeviceModel, getModelSeries } from '../model';
import { AttributeDefinition, IAttribute, IDeviceDataModel, ModelData } from '../tsl';
import { flattenObject, isAttributeDirectionMatch, isAttributeGroupMatch } from '../utils';

export class DataModel<Data extends ModelData = ModelData> implements IDeviceDataModel<Data> {
	
	attributes: IAttribute[];
	
	data: Data;

	attributeGroup?: string | string[];

	context: Record<string, any>;

	constructor(attributeDefinitions?: AttributeDefinition[]) {
		this.attributes = attributeDefinitions?.map(def => AttributeFactory.load(def.key, def)) ?? [];
		this.data = {} as Data;
		this.attributeGroup = undefined;
		this.context = {};
	}

	init(data: Data): void {
		const group = this.getGroupFromData(data);

		this.processData(data, (value, key) => {
			const attr = this.getAttribute(key, 'up', group);

			if(attr) {
				this.set(key, value);
				return attr.key;
			}
			return undefined;
		});
	}

	getData(): Data {
		return this.data;
	}

	get<T = any>(name: string): T {
		return get(this.data, name);
	}

	getContext(): Record<string, any> {
		return this.context;
	}

	set(name: string, value: any): void {
		set(this.data, name, value);
	}

	/**
	 * 设置属性分组
	 */
	setAttributeGroup(group: string): void {
		this.attributeGroup = group;
	}

	/**
	 * 上下文数据
	 * @param context - 上下文数据
	 */
	setContext(context: Record<string, any>): void {
		this.context = context;
	}

	fromDeviceInfo(deviceInfo: Partial<DeviceInfo>): void {
		if(!deviceInfo) {
			return;
		}

		const group = this.getGroupFromDeviceInfo(deviceInfo);
		const context = this.getContext();

		this.processData(deviceInfo, (value, key) => {
			try {
				const attr = this.getAttribute(key, 'down', group);

				if(attr) {
					const nextKey = attr.key;
					let nextValue = attr.definition.getValue ? attr.definition.getValue(deviceInfo, value) : value;
					nextValue = attr.normalizeValue(nextValue, deviceInfo, context);

					// 如果是对象，则合并
					if(isPlainObject(nextValue) && !isEmpty(nextValue)) {
						merge(this.data, nextValue);
					} else {
						this.set(nextKey, nextValue);
					}

					//优先匹配的是path，如果没有path，则使用 key
					return attr.path ?? attr.key;
				}

				return undefined;
			} catch (error: any) {
				throw new Error(`DataModel | fromDeviceInfo | ${key} normalizeValue error: ${error.message}`);
			}
		});
	}

	toDeviceInfo(options?: {status?: boolean, data?: ModelData}): DeviceInfo {
		const deviceInfo = {} as DeviceInfo;
		const data = options?.data ?? this.data;
		const group = this.getGroupFromData(data);
		const context = this.getContext();

		this.processData(data, (value, key) => {
			const attr = this.getAttribute(key, 'up', group);

			if(attr) {
				try {
					const nextKey = attr.path ?? attr.key;
					const nextValue = attr.normalizeDataValue(value, data, context);

					// 如果是对象，则合并
					if(isPlainObject(nextValue) && !isEmpty(nextValue)) {
						merge(deviceInfo, nextValue);
					} else {
						set(deviceInfo, nextKey, nextValue);
					}

					return attr.key;
				} catch (error: any) {
					throw new Error(`DataModel | toDeviceInfo | ${key} normalizeDataValue error: ${error.message}`);
				}
			}

			return undefined;
		});

		// 如果需要包含状态信息，则转换状态信息
		if(options?.status) {
			deviceInfo.status = this.toDeviceInfoStatus(deviceInfo);
		}

		return deviceInfo;
	}

	toDeviceHistoryInfo(historyInfo: { history: Array<{ [key: string]: any; }> } & ModelData): Array<{ [key: string]: any; }> {
		const result: Array<{
			[key: string]: any;
		}> = [];

		const group = this.getGroupFromData({ ...this.data, ...historyInfo });
		historyInfo.history.forEach(data => {
			const historyInfo: Record<string, any> = {};

			this.processData(data, (value, key) => {
				const attr = this.getAttribute(key, 'up', group);

				if(attr) {
					try {
						const normalizeResult = attr.normalizeDataHistory(value, data);

						if(isPlainObject(normalizeResult) && !isEmpty(normalizeResult)) {
							merge(historyInfo, normalizeResult);
						}

						return attr.key;
					} catch (error: any) {
						throw new Error(`DataModel | toDeviceHistoryInfo | ${key} normalizeDataHistory error: ${error.message}`);
					}
				}

				return undefined;
			});

			result.push(historyInfo);
		});

		return result;
	}

	/**
	 * 转换设备信息状态
	 */
	protected toDeviceInfoStatus(deviceInfo: DeviceInfo): DeviceInfo['status'] {
		const flattenDeviceInfo = flattenObject(deviceInfo);
		const group = this.getGroupFromDeviceInfo(deviceInfo);
		const result: NonNullable<ReturnType<IAttribute['normalizeDataStatus']>>[] = [];

		mapValues(flattenDeviceInfo, (value, key) => {
			const attr = this.getAttribute(key, 'up', group);

			if(attr) {
				const status = attr.normalizeDataStatus(value, deviceInfo);

				if(status) {
					result.push(status);
				}
			}
		});

		const sortedStatus = result.sort((a, b) => {
			const aOrder = a.order;
			const bOrder = b.order;

			return aOrder - bOrder;
		}).map(a => omit(a, 'order'));

		return sortedStatus;
	}

	/***
	 * 获取属性
	 */
	protected getAttribute(key: string, direction: AttributeDefinition['direction'] = 'both', group: string | string[]): IAttribute | undefined {
		const matchKeyAttributes = this.attributes.filter(attr => {
			const isMatch = attr.key === key || attr.path === key;
			return isMatch;
		});

		return matchKeyAttributes.find(attr => {
			const attributeDirection = attr.definition.direction ?? 'both';
			const attributeGroup = attr.definition.group ?? AttributeFactory.defaultAttributeDefinitionGroup;
			const isMatchDirection = isAttributeDirectionMatch(attributeDirection, direction);
			//如果有定义了分组，则进行分组匹配，否则不进行分组匹配
			const isMatchGroup = attr.definition.group != null ? isAttributeGroupMatch(attributeGroup, group) : true;

			return isMatchDirection && isMatchGroup;
		});
	}

	toJSON(): string {
		const data = this.data;

		return JSON.stringify(data);
	}

	toDeviceInfoJSON(): string {
		const deviceInfo = this.toDeviceInfo();

		return JSON.stringify(deviceInfo);
	}

	/**
	 * 从模型数据中获取Attribute分组
	 */
	protected getGroupFromData(data: ModelData): string | string[] {
		const productSn = get(data, 'product_sn', get(this.context, 'data.product_sn'));
		const productName = get(data, 'product_name', get(this.context, 'data.product_name'));
		const productPn = get(data, 'product_pn', get(this.context, 'data.product_pn'));

		//如果没有sn，则使用型号，或者类的属性分组或者默认的通用分组
		if(!productSn) {
			const deviceModel = getDeviceModel('', productName, productPn);
			const deviceModelSeries = getModelSeries(deviceModel);

			return deviceModel != null
				? [ deviceModel, deviceModelSeries ]
				: this.attributeGroup ?? AttributeFactory.defaultAttributeDefinitionGroup;
		}

		//获取设备型号和系列
		const deviceModel = getDeviceModel(productSn, productName, productPn);
		const deviceModelSeries = getModelSeries(deviceModel);

		//优先使用设备型号/系列，最后使用默认的通用分组
		return deviceModel != null
			? [ deviceModel, deviceModelSeries ]
			: this.attributeGroup ?? AttributeFactory.defaultAttributeDefinitionGroup;
	}

	/**
	 * 从设备信息中获取Attribute分组
	 */
	protected getGroupFromDeviceInfo(deviceInfo: Partial<DeviceInfo>): string | string[] {
		const sn = get(deviceInfo, 'sn', get(this.context, 'deviceInfo.sn'));
		const model = get(deviceInfo, 'model', get(this.context, 'deviceInfo.model'));
		const subModel = get(deviceInfo, 'subModel', get(this.context, 'deviceInfo.subModel'));
		const pn = get(deviceInfo, 'pn', get(this.context, 'deviceInfo.pn'));

		if(!sn) {
			const deviceModel = model ?? getDeviceModel('', model, subModel, pn);
			const deviceModelSeries = getModelSeries(deviceModel);

			return deviceModel != null
				? [ deviceModel, deviceModelSeries ]
				: this.attributeGroup ?? AttributeFactory.defaultAttributeDefinitionGroup;
		}

		const deviceModel = getDeviceModel(deviceInfo.sn, deviceInfo.model, deviceInfo.pn, deviceInfo.subModel);
		const deviceModelSeries = getModelSeries(deviceModel);

		//优先使用设备型号/系列，最后使用默认的通用分组
		return deviceModel != null
			? [ deviceModel, deviceModelSeries ]
			: this.attributeGroup ?? AttributeFactory.defaultAttributeDefinitionGroup;
	}

	/**
 * 按层级逐层处理数据
 * @param data - 要处理的数据
 * @param handler - 处理函数
 * @param handledKeys - 已处理的键集合
 * @param parentKey - 当前层级（用于递归）
 */
	protected processDataByLevel(
		data: any, 
		handler: (value: any, key: string) => void, 
		handledKeys: Set<string>,
		parentKey = ''
	): void {
		if (!isPlainObject(data) || isEmpty(data)) {
			return;
		}

		const levelKeys = new Set<string>();
	
		// 处理当前层级的数据
		forOwn(data, (value, key) => {
			const newKey = `${parentKey}${parentKey ? '.' : ''}${key}`;
			// 如果当前key已经被处理过，跳过
			if (handledKeys.has(newKey)) {
				return;
			}
		
			handler(value, newKey);
		
			// 如果当前key被处理了，记录到当前层级已处理的keys中
			if (handledKeys.has(newKey)) {
				levelKeys.add(key);
			}
		});

		// 处理下一层级，但跳过当前层级已处理的keys
		forOwn(data, (value, key) => {
			const newKey = `${parentKey}${parentKey ? '.' : ''}${key}`;
			// 如果当前key在当前层级被处理过，跳过其子层级
			if (levelKeys.has(key)) {
				return;
			}
		
			// 如果值是对象且不为空，递归处理下一层级
			if (isPlainObject(value) && !isEmpty(value) && !isArray(value)) {
				this.processDataByLevel(value, handler, handledKeys, newKey);
			}
		});
	}

	/**
	 * 处理数据
	 * @param data - 数据
	 * @param processCallback - 处理回调
	 */
	protected processData(
		/**
		 * 要处理的数据
		 */
		data: ModelData | Partial<DeviceInfo>,

		/**
		 * 数据处理回调
		 * @param value - 值
		 * @param key - 键
		 * @returns 处理过的key或者undefined
		 */
		processCallback: (value: any, key: string) => string | void
	): void {
		const handledKeys = new Set<string>();
		const handler = (value: any, key: string) => {
			const processKey = processCallback(value, key);

			if(processKey) {
				handledKeys.add(processKey);
			}
		};

		// 按层级逐层处理数据
		this.processDataByLevel(data, handler, handledKeys);
	}
}