import { get, assign, omit } from 'lodash';

import { DeviceInfo } from '../deviceInfo/DeviceInfo';

import { DataModel } from './DataModel';
import { ModelData, TSLInfo, IAttribute, AttributeDefinition, TSLInfoKeys } from '../tsl';
import { AttributeFactory } from '../attribute/AttributeFactory';

export class TSLDataModel<Data extends ModelData = TSLInfo> extends DataModel<Data> {
	get<T = any>(name: TSLInfoKeys): T {
		return super.get(name);
	}

	fromDeviceInfo(deviceInfo: Partial<DeviceInfo>): void {
		//如果有 pLoRaWANParams 属性(仅会在下发的时候有)，则将其提升到顶层
		if(deviceInfo && get(deviceInfo, 'pLoRaWANParams')) {
			deviceInfo = assign({}, omit(deviceInfo, 'pLoRaWANParams'), get(deviceInfo, 'pLoRaWANParams'));
		}

		super.fromDeviceInfo(deviceInfo);
	}

	/**
	 * 获取已有注册的全局属性实例
	 * @param key - 属性key
	 */
	getGlobalAttribute({key, path, direction, group}: {key?: string; path?: string; direction?: AttributeDefinition['direction'], group?: string | string[]}): IAttribute | undefined {
		const definition = Array.isArray(group)
			//根据分组的数组顺序，依次获取定义，直到获取到定义为止
			? group.map(g => AttributeFactory.getDefinitionBy({key, path, direction, group: g})).find(d => d != null)
			: AttributeFactory.getDefinitionBy({key, path, direction, group});
		const attributeKey = key ?? definition?.key;

		//如果没有对应的 key 则返回
		if(!attributeKey) {
			return;
		}
		
		const constructor = AttributeFactory.getConstructor(attributeKey);

		//如果都没有注册过对应的构造函数或者定义，则返回
		if (!constructor && !definition) {
			return;
		}

		//有定义过的加载属性实例
		const attribute = AttributeFactory.load(attributeKey, definition);

		return attribute;
	}

	protected getAttribute(key: string, direction: AttributeDefinition['direction'] = 'both', group: string | string[]): IAttribute | undefined {
		//优先使用当前模型的属性实例，如果没有再使用注册的全局属性实例
		return super.getAttribute(key, direction, group) ?? this.getGlobalAttribute({ key, path: key, direction, group });
	}
}