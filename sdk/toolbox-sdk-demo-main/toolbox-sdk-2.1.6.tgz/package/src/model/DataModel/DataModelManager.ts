import "reflect-metadata";
import { DeviceInfo } from '../deviceInfo/DeviceInfo';
import { DataType, ModelData, IDeviceDataModel, IDeviceDataModelManager, DataModelConstructor } from '../tsl';
import { FlashDataModel } from './FlashDataModel';
import { TSLDataModel } from './TSLDataModel';

class DeviceDataModelManager implements IDeviceDataModelManager {
	dataModels: Map<string, DataModelConstructor> = new Map();

	constructor() {
		this.register('flash', FlashDataModel);
		this.register('tsl', TSLDataModel);
	}

	register(name: string, constructor: DataModelConstructor): void {
		this.dataModels.set(name, constructor);
	}

	get(name: string): IDeviceDataModel {
		const constructor = this.dataModels.get(name);

		if(!constructor) {
			throw new Error(`Data model ${name} not found`);
		}

		return new constructor();
	}

	load(data: ModelData, dataType: DataType, context?: Record<string, any>): IDeviceDataModel {
		const model = this.get(dataType);

		if(context) {
			model.setContext(context);
		}

		model.init(data);

		return model;
	}
	
	loadDeviceInfo(deviceInfo: DeviceInfo, dataType: DataType, context?: Record<string, any>): IDeviceDataModel {
		const model = this.get(dataType);
		
		if(context) {
			model.setContext(context);
		}

		model.fromDeviceInfo(deviceInfo);

		return model;
	}
}

export const DataModelManager = new DeviceDataModelManager();