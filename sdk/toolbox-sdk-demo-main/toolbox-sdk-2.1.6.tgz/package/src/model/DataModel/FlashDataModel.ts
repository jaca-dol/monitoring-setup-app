import { mapValues, set } from 'lodash';

import { DeviceInfo, FlashInfo } from '../deviceInfo/DeviceInfo';
import { Status } from '../deviceInfo/StatusDeviceInfo';
import { ModelData } from '../tsl';
import { flattenObject } from '../utils';
import { DataModel } from './DataModel';

export class FlashDataModel<Data extends ModelData = Partial<FlashInfo>> extends DataModel<Data> {

	init(data: Data): void {
		const flattenData = flattenObject(data);

		mapValues(flattenData, (value, key) => {	
			this.set(key, value);
		});
	}

	fromDeviceInfo(deviceInfo: Partial<DeviceInfo>): void {
		if (!deviceInfo) {
			return;
		}

		const flattenDeviceInfo = flattenObject(deviceInfo);
		const context = this.getContext();

		mapValues(flattenDeviceInfo, (value, key) => {
			const attr = this.attributes.find(attr => attr.path === key);

			//不管有没有找到对应属性，都要设置值
			if (attr) {
				const nextKey = attr.key;
				let nextValue = attr.definition.getValue ? attr.definition.getValue(deviceInfo, value) : value;
				nextValue = attr.normalizeValue(nextValue, deviceInfo, context);

				this.set(nextKey, nextValue);
			} else {
				this.set(key, value);
			}
		});
	}

	toDeviceInfo(options?: {status: boolean}): DeviceInfo {
		const deviceInfo = {} as DeviceInfo;
		const flattenData = flattenObject(this.data);
		const context = this.getContext();

		//将模型数据转换为设备信息
		mapValues(flattenData, (value, key) => {
			const attr = this.attributes.find(attr => attr.key === key);

			//不管有没有找到对应属性，都要设置值
			if(attr) {
				const nextValue = attr.normalizeDataValue(value, this.data, context);
				const nextKey = attr.path ?? attr.key;

				set(deviceInfo, nextKey, nextValue);
			} else {
				set(deviceInfo, key, value);
			}
		});

		if(options?.status) {
			deviceInfo.status = this.toDeviceInfoStatus(deviceInfo);
		}

		return deviceInfo;
	}

	toDeviceInfoStatus(deviceInfo: DeviceInfo): Status[] {
		//优先使用设备信息里面的状态
		if(deviceInfo.status) {
			return deviceInfo.status;
		}

		return super.toDeviceInfoStatus(deviceInfo);
	}
	toDeviceHistoryInfo(historyInfo: {history: Array<{[key: string]: any;}>} & ModelData): Array<{[key: string]: any;}> {
		//传入的历史的数据已经由解析库处理，通常不需要进行二次转换
		return historyInfo.history;
	}
}
