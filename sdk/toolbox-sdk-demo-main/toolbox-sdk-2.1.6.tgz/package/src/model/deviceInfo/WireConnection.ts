export interface Wire {
	rc: number, //0没接 1有接
	rh: number, //0没接 1有接
	y1: number, //0没接 1有接
	gh: number, //0没接 1有接
	ob: number, //0没接 1有接
	ob_on_cool: number,//0 on cool 1 on heat
	w1: number, //0没接 1有接
	em: number, //0没接 1有接
	pek: number,//0没接 1有接
	di: number, //0没接 1有接
    gm: number, //0没接 1有接
	w2_aux: number, //0没接，1作为w2，2作为aux
	y2_gl: number, //0没接，1作为y2，2作为gl
    ntc: number, //0没接 1有接
}

export interface WireConnection {
	wire: Wire,
	wxCfg: {
		sys: number, //0炉，1锅炉
		fan: number, //0外部控制，1恒温器控制
	},
	auxTimeout: {  //辅助加热超时时间
		enable: boolean,
		time: number
	},
	comprProtection: { // 压缩机保护
		enable: boolean,
		time: number
	},
    ntc: {
        collectInterval: number
    },
	emCfg: {
		emTimeout: {//紧急制热相关配置
			enable: boolean, //紧急制热超时时间
			time: number
		},
		frostProtection: { //防冻保护
			enable: boolean,
			threshold: number
		}
	},
	roomCard: {
		enable: boolean,
        object: number //0表示开关机；1表示插入计划
	},

    reversingValve: {          
		/** 换向阀模式 - 0：制冷模式 1：制热模式 2：保持配置 */
		mode: 0 | 1 | 2
	}
}

export const DefaultWireConnection = {
	//默认全部没接
	wire: {
		rc: 1, // 电源设置默认接到RC
		rh: 0,//0没接 1有接
		y1: 0, //0没接 1有接
		gh: 0,//0没接 1有接
		ob: 0, //0没接 1有接
		ob_on_cool: 0, //0 on cool 1 on heat
		w1: 0,//0没接 1有接
		em: 0,//0没接 1有接
		pek: 0,//0没接 1有接
		di: 0,//0没接 1有接
		w2_aux: 0, //0没接，1作为w2，2作为aux
		y2_gl: 0, //0没接，1作为y2，2作为gl
		gm: 0, //0没接 1有接
		ntc: 0, //0没接 1有接
	},
	wxCfg: {
		sys: 0, //W1W2供暖系统 默认0炉
		fan: 1, //供暖风扇控制 默认1恒温器控制
	},
	auxTimeout: {  //辅助加热超时时间
		enable: false, //默认关闭
		time: 15//默认15分钟
	},
	comprProtection: { //压缩机保护
		enable: false, //默认关闭
		time: 3
	},
	emCfg: {
		emTimeout: {//紧急制热相关配置
			enable: false, //紧急制热超时时间
			time: 5
		},
		frostProtection: { //防冻保护
			enable: false,
			threshold: 37.4 //华氏度默认37.4 摄氏度默认3
		}
	},
	roomCard: {
		enable: false,
		object: 0 //0表示开关机；1表示插入计划        
	},
	/** 换向阀 */
	reversingValve: {          
		/** 换向阀模式 - 0：制冷模式 1：制热模式 2：保持配置 */
		mode: 2
	},
	ntc: {
		collectInterval: 30
	}
} as const;