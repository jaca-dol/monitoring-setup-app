import { TempControlMode } from '../../service/hook/useInstallSetting';
import { AISetting } from './AISetting';
import { Channel } from './Channel';
import { DaylightSaveTime } from './DaylightSaveTime';
import { GpioSetting } from './GpioSetting';
import { HeatingPlan } from './HeatingPlan';
import { KeyD2D } from './KeyD2D';
import { RS232Setting } from './RS232Setting';
import { RS485Setting } from './RS485Setting';
import { SDI12Setting } from './SDI12Setting';
import { SolenoidRule } from './SolenoidRulesEngine';
import { Status } from './StatusDeviceInfo';
import { TargetTempCtrlMode, TempCtrlSource, TemperatureControlPlan } from './TemperatureControlPlan';
import { Transmit } from './Transmit';
import { ValveConfig } from './ValveConfig';
import { WireConnection } from './WireConnection';

/**
 * 设备通用信息
 * @group 设备信息
 */
export interface StrictGeneralDeviceInfo {
	/**
	 * 设备状态(下面部分状态的组合)
	 */
	status: Array<Status>;

	/**
	 * sn
	 */
	sn: string;

	/**
	 * 型号（去掉频段）
	 * @example AM319
	 */
	model: string;

	/**
	 * 设备下发的原始model字段，显示请使用`statusModel`字段
	 */
	rawModel: string;

	/**
	 * 设备子型号/频段 如N03GL
	 * @example RDL-L0CEU
	 */
	subModel?: string;

	/**
	 * 设备显示型号(设备传过来的型号带有频段，App做一个别名处理)
	 */
	statusModel: string;

	/**
	 * 设备型号系列(非设备信息，App添加的字段)
	 * @example AM300
	 */
	modelSeries: string;

	/**
	 * oem id
	 */
	oem: string;

	/**
	 * 设备信息
	 */
	deviceInformation?: {
		/**
		 * 型号（最原始的型号，去掉频段，子型号、pn等信息）
		 */
		model: string;

		/**
		 * 子型号的拆分项，子型号1
		 * 目前传感器预留了4个，所以取名1-4
		 * @example RDL
		 * @example 2W
		 * @example CO2 / UDL / CO2
		 */
		subModel1: string;

		/**
		 * 子型号的拆分项，子型号2
		 * @example 868M / 915M
		 * @example L0CEU
		 */
		subModel2: string;

		/**
		 * 子型号的拆分项，子型号3
		 */
		subModel3: string;

		/**
		 * 子型号的拆分项，子型号4
		 */
		subModel4: string;

		/**
		 * 设备PN1
		 */
		pn1: string;
		
		/**
		 * 设备PN2
		 */
		pn2: string;

		/**
		 * 设备PN3
		 */
		pn3: string;

		/**
		 * 设备PN4
		 */
		pn4: string;
	};

	/**
	 * EUI
	 */
	deviceEui: string;

	/**
	 * 设备所支持的物模型版本（仅支持 IPSO 协议的设备特有）
	 */
	tslVersion?: string;

	/**
	 * 固件版本
	 */
	firmwareVersion: string;

	/**
	 * 硬件版本
	 */
	hardwareVersion: string;

	/**
	 * 开关机状态，0：关机、1：开机
	 */
	deviceState: 0 | 1;

	/**
	 * 设备时间
	 */
	deviceTime?: number;

	/**
	 * 入网状态，0：未激活、1：已激活
	 */
	joinStatus: 0 | 1;

	/**
	 * 读取方式(非设备信息，App添加的字段)
	 */
	readMode?: 'ble' | 'nfc';

	/**
	 * 探针1传感器ID
	 */
	ch1_sensorID?: string;
	
	/**
	 * 探针2传感器ID
	 */
	ch2_sensorID?: string;

	/**
	 * 读取信号强度(非设备信息，App添加的字段)
	 */
	readSignal?: number;

	rssi: number;

	snr: number;

	/**
	 * PIR空闲时间间隔
	 */
	PIRIdleInterval: number;

	/**
	 * 蜂鸣器开关
	 */
	buzzMode: boolean;

	/**
	 * App EUI
	 * @group pLoRaWANParams
	 */
	appEUI: string;

	/**
	 * 端口
	 * @group pLoRaWANParams
	 */
	port: number;

	/**
	 * 入网类型, 0: ABP、1: OTAA
	 * @group pLoRaWANParams
	 */
	joinType: number;

	/**
	 * 设备地址
	 * @group pLoRaWANParams
	 */
	deviceAddress: string;

	/**
	 * 应用程序秘钥（无法读取，只能写入）
	 * @group pLoRaWANParams
	 */
	applicationKey: string;

	/**
	 * 网络会话秘钥（无法读取，只能写入）
	 * @group pLoRaWANParams
	 */
	networkSessionKey: string;

	/**
	 * 应用程序会话秘钥（无法读取，只能写入）
	 * @group pLoRaWANParams
	 */
	applicationSessionKey: string;

	/**
	 * 支持频段选项
	 * 1 433、2 470、3 868、4 915、 5 868/915
	 */
	supportFreq: number;

	/**
	 * 子版本
	 */
	subVersion?: {
		patchEnable: boolean
		version: string
	}[]

	/**
	 * 蓝牙名称
	 */
	blePhoneName?: string;

	/**
	 * 重新入网
	 */
	rejoinMode: boolean;

	/**
	 * 当前频段
	 * 0: EU868、1: US915、2: AU915、3: CN470、4: AS923、 5: KR920、7: EU433、8: IN865、9: RU864 
	 * @group pLoRaWANParams
	 */
	freqRegion: number;

	/**
	 * 频率值选项
	 * @group pLoRaWANParams
	 */
	freqs: Array<{
		enable?: boolean;
		value: string | number;
		index?: string | number;
		drMin?: number;
		drMax?: number;
	}>;

	/**
	 * 信道规划(仅在AS923的情况下有)
	 * 0: AS923-1、1: AS923-2、2: AS923-3 3: AS923-4
	 * @group pLoRaWANParams
	 */
	channelPlan?: 0 | 1 | 2 | 3;

	/**
	 * 工作模式
	 * 0：Class A、1：Class B、2：Class C、3：Class C to B
	 * @group pLoRaWANParams
	 */
	classType?: 0 | 1 | 2 | 3;

	/**
	 * 组播打开接收窗口周期
	 * @group pLoRaWANParams
	 * 1: 2s
	 * 2: 4s
	 * 3: 8s
	 * 4: 16s
	 * 5: 32s
	 * 6: 64s
	 * 7: 128s
	 */
	pingSlotPeriod: number;

	/**
	 * 指定网关
	 * @group pLoRaWANParams
	 */
	gwSpecific: boolean;


	/**
	 * 接收窗口速率
	 * @group pLoRaWANParams
	 * 0: DR0 (SF12, 125 kHz)
	 * 1: DR1 (SF11, 125 kHz)
	 * 2: DR2 (SF10, 125 kHz)
	 * 3: DR3 (SF9, 125 kHz)
	 * 4: DR4 (SF8, 125 kHz)
	 * 5: DR5 (SF7, 125 kHz)
	 * 8: DR8 (SF12, 500 kHz)
	 * 9: DR9 (SF11, 500 kHz)
	 * 10: DR10 (SF10, 500 kHz)
	 * 11: DR11 (SF9, 500 kHz)
	 * 12: DR12 (SF8, 500 kHz)
	 * 13: DR13 (SF7, 500 kHz)
	 */
	window2Dr: number;

	/**
	 * 接收窗口频率
	 * @group pLoRaWANParams
	 */
	window2Freq: number;

	/**
	 * 输出功率
	 * 
	 * @group pLoRaWANParams
	 * 0：TXPOWER0-16dBm
	 * 1：TXPOWER1-14dBm
	 * 2：TXPOWER2-12dBm
	 * 3：TXPOWER3-10dBm
	 * 4：TXPOWER4-8dBm
	 * 5：TXPOWER5-6dBm
	 * 6：TXPOWER6-4dBm
	 * 7：TXPOWER7-2dBm
	 */
	txPower: number;

	/**
	 * 启用通道(只在CN470, AU915, US915)
	 * @group pLoRaWANParams
	 * @example 输入0,15：表示启用通道0和通道15
	 * @example 输入0-15：表示启用通道0通道15之间的所有通道
	 * @example 输入0-15，16：表示启用通道0到通道15之间的所有通道，以及通道16
	 * @example 输入All：表示启用全部的通道
	 * @example 输入为空：表示禁用全部的通道
	 */
	enableFreqIndex: string;

	/**
	 * 当前通道掩码
	 */
	channelMask: string;

	/**
	 * 屏幕智能模式（AM系列特有）
	 */
	sleepMode?: boolean;

	/**
	 * 屏幕显示模式（AM系列特有）
	 */
	displayMode?: number;

	/**
	 * 确认包模式
	 * @group pLoRaWANParams
	 */
	regularReport: boolean;

	/**
	 * 发送数据包数量
	 * @group pLoRaWANParams
	 */
	confirmPackages: number;

	/**
	 * 速率自适应模式
	 * @group pLoRaWANParams
	 */
	adr: boolean;

	/**
	 * 扩频因子
	 * @group pLoRaWANParams
	 * 5: SF7-DR5
	 * 4: SF8-DR4
	 * 3: SF9-DR3, SF7-DR3
	 * 2: SF10-DR2, SF8-DR2
	 * 1: SF11-DR1, SF9-DR1
	 * 0: SF12-DR0, SF10-DR0
	 */
	dataRate: number;

	/**
	 * 上报间隔
	 * 对应物模型的reporting_interval.m_time字段
	 */
	reportingInterval: number;

	/**
	 * 上报间隔(秒数)
	 * 对应物模型的reporting_interval.s_time字段
	 */
	reportingIntervalSeconds: number;

	/**
	 * 是否禁用上报间隔
	 */
	disableReportingInterval: boolean;

	/**
	 * 倾斜与测距联动开关
	 */
	linkageSwitch: boolean;

	/**
	 * 采集间隔
	 */
	collectInterval?: number;

		/**
	 * 采集间隔2
	 */
	collectInterval2?: number;

	/**
	 * 设备端支持的上报间隔单位,需要将reportingInterval转换成该单位后写入
	 *  0：秒、1：分钟、2：时
	 */
	reportingIntervalUnit?: 0 | 1 | 2;

	/**
	 * 上报间隔单位（仅debug模式下显示，app特有）
	 */
	reportIntervalUnit: 's' | 'min';

	/**
	 * 超阈值采集间隔
	 */
	exceedCollectInterval?: number;

	/**
	 * interface 1(PIn2) 3v3 Output（旧版本UC50X特有）
	 */
	interface1v3Output?: boolean;

	/**
	 * interface 2(PIn2) 3v3 Output（旧版本UC50X特有）
	 */
	interface2v3Output?: boolean;

	/**
	 * the device return to power supply(UC50X、UC51X特有)
	 * 0：关机、1：开机、2：之前设备状态、3：开机开阀、4：开机关阀
	 */
	powerSupplyState?: number;

	/**
	 * 电磁阀接线开关(UC51X特有)
	 */
	solenoidConnectPwrOn?: boolean;

	/**
	 * 是否启用RPS预配置(UC51X CAT)
	 */
	enableRps?: boolean;

	/**
	 * 自动回复确认包
	 * 当开启时，设备收到的下行包无论是否启用确认包字段，均回复FE确认包。
	 * 当关闭时，设备收到的下行包若未启用确认包字段，不回复FE确认包，设备收到的下行包若启用了确认包字段，回复FE确认包。
	 */
	autoConfirmed?: boolean;

	/**
	 * 响应时间：10 ~ 6000(UC51X特有)
	 */
	classaResponseTime?: number;

	/**
	 * 数据上报 0: 全上报  1: 上报1  2: 上报2(UC51X特有)
	 */
	reportEnableType?: number;

	/**
	 * LoRa版本
	 * @group pLoRaWANParams
	 * 1: 1.0.2
	 * 2: 1.0.3
	 * 3: 1.1.0 - 已弃用
	 * 4: 1.0.4
	 */
	loraVersion: 1 | 2 | 3 | 4;

	/**
	 * 组播配置
	 * @group pLoRaWANParams
	 */
	multicast: Array<{
		enable: boolean;
		address: string;
		appskey: string;
		nwkskey: string;
		pingSlotPeriod: number;
		dataRate: number;
		freq: number;
	}>;

	/**
	 * LED指示灯配置
	 * 0: 禁用
	 * 1: 启用 
	 */
	buttonLight: 0 | 1;

	/**
	 * 密码（无法读取，只能写入）
	 */
	password: string;

	/**
	 * 电量统计
	 */
	powerMeter: boolean;

	/**
	 * 按键锁
	 */
	buttonLock: boolean;

	/**
	 * 按键锁ID
	 * 要锁定的id就在里面，全部没有代表不禁用
	 */
	buttonLockId: number[];

	/**
	 * 智能显示
	 */
	smartDispaly: boolean;

	/**
	 * 过流报警
	 */
	overCurrentAlarm: {
		enable: boolean;

		value: number;
	};

	/**
	 * 过流保护
	 */
	overCurrentProtect: {
		/**
		 * 启用
		 */
		enable: boolean;

		/**
		 * 保护值
		 */
		value: number;
	}

	/**
	 * 设备升级结果
	 */
	upgradeResult?: 0 | 1;

	/**
	 * 运营商是否支持低延迟工作模式
	 */
	isSupportLowDelayWorkMode?: boolean;

	/**
	 * 全局采集周期（适用于阈值中有多种类型如温度、CO2浓度而只需要一个全局采集周期的情况）
	 */
	globalCollectInterval?: number;

	/**
	 * 全局采集周期单位
	 * 0: 秒
	 * 1: 分钟
	 */
	globalCollectIntervalUnit?: 0 | 1;

	/**
	 * 全局报警次数
	 */
	globalAlarmTime?: number;

	/**
	 * 全局报警解除上报
	 */
	globalDismissReport?: boolean;

	/**
	 * 累计次数（无开关switch）
	 */
	reportingCounts?: number;

	/**
	 * 累计次数
	 */
	cumulative: {
		enable: boolean;
		count: string;
	};

	/**
	 * 设备定位/基站定位
	 */
	baseStationPosition: boolean;

	/**
	 * 定位设置
	 */
	gps: {
		enable: boolean;
		/**
		 * 持续运动时间
		 */
		moveDuration: number;
		/**
		* 持续静止时间
		*/
		staticDuration: number;
		/**
		* 运动上报间隔
		*/
		reportMove: {
			enable: boolean;
			interval: number;
		}
	}
	/**
	 * 设备数据更新时间(非设备信息，App添加的字段)
	 */
	updateTime: number;

	/**
	 * 是否来自模版的应用(非设备信息，App添加的字段)
	 */
	applyFromTemplate: boolean;

	/**
	 * LoRa d2d设置
	 * @group pLoRaWANParams
	 */
	d2dCfg?: {
		/**
		 * 启用(被控)
		 */
		enable: boolean;

		/**
		 * 启用（主控）
		 */
		enableMaster: boolean;

		/**
		* 长度限制为16-32位，小于32位软件自动在高位处补0
		*/
		key: string;
	};

	/**
	 * D2D数据发送
	 */
  d2dDataSender?: {
		enable: boolean,//总开关
		enableTemp: boolean,//温度开关
		enableHumi: boolean,//湿度开关
		enableUplink: boolean//上行温度
		// TS302两个sensor
		ch1enableTemp?: boolean,//温度1开关
		ch2enableTemp?: boolean,//温度2开关
		ch1enableHumi?: boolean,//湿度1开关
		ch2enableHumi?: boolean,//湿度2开关
	};

	/**
	 * D2D主控设备的按键命令配置
	 */
	keyd2d?: KeyD2D;

	/**
	 * 从设备 被控设置
	 */
	d2dSlave?: {
		extend: boolean;
		cfg: Array<{
			command: number;
			action: string;
		}>
	};

	/**
	 * D2D 气味设置(GS301)
	 */
	d2dOdor?: {
		/**
		 * 氨气
		 */
		nh3: {
			/**
			 * 启用值小于等于（未超标）
			 */
			belowEnable: boolean;

			/**
			 * 启用值大于（超标）
			 */
			overEnable: boolean;

			/**
			 * 值小于等于（未超标）
			 */
			below: number;

			/**
			 * 值大于（超标）
			 */
			over: number;
		};
		/**
		 * 硫化氢
		 */
		h2s: {
			/**
			 * 启用值小于等于（未超标）
			 */
			belowEnable: boolean;

			/**
			 * 启用值大于（超标）
			 */
			overEnable: boolean;

			/**
			 * 值小于等于（未超标）
			 */
			below: number;

			/**
			 * 值大于（超标）
			 */
			over: number;
		};

		/**
		 * 未超标控制命令
		 */
		belowCommand: number;

		/**
		 * 超标控制命令
		 */
		overCommand: number;
	};

	/**
	 * D2D数据接收设置
	 */
	D2DRecv?: {
		enable: boolean;
		matchList: Array<{
			id: string;
			name: string;
		}>;
	};

	/**
	 * 倾斜与测距联动开关	(EM310-UDL)
	 */
	udlSensorSwitch: number;

	/**
	 * 土壤类型
	 */
	soilType: 0 | 1 | 2 | 3;

	/**
	 * 警报上报设置
	 * @group pLoRaWANParams
	 * @argument item 报警项 0：低电平→高电平 1：高电平→低电平 2：低电平→高电平&高电平→低电平
	 * 
	 */
	alarmReporting?: {
		enable: boolean;
		interval: number;
		times: number;
		item?: number;
		dismissReport?: boolean;
	};
	
	/**
	 * 串口设置开关
	 */
	consoleEnable?: boolean;

	/**
	 * 串口模式
	 * 目前仅UC50XCAT1支持，后续建议使用此接口来设置串口模式\
	 * 旧的rs485/rs232的enable配置将逐步废弃\
	 * 0: RS485
	 * 1: RS232
	 * @default 0
	 */
	serialMode?: 0 | 1;

	/**
	 * rs485配置
	 */
	rs485?: RS485Setting;

	/**
	 * rs232
	 */
	rs232?: RS232Setting;

	/**
	 * sdi-12配置
	 */
	sdi12: SDI12Setting

	/**
	 * Modbus通道配置
	 */
	channels?: Channel[];

	/**
	 * GPIO1 采集类型
	 * 0: 脉冲水表计数
	 * 1: 开关量检测
	 */
	gpioMode1?: 0 | 1;

	/**
	 * GPIO2 采集类型
	 * 0: 脉冲水表计数
	 * 1: 开关量检测
	 */
	gpioMode2?: 0 | 1;

	/**
	 * GPIO配置
	 */
	gpioSetting?: GpioSetting;

	aiSetting: AISetting
	/**
	 * 统一的温度单位（如TS302传感器）
	 * */
	temperatureUnit?: string;

	/**
	 * application mode NB系列特有
	 * @deprecated 请使用transmit
	 */
	applicationMode?: "CTWing" | "TCP" | "UDP" | "ONENET";
	/**
	 * 服务器端口
	 * @deprecated 请使用transmit
	 */
	serverPort?: string;
	/**
	 * 服务器地址
	 * @deprecated 请使用transmit
	 */
	serverAddress?: string;

	/**
	 * 应用模式设置
	 */
	transmit: Transmit

	/**
	 * APN设置
	 */
	cellularConfig: {
		apn?: string;
		apnUser?: string;
		apnPassword?: string;
		apnAuth?: number;
		pin?: string
		networkType?: number,
		workPattern?: number,
		enableRps?: number,
	}

	/**
	 * 电动阀配置
	 */
	valveConfig? :  Array<ValveConfig>;

	/**
	 * NB系列特有
	 */
	CSQ?: number;

	/**
	 * 注网时间，NB系列特有
	 */
	registerNetworkTime?: number;

	/**
	 * 屏幕显示模式(AM3XX)
	 * 1: 模式1, 2: 模式2, 3: 模式3
	 */
	screenMode: number;

	/**
	 * 屏幕背景(AM3XX)
	 */
	screenBackgroundColor: 'white' | 'black';

	/**
	 * 屏幕上次更新(AM103)
	 */
	screenLastUpdate: boolean;

	/**
	 * 屏幕智能模式(AM3XX)
	 */
	enableScreenSmart: boolean;

	/**
	 * 屏幕显示(AM3XX)
	 */
	enableScreenDisplay: boolean;

	/**
	 * 屏幕至少刷新间隔(AM103) 单位: min
	 */
	screenLeastRefreshInterval: number;

	/**
	 * 屏幕休眠
	 */
	sleepConfig: {
		enable: boolean,  // 屏幕休眠使能
		sleepStartTime: string, // 开始时间 类型string
		sleepOverTime: string, // 结束时间  类型string
		weekDay: Array<number>, // 重复周期：1-7表示星期一到星期日
		uplinkInterruption: boolean, // 上行中断 
	}

	/**
	 * 数据存储
	 */
	enableDataStorage: boolean;

	/**
	 * 数据回传
	 */
	retransmitEnable: boolean;

	/**
	 * AutoP使能
	 */
	autoPEnable: boolean;

	/**
	 * 基站定位鉴权令牌
	 */
	baseStationPositionAuthToken: string;

	/**
	 * 蜂鸣器停止
	 */
	enableBuzzStop: boolean;

	/**
	 * LED 指示灯
	 * /0: close, 1: 常亮, 2: 闪烁
	 */
	ledMode: 0 | 1 | 2;

	/**
	 * 频率计权
	 * 0: Z计权、1: A计权、2: C计权
	 */
	weightFreq: 0 | 1 | 2;

	/**
	 * 时间计权
	 * 0: 禁用、1: 启用
	 */
	weightTime: 0 | 1;

	/**
	 * 相对初始面
	 * enable: 开关
	 * angle: x,y,z角度
	 */
	planAngle?:{
		enable?: boolean;
		angle?: number[];
	}

	/**
	 * 角度
	 */
	angle: {
		threshold: {
			/**
			 * 偏转角度
			 */
			enable: boolean;

			/**
			 * 警报条件
			 */
			rule: string;

			/**
			 * 警报次数
			 */
			continue: number;

			/**
			 * 警报间隔
			 */
			lock: number;

			x: {
				enable: boolean;
				mode: 1 | 2 | 3 | 4;
				low: string;
				high: string;
				planAngle: string;
			},
			y: {
				enable: boolean;
				mode: 1 | 2 | 3 | 4;
				low: string;
				high: string;
				planAngle: string;
			},
			z: {
				enable: boolean;
				mode: 1 | 2 | 3 | 4;
				low: string;
				high: string;
				planAngle: string;
			}
		}
	};

	/**
	 * 卡模式支持的密钥模式
	 * 0: 默认、1: 随机、2: 自定义
	 */
	keyMode: 0 | 1 | 2;

	/**
	 * 卡模式版本
	 * 0: 旧卡模式，>0 新卡模式
	 */
	cardVersion: number;

	/**
	 * 是否支持随机密钥
	 */
	supportRandomKey: boolean;

	/**
	 * 雨量累计周期
	 */
	rainPeriod?: number;

	/**
	 * tof测试模式
	 */
	tofTestMode?: boolean;

	/**
	 * 测试模式持续时间（单位分钟）
	 */
	tofTestModeContinueTime?: number;

	/**
	 * 人体高度（单位厘米）
	 */
	bodyHeight?: number;

	/**
	 * 防抖时间（秒）
	 */
	jitterTime?: number;

	/**
	 * LoRaD2D双击使能（WS101）
	 */
	doubleClick?: boolean;

	/**
	 * 屏下按键
	 */
	buttonMode: 0 | 1;

	/**
	 * 模版ID(DS系列)
	 */
	templateId?: number;

	/**
	 * 屏幕至少刷新周期(单位天，DS系列)
	 */
	leastRefresh?: number;

	/**
	 * 1、NB设备工作模式 0：低功耗模式 (PSM) 1:低延时模式 (eDRX)
	 * 2、UC51X-CAT 模块工作模式 0-模块断电 1-PSM 2-DRX 3-eDRX 4-长供电
	 * 3、UC50X-CAT 0：低功耗、3：低延时
	 */
	workPattern?: number;

	/**
	 * 工作模式: 
	 * mode - 0 标准模式, 1 - 垃圾桶模式, 2 - 停车场模式
	 * config: 上报间隔(秒)、采集间隔(秒)、安装高度(毫米)、安装高度使能
	 * 以mode作为config数组下标取对应值
	 */
	workMode?: {
		mode: 0 | 1 | 2;
		config: Array<{
			reportingInterval: number;
			collectInterval: number;
			installHeight: number;
			installHeightEnable: boolean;
		}>
	};
	/**
	 * 接口类型
	 * mode - 2 - 计数器, 1 - 数字量
	 * pulsedFilter - 脉冲滤波
	 */
	di?: {
		mode: number,
		count?: {
			start?: boolean,
			pulsedFilter?: boolean,
			valueInit?: number
		},
		/**
	 * 脉冲转换
	 * waterYield - 分子
	 * waterPulse - 分母
	 * unit - 单位
	 */
		pulseConversion?: {
			enable: boolean,
			waterYield?: number,
			waterPulse?: number,
			unit?: string
		}
	},

	rulesForEngine: Array<{
		enable?: boolean;
		id: number;
		condition: number;
		type: number;
		/**
		 * 值大于：2
		 * 值小于：1
		 * 值介于：3
		 * 值变化：5
		 * 值为真：6
		 * 值为假：7
		 */
		mode: number;
		high: number;
		low: number;
		saltationValue: number;
		then?: number;
	}>;

	/**
	 * 定位设置
	 */
	locateConfig?: {
		strategy: 0 | 1 | 2; //0：gnss定位 1：wifi定位 2：wifi+gnss定位 
		gnssTimeout: number;
		wifiTimeout: number;
		bssidNumber: number;
	};

	/**
		* 安装方式
		* 0：竖直安装 1：水平安装
		*/
	installMode?: 0 | 1;

	/**
	 * 温度控制
	 */
	tempControl?: {
		enable: boolean;

		/**
		 * 温度控制模式
		 * 0：温度自动控制、1：阀门开度控制
		 */
		mode: 0 | 1;

		/**
		 * 温度自动控制
		 */
		auto: {
			/**
			 * 目标问题
			 */
			target: number;

			/**
			 * 误差
			 */
			error: number;

			/**
			 * 范围
			 */
			range: {
				min: number;
				max: number;
			};

			/**
			 * 开窗检测
			 */
			windowOpenDetect: {
				enable: boolean;
				threshold: number;
				time: number;
				tempChange: number;
			};
		};

		/**
		 * 阀门开度控制
		 */
		fixed: {
			level: number;
		};
	};

	/**
	 * 防冻保护
	 */
	frostProtection?: {
		enable: boolean;
		threshold: number;
	};

	/**
	 * 儿童锁
	 */
	childrenLock?: boolean;

	/**
	 * 供暖计划
	 */
	heatingPlan?: HeatingPlan;

	/**
	 * 温控系统开关
	 */
	systemEnable: boolean;

	/**
	 * 温控模式
	 * 221 Off 0制热 1紧急制热 2制冷 3自动
	 */
	tempCtrlMode: TempControlMode;

    /**
     * 温控模式启用列表
     */
    tempCtrlModeEnable: Array<TempControlMode>
    
    /**
     * 最小死区
     */
    minDeadZone: number;

    /**
     * 自定义按键
     */
    customButtonEnable: boolean;

    /** 
     * 自定义按键1
     */
    customButton1: number;

    /**
     * 自定义按键2
     */
    customButton2: number;

    /**
     * 自定义按键3
     */
    customButton3: number;
    
	/**
	 * 风扇模式
	 * 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速 
	 */
	fanMode: 13 | 0 | 1 | 2 | 3 | 4 | 5;

	/**
	 * 风扇延迟时间
	 */
	fanDelay: {
		enable: boolean;
		time: number;
	};

	/**
	 * 风扇工作时间
	 */
	fanWorkTime: number;

	/**
	 * 时间显示
	 * 0 12小时制  1 24小时制
	 */
	hour24: number;

	/**
	 * 目标温度
	 * 分别对应“0制热 1紧急制热 2制冷 3自动”四种目标温度
	 */
	targetTemp: number[];

    /** 来源 - 0：NTC 1：LoRa 2：D2D 3：WT401 */
    tempCtrlSource: TempCtrlSource;

    /**
     * 0 单设定点 1 双设定点
     */
    targetTempCtrlMode: TargetTempCtrlMode;

	/**
	 * 目标温度范围
	 */
	targetRange: {
		max: number;
		min: number;
	} | Array<{
		max: number;
		min: number;
	}>;

	/**
	 * 目标温度允差
	 */
	glblError: number;

    /**
     * 制冷目标温度允差
     */
    coolGlblError: number;

    /**
     * 制热目标温度允差
     */
    heatGlblError: number;


	/**
	 * 自动控制允差
	 */
	autoError: number;

	/**
	 * 夏令时配置
	 */
	daylightSaveTime: DaylightSaveTime;

	/**
	 * 夏令时开始和结束时间（utc 时间戳）
	 * 注意：不是所有设备都会返回该字段，目前只有WT201等少数设备会返回
	 */
	dstTimestamp: {
		/**
		 * 开始时间
		 */
		start: number;

		/**
		 * 结束时间
		 */
		end: number;
	}

	/**
	 * 温度控制计划
	 */
	tempCtrlPlan: TemperatureControlPlan[];

    /**
     * 目标温度范围
     */
    targetRanges: {
        min: number;
        max: number;
    }[];

    /**
     * 冷却目标温度
     */ 
    coolTargetTemp: number;

    /**
     * 加热目标温度
     */
    heatTargetTemp: number;

	/**
	 * 接线配置
	 */
	wireConnection: WireConnection;

	/**
	 * 电磁阀规则引擎
	 * 目前UC51Xv4特有
	 */
	solenoidRulesEngine?: SolenoidRule[];

	/**
	 * UC51Xv4 滤波模式
	 * 0: 禁用、1: 硬件滤波（us）、2:  软件滤波（ms）
	 */
	pulsedFilterMode?: 0 | 1 | 2;

	/**
	 * UC51Xv4 滤波时间
	 */
	pulsedFilterTime?: number;

	/**
	 * 压力传感器类型
	 * 0: 标准
	 * 1：自定义
	 */
	pressureMode?: 0 | 1;

	/**
	 * 压力传感器2类型
	 * 0: 标准
	 * 1：自定义
	 */
	pressureMode2?: 0 | 1;

	/**
	 * 压力传感器采集信号类型
	 * 0：电压
	 * 1：电流
	 */
	pressureType?: 0 | 1;

	/**
	 * 压力传感器2采集信号类型
	 * 0：电压
	 * 1：电流
	 */
	pressureType2?: 0 | 1;

	/**
	 * 压力传感器信号最小值
	 * 电压单位：mv
	 * 电流单位：ua
	 */
	pressureOsl?: number;

	/**
	 * 压力传感器2信号最小值
	 * 电压单位：mv
	 * 电流单位：ua
	 */
	pressureOsl2?: number;

	/**
	 * 压力传感器信号最大值
	 * 电压单位：mv
	 * 电流单位：ua
	 */
	pressureOsh?: number;

	/**
	 * 压力传感器2信号最大值
	 * 电压单位：mv
	 * 电流单位：ua
	 */
	pressureOsh2?: number;

	/**
	 * 供电时长(ms)
	 */
	interfaceOutput?: number;

	/**
	 * 供电时长2(ms)
	 */
	interfaceOutput2?: number;

	/**
	 * 压力传感器量程最小值
	 */
	pressureRangeMin?: number;

	/**
	 * 压力传感器2量程最小值
	 */
	pressureRangeMin2?: number;

	/**
	 * 压力传感器量程最大值
	 */
	pressureRangeMax?: number;

	/**
	 * 压力传感器2量程最大值
	 */
	pressureRangeMax2?: number;

	/**
	* 时区偏移小时 * 10（支持时间的设备特有）
	*/
	timezone?: number;

	/**
	 * 时区偏移分钟
	 * 与 timezone 是共用同一个地址，所以两个字段最好不要同时配置
	 */
	timezoneMin: number;

	/** 通讯模式 - 0：BLE+LoRa 1：PowerBus+LoRa 2：BLE 3：POWERBUS */	
	commMode?: 0 | 1 | 2 | 3;

	/** BLE传输周期 */
	bleTransferInterval?: number;

    /** BLE+LoRa传输周期 */
    bleLoraTransferInterval?: number;

	/** PowerBus传输周期 */
	powerBusTransferInterval?: number;

	/** LoRa上报周期 */
	loraReportInterval?: number;

    /** BLE+LoRa上报周期 */
    bleLoraReportInterval?: number;

    /** PowerBus+LoRa上报周期 */
    powerBusLoraReportInterval?: number;

	/**
	 * 信号类型
	 * 0：短按
	 * 1：短按、双击
	 * 2：短按、长按
	 * 3：短按、双击、长按
	 */
	switchMode: 0 | 1 | 2 | 3;
    

	blePairInfo?: {
        /** 地址类型 - 0：公共 1：随机 */
        addrType: 0 | 1;

        /** 蓝牙地址 */
        address: string;

        /** 蓝牙名称 */
        name: string;
    };

	//用于专门读取蓝牙信息
	fetchBluePairInfo?: {
        /** 地址类型 - 0：公共 1：随机 */
        addrType: 0 | 1;

        /** 蓝牙地址 */
        address: string;

        /** 蓝牙名称 */
        name: string;
    };	
      
	/**
	 * 告警LED
	 */
	alarmLed?: boolean;

	mcsDelay?: {
		/**
		 * 门磁延迟告警
		 */
		enable: boolean;
		/**
		 * 门磁延迟告警时间
		 */
		value: number;
	}
}

export interface GeneralDeviceInfo extends StrictGeneralDeviceInfo {
	[key: string]: any;
}