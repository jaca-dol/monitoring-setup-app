import { SENSORS } from '../constants';

export type SENSOR_KEYS = keyof (typeof SENSORS);

/**
 * 传感器配置
 */
export interface SensorData {

	/**
	 *  唯一标识
	 */
	key: string;

	/**
	 * 启用
	 */
	enable: boolean;

	/**
	* 是否上报
	*/
	report?: boolean;

	/**
	 * 采集值
	 * 特殊情况:
	 * error - 错误
	 * out - 超量程
	 */
	value: string | number;

	/**
	 * 单位
	 */
	unit: string;

	/**
	 * 先前的单位
	 */
	prevUnit?: string;

	/**
	 * 传感器类型父节点 如ch1.temperature中的ch1
	 * */
	rootKey?: string;

	/**
	 * 全局采集周期（适用于阈值中有多种类型如温度、CO2浓度而只需要一个全局采集周期的情况）
	 */
	globalCollectInterval?: number;

	/**
	 * 上报累计值(VS350)
	 */
	reportAccumulated?: boolean;
	
	/**
	 * 重置累计值(VS350)
	 */
	resetAccumulated?: boolean;
  
	/**
	 * 重置累计间隔 单位分钟(VS350)
	 */
	resetAccumulatedInterval?: number;

	/**
	 * 设置检测方向 false(0)：正向， true(1)：反向 (VS351)
	 */
	setDetectionDirection?: boolean;

	/**
	 * 设置安装高度，单位mm (VS351)
	 */
	setMountingHeight?: number;
	
	/**
	 * oled显示屏启用控制(VS360)
	 */
	oledEnableControls?: boolean;

	/**
	 * 设置从机的发射模式(VS360)
	 */
	setSlaveSendModel?: number;

	/**
	 * 告警类型
	 */
	alarmType?: {
		/**
		 * 采集错误
		 */
		collectionError?: Record<string, any>;

		/**
		 * 超量程错误
		 */
		rangeError?: Record<string, any>;

		/**
		 * 阈值告警解除
		 */
		alarmDeactivation?: Record<string, any>;

		/**
		 * 阈值告警触发
		 */
		alarmTrigger?: Record<string, any>;

		/**
		 * 干扰告警解除
		 */
		interferenceAlarmDeactivation?: Record<string, any>;

		/**
		 * 干扰告警触发
		 */
		interferenceAlarmTrigger?: Record<string, any>;

		/**
		 * 燃烧告警解除
		 */
		burningAlarmDeactivation?: Record<string, any>;

		/**
		 * 燃烧告警触发
		 */
		burningAlarmTrigger?: Record<string, any>;
	};

	/**
	 * 重置 (VS351)
	 */
	reset?: {
		/**
		 * 重置累计值 (VS351)
		 */
		resetAccumulated?: boolean;

		/**
		 * 重置累计值星期 0:每天 1~7对应周日到周一 (VS351)
		 */
		resetAccumulatedWeek?: number;

		/**
		 * 重置累计值小时点0~23 (VS351)
		 */
		resetAccumulatedHour?: number;

		/**
		 * 重置累计值分钟点0~59 (VS351)
		 */
		resetAccumulatedMinute?: number;
	}

	/**
	 * 休眠模式功能 (VS351)
	 */
	sleep?: {
		/**
		 * 是否启用休眠模式功能 0：disable 1:enable (VS351)
		 */
		enableHibernateMode?: boolean; 

		/**
		 * 设置进入休眠模式小时点 0~23 (VS351)
		 */
		setIntoHibernateHour?: number;

		/**
		 * 设置进入休眠模式分钟点 0~59 (VS351)
		 */
		setIntoHibernateMinute?: number;

		/**
		 * 设置退出休眠模式小时 0~23 (VS351)
		 */
		setExitHibernateHour?: number;

		/**
		 * 设置退出休眠模式分钟点 0~59 (VS351)
		 */
		setExitHibernateMinute?: number;
	}

	/**
	 * 进出人数(VS351)
	 */
	cyclePeopleThreshold?: {
		/**
		 * 启用
		 */
		enable?: boolean;
		/**
		 * 进入人数高于
		 */
		inPeopleHigh?: number;
		/**
		 * 离开人数高于
		 */
		outPeopleHigh?: number;
	}

	/**
	 * 累计进出人数(VS351)
	 */
	cumulativePeopleThreshold?: {
		/**
		 * 启用
		 */
		enable?: boolean;
		/**
		 * 累计进入人数高于
		 */
		accumulatedInPeopleHigh?: number;
		/**
		 * 累计出去人数高于
		 */
		accumulatedOutPeopleHigh?: number;
	}

	/**
	 * 校准设置
	 */
	calibration?: {
		/**
		 * 启用
		 */
		enable: boolean;

		/**
		 * 校准值
		 */
		value: number | string;

		/**
		 * 自动背景校准（CO2）
		 */
		autoBackgroundCalibration?: boolean;

		/**
		* 气压补偿（CO2）/ 海拔高度校准
		*/
		altitudeCalEnable?: boolean;

		/**
		 * 海拔
		 */
		altitudeValue?: number;
	};
	/* 
	 * 水流状态判断时长
	 */
	decisionTime?: number;
	/* 
	 * 流水超时报警
	 */
	flowRunning?: {
		enable: boolean;
		excessValue: number;
	};
	/* 
	 * 停水超时报警
	*/
	flowStopping?: {
		enable: boolean;
		excessValue: number;
	};
	/**
	 * 阈值设置
	 */
	threshold?: {
		/**
		 * 启用
		 */
		enable: boolean;

		/**
		 * 模式
		 */
		mode?: number; 

		/**
		 * 值大于
		 */
		high: number | string;

		/**
		 * 值小于
		 */
		low: number | string;

		/**
		 * 持续时间
		 * @deprecated
		 */
		continueTime?: number;

		/**
		 * 持续时间
		 */
		duration?: number;

		/**
		 * 锁定时间
		 * @deprecated
		 */
		lockTime?: number;
		
		/**
		 * 采集周期
		 */
		collectInterval?: number;

		/**
		 * 一级阈值(AM103、AM3XX)
		 */
		alarmLevel1?: string;

		/**
		 * 二级阈值(AM103、AM3XX)
		 */
		alarmLevel2?: string;

		/**
		 * 阈值解除上报
		 * */
		dismissReport?: boolean;

		/**
			* 报警次数
			* */
		alarmTime?: number;
 
		/**
		* 报警间隔 (min) 
		*/
		alarmInterval?: number;
 
		/**
		* 温度突变
		*/
		saltationEnable?: boolean;
 
		/**
		* 温度突变值
		*/
		saltationValue?: string | number;

		/**
		 * 进入人数低于(VS350)
		 */
		inPeopleLow?: number;

		/**
		 * 进入人数高于(VS350)
		 */
		inPeopleHigh?: number;

		/**
		 * 离开人数低于(VS350)
		 */
		outPeopleLow?: number;

		/**
		 * 离开人数高于(VS350)
		 */
		outPeopleHigh?: number;

		/**
		 * 累计进入人数低于(VS350)
		 */
		accumulatedInPeopleLow?: number;

		/**
		 * 累计进入人数高于(VS350)
		 */
		accumulatedInPeopleHigh?: number;

		/**
		 * 累计出去人数高于(VS350)
		 */
		accumulatedOutPeopleHigh?: number;

		/**
		 * 阈值等级
		 */
		thresholdLevel?: number;
		/**
		 * 持续时间等级
		 */
		durationLevel?: number;

	};
/**
  * 储罐模式阈值设置
	*/
threshold2?: {
	/**
	 * 启用
	 */
	enable: boolean;

	/**
	 * 模式
	 */
	mode?: number; 

	/**
	 * 值大于
	 */
	high: number | string;

	/**
	 * 值小于
	 */
	low: number | string;

	/**
	 * 持续时间
	 * @deprecated
	 */
	continueTime?: number;

	/**
	 * 锁定时间
	 * @deprecated
	 */
	lockTime?: number;
	
	/**
	 * 采集周期
	 */
	collectInterval?: number;

	/**
	 * 一级阈值(AM103、AM3XX)
	 */
	alarmLevel1?: string;

	/**
	 * 二级阈值(AM103、AM3XX)
	 */
	alarmLevel2?: string;

	/**
	 * 阈值解除上报
	 * */
	dismissReport?: boolean;

	/**
		* 报警次数
		* */
	alarmTime?: number;

	/**
	* 报警间隔 (min) 
	*/
	alarmInterval?: number;

	/**
	* 温度突变
	*/
	saltationEnable?: boolean;

	/**
	* 温度突变值
	*/
	saltationValue?: string | number;

	/**
	 * 进入人数低于(VS350)
	 */
	inPeopleLow?: number;

	/**
	 * 进入人数高于(VS350)
	 */
	inPeopleHigh?: number;

	/**
	 * 离开人数低于(VS350)
	 */
	outPeopleLow?: number;

	/**
	 * 离开人数高于(VS350)
	 */
	outPeopleHigh?: number;

	/**
	 * 累计进入人数低于(VS350)
	 */
	accumulatedInPeopleLow?: number;

	/**
	 * 累计进入人数高于(VS350)
	 */
	accumulatedInPeopleHigh?: number;

	/**
	 * 累计出去人数高于(VS350)
	 */
	accumulatedOutPeopleHigh?: number;

};
	/**
	 * 持续低阈值告警
	 */
	continueLowThreshold?: {
		/**
		 * 启用
		 */
		enable: boolean;

		/**
		 * 值大于
		 */
		high: number;

		/**
		 * 值小于
		 */
		low: number;

		continueTime: number;
	};

	/**
	 * 持续高阈值告警
	 */
	continueHighThreshold?: {
		/**
		 * 启用
		 */
		enable: boolean;

		/**
		 * 值大于
		 */
		high: number;

		/**
		 * 值小于
		 */
		low: number;

		continueTime: number;
	};

	/**
	 * 异常值校准设置（部分型号特有）
	 */
	abnormalCheck?: {
		enable: boolean;
		range: number;
		percentage: number;
	};

	/**
	 * 突变阈值
	 */
	saltationThreshold?: {
		enable: boolean;
		max: string;
		mode?: number;
		collectInterval?: number;
		continueTime?: number;
		lockTime?: number;
	};

	/**
	 * 储罐模式突变阈值
	 */
	saltationThreshold2?: {
			enable: boolean;
			max: string;
			mode?: number;
			collectInterval?: number;
			continueTime?: number;
			lockTime?: number;
	};

	/**
	 * 屏幕警告配置（AM系列特有）
	 */
	alarmScreen?: {
		/**
		 * 启用
		 */
		enable: boolean;
		
		/**
		 * 警告阈值
		 */
		value: string;

		/**
		 * 一级阈值（AM103特有）
		 */
		value2: string;
	};
}


/**
 * 设备传感器信息
 * @group 设备信息
 */
export type SensorDeviceInfo = {
	// eslint-disable-next-line no-unused-vars
	[key in SENSOR_KEYS]?: SensorData;
}