import { SensorData } from './SensorDeviceInfo';
import { Status } from './StatusDeviceInfo';

/**
 * 指标数据
 * 来自设备的数据
 */
export interface MetricData extends Partial<SensorData>, Partial<Status> {
	/**
	 * 指标key
	 */
	key: string;

	/**
	 * 值
	 */
	value?: any;

	/**
	 * 传感器名称
	 */
	sensorName?: string;
}