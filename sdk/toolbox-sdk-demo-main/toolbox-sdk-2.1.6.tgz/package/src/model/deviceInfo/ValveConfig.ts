export interface ValveConfig {

   /**
    * 阀门序号，1/2
    */       
  id?: number;
  
  /**
   * 0-两通阀  1-三通阀
   */
  type?: number;

  /**
   * 绑定压力表
   */
  valveAiMap?: number;

  /**
   * 两通阀开阀时间，三通阀左开时间，单位：秒
   */
  openTime?: number;

  /**
   * 三通阀右开阀时间，单位：秒
   */
  rightOpenTime?: number;

  /**
   * 三通阀左开阀时间，单位：秒
   */
  leftOpenTime?: number;

  /**
   * 两通阀总开阀时间，单位：秒
   */
  totalReferenceValue?: number;

  /**
   * 三通阀总左开阀时间，单位：秒
   */
  totalLeftReferenceValue?: number;

  /**
   * 三通阀总右开阀时间，单位：秒
   */
  totalRightReferenceValue?: number;

  /**
   * 自动校准
   */
  autoCalibration?: boolean;

  /**
   * 异常校正后上报事件
   */
  reportCalibration?: boolean;

  /**
   * 堵转电流，单位：mA
   */
  blockCurrent?: number;

  /**
   * 堵转时间，单位：ms
   */
  blockTime?: number;

  /**
   * 0-关闭阀门  1-保持堵转状态
   */
  blockHandle?: number;

  /**
   * 电机延迟保护时间，单位：ms
   */
  protectTime?: number;

  /**
   * 关阀延时时间，单位：s
   */
  delayCloseTime?: number;

  /**
   * 启动延时时间，单位：s
   */
  delayOpenTime?: number;

  /**
   * 三通阀左开阀延时时间，单位：s
   */
  delayAllOpenTime?: number;

  /**
   * 三通阀右开阀延时时间，单位：s
   */ 
  delayAllOpenTimeRight?: number;
}

