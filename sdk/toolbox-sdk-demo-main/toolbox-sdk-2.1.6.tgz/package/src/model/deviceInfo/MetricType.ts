export enum CommonMetricType {
	common = "common",
	deviceState = "deviceState",
	deviceLocation = "deviceLocation",
	deviceTime = "deviceTime",
	model = "model",
	readMode = "readMode",
	signalStrength = "signalStrength",
}

export enum ControlMetricType {
	control = "control",
	switch = "switch",
	do = "do"
}

export enum CollectMetricType {
	di = "di",
	ai = "ai",
	sdi = "sdi",
	channel = "channel",
	sensor = "sensor",
	loud = "loud",
}

export enum SensorDataType {
	Temperature = "temperature",
	Humidity = "humidity",
	Pressure = "pressure",
	Light = "light",
	Noise = "noise"
}

/**
 * 指标组别枚举
 * 用于对设备状态指标进行分类和组织显示
 */
export enum MetricGroup {
	/** 
	 * 基本信息组 - 设备的基础信息
	 * 包含: 设备型号、序列号、固件版本、硬件版本等基本设备信息
	 * 显示位置: 首页页面顶部，设备基本信息页面
	 */
	Basic = 'basic',
	
	/** 
	 * 状态组 - 设备的运行状态信息
	 * 包含: 电池电量、信号强度、工作模式、运行状态等
	 * 显示位置: 设备基本信息页面的常规状态区域
	 */
	State = 'state',
	
	/** 
	 * 传感器组 - 传感器数据
	 * 包含: 温度、湿度、压力、光照等传感器测量值
	 * 显示位置: 首页的传感器数据区域，独立显示
	 */
	Sensor = 'sensor',
	
	/** 
	 * 网络组 - 网络连接相关信息
	 * 包含: LoRaWAN参数、网络状态、连接质量等
	 * 显示位置: 设备基本信息页面的网络信息区域
	 */
	Network = 'network',
	People = 'people',
	
	/** 
	 * D2D组 - 设备到设备通信相关
	 * 包含: D2D网络状态、通信参数等
	 * 显示位置: 设备基本信息页面的D2D信息区域
	 */
	D2D = 'D2D',
	
	/** 
	 * 自定义组 - 特定设备的自定义状态数据
	 * 包含: 设备特有的状态信息，如检测灵敏度等
	 * 显示位置: 设备基本信息页面最底部，与标准状态信息分离显示
	 * 使用场景: 当设备有特殊的状态指标需要单独展示时使用
	 */
	Custom = 'custom',
}
export type MetricType = keyof typeof CommonMetricType | keyof typeof ControlMetricType | keyof typeof CollectMetricType;

export type CollectMetricDataType = SensorDataType;