import { ExportHistoryDataRecord } from './DeviceHistoryData';
import { DeviceInfo } from './DeviceInfo';
import { ImgTemplate } from './ImgTemplate';
import { SolenoidWork } from './SolenoidWork';

/**
 * 设备状态
 */
export interface DeviceState {
	rawData: number[];
	deviceInfo: DeviceInfo;
	prevDeviceInfo: DeviceInfo;
	settingMode: 'template' | 'device';
	cardData: number[];
	imgTemplates: Array<ImgTemplate>;
	imgImportTipVisible: boolean; 
	exportHistoryDataRecord: Array<ExportHistoryDataRecord>;
	solenoidWork: Array<SolenoidWork>
}
