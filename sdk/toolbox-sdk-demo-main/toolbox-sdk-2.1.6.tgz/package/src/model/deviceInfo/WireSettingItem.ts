export interface WireSettingItem {
	id: number | string,
	key?: string,
	leftName: string,
	rightName: string,
	leftSelect: boolean,
	rightSelect: boolean,
	showLeft: boolean,
	showRight: boolean,
}