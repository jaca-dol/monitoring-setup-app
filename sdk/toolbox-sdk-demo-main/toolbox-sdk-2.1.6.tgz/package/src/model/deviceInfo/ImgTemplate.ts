
/**
 * 图片模版(电子墨水屏图片模版)
 * WS156特有
 * @ignore
 */
export interface ImgTemplate {
	id: string;

	name: string;

	/**
	 * bmp图片的hex数据
	 */
	bmpHexData: number[];

	/**
	* 屏幕图片数据（base64的图片数据）
	*/
	displayImage: string;

	/**
	* 屏幕显示类型
	*/
	displayType: 'text' | 'image';

	/**
	* 屏幕显示文本数据
	*/
	displayText?: Array<{
		id: number;
		text: string;
		height: number;
	}>;

	/**
	* 数据采集周期
	*/
	globalCollectInterval?: number
}