/**
 * UC系列控制器相关的规则引擎类型定义
 * 适用于以下设备
 * UC50X-Cat1：已实现
 * UC300-LoRa、UC300-Cell、UC100-LoRa：仅作预留、暂无实现
 */

import { AISetting } from './AISetting';
import { DeviceInfo } from './DeviceInfo';

/**
 * 规则引擎规则
 */
export interface UCRule {
	/**
	 * 规则ID
	 */
	id: number;

	/**
	 * 是否启用
	 */
	enable: boolean;

	/**
	 * 条件逻辑
	 */
	logics: UCRuleLogic[];

	/**
	 * 条件
	 */
	conditions: UCRuleCondition[];

	/**
	 * 动作
	 */
	actions: UCRuleAction[];
}

/**
 * 格式化后的规则
 */
export interface FormattedUCRule extends UCRule {
	/**
	 * 规则标题
	 */
	title: string;

	/**
	 * 条件总结
	 */
	conditionSummary: string[];

	/**
	 * 动作总结
	 */
	actionSummary: string[];

	/**
	 * 是否禁用
	 */
	disabled: boolean;
}

/**
 * 规则逻辑
 */
export enum UCRuleLogic {
	/**
	 * 与: 所有条件都满足
	 */
	and = 'and',

	/**
	 * 或: 任意条件满足
	 */
	or = 'or'
}

/**
 * 规则条件类型
 */
export type UCRuleConditionType =
	'local_time' //本地时间
	| 'digital_input' //数字输入
	| 'counter' //计数器
	| 'modbus_channel' //Modbus通道
	| 'ai_4_20_ma' //4-20mA模拟输入
	| 'ai_0_10_v' //0-10V模拟输入
	| 'device_reboot' //设备重启
	| 'signal_strength' //信号强度
	| 'cellular_status' //蜂窝状态
	| 'app_connection_status' //平台状态

/**
 * 规则条件
 */
export interface UCRuleCondition {
	/**
	 * 条件ID
	 */
	id: number;

	/**
	 * 条件类型
	 */
	type: UCRuleConditionType;

	/**
	 * 条件参数
	 */
	params: Record<string, any>;
}

/**
 * 规则动作类型
 */
export type UCRuleActionType = 
	'digital_output' //数字输出
	| 'gpio' //GPIO
	| 'counter' //计数器
	| 'send_server_message' //发送服务器消息
	| 'send_sms_message' //发送短信消息
	| 'send_d2d_control_message' //发送D2D控制消息
	| 'send_rs485_data' //发送RS485数据
	| 'report_data' //上报数据包
	| 'report_alarm' //上报告警包
	| 'reboot' //重启设备
	| 'change_collect_interval' //改变采集间隔
	| 'change_report_interval' //改变上报间隔
	| 'polling_collection_report' //轮询采集上报
	| 'enable_rule' //启用规则

/**
 * 规则动作
 */
export interface UCRuleAction {
	/**
	 * 动作ID
	 */
	id: number;

	/**
	 * 动作类型
	 */
	type: UCRuleActionType;

	/**
	 * 动作参数
	 */
	params: Record<string, any>;
}

/**
 * UC系列设备支持的规则引擎配置
 */
export interface UCRuleEngineDeviceProfile {
	/**
	 * 设备系列
	 */
	modelSeries: string;

	/**
	 * 每条规则支持的最大条件数量
	 */
	maxConditions: number;

	/**
	 * 每条规则支持的最大动作数量
	 */
	maxActions: number;

	/**
	 * 获取规则支持的条件类型
	 */
	getRuleSupportConditionTypes: (rule: UCRule, deviceInfo: DeviceInfo) => UCRuleConditionType[];

	/**
	 * 获取规则支持的动作类型
	 */
	getRuleSupportActionTypes: (rule: UCRule, deviceInfo: DeviceInfo) => UCRuleActionType[];
}

interface ModbusChannelOption {
	label: string;
	value: number;
	dataType: 'boolean' | 'number';
}

export interface UCRuleContextValue {
	modbusChannelOptions?: ModbusChannelOption[];
	aiSettings?: AISetting;
}