import type { ImageSourcePropType } from 'react-native';

/**
 * 推荐图片尺寸
 */
interface RecommendedImageSize {
	width: number;
	height: number;
}

/**
 * 屏幕显示状态
 */
export interface WT30XScreenState {
	/**
	 * 覆盖图片
	 * 会把其他内容都覆盖
	 */
	coverImage?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};

  // --- 顶部状态栏
  status?: Array<{
		width: number;
		height: number;
		icon: ImageSourcePropType;
		visible: boolean;
		recommendedImageSize: RecommendedImageSize;
	}>;

  // --- 主要内容 ---
  humidityIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
  humidityNumberIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
  temperatureNumberIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
	targetTempIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
	targetTempNumberIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
	scheduleIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
	scheduleText?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
  // --- 底部模式区域 ---
  modeIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
	modeText?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};

  // --- 底部风速区域 ---
  fanIcon?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
	fanText?: {
		source: ImageSourcePropType;
		width: number;
		height: number;
		recommendedImageSize: RecommendedImageSize;
	};
}

/**
 * 高亮显示的屏幕状态字段
 */
export type WT30XActiveDisplayField = keyof WT30XScreenState;