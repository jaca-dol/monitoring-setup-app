export interface Interface1Output {
  /**
  * interface 1 5/9/12v 输出开关
  */
  interface1v12Output: boolean;
  /**
  * interface 1 5/9/12v 供电时间
  */
  interface1v12OutputTime: number;
  /**
  * interface 1 5/9/12v 电流
  */
  interface1v12Current: number;
  /**
  * interface 1 3.3v 输出开关
  */
  interface1v3Output: boolean;
  /**
  * interface 1 3.3v 供电方式
  * 0: 持续供电、1: 可配置供电时间
  */
  interface1v3OutputType: number;
  /**
  * interface 1 3.3v 供电时间
  */
  interface1v3OutputTime: number;
  /**
  * interface 1 3.3v 电流
  */
  interface1v3Current: number;
}

export interface Interface2Output {
  /**
   * interface 2 5/9/12v 输出开关
   */
  interface2v12Output: boolean;

  /**
   * interface 2 5/9/12v 电流
   */
  interface2v12Current: number;

  /**
   * interface 2 5/9/12v 采集前供电时间
   */
  interface2v12OutputTime: number;

  /**
   * interface 2 3.3v 输出开关
  */
  interface2v3Output: boolean;

  /**
   * interface 2 3.3v 电流
   */
  interface2v3Current: number;

  /**
   * interface 2 3.3v 采集前供电时间
   */
  interface2v3OutputTime: number;

  /**
  * interface 2 3.3v 供电方式
  * 0: 持续供电、1: 可配置供电时间
  */
  interface2v3OutputType: number;
}