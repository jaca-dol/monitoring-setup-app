import { TextStyle, ViewStyle } from 'react-native';

import { SENSOR_KEYS } from './SensorDeviceInfo';
import { ContainerAction, StatusAction } from './StatusAction';

type Regions = {
	[key in `region${1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10}`]?: boolean;
};
/**
 * 设备状态信息
 * @group 设备信息
 */
export type StatusDeviceInfo ={
	pn: string;

	/**
	 * 设备时间
	 */
	deviceTime?: number;

	/**
	 * 时区（小时偏移 * 10）
	 */
	timezone?: number;

	/**
	 * NB网络状态
	 */
	networkStatus?: 'register' | 'unregister';

	/**
	 * 平台连接状态0=未连接平台 1=已连接平台
	 */
	serverStatus?: number;

	/**
	 * SIM卡状态 - 0:卡状态预留 1:SIM卡识别成功 2:SIM卡未识别 3:需要PIN码 4:PIN码错误 5:需要PUK码 6:未插入SIM卡
	 */
	simStatus?: number;

	/**
	 * 信号强度
	 * flashInfo返回的是string
	 * tslInfo返回的是number
	 */
	signalStrength?: string | number;

	/**
	 * 电池电量
	 */
	battery?: number;

	/**
	 * 电池充电状态
	 * 0：无充电 1：在充电
	 */
	batteryCharge?: number;

	/**
	 * 电池充电状态
	 * 1-4 充电中 6 充电中 7 充电完成
	 * 修复batteryCharge在100%电量并插电不显示冲电的问题
	 */
	batteryStatus?: number;

	/**
	 * 从机电量（VS360）
	 */
	slaveBattery?: number;

	/**
	 * 电压
	 */
	voltage?: string;

	/**
	 * 电流
	 */
	current?: string;

	/**
	 * 用电量
	 */
	energy?: string;

	/**
	 * 功率
	 */
	powerValue?: string;

	/**
	 * 功率因数
	 */
	powerFactor?: string;

	/**
	 * PIR传感器状态
	 */
	pirStatus?: 0 | 1 | 2;

	/**
	 * 光照状态
	 */
	illuminationStatus?: 0 | 1;

	/**
	 * 设备姿态
	 */
	openDetect?: 0 | 1;

	/**
	 * 脉冲计数1
	 */
	pulseCount1?: number;

	/**
	 * 脉冲计数2
	 */
	pulseCount2?: number;

	/**
	 * 液位状态 0:未标定 1:满液 2:缺液 '65535':错误
	 **/
	liquidCondition?: 0 | 1 | 2 | '65535';

	/**
	 * 电磁阀控制1
	 */
	solenoidState1?: number;
	
	/**
	 * 电磁阀控制2
	 */
	solenoidState2?: number;

	/**
	 * 阀门 1 实际开关
	 * 旧名称：反馈 1
	 */
	feedBack1?: number;

	/**
	 * 阀门 2 实际开关
	 * 旧名称：反馈 2
	 */
	feedBack2?: number;

	iccid?: string; 
	imei?: string;
	imsi?: string;

	/**
	 * 声级
	 */
	loud?: string;

	/**
	 * 等效连续声级
	 */
	loudEqual?: string;

	/**
	 * 最大声级
	 */
	loudMax?: string;

	/**
	 * 甲烷是否告警
	 */
	methane?: boolean;

	/**
	 * 电磁阀开关
	 */
	solenoidValve?: boolean;

	/**
	 * 继电器
	 */
	relay?: boolean;

	/**
	 * 剩余寿命
	 */
	residualLife?: number;

	/**
	 * X轴角度
	 */
	angleX?: string;

	/**
	 * Y轴角度
	 */
	angleY?: string;

	/**
	 * Z轴角度
	 */
	angleZ?: string;

	/**
	 * 风速
	 */
	windSpeed?: string;

	/**
	 * 风向
	 */
	windDirection?: string;

	/**
	 * 雨量
	 */
	rainfall?: string;

	/**
	 * RX2速率(D2D)
	 * @deprecated 请使用window2Dr代替，该字段仅作为历史遗留字段保留
	 */
	d2dDr?: number;

	/**
	 * RX2速率
	 */
	window2Dr?: number;

	/**
	 * 信道掩码
	 */
	channelMask?: string;

	/**
	 * 上行帧计数
	 */
	upLinkFrameCounter: number;

	/**
	 * 下行帧计数
	 */
	downLinkFrameCounter: number;

	/**
	 * RX2频率(D2D)
	 * @deprecated 请使用window2Freq代替，该字段仅作为历史遗留字段保留
	 */
	d2dFreq?: number;

	/**
	 * RX2频率
	 */
	window2Freq?: number;

	/**
	 * 系统更新时间(内部调试字段)
	 */
	systemUptime?: string;

	/**
	 * 内部调试字段
	 */
	loraRecvCount?: string;
	
	/**
	 * 数字量
	 */
	diLevel?: string;

	/**
	 * 计数值
	 */
	diCount?: string;

	/**
	 * TOF传感器所测距离
	 */
	tofDistance?: number;

	/**
	 * TOF传感器占用状态
	 */
	tofOccupancy?: boolean;

	/**
	 * （TS30X）传感器第一根探针
	 */
	ch1?: string;

	/**
	 * （TS30X）传感器第二根探针
	*/
	ch2?: string;

	/**
	 * 经度
	 */
	longitude?: string;

	/**
	 * 纬度
	 */
	latitude?: string;

	/**
	 * 海拔高度
	 */
	altitude?: string;

	/**
	 * 进入人数
	 */
	inPeople?: string;

	/**
	 * 离开人数
	 */
	outPeople?: string;

	/**
	 * 累计进入人数
	 */
	accumulatedInPeople?: string;

	/**
	 * 累计离开人数
	 */
	accumulatedOutPeople?: string;

	/**
	 * 检测温度
	 */
	dectTemperature: string;

	/**
	 * 阀门开度
	 */
	motorLevel?: string;

	/**
	 * 电机行程
	 */
	motorRange?: number;

	/**
	 * 电机位置
	 */
	motorPosition: number;

	/**
	 * 温度控制状态
	 * 0待机 1一级制热 2二级制热 3三级制热 4四级制热 
	 * 5紧急制热 6一级制冷 7二级制冷 8五级制热
	 */
	tempCtrlState: number;

	/**
	 * 风扇模式 - 0：自动 1：通风 2：常开 3：低速 4：中速 5：高速 13：禁用
	 */
	fanState: 0 | 1 | 2 | 3 | 4 | 5 | 13;
	ambient_temp?: number;
	object_temp?: number;

	/**
	 * 阀门1
	 * 电动阀类型
	 * 0-两通阀  1-三通阀
	 */
	valveType1?: number;

	/**
	 * 阀门1
	 * 堵转电流，单位mA
	 */
	blockCurrent1?: number;

	/**
	 * 阀门2
	 * 电动阀类型
	 * 0-两通阀  1-三通阀
	 */
	valveType2?: number;

	/**
	 * 阀门2
	 * 堵转电流，单位mA
	 */
	blockCurrent2?: number;

	/**
	 * 阀门1开度
	 */
	valveState1?: number;

	/**
	 * 阀门2开度
	 */
	valveState2?: number;

	/**
	 * 传感器Id
	 */
	sensorID?: string;

    /**
     * 执行计划Id
     */
    executePlanId?: number;
    
    /**
     * 执行计划名称
     */
    planName?: string;

	/**
  * 传感器类型
	* 0: 无探针
	* 1: PT100
	* 2: SHT41
	* 3: DS18B20
	*/
	sensorType?: 0 | 1 | 2 | 3;
	/**
	 * 阀门开度
	 */
	valveOpening: number;

	/**
	 * 总人数
	 */
	totalPeople?: number;

	/**
	 * 占用状态
	 */
	occupyState?: boolean;

	/**
	 * 存储状态
	 * 0: 充足
	 * 1: 不足
	 * 2: 存满
	 * 3: 覆盖
	 */
	storageStatus?: number;

	/**
	 * 空闲区域
	 */
	freeRegion?: number;

	/**
	 * 按键状态
	 */
	key1state?: number;
	key2state?: number;
	key3state?: number;
} & Regions


type GeneralName = 'sn'
| 'model'
| 'oem'
| 'hardwareVersion'
| 'firmwareVersion'
| 'deviceState'
| 'deviceEui'
| 'joinStatus'
| 'rssi/snr'
| 'readMode'
| 'atmospheric Pressure'
| 'sensorID'
| 'ch1_sensorID'
| 'ch2_sensorID';

/**
 * 状态名称集合
 */
export type StatusName =
	| GeneralName
	| keyof StatusDeviceInfo
	| SENSOR_KEYS;

/**
 * 状态元素
 */
export interface Status {
	/**
	 * 状态名称
	 */
	name: StatusName;


	/**
	 * 状态值
	 */
	value: string | number;

	/**
	 * 状态类型(大部分情况下与name一致，少部分不一样)
	 */
	type?: string;

	/**
	 * 状态单位
	 */
	unit?: string;

	/**
	 * 传感器ID
	 */
	sensorID?: string;
}

/**
 * 格式化后的状态
 */
export interface FormattedStatus extends Status {
	/**
	 * 状态标题（翻译后）
	 */
	label: string;

	/**
	 * 状态值（转换后）
	 */
	text: string;

	/**
	 * 卡片层交互
	 */
	containerAction?: ContainerAction;

	/**
	 * 下标文案
	 */
	subText?: string;

	/**
	 * 下标文本的前缀
	 */
	suffix?: string;

	/**
	 * 内容容器样式
	 */
	bodyStyle?: ViewStyle;

	/**
	 * 内容文本样式
	 */
	footerTextStyle?: TextStyle;

	/**
	 * 内容文本类型
	 */
	footerTextType?: 'time' | 'text';

	/**
	 * 提示信息
	 */
	tip?: string;

	/**
	 * 图标名称
	 */
	iconName?: string;

	/**
	 * 信号值
	 */
	signal?: number;

	/**
	 * 支持动作
	 */
	action?: StatusAction[];

	/**
	 * 是否是最后一个状态
	 */
	last?: boolean;

	/**
	 * 是否为整行样式
	 */
	block?: boolean;

	/**
	 * 其他状态参数
	 */
	[key: string]: any;
}