/**
 * 夏令时配置
 */
export interface DaylightSaveTime {
	/**
	 * 是否启用夏令时
	 */
	enable: boolean;

	/**
	 * 偏移量
	 */
	offset: number;    //单位分钟

	/**
	 * 开始时间
	 */
	start: DaylightItemTime;

	/**
	 * 结束时间
	 */
	end: DaylightItemTime;
}

/**
 * 夏令时时间Item项
 */
export interface DaylightItemTime {
	month: number,    //第几月
	weekNum: number,  //第几周
	weekDay: number,  //周几
	minute: number,   //hour*60+minute
}

/**
 * 默认的夏令时开始时间和结束时间
 */
export const DefaultDaylightTime = {
	startTime: {
		month: 3,       //默认3月
		weekNum: 2,    //默认第二周
		weekDay: 7,    // 默认周日
		minute: 0,     // 默认12点
	},
	endTime: {
		month: 11,     //默认11月
		weekNum: 1,    //默认第一周
		weekDay: 1,    //默认周一
		minute: 0,     // 默认12点
	}
};
