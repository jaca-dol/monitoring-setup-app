import { SENSORS } from '../constants';
import { DeviceInfo, PartialDeviceInfo } from './DeviceInfo';

/**
 * 设备最基本的数据，所有设备都有的
 */
export interface BasicDeviceData {
	/**
	 * 设备id
	 */
	id?: string;

	/**
	 * 设备序列号
	 */
	sn: string;
}

/**
 * 设备数据
 */
export type DeviceData = Partial<DeviceInfo> & BasicDeviceData; //为了方便后续辨识和应用，所以使用了别名

/**
 * 获取具体设备数据泛型 = 通用设备数据 + 设备特有数据
 */
export type GetDeviceData<DeviceSpecificInfo> = PartialDeviceInfo & BasicDeviceData & DeviceSpecificInfo;

export const SensorKeys = Object.keys(SENSORS);

export type ISensorKeys = keyof typeof SENSORS;

/**
 * 存储数据源接口
 */
export interface StorageDataSource {
	subscribe(callback: (data: DeviceData) => void): void;
  unsubscribe(callback: (data: DeviceData) => void): void;
}