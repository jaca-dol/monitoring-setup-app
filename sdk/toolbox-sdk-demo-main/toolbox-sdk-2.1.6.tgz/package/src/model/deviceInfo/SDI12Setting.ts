import { ProtocolGroup } from './Transmit';

/**
 * SDI-12 设置
 * UC50X、UC50XNB、UC50XCAT1...
 */
export interface SDI12Setting extends ProtocolGroup {
  /**
   * 是否启用
   */
  enable: boolean;

  /**
   * 接口2（Pin 1）5/9/12V 输出使能
   */
  interface2Output: boolean;

  /**
   * 供电电流
   */
  currentSdiOut: number;

  /**
   * 采集数据前对设备供电时间（秒）
   */
  sdiPowerOutTime: number;

  /**
   * 波特率
   */
  baud: number;

  /**
   * 数据位长度
   */
  dataBits: number;

  /**
   * 停止位
   */
  stopBits: number;

  /**
   * 奇偶校验
   * 0: 无校验
   * 1: 奇校验
   * 2: 偶校验
   */
  parity: number;

  /**
   * 最大重试次数
   */
  maxRetryTimes: number;

  /**
   * SDI-12透传模式
   */
  sdiPassthroughEnable: boolean;

  /**
   * 透传端口
   * 仅LoRa设备支持
   */
  sdiPassthroughPort?: number;

  /**
   * SDI-12通道配置
   */
  sdiChannel: Array<{
    /**
     * 通道号
     */
    id: number;
    
    /**
     * 通道使能
     */
    enable?: boolean;
    
    /**
     * 通道名称
     */
    name: string;

    /**
     * 从设备地址
     */
    address: string;

    /**
     * 自定义指令
     */
    customCommand: string;

    /**
     * 采集值
     */
    value: string;
  }>
}