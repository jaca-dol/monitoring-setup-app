export interface Point {
	x: number;
	y: number;
}

export interface DetectionRegion {
	id: number,
	enable: boolean,
	points?: Point[]
}