export interface IWT101DeviceInfo {
	/**
	 * 检测温度显示（WT101 v1.3 新增）
	 */
	ambientDisplay?: boolean;
	/**
	 * 有效行程（WT101 v1.3 新增）
	 */
	validRange?: {
		enable: boolean;
		percentage: number;
	}
}

export interface IWT101SupportSettingKey {
    timezonePicker: string;
    daylightSaveTime: string;
    ambientDisplay: string;
    validRange: string;
}

declare module '../DeviceInfo' {
    interface DeviceSettingServiceExtendSupportSettingKey extends IWT101SupportSettingKey {}
    interface DeviceSpecificInfo extends IWT101DeviceInfo {}
}