export interface IWS51XSupportSettingKey {
    patchUpgrade: boolean
}

declare module '../DeviceInfo' {    
    interface DeviceSettingServiceExtendSupportSettingKey extends IWS51XSupportSettingKey {}
}