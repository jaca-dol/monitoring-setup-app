interface PirConfig {        
    enable: boolean;
    freeTime: number;
    saveEnergy: {
        enable: boolean;
        occupied: number;
        unoccupied: number;
    };
    nightOccupancy: {
        enable: boolean;
        occupied: number;
        nightTime: {
            start: number,
            end: number,
        }            
    };
}

export interface IWT401DeviceInfo {
    bleName: string;
    pirConfig: PirConfig;

    //以下为预配置
    fanModeEnable: number[];
    syncData: boolean; //温湿度数据源        
    bleEnable: boolean; //蓝牙使能        
    tempCtrlPlanModeEnable: boolean; //计划温控模式启用        
    outsideDataTimeout: number; //外部数据超时时间
    tempUnlockButtons: number[]; //临时解锁组合键
    tempUnlockEnable: boolean; //临时解锁使能
    tempUnlockTimeout: number; //临时解锁时间
    pirCommonMode: number; //节能检测模式
    pirCommonCheckPeriod: number; //节能持续时间
    pirCommonCheckRate: number; //节能触发比例
    pirNightMode: number; //夜间检测模式
    pirNightCheckPeriod: number; //夜间持续时间
    pirNightCheckRate: number; //夜间触发比例
    originTemperature: number; //外部温度
    originHumidity: number; //外部湿度
    screenDisplaySettings: number[]; //屏幕显示设置
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IWT401DeviceInfo {}
}