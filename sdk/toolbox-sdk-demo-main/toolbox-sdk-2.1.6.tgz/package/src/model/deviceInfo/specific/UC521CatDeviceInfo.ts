export interface UC521CatSupportSettingKey {
    powerSupplyState: string;
    rpsPreConfig: string;
    reportValveChange: string;
}

export interface UC521CatDeviceInfo {
		/**
		 * 阀门状态改变是否上报
		 */
		reportValveChange?: boolean;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends UC521CatDeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends UC521CatSupportSettingKey {}
}