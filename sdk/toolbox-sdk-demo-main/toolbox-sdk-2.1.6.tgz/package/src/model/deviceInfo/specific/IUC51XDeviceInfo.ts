export interface IUC51XSupportSettingKey {
    gpioInvert: string;
    irrigationPeriod: string;
    nonIrrigationPeriod: string;
    openDelayCollectTime: string;
}

declare module '../DeviceInfo' {
    interface DeviceSettingServiceExtendSupportSettingKey extends IUC51XSupportSettingKey {}
}