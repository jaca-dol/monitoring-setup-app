import { WT30XTSLInfo } from "../../tsl";
import { CamelCaseKeys } from "../../../utils/util/type";
import { WT30XTemperatureControlPlan } from "../TemperatureControlPlan";
import { ImageSourcePropType } from 'react-native';

export interface IWT30XExtendDeviceInfo {
	/**
	 * 采集间隔
	 */
	collectionInterval: {
		unit: 0 | 1;
		secondsOfTime?: number;
		minutesOfTime?: number;
	};

	/**
	 * 温控状态
	 */
	temperatureControlStatus: WT30XTSLInfo['temperature_control_info']['status'];

	/**
	 * 阀门状态
	 */
	temperatureControlValveStatus: WT30XTSLInfo['temperature_control_valve_status'];

	/**
	 * 风扇状态
	 */
	fanControlStatus: WT30XTSLInfo['fan_control_info']['status'];

	/**
	 * 执行计划id
	 */
	executionPlanId: WT30XTSLInfo['execution_plan_id'];

	/**
	 * 模式启用 - 7：通风、制热、制冷 3：通风、制热 5：通风、制冷
	 * @default 7
	 */
	modeEnable: WT30XTSLInfo['mode_enable'];

	/**
	 * 继电器/阀门变更上报
	 */
	relayChangesReportEnable: boolean;

	/**
	 * 智能显示
	 */
	intelligentDisplayEnable: boolean;

	/**
	 * 智能显示设置
	 */
	screenObjectSettings: {
		/** 屏幕启用 - 0：禁用 1：启用 */
		enable: 0 | 1;

		/** 环境温度显示 - 0：禁用 1：启用 */
		environmentalTemperature: 0 | 1;

		/** 环境湿度显示 - 0：禁用 1：启用 */
		environmentalHumidity: 0 | 1;

		/** 目标温度显示 - 0：禁用 1：启用 */
		targetTemperature: 0 | 1;

		/** 任务名称显示 - 0：禁用 1：启用 */
		scheduleName: 0 | 1;
	};

	/**
	 * 系统开关
	 */
	systemStatus: boolean;

	/**
	 * 温控模式
	 */
	temperatureControlMode: WT30XTSLInfo['temperature_control_mode'];

	/**
	 * 目标温度分辨率
	 */
	targetTemperatureResolution: 0.5 | 1;

	/**
	 * 目标温度允差
	 */
	targetTemperatureTolerance: WT30XTSLInfo['target_temperature_tolerance'];

	/**
	 * 温度控制模式的目标温度
	 */
	targetTemp: number[];

	/**
	 * 温度控制模式的目标温度范围
	 */
	targetTempRange: Array<{
		min: number;
		max: number;
	}>;

	/**
	 * 目标湿度范围
	 */
	targetHumidityRange: WT30XTSLInfo['target_humidity_range'];

	/**
	 * 控温除湿设置
	 */
	temperatureControlDehumidification: {
		enable: boolean;
		temperatureTolerance: number;
	};

	/**
	 * 风扇模式
	 */
	fanControlMode: WT30XTSLInfo['fan_control_mode'];

	/**
	 * 风扇延迟关闭设置
	 */
	fanDelayClose: {
		enable: boolean;
		time: number;
	};

	/**
	 * 自动风速设置
	 */
	fanAutoModeTemperatureRange: CamelCaseKeys<WT30XTSLInfo['fan_auto_mode_temperature_range']>;

	/**
	 * 风扇停止设置
	 */
	fanStopEnable: boolean;

	/**
	 * 定时开关系统
	 */
	timedSystemControl: {
		/**
		 * 总开关
		 */
		enable: boolean;

		/**
		 * 开始时间设置
		 */
		startCycleSetting: Array<{
			id: number;
			enable: boolean;
			timePoint: number | null;
			cycleSetting: Array<1 | 2 | 3 | 4 | 5 | 6 | 7>;
		}>;

		/**
		 * 结束时间设置
		 */
		endCycleSetting: Array<{
			id: number;
			enable: boolean;
			timePoint: number | null;
			cycleSetting: Array<1 | 2 | 3 | 4 | 5 | 6 | 7>;
		}>;
	};

	/**
	 * 临时解除组合键
	 */
	temporaryUnlockSettings: Omit<CamelCaseKeys<WT30XTSLInfo['temporary_unlock_settings']>, 'reserved'>;

	/**
	 * 温度控制计划
	 */
	temperatureControlPlan: WT30XTemperatureControlPlan[];

	/**
	 * 接口类型
	 */
	interfaceSettings: CamelCaseKeys<Partial<WT30XTSLInfo['interface_settings']>>;

	/**
	 * 阀门控制设置
	 */
	valveControlSettings: CamelCaseKeys<WT30XTSLInfo['valve_control_settings']>;

	/**
	 * 阀门输出0%设置
	 */
	valveOutput0vEnable: boolean;

	/**
	 * EC风扇控制设置
	 */
	fanEcControlSettings: CamelCaseKeys<WT30XTSLInfo['fan_ec_control_settings']>;

	/**
	 * DI启用
	 */
	diEnable: boolean;

	/**
	 * DI设置
	 */
	diSettings: {
		/**
		 * DI类型
		 * 0: 房卡 1: 门磁
		 */
		object: 0 | 1;

		/**
		 * 房卡控制
		 */
		cardControl?: {
			/**
			 * 房卡控制类型
			 * 0: 系统控制，1: 插入计划
			 */
			type: 0 | 1;

			/**
			 * 系统控制
			 */
			systemControl?: {
				/**
				 * 插卡 - 0：系统关 1：系统开
				 */
				triggerByInsertion: 0 | 1;
			};

			/**
			 * 插入计划
			 */
			insertionPlan?: {
				/**
				 * 插卡计划id
				 */
				triggerByInsertion: number;

				/**
				 * 拔卡计划id
				 */
				triggerByExtraction: number;
			};
		};

		/**
		 * 门磁
		 */
		magnetDetection?: {
			/**
			 * 门磁类型
			 * 0: 常闭型 1: 常开型
			 */
			magnetType: 0 | 1;
		};
	};

	/** 开窗检测启用 */
	windowOpeningDetectionEnable: boolean;

	/** 开窗检测设置 */
	windowOpeningDetectionSettings: {
		/** 开窗检测方式 0：温度检测 1：门磁检测 */
		type: 0 | 1;

		/** 温度检测 */
		temperatureDetection?: {
			/** 温度变化 */
			differenceInTemperature: number;

			/** 停止时间 */
			stopTime: number;
		};

		/** 门磁检测 */
		magnetDetection?: {
			/** 检测持续时间 */
			duration: number;
		};
	};

	/**
	 * 防冻保护设置
	 */
	freezeProtectionSettings: {
		enable: boolean;

		/**
		 * 防冻保护目标温度
		 */
		targetTemperature: number;
	};

	/** 温度数据来源 */
	temperatureSource: Partial<CamelCaseKeys<WT30XTSLInfo['temperature_source']>>;

	/** 屏幕显示预配置 */
	screenContentSettings: CamelCaseKeys<WT30XTSLInfo['screen_content_settings']>;

	/**
	 * 屏幕自定义图片资源
	 * 仅用于保存已经修改过的预配置图片资源（不做下发），方便后续加载预配置时预览使用
	 */
	screenCustomImageSource?: Record<string, {
		width: number;
		height: number;
		source: ImageSourcePropType;
		recommendedImageSize: { width: number; height: number };
	}>;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IWT30XExtendDeviceInfo {}
}