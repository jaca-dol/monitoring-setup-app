export interface IVS370DeviceInfo {
	/**
	 * 休眠时间
	 */
	sleepTime?: [
		{
			enable:	boolean,
			sleepStartTime:	number,
			sleepEndTime: number
		},
		{
			enable:	boolean,
			sleepStartTime:	number,
			sleepEndTime: number
		}
	];
	/**
	 * 触发有人灵敏度
	 * 0: 低
	 * 1: 中
	 * 2: 高
	 */
	radarSensitivity?: 0 | 1 | 2;
	/**
	 * 保持有人灵敏度
	 * 0: 低
	 * 1: 中
	 * 2: 高
	 */
	pirSensitivity?: 0 | 1 | 2;
	/**
	 * 光照采集开关
	 */
	illuminationEnable?: boolean;
}

export interface IVS370SupportSettingKey {
	/**
	 * 全量多模块升级不需要多次NFC会话
	 */
	fullUpgradeNoListenTag: boolean;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IVS370DeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends IVS370SupportSettingKey {}
}