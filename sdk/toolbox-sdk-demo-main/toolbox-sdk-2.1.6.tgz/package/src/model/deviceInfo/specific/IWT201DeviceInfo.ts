export interface IWT201DeviceInfo {
		/**
		 * 控制权限
		 * 0：恒温器控制
		 * 1：远程控制
		 */
		tstatOwner?: 0 | 1;

		/**
		 * 调节湿度配置
		 * 只有在有湿度传感器时才有该配置
		 */
		fanHumiAdjust?: {
			/**
			 * 启用
			 */
			enable: boolean;
			/**
			 * 调节周期（分钟）
			 */
			time: number;
		};

		/**
		 * 目标湿度范围
		 * 只有在有湿度传感器时才有该配置
		 */
		humiRange?: {
			min: number;
			max: number;
		};

		/**
		 * 控温除湿
		 * 只有在有湿度传感器时才有该配置
		 */
		dehumiCtrl?: {
			/**
			 * 启用
			 */
			enable: boolean;

			/**
			 * 除湿温度允差
			 */
			error: number;
		};

		D2DRecv?: {
			enable: boolean;
			matchList: Array<D2DRecvMatchItem>;
		};

		/**
		 * 目标温度分辨率
		 * 固件版本2.0及以上支持
		 * 0：0.5
		 * 1：1.0
		 */
		targetResolution?: 0 | 1;

		/**
		 * 温控模式启用
		 * 固件版本2.0及以上支持
		 * 0：制热
		 * 1：紧急制热
		 * 2：制冷
		 * 3：自动
		 */
		buttonLockMask?: number[];

		/**
		 * 双设定目标温度设置
		 */
		doubleSetPoint?: {
			enable: boolean;
			heatTarget: number;
			heatTargetError: number;
			coolTarget: number;
			coolTargetError: number;
		};

		/**
		 * 压缩机和辅助制热联用
		 */
		yauxEnable?: boolean;

		/**
		 * 占用模式
		 */
		occupiedConfig: {
			mode: number;
			timeout: number;
		};
		
		/**
		 * 自定义温控等级
		 * @memberof DeviceSpecificInfo
		 */
		customLevelConfig: {
			"enable": boolean,
			"heatArray": {
				"y1": boolean,
				"y2": boolean,
				"w1": boolean,
				"w2": boolean,
				"e": boolean
			}[];
			"coolArray": {
				"y1": boolean,
				"y2": boolean,
				"w1": boolean,
				"w2": boolean,
				"e": boolean
			}[];
			"emheatArray": {
				"y1": boolean,
				"y2": boolean,
				"w1": boolean,
				"w2": boolean,
				"e": boolean
			}[];
		};

		/**
		 * 共用标志
		 */
		shareEnable: 0 | 1;

		/**
		 * 死区范围
		 */
		deadBand: number;
}

interface D2DRecvMatchItem {
	//deviceEUI
	id: string;
	//model
	name: string;
}

export interface IWT201SupportSettingKey {
    humidity: string;
    tstatOwner: string;
    buttonLockMask: number[];
    targetResolution: 0 | 1;
    doubleSetPoint: string;
    yaux: string;
}

declare module '../DeviceInfo' {
    interface DeviceSettingServiceExtendSupportSettingKey extends IWT201SupportSettingKey {}
    interface DeviceSpecificInfo extends IWT201DeviceInfo {}
}