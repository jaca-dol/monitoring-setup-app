export interface IVS350DeviceInfo {
	/**
	 * 上报模式 0、整点上报 1、即刻上报
	 */
	reportingMode?: number;
	installCfg?: {
		/**
		 * 安装方式	0：侧装 1：顶装
		 */
		installationMode: number;
		installationHeight: number; // 安装高度，单位m
		/**
		 * 上报是否检测灵敏度 0：不上报 1：上报
		 */
		reportEnable: number;
	};
	detectionSensitivity?: {
		enable: boolean; // 界面不提供开关，始终为true
		value: number; // 数值值（同状态页面数值）
		unit: string; // 单位dB
		/**
		 * 校准设置
		 */
		calibration: {
			enable: boolean; // 界面不提供开关，始终为true
			value: number | string;
		};
	};
}

export interface IVS350SupportSettingKey {
	minuteReportingMode: string; // 旧上报模式 V2硬件使用
	reportingMode: string;
	beforeReportingMode: string;
	installCfg: string;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IVS350DeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends IVS350SupportSettingKey {}
}