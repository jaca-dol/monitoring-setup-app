export interface IUC521CatSupportSettingKey {
    powerSupplyState: string;
    rpsPreConfig: string;
    reportValveChange: string;
}
export interface IUC521CatDeviceInfo {
    /**
	 * 阀门状态改变是否上报
	 */
	reportValveChange?: boolean;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IUC521CatDeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends IUC521CatSupportSettingKey {}
}