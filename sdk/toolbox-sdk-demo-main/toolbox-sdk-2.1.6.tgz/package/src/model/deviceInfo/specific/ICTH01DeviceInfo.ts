import { SensorData } from '../SensorDeviceInfo';

export interface Measurement {
	name: string;
	value: number | string;
}

export interface ThresholdData {
	key: string;
	threshold: NonNullable<SensorData['threshold']> & { channel?: number };
}

interface CurrentInterface {
	type: 0 | 1;
	config: {
		direction: 0 | 1;
		range: 0 | 1 | 2 | 3 | 4 | 5;
	}[];
}

export interface ICTH01DeviceInfo {
  currentIntensity: Measurement[]; // 电流有效值
	voltageIntensity: Measurement[]; // 电压有效值
	forwardActiveEnergy: Measurement[]; // 正向有功能耗
	reverseActiveEnergy: Measurement[]; // 反向有功能耗
	forwardReactiveEnergy: Measurement[]; // 正向无功能耗
	reverseReactiveEnergy: Measurement[]; // 反向无功能耗
	apparentEnergy: Measurement[]; // 视在能耗值
	powerFactorIntensity: Measurement[]; // 功率因数
	activePower: Measurement[]; // 有功功率
	reactivePower: Measurement[]; // 无功功率
	apparentPower: Measurement[]; // 视在功率
	currentHarmonicDistortion: Measurement[]; // 电流总谐波失真
	voltageHarmonicDistortion: Measurement[]; // 电压总谐波失真
	v3u: number | undefined; // 电压三相不平衡度
	bluetoothName: {
		content: string; // 蓝牙名称
		length: number; // 蓝牙名称长度
	};
	voltageInterface: 0 | 1;
	currentInterface1: CurrentInterface; // 电流接口1
	currentInterface2: CurrentInterface; // 电流接口2
	currentInterface3: CurrentInterface; // 电流接口3
	currentInterface4: CurrentInterface; // 电流接口4
	currentAlarmSettings: ThresholdData[]; // 电流阈值告警设置
	voltageAlarmSettings: ThresholdData[]; // 电压阈值告警设置
	currentHarmonicDistortionAlarmSettings: ThresholdData[]; // 电流总谐波畸变率阈值告警设置
	voltageHarmonicDistortionAlarmSettings: ThresholdData[]; // 电压总谐波畸变率阈值告警设置
	voltageThreePhaseImbalanceAlarmSettings: ThresholdData; // 电压三相不平衡度告警设置
	reportEnable: {
    temperature: boolean;
    current: boolean;
    voltage: boolean;
    powerFactor: boolean;
    activePower: boolean;
    reactivePower: boolean;
    apparentPower: boolean;
    forwardActiveEnergy: boolean;
    reverseActiveEnergy: boolean;
    forwardReactiveEnergy: boolean;
    reverseReactiveEnergy: boolean;
    apparentEnergy: boolean;
    thdi: boolean;
    thdv: boolean;
    voltageUnbalance: boolean;
    reserved: boolean;
  }; // 上报参数
}

declare module '../DeviceInfo' {
  interface DeviceSpecificInfo extends ICTH01DeviceInfo {}
}