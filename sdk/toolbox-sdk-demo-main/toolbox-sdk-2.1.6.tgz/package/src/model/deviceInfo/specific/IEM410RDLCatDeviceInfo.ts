export interface IEM410RDLCatDeviceInfo {
    /**
	 * 距离量程 [通用, 雨水井, 污水井]
	 */
     distanceRange: number[];
     /**
      * 场景模式 0：通用 1：雨水井 2：污水井
      */
     caseMode: number;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IEM410RDLCatDeviceInfo {}
}