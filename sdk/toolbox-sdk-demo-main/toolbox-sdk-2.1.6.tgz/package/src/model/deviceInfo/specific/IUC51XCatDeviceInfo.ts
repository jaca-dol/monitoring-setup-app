export interface IUC51XCatSupportSettingKey {
    powerSupplyState: string;
    rpsPreConfig: string;
}

declare module '../DeviceInfo' {
    interface DeviceSettingServiceExtendSupportSettingKey extends IUC51XCatSupportSettingKey {}
}