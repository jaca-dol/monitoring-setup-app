export interface IUC711DeviceInfo {
    filterCleaningAlarm: {
        enable: boolean;
        interval: number;
    };
    /**
     * 压缩机和辅助制热联用
     */
    yauxEnable?: boolean;
    /**
     * 执行计划名称
     */
    executePlanName: string;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IUC711DeviceInfo {}
}