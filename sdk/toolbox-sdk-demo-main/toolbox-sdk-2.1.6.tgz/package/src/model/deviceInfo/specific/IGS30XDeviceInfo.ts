export interface IGS30XSupportSettingKey {
    nh3Calibration: string;
}

declare module '../DeviceInfo' {
	interface DeviceSettingServiceExtendSupportSettingKey extends IGS30XSupportSettingKey {}
}