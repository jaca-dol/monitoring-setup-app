import { DaylightSaveTime } from "../DaylightSaveTime";
import { DetectionRegion } from "../DetectionRegion";

export interface IVS321DeviceInfo {
		/**
		 * 人像检测
		 * 
		 */
		peopleDetection: {
			/**
			 * 检测功能：0：人数统计，1：工位占用
			 *
			 * @type {number}
			 */
			detectionFunction: number,
			/**
			 * 检测模式：0：pir触发模式， 1：自动模式
			 *
			 * @type {number}
			 */
			detectionMode: number,
			/**
			 * 检测周期：默认2min
			 *
			 * @type {number}
			 */
			detectionInterval: number,
			/**
			 * 检测区域
			 *
			 * @type {DetectionRegion[]}
			 */
			detectionRegion: DetectionRegion[],

			/**
			 * 休眠模式功能 (VS321)
			 */
			sleep?: {
				/**
				 * 是否启用休眠模式功能 0：disable 1:enable (VS321)
				 */
				enableHibernateMode?: boolean; 

				/**
				 * 设置进入休眠模式小时点 0~23 (VS321)
				 */
				setIntoHibernateHour?: number;

				/**
				 * 设置进入休眠模式分钟点 0~59 (VS321)
				 */
				setIntoHibernateMinute?: number;

				/**
				 * 设置退出休眠模式小时 0~23 (VS321)
				 */
				setExitHibernateHour?: number;

				/**
				 * 设置退出休眠模式分钟点 0~59 (VS321)
				 */
				setExitHibernateMinute?: number;
			},

			/**
			 * 夏令时配置
			 */
			daylightSaveTime?: DaylightSaveTime;
		}
}

export interface IVS321SupportSettingKey {
    humidity: string;
    /**
     * 图像验证
     */
    imageVerification: boolean;

    /**
     * 激活状态
     */
    activatedState: boolean;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IVS321DeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends IVS321SupportSettingKey {}
}