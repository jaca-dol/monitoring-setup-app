export interface IVS360SupportSettingKey {
    hourReportingMode: boolean
}

declare module '../DeviceInfo' {
    interface DeviceSettingServiceExtendSupportSettingKey extends IVS360SupportSettingKey {}
}