export interface IWT102DeviceInfo {
  // 阀门开度
  valveOpeningDegree: number;
  // 电机校准状态
  motorCalibrationResult: {
    status?: 0 | 1 | 2 | 3 | 4;
  };
  // 电机行程
  motorTotalStroke: number;
  // 电机位置
  motorPosition: number;
  // 温度数据来源
  tempDataSource: {
    type: 0 | 1 | 2;
    external_ntc_reception?: {
      timeout: number;
      timeout_response: 0 | 1 | 2;
    };
    lorawan_reception?: {
      timeout: number;
      timeout_response: 0 | 1 | 2;
    };
  }
  // 环境温度显示
  envTempDisplayEnable: boolean;
  // 供暖日期
  heatingDateSettings: {
    startMon: number;
    startDay: number;
    endMon: number;
    endDay: number;
  };
  // 供暖期上报周期
  heatingPeriodReporting: {
    unit: 0 | 1;
    value: number;
  };
  // 非供暖期上报周期
  nonHeatingPeriodReporting: {
    unit: 0 | 1;
    value: number;
  };
  // 非供暖期阀门状态
  valveStatusControl: 0 | 1;
  // 温度控制使能
  targetTemperatureEnable: boolean;
  // 目标温度调节范围最小值
  targetTemperatureAdjustmentRangeMin: number;
  // 目标温度调节范围最大值
  targetTemperatureAdjustmentRangeMax: number;
  // 温控模式配置
  targetTemperatureModeSettings: {
    mode: 0 | 1 | 2;
    // 温度自动控制模式 / 综合控制模式
    autoControl?: {
      targetTemperature: number;
    };
    // 阀门开度控制模式
    valveControl?: {
      targetValveStatus: number;
    }
  }
  // 开窗检测
  windowOpeningDetection: {
    // 开窗检测使能
    enable: boolean;
    // 降温速度
    coolingRate: number;
    // 开窗阀门状态
    valveStatus: 0 | 1;
    // 停止调温时间
    stopTempControlTime: number;
  };
  // Auto-Away
  autoAway: {
    enable: boolean;
    startTime: number;
    endTime: number;
    repeat: Array<number>;	// 0-7
    energySavingSettings: {
      mode: 0 | 1;
      energySavingTemperature?: number;
      energySavingValveOpeningDegree?: number;
    };
  };
  // 防冻保护
  antiFreezeProtection: {
    enable: boolean,
    temperatureValue: number;
  };
  // 强制加热功能使能
  mandatoryHeatingEnable: 0 | 1;
  // 计划
  scheduleSettings: {
    id: number;
    enable: boolean;
    // 计划时间
    startTime: number;
    // 循环周期
    cycleSettings: Array<number>;
    // 温度控制模式
    temperatureControlMode: 0 | 1 | 2;
    // 目标温度
    targetTemperature: number;
    // 目标阀门开度
    targetValveStatus: number;
    // 提前预热功能
    preHeatingEnable: boolean;
    // 提前预热模式
    preHeatingMode: 0 | 1;
    // 手动预热时长
    preHeatingManualTime: number;
    // 上报周期
    reportCycle: number;
  }[],
}

declare module '../DeviceInfo' {
  interface DeviceSpecificInfo extends IWT102DeviceInfo {}
}