export interface IUC521DeviceInfo {
    /**
    * 阀门状态改变是否上报
    */
    reportValveChange?: boolean;
    interfaceOutput2: number, // 新增接口电压输出时间，ms
    pressureMode2: number, // 新增ai模式，标准0/自定义1
    pressureType2: number, // 新增ai类型，电压0/电流1
    pressureOsl2: number, // 新增ai量程最小值，0 mv/ua
    pressureOsh2: number, // 新增ai量程最大值，5000 mv/ua
    pressureRangeMin2: number, // 新增ai压力量程最小值，0 kpa
    pressureRangeMax2: number, // 新增ai压力量程最大值，1600 kpa
    collcetInterval2: number,
    pressure2?: {
       enable: boolean,
       value: string
       unit: string;
       calibration?:  {
           enable: boolean,
           value: string
       },
    }
}

export interface IUC521SupportSettingKey {
    powerSupplyState: string;
    rpsPreConfig: string;
    reportValveChange: string;
    openDelayCollectTime: string;
    collectInterval2: string;
    irrigationPeriod: string;
    irrigationPeriod2: string;
    nonIrrigationPeriod: string;
    nonIrrigationPeriod2: string;	
    valveBindPressureGauge: string;
    ruleEngineValveStatus: string;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IUC521DeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends IUC521SupportSettingKey {}
}