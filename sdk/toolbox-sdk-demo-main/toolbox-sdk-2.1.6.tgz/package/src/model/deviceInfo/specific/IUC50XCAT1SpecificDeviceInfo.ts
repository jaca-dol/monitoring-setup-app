import { GetDeviceData } from '../';
import { UC50XCAT1TSLInfo } from '../../tsl';

export type UC50XCAT1DeviceData = GetDeviceData<IUC50XCAT1SpecificDeviceInfo>;

export interface IUC50XCAT1SpecificDeviceInfo {
	cumulativeTimes: UC50XCAT1TSLInfo['cumulative_times'];
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IUC50XCAT1SpecificDeviceInfo {}
}