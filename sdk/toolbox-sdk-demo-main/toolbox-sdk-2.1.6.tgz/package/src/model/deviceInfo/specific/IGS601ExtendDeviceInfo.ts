export interface IGS601ExtendDeviceInfo {
    /**
     * 蜂鸣器休眠时间
     */
    buzzSleep?: Array<{
        /**
         * 启用
         */
        enable: boolean;

        /**
         * 开始时间（分钟数）
         */
        startTime: number;

        /**
         * 结束时间（分钟数）
         */
        endTime: number;
    }>;
}

export interface IGS601SupportSettingKey {
        /**
		 * TVOC自清洁
		 */
		tvocClear: string;
}

declare module '../DeviceInfo' {
    interface DeviceSpecificInfo extends IGS601ExtendDeviceInfo {}
    interface DeviceSettingServiceExtendSupportSettingKey extends IGS601SupportSettingKey {}
}