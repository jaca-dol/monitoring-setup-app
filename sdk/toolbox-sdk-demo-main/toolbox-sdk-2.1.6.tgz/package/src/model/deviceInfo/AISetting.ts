import { Interface1Output } from './InterfaceOutput';

/**
 * AI设置
 * UC50X、UC50XNB、UC50XNB-CAT1
 */
export interface AISetting extends OldInterface1Output, Interface1Output {
  ai1: {
    enable: boolean;

    /**
     * 0: 4-20mA 1: 0-10V
     */
    type: number;

    /**
     * 解析库返回的是string类型，物模型返回的是number类型，下同
     */
    ai1OshCurrent: string | number;
    ai1OslCurrent: string | number;
    ai1UnitCurrent: string;
    ai1OshVoltage: string | number;
    ai1OslVoltage: string | number;
    ai1UnitVoltage: string;
  };

  ai2: {
    enable: boolean;

    /**
     * 0: 4-20mA 1: 0-10V
     */
    type: number;

    /**
     * 解析库返回的是string类型，物模型返回的是number类型，下同
     */
    ai2OshCurrent: string | number;
    ai2OslCurrent: string | number;
    ai2UnitCurrent: string;
    ai2OshVoltage: string | number;
    ai2OslVoltage: string | number;
    ai2UnitVoltage: string;
  };
}

/**
 * 仅在UC50X设备中使用
 */
interface OldInterface1Output {
  /**
   * interface 2 (Pin 1) 5/9/12v 输出
   * 
   * 已废弃：不再推荐使用此字段。
   * 新型号命名请使用 `interface1v12Output` 来替代。
   */
  interface2Output?: boolean;

  /**
   * interface 2(Pin 1) 5/9/12v 采集前供电时间
   * 
   * 已废弃：不再推荐使用此字段。
   * 新型号命名请使用 `interface1v12OutputTime` 来替代。
   */
  powerOutputTime?: number;

  /**
  * interface 2(Pin 2) 3.3v 输出
  * 新版本(V1.0 1.17, V2.0 1.10)UC50X特有
  * 
  * 已废弃:不再推荐使用此字段。
  * 新型号命名请使用 `interface1v3Output` 来替代。
  */
  interface2v3Output?: boolean;

  /**
  * interface 2(Pin 2) 3.3v 供电方式
  * 0: 持续供电、1: 可配置供电时间
  * 新版本(V1.0 1.17, V2.0 1.10)UC50X特有
  * 
  * 已废弃：不再推荐使用此字段。
  * 新型号命名请使用 `interface1v3OutputType` 来替代。
  */
  interface2v3OutputType?: 0 | 1;

  /**
  * interface 2(Pin 2) 3.3v 采集前供电时间
  * 新版本(V1.0 1.17, V2.0 1.10)UC50X特有
  * 
  * 已废弃：不再推荐使用此字段。
  * 新型号命名请使用 `interface1v3OutputTime` 来替代。
  */
  interface2v3OutputTime?: number;

  /**
  * 供电电流 单位：mA 
  * 
  * 已废弃：不再推荐使用此字段。
  * 新型号命名请使用 `interface1v3Current` 来替代。
  */
  interface2v3Current?: number;
  interface2v12Current?: number;
}

