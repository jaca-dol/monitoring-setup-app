/* eslint-disable no-unused-vars */
/* eslint-disable no-redeclare */
import _ from 'lodash';

import { Version } from '../utils/util/Version';
import { MODEL_SERIES, MODELS } from './constants';
import { getDeviceIsNeutral, getDeviceModel, getModelSeries } from './model';

/**
 * 如果是sn则转换为model
 * @param snOrModel
 */
function snToModel(snOrModel: string) {
	if (!snOrModel) {
		return;
	}

	if (snOrModel.length >= 12 && snOrModel.charAt(0).match(/[0-9]/)) {
		return getDeviceModel(snOrModel);
	}
	
	return snOrModel;
}

type DeviceModelPattern = string | RegExp;

/**
 * 根据sn和型号规则判断是否为同型号设备
 * @param sn 设备sn或设备型号
 * @param pattern 设备型号规则
 */
export function identifyByModelPattern(
	snOrModel: string,
	pattern: DeviceModelPattern | DeviceModelPattern[],
) {
	const model = snToModel(snOrModel);
	
	if (!model) {
		return false;
	}

	const prefixes = _.isArray(pattern) ? pattern : [pattern];

	return prefixes.some(p => {
		if (_.isString(p)) {
			return model.startsWith(p);
		} else {
			p.lastIndex = 0;
			return p.test(model);
		}
	});
}

/**
 * 鉴别设备类型函数
 */
export function identify(sn: string): ModelIdentifier;
export function identify(model: MODELS): ModelIdentifier;
export function identify(snOrModel: string) {
	return new ModelIdentifier(snOrModel);
}

/**
 * 记忆函数的identify
 */
export const memoIdentify = _.memoize(identify, snOrModel => snOrModel);

/**
 * 鉴别设备类型集合
 */
export const Identify = {
	/**
	* 是否为AM设备
	* @param sn
	*/
	isAMDevice(snOrModel: string) {
		return identifyByModelPattern(snOrModel, "AM");
	},

	/**
	 * 是否为EM设备
	 */
	isEMDevice(snOrModel: string) {
		return identifyByModelPattern(snOrModel, "EM");
	},

	/**
	* 是否为NB设备
	*/
	isNBDevice(snOrModel: string) {
		return (
			identifyByModelPattern(snOrModel, /-N[0-9]{2}[A-Z]+$/) ||
			identifyByModelPattern(snOrModel, /NB/) ||
			identifyByModelPattern(snOrModel, /(L0ACN|N03GL|N04GL|L0BEU|L0CEU|L0DEU)/)
		);
	},

	/**
	 * 是否为LoRa设备
	 */
	isLoRaDevice(snOrModel: string) {
		return !this.isNBDevice(snOrModel) && identifyByModelPattern(snOrModel, /[A-Z]+$/);
	},

	/**
	* 是否为UC50X
	*/
	isUC50X(snOrModel: string) {
		return identifyByModelPattern(snOrModel, 'UC50');
	},

	/**
	* 是否为UC50XNB
	*/
	isUC50XNB(snOrModel: string) {
		return identifyByModelPattern(snOrModel, /^UC50[1-9]-(N0[A-Z0-9]{3}|L0ACN)$/);
	},

	/**
	 * 是否为UC50Xv2
	 */
	isUC50Xv2(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'UC50') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0');
	},
	/**
	 * 是否为UC50Xv3
	 */
	isUC50Xv3(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'UC50') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v3.0');
	},

	/**
	 * 是否为UC51Xv4
	 */
	isUC51Xv4(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'UC51') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v4.0');
	},

	/**
	 * 是否为WTS气象站v2硬件及v1.2固件
	 */
	isWTSv2(snOrModel: string, hardwareVersion: string, firmwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'WTS') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0') && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.2');
	},
	
	/**
	 * 是否为WTS气象站v3硬件
	 */
	isWTSv3(snOrModel: string, hardwareVersion: string, firmwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'WTS') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v3.0') && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.1');
	},

	/**
	 * 是否为TS30X
	 */
	isTS30X(snOrModel: string) {
		return identifyByModelPattern(snOrModel, 'TS30');
	},

	/**
	 * 是否为TS60X美国版本（L0FNA）
	 */
	isTS60XUSVersion(snOrModel: string) {
		const model = snToModel(snOrModel);
		return model === MODELS['TS601-L0FNA'] || model === MODELS['TS602-L0FNA'];
	},

	/**
	 * 是否为TS601系列（包含L0DEU、L0FNA、L0DLA）
	 */
	isTS601Model(snOrModel: string) {
		const model = snToModel(snOrModel);
		return model === MODELS['TS601-L0DEU'] || model === MODELS['TS601-L0FNA'] || model === MODELS['TS601-L0DLA'];
	},

	/**
	 * 是否为TS602系列（包含L0DEU、L0FNA、L0DLA）
	 */
	isTS602Model(snOrModel: string) {
		const model = snToModel(snOrModel);
		return model === MODELS['TS602-L0DEU'] || model === MODELS['TS602-L0FNA'] || model === MODELS['TS602-L0DLA'];
	},

	/**
	 * 是否为TS602系列且传感器类型为SHT41（sensorType === 2）
	 */
	isTS602SHT41(snOrModel: string, sensorType?: number | null) {
		return this.isTS602Model(snOrModel) && sensorType === 2;
	},

	/**
	 * 是否为EM41X
	 */
	isEM41X(snOrModel: string) {
		return identifyByModelPattern(snOrModel, 'EM41');
	},

	/**
	 * 是否为WS50X EU/US 固件0102迭代
	 */
	isWS50XEUUSV0102(snOrModel: string, firmwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'WS50') && identifyByModelPattern(snOrModel, /(EU|US)/) && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.2');
	},

	/**
	 * 是否为WS50X机械式
	 */
	isWS50XMECH(snOrModel: string) {
		return identifyByModelPattern(snOrModel, 'WS50') && identifyByModelPattern(snOrModel, /(EU|EUD|US)/);
	},

	isWS50XCN(model: string) {
		return model?.includes('EUD');
	},

	/**
	 * 是否为WS50X触控式V2及以上
	 */
	isWS50XTouchV2(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, 'WS50') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0') && !this.isWS50XMECH(snOrModel);
	},

	/**
	 * 是否为WS558v2版本
	 */
	isWS558v2(sn: string) {
		return identifyByModelPattern(sn, 'WS558') && sn.startsWith('6756');
	},

	/**
	 * 是否为AM3XXv2
	 */
	isAM3XXv2(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, ['AM3']) && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0');
	},

	isAM319Model(snOrModel: string) {
		return identifyByModelPattern(snOrModel, ['AM319']);
	},

	/**
	 * 是否为AM307/AM319.0000.0200.0104&AM308.0000.0200.0106迭代
	 */
	isAMModelSeriesV0104(snOrModel: string, firmwareVersion: string, hardwareVersion: string) {
		const isAM3XXv2 = identify(snOrModel).isAM3XXv2(hardwareVersion);
		const isAM319Model = identify(snOrModel).isAM319Model();

		if(isAM319Model && isAM3XXv2 && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.4')){
			return true;
		}

		const supportModels: Record<string, boolean> = {
			[MODELS['AM307']]: isAM3XXv2 && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.4'),
			[MODELS['AM307L']]: isAM3XXv2 && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.4'),
			[MODELS['AM308']]: isAM3XXv2 && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.6'),
			[MODELS['AM308L']]: isAM3XXv2 && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.6'),
		};
		return supportModels[snOrModel] ;
	},

	/**
	 * 是否为EM5XXv2
	 */
	isEM5XXv2(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, ['EM5']) && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0');
	},

	/**
	 * 是否为EM500_0200_0107迭代
	 * */
	isEM500_0200_0107(snOrModel: string, hardwareVersion: string, firmwareVersion: string) {
		return this.isEM5XXv2(snOrModel, hardwareVersion) && Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.7');
	},

	/**
	 * 是否为EM300-DI(-HALL)-v3
	 */
	isEM300DIv3(snOrModel: string, firmwareVersion: string) {
		return identifyByModelPattern(snOrModel, [ 'EM300-DI','EM300-DI-HALL' ]) && Version.isGreaterThanOrEqualTo(firmwareVersion.split('-')[0]!, 'v1.3');
	},

	/**
	 * 是否为WS1X6系列
	 */
	isWS1X6(snOrMode: string) {
		return identifyByModelPattern(snOrMode, [/WS1[0-9]6/]);
	},

	/**
	 * 是否为WT201v2
	 */
	isWT201v2(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, ['WT201']) && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0');
	},

	/**
	 * 是否为WT211v2
	 */
	isWT211v2(snOrModel: string, hardwareVersion: string) {
		return identifyByModelPattern(snOrModel, ['WT211']) && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0');
	},

	/**
	 * 是否为EM320-TH认证版本（003/004），认证版本NFC写入时需要每次输入密码
	 */
	isEM320THCert(sn: string) {
		if (!sn || sn.length < 15) return false;
		if (!identifyByModelPattern(sn, /^EM320-TH/)) return false;
		const additional = sn.substring(12, 15);
		return additional === '003' || additional === '004';
	},

	/**
	 * 是否为中性设备型号
	 */
	isNeutral(oem: string) {
		return getDeviceIsNeutral(oem);
	},

	/**
	 * 比较两个型号是否通用
	 * @param source 当前sn或型号
	 * @param target 目标sn或型号
	 */
	isEqualWith(source: string, target: string) {
		const [ sourceModel, targetModel ] = [ snToModel(source), snToModel(target) ];
		
		if(!sourceModel || !targetModel) {
			return false;
		}

		if(sourceModel === targetModel) {
			return true;
		}

		return false;
	},

	/**
	 * 型号数组中是否包含当前型号
	 * @param sn sn 
	 * @param arr 型号/系列数组
	 * @returns 
	 */
	includes(snOrModel: string, arr: Array<MODELS | MODEL_SERIES>) {
		const model = snToModel(snOrModel);
		const modelSeries = getModelSeries(model) as MODEL_SERIES;

		if(!model) {
			return false;
		}

		return arr.includes(model as MODELS) || arr.includes(modelSeries);
	},

	/**
	 * 返回当前型号/型号系列最合适的值,如果没有则返回默认值
	 * 如果型号和型号系列同时存在，优先选择型号
	 * @param sn sn
	 * @param specifics
	 * @example
	 * Identify.select('6217xxxxxx', {
	 *   [MODELS['AM103']]: {
	 *     backgroundColor: 'green'
	 *   },
	 *   [MODELS['AM307']]: {
	 *     backgroundColor: 'red'
	 *   },
	 *   default: {
	 *     backgroundColor: 'blue'
	 *   }
	 * })
	 * 
	 * @returns 
	 */
	select<T>(snOrModel: string, specifics: { [m in MODELS]?: T } & { [ms in MODEL_SERIES]?: T } & { default: T }): T {
		const model = snToModel(snOrModel);
		const modelSeries = getModelSeries(model) as MODEL_SERIES;

		if(!model) {
			return specifics.default;
		}

		const result = model in specifics
			? specifics[model as MODELS]
			: modelSeries in specifics
				? specifics[modelSeries]
				: specifics.default;

		return result as T;
	}
};

/**
 * 鉴别设备类型的工具对象封装
 */
export class ModelIdentifier {

	model: MODELS;

	sn: string;
	
	constructor(sn: string) {
		this.sn = sn;
		this.model = snToModel(sn) as MODELS;
	}

	/**
	* 是否为AM设备
	*/
	isAMDevice() {
		return Identify.isAMDevice(this.model);
	}

	/**
	 * 是否为EM设备
	 */
	isEMDevice() {
		return Identify.isEMDevice(this.model);
	}

	/**
	 * 是否为LoRa设备
	 */
	isLoRaDevice() {
		return Identify.isLoRaDevice(this.model);
	}

	/**
	 * 是否为NB设备
	 */
	isNBDevice() {
		return Identify.isNBDevice(this.model);
	}

	/**
	 * 是否为UC50X
	 */
	isUC50X() {
		return Identify.isUC50X(this.model);
	}

	/* 是否为TS30X
	 * */
	isTS30X() {
		return Identify.isTS30X(this.model);
	}

	/**
	 * 是否为TS60X美国版本（L0FNA）
	 */
	isTS60XUSVersion() {
		return Identify.isTS60XUSVersion(this.model);
	}

	/**
	 * 是否为TS601系列（包含L0DEU、L0FNA、L0DLA）
	 */
	isTS601Model() {
		return Identify.isTS601Model(this.model);
	}

	/**
	 * 是否为TS602系列（包含L0DEU、L0FNA、L0DLA）
	 */
	isTS602Model() {
		return Identify.isTS602Model(this.model);
	}

	/**
	 * 是否为TS602系列且传感器类型为SHT41（sensorType === 2）
	 */
	isTS602SHT41(sensorType?: number | null) {
		return Identify.isTS602SHT41(this.model, sensorType);
	}

	/**
	 * 是否为EM41X
	 */
	isEM41X() {
		return Identify.isEM41X(this.model);
	}
	
	/**
	 * 是否为UC50XNB
	 */
	isUC50XNB() {
		return Identify.isUC50XNB(this.model);
	}

	/**
	 * 是否为UC50Xv2
	 */
	isUC50Xv2(hardwareVersion: string) {
		return Identify.isUC50Xv2(this.model, hardwareVersion);
	}
	
	/**
	 * 是否为UC50Xv3
	 */
	isUC50Xv3(hardwareVersion: string) {
		return Identify.isUC50Xv3(this.model, hardwareVersion);
	}

	/**
	 * 是否为UC51Xv4
	 */
	isUC51Xv4(hardwareVersion: string) {
		return Identify.isUC51Xv4(this.model, hardwareVersion);
	}

	/**
	 * 是否为WTS气象站v2硬件及v1.2固件
	 */
	isWTSv2(hardwareVersion: string, firmwareVersion: string) {
		return Identify.isWTSv2(this.model, hardwareVersion, firmwareVersion);
	}
	/**
	 * 是否为WTS气象站v3硬件
	 */
	isWTSv3(hardwareVersion: string, firmwareVersion: string) {
		return Identify.isWTSv3(this.model, hardwareVersion, firmwareVersion);
	}

	/**
	 * 是否为WS50X EU/US 固件0102迭代
	 */
	isWS50XEUUSV0102(firmwareVersion: string) {
		return Identify.isWS50XEUUSV0102(this.model, firmwareVersion);
	}

	/**
	 * 是否为WS50X机械式
	 */
	isWS50XMECH() {
		return Identify.isWS50XMECH(this.model);
	}

	/**
	 * 是否为WS50X触控式V2及以上
	 */
	isWS50XTouchV2(hardwareVersion: string) {
		return Identify.isWS50XTouchV2(this.model, hardwareVersion);
	}

	/**
	 * 是否为WS558v2版本
	 */
	isWS558v2() {
		return Identify.isWS558v2(this.sn);
	}

	/**
	 * 是否为AM3XXv2
	 */
	isAM3XXv2(hardwareVersion: string) {
		return Identify.isAM3XXv2(this.model, hardwareVersion);
	}

	/**
	 * 是否为AM319系列
	 */
	isAM319Model(){
		return Identify.isAM319Model(this.model);
	}

	/**
	 * 是否为AM307/AM319.0000.0200.0104&AM308.0000.0200.0106迭代
	 */
	isAMModelSeriesV0104(firmwareVersion: string, hardwareVersion: string) {
		return Identify.isAMModelSeriesV0104(this.model, firmwareVersion, hardwareVersion);
	}

	/**
	 * 是否为EM300-DI(-HALL)-v3
	 */
	isEM300DIv3(firmwareVersion: string) {
		return Identify.isEM300DIv3(this.model, firmwareVersion);
	}

	/**
	 * 是否为EM5XXv2
	 */
	isEM5XXv2(hardwareVersion: string) {
		return Identify.isEM5XXv2(this.model, hardwareVersion);
	}

	/**
 	* 是否为WS1X6系列
 	*/
	isWS1X6() {
		return Identify.isWS1X6(this.model);
	}

	/**
	* 是否为EM500_0200_0107迭代
	*/
	isEM500_0200_0107(hardwareVersion: string, firmwareVersion: string) {
		return Identify.isEM500_0200_0107(this.model, hardwareVersion, firmwareVersion);
	}

	/**
	 * 是否为WT201v2
	 */
	isWT201v2(hardwareVersion: string) {
		return Identify.isWT201v2(this.model, hardwareVersion);
	}

	isWT211v2(hardwareVersion: string) {
		return Identify.isWT211v2(this.model, hardwareVersion);
	}

	/**
	 * 是否为EM320-TH认证版本（003/004）
	 */
	isEM320THCert() {
		return Identify.isEM320THCert(this.sn);
	}

	/**
	 * 是否为中性设备型号
	 */
	isNeutral(oem: string) {
		return Identify.isNeutral(oem);
	}

	/**
	 * 比较当前型号与目标型号是否相同
	 * @param target 目标sn或型号
	 */
	isEqualWith(target: string) {
		return Identify.isEqualWith(this.model, target);
	}

	/**
	 * 型号数组中是否包含当前型号
	 * @param sn sn 
	 * @param arr 型号/系列数组
	 * @returns 
	 */
	includes(arr: Array<MODELS | MODEL_SERIES>) {
		return Identify.includes(this.model, arr);
	}

	/**
	 * 从集合中选择当前型号/型号系列最合适的值, 如果没有则返回默认值
	 * 如果型号和型号系列同时存在，优先选择型号
	 * @param specifics 型号/系列集合
	 * @example
	 * identify.select({
	 *	[MODELS['AM103']]: "setting.buttonLight.am.label",
	 *	[MODEL_SERIES['WS100']]: "setting.buttonLight.ws100.label",
	 *	default: 'setting.buttonLight.default.label'
	 * })
	 */
	select<T>(specifics: { [m in MODELS]?: T } & { [ms in MODEL_SERIES]?: T } & { default: T }): T {
		return Identify.select(this.model, specifics);
	}
}