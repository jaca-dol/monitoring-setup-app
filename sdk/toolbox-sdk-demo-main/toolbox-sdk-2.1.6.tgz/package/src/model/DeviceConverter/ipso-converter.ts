/* eslint-disable no-fallthrough */
/* eslint-disable no-case-declarations */
import { Buffer } from 'buffer';
import { MODEL } from '@ursalink-cloud/core-sdk/lib/device';
import { Version } from '@ursalink-cloud/core-sdk/lib/util';

import {BufferReader} from './buffer-reader';
import {array, fixFloat, safeValue, timeToS} from './util';
import {DATA_TYPE, IPSO_ID_MAP} from './ipso-definition';
import _ from 'lodash';
import {ConfigData, Data, PayloadContext} from './types';

const IPSO_PARSER: {
  [key: number]: (
    channel: number,
  ) => (reader: BufferReader, data: Data) => void;
} = {};
_.forEach(IPSO_ID_MAP, tuple => {
	IPSO_PARSER[tuple.id] = parseSimpleChannelData(tuple);
});

// analog input
IPSO_PARSER[2] = (channel: number) => (reader: BufferReader, data: Data) => {
	const {model = "", firmware = "", hardware = ""} = data.context || {};
	const offset = reader.getOffset();
	let coefficient = 100;
	let fractionDigits = 2;
	switch (model) {
		case MODEL.UC501:
			// @ts-ignore        
		case MODEL.UC502:			
			const firmwareVersion = new Version(firmware);
			const hardwareVersion = new Version(hardware);
			if ((firmwareVersion.compareWith("v1.11") >= 0 && hardwareVersion.compareWith("v2.0") >= 0)
			|| (firmwareVersion.compareWith("v1.18") >= 0 && hardwareVersion.compareWith("v1.0") >= 0)) {
				coefficient = 1000;
				fractionDigits = 3;
			}
		// tslint:disable-next-line:no-switch-case-fall-through
		case "":
		case MODEL.UC11_N1:
		case MODEL.UC1122:
		case MODEL.UC1152:
			const tuple = array(4);
			const [ ccy, min, max, avg ] = tuple.map(() => fixFloat(reader.readInt16LE() / coefficient, fractionDigits));
			reader.setOffset(offset);
			const raw = tuple.map(() => reader.readHex(2));
			data[channel] = {
				channel,
				type: "analogInput",
				value: {ccy, min, max, avg, raw},
			};
			break;
		default:
			const value = fixFloat(reader.readUInt32LE() / coefficient, fractionDigits);
			reader.setOffset(offset);
			const rawValue = reader.readHex(4);
			data[channel] = {
				channel,
				type: "analogInput",
				value: {ccy: value, min: value, max: value, avg: value, raw: rawValue},
			};
			break;
	}
};

IPSO_PARSER[101] = (channel: number) => (reader: BufferReader, data: Data) => {
	console.log('read data: illumianceSensor');
	const value = reader.readUInt16LE();
	reader.readUInt16LE();
	reader.readUInt16LE();
	data[channel] = {
		channel,
		type: 'illumianceSensor',
		value,
		unit: 'lux'
	};
};

const URSA_PARSER: {
  [key: number]: (reader: BufferReader, data: Data) => void;
} = {
	1: parseSimpleConfigData('version', DATA_TYPE.UInt8, value =>
		value.toString(),
	),
	2: parseSimpleConfigData('interval', DATA_TYPE.UInt16),
	3: parseSimpleConfigData('period', DATA_TYPE.UInt16),
	4: skip(1, 'response'), // response
	5: parseLoRaChanMask,
	6: skip(9, 'alarmConfig'), // alarmConfig
	7: skip(1, 'debugLevel'), // debugLevel
	8: skip(6, 'sn'), // sn
	9: parseVersion('hardware'),
	10: parseVersion('firmware'),
	11: parseSimpleConfigData('powerOn', DATA_TYPE.UInt8, value => value > 0),
	12: parseSimpleConfigData('powerOff', DATA_TYPE.UInt8, value => value > 0),
	13: parseAlarm,
	14: parseChannels,
	15: parseSimpleConfigData('class', DATA_TYPE.UInt8),
	16: skip(1, 'reboot'),
	17: skip(4, 'timestamp'),
	18: parseText,
	19: parseSimpleConfigData('intelligenceReport', DATA_TYPE.UInt8),
	20: parseConversion,
	21: parseCollectFailedChannelIds,
	22: skip(8, 'sn'), // sn
	23: skip(2, 'timezone'),
	24: parseChannelEnableConfig,
	25: parseChannels2
};

const URSA_WRITER: {[key: string]: (value: any) => Buffer} = {
	interval: writeSimpleData(2, DATA_TYPE.UInt16),
	period: writeSimpleData(3, DATA_TYPE.UInt16),
	alarmConfig: writeAlarm as (value: any) => Buffer,
	intelligenceReport: writeSimpleData(0x13, DATA_TYPE.UInt8, v =>
		_.isNumber(v) ? v : 0,
	),
	channelEnableConfigList: writeChannelEnableConfig,
};

export function convertBase64ToObject(payload: string, context?: PayloadContext) {
	const reader = new BufferReader(Buffer.from(payload, 'base64'));
	console.log(reader.getBuffer().toString('hex'));
	const data: Data = {config: {}, context};
	while (reader.hasNextByte()) {
		const channel = reader.readUInt8();
		const type = reader.readUInt8();
		console.log(`channel: ${channel}, type: ${type}`);
		const parser = getReadParser(channel, type);
		if (parser) {
			parser.parse(reader, data);
		}
	}
	return data;
}

export function convertObjectToBase64(json: ConfigData) {
	// @ts-ignore
	return Buffer.concat(convertObjectToBuffers(json)).toString('base64');
}

export function convertObjectToBase64Array(json: ConfigData) {
	return convertObjectToBuffers(json).map(buffer => buffer.toString('base64'));
}

export function convertObjectToBuffers(json: ConfigData) {
	return Object.keys(json)
		.filter(
			key =>
				URSA_WRITER[key] !== undefined &&
				json[key as keyof ConfigData] !== undefined,
		)
		.map(key => URSA_WRITER[key]!(json[key as keyof ConfigData]));
}

function getReadParser(channel: number, type: number) {
	if (channel === 255) {
		return {parse: URSA_PARSER[type]!};
	} else {
		return {parse: IPSO_PARSER[type]!(channel)};
	}
}

function parseSimpleChannelData(tuple: {
  converter?: (value: any) => any;
  dataType: string;
  id: number;
  sensorType: string;
  unit?: string;
}) {
	return (channel: number) => (reader: BufferReader, data: Data) => {
		console.log('read data:', tuple.sensorType);
		const value = (reader as any)[`read${tuple.dataType}`]();
		data[channel] = {
			channel,
			type: tuple.sensorType,
			unit: tuple.unit,
			value: (tuple.converter || (v => v))(value),
		};
	};
}

function parseSimpleConfigData(
	property: string,
	dataType: string,
	converter: (value: any) => any = value => value,
) {
	return (reader: BufferReader, data: Data) => {
		console.log('read data:', property);
		const value = (reader as any)[`read${dataType}`]();
		if (!data.config) {
			data.config = {};
		}
		(data.config as any)[property] = converter(value);
	};
}

function writeSimpleData(
	type: number,
	dataType: string,
	converter: (value: any) => number = value => value,
) {
	return (value: any) => {
		let size = 3;
		if (dataType.endsWith('16LE')) {
			size += 1;
		} else if (dataType.endsWith('32LE')) {
			size += 3;
		}
		const buffer = Buffer.alloc(size);
		buffer.writeUInt8(255, 0);
		buffer.writeUInt8(type, 1);
		(buffer as any)[`write${dataType}`](converter(value), 2);
		return buffer;
	};
}

function skip(length: number, property = 'undefined') {
	return (reader: BufferReader) => {
		console.log('skip data:', property);
		reader.moveOffset(length);
	};
}

function parseLoRaChanMask(reader: BufferReader, data: Data) {
	console.log('read data: LoRaChanMask');
	const id = reader.readUInt8();
	const value = reader.readUInt16LE();
	data.config.loRaChanMask = {id, value};
}

function parseText(reader: BufferReader, data: Data) {
	console.log('read data: text');
	const length = reader.readUInt8();
	data.config.text = reader.readString(length);
}

function parseAlarm(reader: BufferReader, data: Data) {
	console.log('read data: alarm');
	const MODE = [ 'DISABLE', 'BELOW', 'ABOVE', 'WITHIN', 'BELOW_OR_ABOVE' ];
	const idAndMode = reader.readUInt8();
	const id = (idAndMode & 56) >>> 3; // & 0x00111000 >> 3
	let mode = MODE[idAndMode & 7]!; // & 0x00000111
	const min = reader.readInt16LE() / 10;
	const max = reader.readInt16LE() / 10;
	const current = reader.readInt16LE() / 10;
	let lessThan = min;
	let greaterThan = max;
	if (mode === 'WITHIN') {
		lessThan = max;
		greaterThan = min;
	} else if (mode === 'BELOW_OR_ABOVE') {
		// 对于云端没有 BELOW_OR_ABOVE, 要么BELOW要么ABOVE
		mode = current < lessThan ? 'BELOW' : 'ABOVE';
	}
	data.config.alarm = {id, mode, greaterThan, lessThan, current};
	const channel = 1; // T1
	data[channel] = data[channel] || {
		channel,
		type: 'temperatureSensor',
		unit: '℃',
		value: current
	};
}

function parseConversion(reader: BufferReader, data: Data) {
	console.log('read data: conversion');
	const value = reader.readUInt8();
	const index = (value & 240) >>> 4; // & 11110000 >> 4
	const type = (value & 15) === 0 ? 'mA' : 'V'; // & 00001111
	if (!data.config.conversion) {
		data.config.conversion = [];
	}
	data.config.conversion.push({index, type});
}

function parseVersion(property: string) {
	return (reader: BufferReader, data: Data) => {
		console.log('read data:', property);
		const mainVer = reader.readUInt8();
		const subVer = reader.readUInt8();
		const realMainVer = (mainVer % 16) + Math.floor(mainVer / 16) * 10;
		const realSubVer =
			subVer % 16 === 0 && property === 'hardware'
				? Math.floor(subVer / 16)
				: (subVer % 16) + Math.floor(subVer / 16) * 10;
		if (property === 'hardware') {
			data.config.hardware = `v${realMainVer}.${realSubVer}`;
		} else if (property === 'firmware') {
			data.config.firmware = `v${realMainVer}.${realSubVer}`;
		}
	};
}

function writeAlarm(alarmConfig: {
  continueTime?: number;
  continueTimeUnit?: string;
  greaterThan?: number;
  id?: number;
  lessThan?: number;
  lockoutTime?: number;
  lockoutTimeUnit?: string;
  mode?: string;
}) {
	const MODE: {[key: string]: number} = {
		DISABLE: 0,
		BELOW: 1,
		ABOVE: 2,
		WITHIN: 3,
		BELOW_OR_ABOVE: 4,
	};
	const buffer = Buffer.alloc(11);
	buffer.writeUInt8(255, 0);
	buffer.writeUInt8(6, 1);
	const idAndMode =
		((alarmConfig.id || 0) << 3) + MODE[alarmConfig.mode || 'DISABLE']!;
	buffer.writeUInt8(idAndMode, 2);
	let {lessThan = 999.9, greaterThan = 999.9} = alarmConfig;
	if (
		(alarmConfig.mode === 'BELOW_OR_ABOVE' || alarmConfig.mode === 'WITHIN') &&
		lessThan > greaterThan
	) {
		// min和max都有值时min一定小于max
		[ lessThan, greaterThan ] = [ greaterThan, lessThan ];
	}
	buffer.writeInt16LE(Math.round(safeValue(lessThan, 999.9) * 10), 3); // min
	buffer.writeInt16LE(Math.round(safeValue(greaterThan, 999.9) * 10), 5); // max
	buffer.writeUInt16LE(
		timeToS(alarmConfig.lockoutTime || 0, alarmConfig.lockoutTimeUnit),
		7,
	);
	buffer.writeUInt16LE(
		timeToS(alarmConfig.continueTime || 0, alarmConfig.continueTimeUnit),
		9,
	);
	return buffer;
}

function writeChannelEnableConfig(
	configList: {enabled: boolean; index: number}[],
): Buffer {
	if (!configList.length) {
		return Buffer.from([]);
	}
	const buffer = Buffer.alloc(4);
	buffer.writeUInt8(255, 0);
	buffer.writeUInt8(24, 1);
	const type = 0;
	buffer.writeUInt8(type, 2);
	let value = 0b00000000;
	configList
		.filter(v => v.enabled)
		.forEach(v => (value = value | (1 << (v.index - 1))));
	buffer.writeUInt8(value, 3);
	return buffer;
}

const CHANNEL_TYPE = [
	'REG_COIL',
	'REG_DISCRETE',
	'REG_INPUT',
	'REG_HOLD_INT16',
	'REG_HOLD_INT32',
	'REG_HOLD_FLOAT',
	'REG_INPUT_INT32',
	'REG_INPUT_FLOAT',
	'REG_INPUT_INT32_AB',
	'REG_INPUT_INT32_CD',
	'REG_HOLD_INT32_AB',
	'REG_HOLD_INT32_CD'
];

function parseChannels(reader: BufferReader, data: Data) {
	console.log('read data: channels');
	const channelId = reader.readUInt8();
	const ptype = reader.readUInt8();
	const dataType = CHANNEL_TYPE[ptype & 7]!;
	const dataLength = ptype >> 3;
	return handleChannelsData(reader, data, dataType, dataLength, channelId);
}

function parseChannels2(reader: BufferReader, data: Data) {
	console.log('read data: channels2');
	const channelId = reader.readUInt8();
	const dataLength = reader.readUInt8();
	const dataType = CHANNEL_TYPE[reader.readUInt8()]!;
	return handleChannelsData(reader, data, dataType, dataLength, channelId);
}

function handleChannelsData(
	reader: BufferReader,
	data: Data,
	dataType: string,
	dataLength: number,
	channelId: number,
) {
	const offset = reader.getOffset();
	let raw = '';
	let value = 0;
	switch (dataType) {
		case 'REG_COIL':
		case 'REG_DISCRETE':
			value = reader.readUInt8();
			reader.setOffset(offset);
			raw = reader.readHex(1);
			break;
		case 'REG_INPUT':
		case 'REG_HOLD_INT16':
		case 'REG_INPUT_INT32_AB':
		case 'REG_INPUT_INT32_CD':
		case 'REG_HOLD_INT32_AB':
		case 'REG_HOLD_INT32_CD':
			value = reader.readUInt16LE();
			reader.setOffset(offset);
			raw = reader.readHex(2);
			break;
		case 'REG_HOLD_INT32':
		case 'REG_INPUT_INT32':
			value = reader.readUInt32LE();
			reader.setOffset(offset);
			raw = reader.readHex(4);
			break;
		case 'REG_HOLD_FLOAT':
		case 'REG_INPUT_FLOAT':
			value = fixFloat(reader.readFloatLE(), 4);
			reader.setOffset(offset);
			raw = reader.readHex(4);
			break;
	}
	if (!data.config.channelData) {
		data.config.channelData = array(8);
	}
	data.config.channelData[channelId] = {
		channelId,
		dataType,
		dataLength,
		value,
		raw
	};
}

function parseCollectFailedChannelIds(reader: BufferReader, data: Data) {
	const ids = data.config.collectFailedChannelIds || [];
	ids.push(reader.readUInt8());
	data.config.collectFailedChannelIds = ids;
}

function parseChannelEnableConfig(reader: BufferReader, data: Data) {
	const configMap = new Map(
		(data.config.channelEnableConfigList || []).map(v => [ v.index, v.enabled ]),
	);
	const type = reader.readUInt8();
	const value = reader.readUInt8();
	if (type === 0) {
		for (let i = 0; i < 8; i++) {
			configMap.set(i + 1, ((value >> i) & 1) === 1);
		}
	} else {
		configMap.set(type, value === 1);
	}
	data.config.channelEnableConfigList = [...configMap].map(v => ({
		index: v[0],
		enabled: v[1]
	}));
}
