import type { MODEL } from '@ursalink-cloud/core-sdk/lib/device';

export interface Data {
    config: ConfigData;
    context?: PayloadContext;

    [channel: number]: ChannelData;
}

export interface PayloadContext {
	firmware?: string;
	hardware?: string;
	model?: MODEL;
	sn?: string;
	version?: string;
}


// IPSO标准定义（1<= channel <=254）
// DATA_TYPE = IPSO_OBJECT_ID - 3200
// Type 	IPSO	DataSize	Data Resolution per bit
// Digital Input	3200	1	1
// Digital Output	3201	1	1
// Analog Input	3202	2	0.01 signed
// Analog Output	3203	2	0.01 signed
// Illuminance Sensor	3301	2	1 lux Unsigned MSB
// Presence Sensor	3302	1	1
// Temperature Sensor	3303	2	0.1 °C Signed MSB
// Humidity Sensor	3304	1	0.5% unsigned
// Voltage	3316	2	0.01V unsigned
// Current	3317	2	0.01A unsigned
// Power	3328	1	1%

// ursalink自定义（channel == 255）
// Type 	TypeID	DataSize	Data Resolution per bit
// 协议版本	1	1	0x01
// 采集周期	2	2	1s
// 上报周期	3	2	1s
// 应答配置	4	1	Bit0:定期上报应答(0:disable  1:enable) Bit1:警报上报应答(0:disable  1:enable)
// LoRaChanMask	5	3	ID(1B) + Value(2B) ID:1~6
// 警报配置	6	8	ID(1B)Mode(1B)+Min(2B)+Max(2B)+Cur(2B)  Mode= 0:disable, 1:below, 2:above,  3:within, 4:below or above
// DebugLevel	7	1	Bit0:info   Bit1:debug bit2:warn  Bit3:err
// ProductSN	8	6	641090824375 => 0x641090824375
// HwVer	9	2	0110 => 0x01 0x10
// SwVer	10	2	6410 => 0x64 0x10
// PowerOnEvent	11	1	0xff reserved.
// PowerOffEvent	12	1	0xff reserved
// LockTime	13	3	id(1B) + value(2B) id:1~8。（表示第几条规则） 1s
// ContinueTime	14	3	id(1B) + value(2B) id:1~8。（表示第几条规则） 1s

export interface ChannelData {
    channel: number;
    type: string;
    unit?: string;
    value: any;
}

export interface ConfigData {
    alarm?: {
        current?: number;
        greaterThan?: number;
        id: number
        lessThan?: number;
        mode: string;
    };
    alarmConfig?: {
        continueTime?: number;
        continueTimeUnit?: string;
        greaterThan?: number;
        id: number
        lessThan?: number;
        lockoutTime?: number;
        lockoutTimeUnit?: string;
        mode: string;
    };
    channelData?: ({
        channelId: number;
        dataLength: number;
        dataType: string;
        raw: string;
        value: number;
    } | undefined)[];
    channelEnableConfigList?: { enabled: boolean; index: number; }[];
    collectFailedChannelIds?: number[];
    conversion?: {
        index: number;
        type: "mA" | "V" | string;
        [key: string]: any;
    }[];
    debugLevel?: string;
    firmware?: string;
    hardware?: string;
    intelligenceReport?: number; // 0: off 2: on
    interval?: number;
    loRaChanMask?: {
        id: number;
        value: number;
    };
    period?: number;
    powerOff?: boolean;
    powerOn?: boolean;
    response?: {
        alarm?: boolean;
        regularReport?: boolean;
    };
    sn?: string;
    text?: string;
    version?: string;
}
