import {convertBase64ToObject} from './ipso-converter';
import {Device} from '@ursalink-cloud/core-sdk';
import {MODEL} from '@ursalink-cloud/core-sdk/lib/device';
import {LORA_REPORT_SERVICE, LoRaDeviceReport} from './lora-device-report';

const payload = 'CQEBCgEB';
const result = convertBase64ToObject(payload);
console.log(result);

const device = Device.create(MODEL.UC1114);
const reportService = device.componentInstance<typeof LoRaDeviceReport>(
	LORA_REPORT_SERVICE,
	device,
);
if (reportService) {
	reportService
		.handleReportData(payload)
		.then(() => console.log(device.data))
		.catch(e => console.error(e));
}
