import _ from 'lodash';

export function timeToS(time: number, unit = 's') {
	if (unit === 'min') {
		return time * 60;
	} else {
		return time;
	}
}

export function array<T = undefined>(length: number, filledWith?: T): T[] {
	return new Array(length).fill(
		filledWith ? _.cloneDeep(filledWith) : filledWith,
	);
}

export function fixFloat(float: number | string, fractionDigits = 1): number {
	const value = _.isString(float) ? parseFloat(float) : float;
	return parseFloat(value.toFixed(fractionDigits));
}

export function safeValue(currentValue: any, defaultValue: any) {
	if (currentValue === undefined || currentValue === null) {
		return defaultValue;
	}
	return currentValue;
}
