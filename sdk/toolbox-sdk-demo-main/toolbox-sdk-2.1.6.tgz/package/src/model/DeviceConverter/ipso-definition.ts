interface IpsoTuple {
  converter?: (value: any) => any;
  dataType: string;
  id: number;
  sensorType: string;
  unit?: string;
}

const DATA_TYPE = {
	Int8: 'Int8',
	UInt8: 'UInt8',
	Int16: 'Int16LE',
	UInt16: 'UInt16LE',
	Int32: 'Int32LE',
	UInt32: 'UInt32LE'
};

function defineIpsoTuple(
	id: number,
	sensorType: string,
	dataType: string,
	unit?: string,
	converter?: (value: any) => any,
) {
	return {id, sensorType, unit, dataType, converter};
}

const tuples = [
	defineIpsoTuple(0, 'digitalInput', DATA_TYPE.UInt8),
	defineIpsoTuple(1, 'digitalOutput', DATA_TYPE.UInt8),
	defineIpsoTuple(
		3,
		'analogOutput',
		DATA_TYPE.Int16,
		undefined,
		value => value / 100,
	),
	defineIpsoTuple(102, 'presenceSensor', DATA_TYPE.UInt8),
	defineIpsoTuple(
		103,
		'temperatureSensor',
		DATA_TYPE.Int16,
		'°C',
		value => value / 10,
	),
	defineIpsoTuple(
		104,
		'humiditySensor',
		DATA_TYPE.UInt8,
		'%',
		value => value / 2,
	),
	defineIpsoTuple(106, 'actuation', DATA_TYPE.UInt16, ''),
	defineIpsoTuple(
		115,
		'barometerPressure',
		DATA_TYPE.UInt16,
		'hPa',
		value => value / 10,
	),
	defineIpsoTuple(116, 'voltage', DATA_TYPE.UInt16, 'V', value => value / 100),
	defineIpsoTuple(117, 'current', DATA_TYPE.UInt8, '%'),
	defineIpsoTuple(119, 'depth', DATA_TYPE.Int16, 'm', value => value / 100),
	defineIpsoTuple(123, 'pressure', DATA_TYPE.UInt16, 'kPa'),
	defineIpsoTuple(124, 'loudness', DATA_TYPE.UInt16, 'dB', value => value / 10),
	defineIpsoTuple(125, 'concentration', DATA_TYPE.UInt16, ''),
	defineIpsoTuple(
		126,
		'concentration',
		DATA_TYPE.Int16,
		'ppm',
		value => value / 10,
	),
	defineIpsoTuple(127, 'conductivity', DATA_TYPE.UInt16, ''),
	defineIpsoTuple(128, 'power', DATA_TYPE.UInt16, 'W', value => value / 100),
	defineIpsoTuple(
		130,
		'distance',
		DATA_TYPE.UInt16,
		'm',
		value => value / 1000,
	), // 用除法避免精度丢失
	defineIpsoTuple(
		146,
		'par',
		DATA_TYPE.UInt16,
		'μmol·m⁻²·s⁻¹',
		value => value / 10,
	),
	defineIpsoTuple(148, 'illuminance', DATA_TYPE.UInt32, 'lux'),
	defineIpsoTuple(200, 'counter', DATA_TYPE.UInt32),
];

const IPSO_ID_MAP: {[id: number]: IpsoTuple} = {};
tuples.forEach(tuple => {
	IPSO_ID_MAP[tuple.id] = tuple;
});

export {IPSO_ID_MAP, DATA_TYPE};
