/* eslint-disable @typescript-eslint/no-unused-vars */
import { ExComponent } from "@ursalink-cloud/core-sdk/lib/util";
import { Device, Metric } from "@ursalink-cloud/core-sdk";
import _ from "lodash";
import { BasicDevice } from "@ursalink-cloud/core-sdk/lib/device";

export const LORA_REPORT_SERVICE = "lora-report-service";

@ExComponent(Device.LoRaDevice, LORA_REPORT_SERVICE)
export class LoRaDeviceReport {

	constructor(public device: Device.BasicDevice) {

	}

	public async handleReportData(payload: string) {
		const data = await this.decodePayload(payload);
		if (await this.handleConfig(data)) {
			await this.postHandleConfig();
		}
		if (await this.handleStatus(data)) {
			await this.postHandleStatus();
		}
	}

	protected async decodePayload(_payload: string): Promise<any> {
		// do nothing
	}

	protected async handleConfig(_data: any): Promise<boolean> {
		return false;
	}

	protected async handleStatus(_data: any): Promise<boolean> {
		console.warn("invalid device type!", this.device.data.sn);
		return false;
	}

	protected async postHandleConfig() {
		// const attributes = _.pick(this.device.data, [
		// 	"firmware",
		// 	"hardware",
		// 	"config",
		// 	"protocol",
		// 	"collectSettings",
		// ]);
		// DeviceUpdater.setAttributes(this.device.id, attributes);
		// DeviceDataPublisher.setAttributes(this.device.id, attributes);
	}

	protected async postHandleStatus() {
		this.triggerThresholdAlert(this.device);

		// const record = new Record.MetricRecordWriter(this.device.metrics())
		//     .setRecord({id: this.device.id, ts: now()})
		//     .write()
		//     .getRecord();
		// defer(DeviceRecordDAO.put(record));

		// const attributes = _.pick(this.device.data, [
		// 	"desired", "collects", "collectSettings", "alerts", "alertSettings",
		// 	"rssi", "snr", "lastSeen", "lastUpdated", "battery",
		// ]);
		// DeviceUpdater.setAttributes(this.device.id, attributes);
		// DeviceDataPublisher.setAttributes(this.device.id, attributes);
		// await this.triggerRules(this.device.data);
	}

	private triggerThresholdAlert(device: BasicDevice) {
		const metrics = device.metrics()
			.omit(Metric.OnlineMetric)
			.list()
			.filter(m => m.getAlerts()?.shouldNotify);

		// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
		const contents = metrics.map(m => m.getAlerts()!.text)
			.filter(v => !_.isEmpty(v));

		if (contents.length) {
			// 发送警报
			// defer(AlarmMessageService.notify({
			//     type: ALARM_EVENT.THRESHOLD,
			//     timestampInMs: Date.now(),
			//     data: {
			//         deviceData: device.data,
			//         contents,
			//     },
			// }));
			// 标记为已告警
			metrics.forEach(m => m.markAsNotified());
		}
	}
}

