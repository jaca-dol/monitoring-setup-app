/* eslint-disable @typescript-eslint/no-unused-vars */

import { LORA_REPORT_SERVICE } from "./LoRaDeviceReport";
import { ExComponent } from "@ursalink-cloud/core-sdk/lib/util";
import { Device, Metric } from "@ursalink-cloud/core-sdk";
import { UC11Report } from "./UC11Report";
import { Data } from "../types";

@ExComponent(Device.UC11N1Device, LORA_REPORT_SERVICE)
export class UC11N1Report extends UC11Report {

	protected getOffset(type: Metric.COLLECT_METRIC): number {
		switch (type) {
			case Metric.COLLECT_METRIC.GPIO:
				return 2;
			case Metric.COLLECT_METRIC.AI:
				return 4;
			case Metric.COLLECT_METRIC.CHN:
				return 6;
			default:
				return -65535;
		}
	}

	protected async handleStatus(data: Data): Promise<boolean> {
		if (!await super.handleStatus(data)) {
			return false;
		}
		this.device.metrics()
			.get(Metric.SENSOR_CHANNEL_TYPE.BATTERY)
			?.setValue(data[1]?.value);
		return true;
	}

}
