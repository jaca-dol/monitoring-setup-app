import _ from "lodash";
import { getModelBySN } from "@ursalink-cloud/core-sdk/lib/device";

import { LoRaDeviceReport } from "./LoRaDeviceReport";
import { Data, PayloadContext } from "../types";
import { convertBase64ToObject } from "../ipso-converter";


export function decodeIPSODataWithContext(raw: string, context: PayloadContext): Data {
	return convertBase64ToObject(raw, context);
}

export abstract class IpsoReport extends LoRaDeviceReport {

	protected async decodePayload(payload: string): Promise<Data> {
		return decodeIPSODataWithContext(payload, {
			firmware: this.device.data.firmware,
			hardware: this.device.data.hardware,
			model: getModelBySN(this.device.data.sn, true),
			sn: this.device.data.sn,
			version: this.device.data.protocol?.version,
		});
	}

	protected async handleConfig(data: Data): Promise<boolean> {
		const config = data.config;
		if (_.isEmpty(config)) {
			return false;
		}
		const deviceData = this.device.data;

		// 兼容过去添加的设备(没有config)
		if (!deviceData.config) {
			deviceData.config = {period: this.device.getReportPeriod()};
		}
		deviceData.config.interval = config.interval ?? deviceData.config.interval;
		deviceData.config.period = config.period || deviceData.config.period;
		deviceData.config.intelligenceReport = config.intelligenceReport ?? deviceData.config.intelligenceReport;
		if (config.loRaChanMask) {
			// do nothing
		}
		if (config.hardware) {
			deviceData.hardware = config.hardware;
		}
		if (config.firmware) {
			deviceData.firmware = config.firmware;
		}
		// 更新协议版本
		if (config.version) {
			deviceData.protocol = {...this.device.protocol().toJson(), version: config.version};
		}
		return true;
	}

}
