/* eslint-disable @typescript-eslint/no-unused-vars */
//@ts-nocheck
import { LORA_REPORT_SERVICE } from "./LoRaDeviceReport";
import { ExComponent } from "@ursalink-cloud/core-sdk/lib/util";
import { Device, Metric } from "@ursalink-cloud/core-sdk";
import { IpsoReport } from "./IpsoReport";
import { Data } from "../../../types/ucp/ug";
import _ from "lodash";

@ExComponent(Device.SensorDevice, LORA_REPORT_SERVICE)
export class SensorReport extends IpsoReport {

	protected async handleConfig(data: Data): Promise<boolean> {
		if (!await super.handleConfig(data)) {
			return false;
		}
		const config = data.config;
		if (_.isEmpty(config)) {
			return false;
		}
		// 处理通道启用禁用
		if (config.channelEnableConfigList) {
			config.channelEnableConfigList.forEach(({index, enabled}) => {
				this.device.metrics().get("ext" + index)?.applySettings({enabled});
			});
		}
		return true;
	}

	protected async handleStatus(data: Data): Promise<boolean> {
		this.device.metrics()
			.pick(Metric.SensorCollectMetric)
			.list()
			.forEach((m: Metric.SensorCollectMetric) => {
				const value = data[m.getSettings().channelId || -1]?.value;
				m.setValue(value);
			});

		this.device.metrics()
			.get(Metric.SENSOR_CHANNEL_TYPE.BATTERY)
			?.setValue(this.getBattery(data));

		this.device.metrics()
			.get(Metric.SENSOR_CHANNEL_TYPE.TEMPERATURE)
			?.setValue(data.config.alarm?.current);
		return true;
	}

	private getBattery(data: Data): number | undefined {
		const model = this.device.identifyModel().model;
		const batteryId = Device.getSensor(model)
			?.channels
			.find(c => c.type === Metric.SENSOR_CHANNEL_TYPE.BATTERY)
			?.channelId;
		return data[batteryId || -1]?.value;
	}

}
