/* eslint-disable no-mixed-spaces-and-tabs */
//@ts-nocheck
import { IpsoReport } from "./IpsoReport";
import { Data } from "../types";
import { Metric } from "@ursalink-cloud/core-sdk";
import _ from "lodash";
import { DIO_DATA_TYPE } from "@ursalink-cloud/core-sdk/lib/metric";

const DATA_TYPE_MAP: { [key: string]: DIO_DATA_TYPE } = {
	digitalInput: DIO_DATA_TYPE.DI,
	digitalOutput: DIO_DATA_TYPE.DO,
	counter: DIO_DATA_TYPE.COUNTER,
};

export abstract class UC11Report extends IpsoReport {

    protected abstract getOffset(type: Metric.COLLECT_METRIC): number;

    protected async handleConfig(data: Data): Promise<boolean> {
    	if(!await super.handleConfig(data)) {
    		return false;
    	}
    	const config = data.config;
    	if (_.isEmpty(config)) {
    		return false;
    	}
    	// 处理ai类型
    	if (config.conversion) {
    		config.conversion.forEach(({index, type}) => {
    			this.device.metrics().get("ain" + index)?.applySettings({
    				dataType: type === "V"
    					? Metric.AIN_DATA_TYPE.VOLTAGE
    					: Metric.AIN_DATA_TYPE.CURRENT,
    			});
    		});
    	}
    	return true;
    }

    protected async handleStatus(data: Data): Promise<boolean> {
    	this.device.metrics()
    		.pick(Metric.DioCollectMetric, Metric.AinCollectMetric)
    		.list()
    		.forEach((m: Metric.CollectMetric) => {
    			const v = data[m.index + this.getOffset(m.type)];
    			if (!v) {
    				return;
    			}
    			if (m instanceof Metric.DioCollectMetric) {
    				const dataType = DATA_TYPE_MAP[v.type];
    				m.applySettings({dataType});
    			}
    			m.setValue(v.value);
    		});
    	const type = Metric.COLLECT_METRIC.CHN;
    	const channels = data.config.channelData;
    	channels?.forEach(c => {
    		if (!c) {
    			return;
    		}
    		const metric = this.device.metrics()
    			.get(type + (c.channelId - this.getOffset(type)));
    		if (metric && !metric.removed()) {
    			metric.setValue({rawValue: c.value, rawHex: c.raw})
    				.applySettings({dataType: c.dataType});
    		}
    	});
    	const collectFailedIds = data.config.collectFailedChannelIds;
    	collectFailedIds?.forEach(id => {
    		this.device.metrics()
    			.get(type + (id - this.getOffset(type)))
    			?.setValue(null);
    	});
    	return true;
    }

}
