/* eslint-disable @typescript-eslint/no-unused-vars */
import { UC11Report } from "./UC11Report";
import { ExComponent } from "@ursalink-cloud/core-sdk/lib/util";
import { Device, Metric } from "@ursalink-cloud/core-sdk/lib";
import { LORA_REPORT_SERVICE } from "./LoRaDeviceReport";

@ExComponent(Device.UC1114Device, LORA_REPORT_SERVICE)
export class UC1114Report extends UC11Report {
	protected getOffset(type: Metric.COLLECT_METRIC): number {
		switch (type) {
			case Metric.COLLECT_METRIC.DI:
				return 0;
			case Metric.COLLECT_METRIC.DO:
				return 8;
			default:
				return -65535;
		}
	}
}
