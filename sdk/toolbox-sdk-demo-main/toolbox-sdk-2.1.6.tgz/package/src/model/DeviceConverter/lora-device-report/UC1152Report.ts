/* eslint-disable @typescript-eslint/no-unused-vars */
import { UC11Report } from "./UC11Report";
import { ExComponent } from "@ursalink-cloud/core-sdk/lib/util";
import { Device, Metric } from "@ursalink-cloud/core-sdk";
import { LORA_REPORT_SERVICE } from "./LoRaDeviceReport";

@ExComponent(Device.UC1152Device, LORA_REPORT_SERVICE)
export class UC1152Report extends UC11Report {
	protected getOffset(type: Metric.COLLECT_METRIC): number {
		switch (type) {
			case Metric.COLLECT_METRIC.DI:
				return 0;
			case Metric.COLLECT_METRIC.DO:
				return 8;
			case Metric.COLLECT_METRIC.CHN:
				return 24;
			default:
				return -65535;
		}
	}
}
