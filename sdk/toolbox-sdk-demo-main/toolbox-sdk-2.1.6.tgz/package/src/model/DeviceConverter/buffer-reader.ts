import { Buffer } from 'buffer';

export class BufferReader {
	constructor(buffer: Buffer) {
		this.buffer = buffer;
	}

	public byteAt(index: number) {
		return this.buffer[index];
	}

	public firstByte(): number {
		return this.buffer[0]!;
	}

	public getBuffer(): Buffer {
		return this.buffer;
	}

	public getOffset() {
		return this.offset;
	}

	public hasNextByte(): boolean {
		return this.buffer.length > this.offset;
	}

	public lastByte(): number {
		return this.buffer[this.buffer.length - 1]!;
	}

	public moveOffset(plus: number) {
		this.offset += plus;
	}

	public readBit(bits: number) {
		const result = [];
		const binary = this.buffer.readUInt8(this.offset);
		for (let idx = 0; idx < bits; idx++) {
			result[idx] = (binary >> idx) & 1;
		}
		this.offset += 1;
		return result;
	}

	public readBuffer(length: number) {
		const buffer = this.buffer.slice(this.offset, this.offset + length);
		this.offset += length;
		return buffer;
	}

	public readFloatLE() {
		const result = this.buffer.readFloatLE(this.offset);
		this.offset += 4;
		return result;
	}

	public readHex(length: number) {
		const hex = this.buffer
			.slice(this.offset, this.offset + length)
			.toString('hex');
		this.offset += length;
		return hex;
	}

	public readInt16LE() {
		const result = this.buffer.readInt16LE(this.offset);
		this.offset += 2;
		return result;
	}

	public readInt32LE() {
		const result = this.buffer.readInt32LE(this.offset);
		this.offset += 4;
		return result;
	}

	public readInt8() {
		const result = this.buffer.readInt8(this.offset);
		this.offset += 1;
		return result;
	}

	public readString(size: number) {
		const result = this.buffer.slice(this.offset, this.offset + size);
		this.offset += size;
		return result.toString().replace(/\0/g, '');
	}

	public readUInt16LE() {
		const result = this.buffer.readUInt16LE(this.offset);
		this.offset += 2;
		return result;
	}

	public readUInt32LE() {
		const result = this.buffer.readUInt32LE(this.offset);
		this.offset += 4;
		return result;
	}

	public readUInt8() {
		const result = this.buffer.readUInt8(this.offset);
		this.offset += 1;
		return result;
	}

	public setOffset(offset: number) {
		this.offset = offset;
	}

  private readonly buffer: Buffer;
  private offset = 0;
}
