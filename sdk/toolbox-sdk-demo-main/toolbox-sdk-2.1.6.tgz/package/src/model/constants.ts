import _ from 'lodash';

export enum FREQUENCY {
	EU868,
	US915,
	AU915,
	CN470,
	AS923,
	KR920,
	EU433 = 7,
	IN865,
	RU864,
	CN470_INTRA = 1,
	CN470_INTER = 2,
	//下面的几个比较特殊，没有对应的值(freqRegion)，而是用另一个字段channelPlan()
	//所以只是作为统一的标识符
	AS923_1 = 'AS923-1',
	AS923_2 = 'AS923-2',
	AS923_3 = 'AS923-3',
	AS923_4 = 'AS923-4',
}

export const SUPPORTED_FREQUENCY_OPTIONS = {
	1: [{ value: FREQUENCY.EU433, label: 'EU433' }],
	2: [{ value: FREQUENCY.CN470, label: 'CN470' }],
	3: [ { value: FREQUENCY.EU868, label: 'EU868' }, { value: FREQUENCY.IN865, label: 'IN865' }, { value: FREQUENCY.RU864, label: 'RU864' } ],
	4: [
		{ value: FREQUENCY.US915, label: 'US915' },
		{ value: FREQUENCY.AU915, label: 'AU915' },
		{ value: FREQUENCY.AS923, label: 'AS923' },
		{ value: FREQUENCY.KR920, label: 'KR920' }
	],
	5: [
		{ value: FREQUENCY.EU868, label: 'EU868' }, 
		{ value: FREQUENCY.IN865, label: 'IN865' }, 
		{ value: FREQUENCY.RU864, label: 'RU864' },
		{ value: FREQUENCY.US915, label: 'US915' },
		{ value: FREQUENCY.AU915, label: 'AU915' },
		{ value: FREQUENCY.AS923, label: 'AS923' },
		{ value: FREQUENCY.KR920, label: 'KR920' }
	],
};

export const ALL_FREQUENCY_OPTIONS = [
	{ value: FREQUENCY.EU868, label: 'EU868' },
	{ value: FREQUENCY.US915, label: 'US915' },
	{ value: FREQUENCY.AU915, label: 'AU915' },
	{ value: FREQUENCY.CN470, label: 'CN470' },
	{ value: FREQUENCY.AS923, label: 'AS923' },
	{ value: FREQUENCY.KR920, label: 'KR920' },
	{ value: FREQUENCY.EU433, label: 'EU433' },
	{ value: FREQUENCY.IN865, label: 'IN865' },
	{ value: FREQUENCY.RU864, label: 'RU864' }
];

export const FREQ_MODE_OPTIONS = [
	{ value: FREQUENCY.CN470_INTRA, label: 'CN470同频' },
	{ value: FREQUENCY.CN470_INTER, label: 'CN470异频' }
];

export const RX2_DATA_RATE_OPTIONS = {
	[FREQUENCY.EU868]: {
		default: 0,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.US915]: {
		default: 8,
		options: [
			{ value: 8,  label: 'DR8(SF12, 500 kHz)' },
			{ value: 9,  label: 'DR9(SF11, 500 kHz)' },
			{ value: 10, label: 'DR10(SF10, 500 kHz)' },
			{ value: 11, label: 'DR11(SF9, 500 kHz)' },
			{ value: 12, label: 'DR12(SF8, 500 kHz)' },
			{ value: 13, label: 'DR13(SF7, 500 kHz)' }
		]
	},
	[FREQUENCY.IN865]: {
		default: 2,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.AU915]: {
		default: 8,
		options: [
			{ value: 8, label: 'DR8(SF12,500KHz)' },
			{ value: 9, label: 'DR9(SF11,500KHz)' },
			{ value: 10, label: 'DR10(SF10,500KHz)' },
			{ value: 11, label: 'DR11(SF9,500KHz)' },
			{ value: 12, label: 'DR12(SF8,500KHz)' },
			{ value: 13, label: 'DR13(SF7,500KHz)' }
		]
	},
	[FREQUENCY.AS923]: {
		default: 2,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.AS923_1]: {
		default: 2,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.AS923_2]: {
		default: 2,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.AS923_3]: {
		default: 2,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.AS923_4]: {
		default: 2,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.KR920]: {
		default: 0,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	CN779: {
		default: 0,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.EU433]: {
		default: 0,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.CN470]: {
		default: 0,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	},
	[FREQUENCY.RU864]: {
		default: 0,
		options: [
			{ value: 0, label: 'DR0 (SF12, 125 kHz)' },
			{ value: 1, label: 'DR1 (SF11, 125 kHz)' },
			{ value: 2, label: 'DR2 (SF10, 125 kHz)' },
			{ value: 3, label: 'DR3 (SF9, 125 kHz)' },
			{ value: 4, label: 'DR4 (SF8, 125 kHz)' },
			{ value: 5, label: 'DR5 (SF7, 125 kHz)' }
		]
	}
};

export const RX2_FREQ_DEFAULT = {
	[FREQUENCY.AS923]: 923200000,
	[FREQUENCY.AU915]: 923300000,
	[FREQUENCY.CN470]: 505300000,
	[FREQUENCY.EU433]: 434665000,
	[FREQUENCY.EU868]: 869525000,
	[FREQUENCY.IN865]: 866550000,
	[FREQUENCY.KR920]: 921900000,
	[FREQUENCY.RU864]: 869100000,
	[FREQUENCY.US915]: 923300000,
	[FREQUENCY.AS923_1]: 923200000,
	[FREQUENCY.AS923_2]: 921400000,
	[FREQUENCY.AS923_3]: 916600000,
	[FREQUENCY.AS923_4]: 917300000,
	'CN779': 786000000
};

const FREQUENCY_FACTOR = Math.pow(10, 6);

export const RX2_FREQUENCY_LIMIT = {
	[FREQUENCY.AS923]: {
		min: 915.0 * FREQUENCY_FACTOR,
		max: 928.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.AS923_1]: {
		min: 915.0 * FREQUENCY_FACTOR,
		max: 928.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.AS923_2]: {
		min: 915.0 * FREQUENCY_FACTOR,
		max: 928.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.AS923_3]: {
		min: 915.0 * FREQUENCY_FACTOR,
		max: 928.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.AS923_4]: {
		min: 917.0 * FREQUENCY_FACTOR,
		max: 920.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.KR920]: {
		min: 920.9 * FREQUENCY_FACTOR,
		max: 923.3 * FREQUENCY_FACTOR
	},
	[FREQUENCY.AU915]: {
		min: 923.3 * FREQUENCY_FACTOR,
		max: 927.5 * FREQUENCY_FACTOR
	},
	[FREQUENCY.US915]: {
		min: 923.3 * FREQUENCY_FACTOR,
		max: 927.5 * FREQUENCY_FACTOR
	},
	[FREQUENCY.EU868]: {
		min: 863.0 * FREQUENCY_FACTOR,
		max: 870.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.IN865]: {
		min: 865.0 * FREQUENCY_FACTOR,
		max: 867.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.RU864]: {
		min: 864.0 * FREQUENCY_FACTOR,
		max: 870.0 * FREQUENCY_FACTOR
	},
	[FREQUENCY.CN470]: {
		min: 500.3 * FREQUENCY_FACTOR,
		max: 509.7 * FREQUENCY_FACTOR
	},
	[FREQUENCY.EU433]: {
		min: 433.175 * FREQUENCY_FACTOR,
		max: 434.665 * FREQUENCY_FACTOR
	}
};

//Action Types
export const SET_RAW_DATA = 'SET_RAW_DATA';

export const SET_DEVICE_INFO = 'SET_DEVICE_INFO';

export const SET_PRE_DEVICE_INFO = 'SET_PRE_DEVICE_INFO';

export const SET_SETTING_MODE = 'SET_SETTING_MODE';

export const PRIVATE_KEYS = [ 'applicationKey', 'networkSessionKey', 'applicationSessionKey', 'multicast' ];

export const SET_DS_TEMP = 'SET_DS_TEMP';

export const SET_SDI_DATA = 'SET_SDI_DATA';

export const UPDATE_DEVICE_INFO = 'UPDATE_DEVICE_INFO';

/**
 * 设备型号
 */
export enum MODELS {
	/**
	 * 未知设备
	 */
	UNKNOWN = "-",

	//EM500（室外环境监测）系列
	
	/**
	 * 检测参数：PAR值
	 */
	"EM500-PAR" = "EM500-PAR",
	"EM500_PAR" = "EM500-PAR",

	/**
	 * 仅做旧版本兼容
	 */
	"EM500-PM25" = "EM500-PM25",
	"EM500_PM25" = "EM500-PM25",

	/**
	 * 监测CO2浓度、TVOC、大气压、温湿度
	 */
	"EM500-CO2" = "EM500-CO2",
	"EM500_CO2" = "EM500-CO2",

	/**
	 * 光照传感器
	 */
	"EM500-LGT" = "EM500-LGT",
	"EM500_LGT" = "EM500-LGT",

	/**
	 * 检测参数：土壤湿度
	 */
	"EM500-SMT-EC5" = "EM500-SMT-EC5",
	"EM500_SMT_EC5" = "EM500-SMT-EC5",

	/**
	 * 检测参数：电导率、温湿度
	 */
	"EM500-SMTC-MEC20" = "EM500-SMTC-MEC20",
	"EM500_SMTC_MEC20" = "EM500-SMTC-MEC20",

	/**
	 * 检测参数：土壤湿度
	 */
	"EM500-SMT-MT10" = "EM500-SMT-MT10",
	"EM500_SMT_MT10" = "EM500-SMT-MT10",

	/**
	 * 检测参数：土壤湿度
	 */
	"EM500-SMT-MT05" = "EM500-SMT-MT05",
	"EM500_SMT_MT05" = "EM500-SMT-MT05",

	/**
 	* 检测温度 
 	*/
	"EM500-PT100-T050" = "EM500-PT100-T050",
	"EM500_PT100_T050" = "EM500-PT100-T050",

	"EM500-PT100-T200" = "EM500-PT100-T200", 
	"EM500_PT100_T200" = "EM500-PT100-T200", 

	"EM500-PT100-T500" = "EM500-PT100-T500",
	"EM500_PT100_T500" = "EM500-PT100-T500",

	"EM500-PT100-T800" = "EM500-PT100-T800",
	"EM500_PT100_T800" = "EM500-PT100-T800",

	/**
	 * 超声波检测距离/高度 Wxxx表明可测量的最大距离
	 */
	"EM500-UDL-W050" = "EM500-UDL-W050",
	"EM500_UDL_W050" = "EM500-UDL-W050",

	/**
	 * 超声波检测距离/高度 Wxxx表明可测量的最大距离
	 */
	"EM500-UDL-W100" = "EM500-UDL-W100",
	"EM500_UDL_W100" = "EM500-UDL-W100",

	/**
	 * 超声波检测距离/高度 Wxxx表明可测量的最大距离
	 */
	"EM500-UDL-S050" = "EM500-UDL-S050",
	"EM500_UDL_S050" = "EM500-UDL-S050",

	/**
	 * 超声波检测距离/高度 Wxxx表明可测量的最大距离
	 */
	"EM500-UDL-S100" = "EM500-UDL-S100",
	"EM500_UDL_S100" = "EM500-UDL-S100",

	//精度较差，不导入生产
	"EM500-UDL-C020" = "EM500-UDL-C020",
	"EM500_UDL_C020" = "EM500-UDL-C020",

	"EM500-UDL-C050" = "EM500-UDL-C050",
	"EM500_UDL_C050" = "EM500-UDL-C050",

	"EM500-UDL-C100" = "EM500-UDL-C100",
	"EM500_UDL_C100" = "EM500-UDL-C100",

	/**
	 * 投入式检测水位 Lxxx表明测量的最大距离
	 */
	"EM500-SWL-L003" = "EM500-SWL-L003",
	"EM500_SWL_L003" = "EM500-SWL-L003",

	"EM500-SWL-L005" = "EM500-SWL-L005",
	"EM500_SWL_L005" = "EM500-SWL-L005",

	"EM500-SWL-L010" = "EM500-SWL-L010",
	"EM500_SWL_L010" = "EM500-SWL-L010",

	"EM500-SWL-L050" = "EM500-SWL-L050",
	"EM500_SWL_L050" = "EM500-SWL-L050",

	"EM500-SWL-KZ" = "EM500-SWL-KZ",
	"EM500_SWL_KZ" = "EM500-SWL-KZ",

	"EM500-PP-KZ" = "EM500-PP-KZ",
	"EM500_PP_KZ" = "EM500-PP-KZ",

	/**
	 * 测管道内压力（水压/液压/油压/气压）
	 */
	"EM500-PP-G1/2M-P300" = "EM500-PP-G1/2M-P300",
	"EM500_PP_G1_2M_P300" = "EM500-PP-G1/2M-P300",

	/**
	 * 测管道内压力（水压/液压/油压/气压）
	 */
	"EM500-PP-G1/2M-1002" = "EM500-PP-G1/2M-1002",
	"EM500_PP_G1_2M_1002" = "EM500-PP-G1/2M-1002",

	/**
	 * 测管道内压力（水压/液压/油压/气压）
	 */
	"EM500-PP-G1/2M-4780" = "EM500-PP-G1/2M-4780",
	"EM500_PP_G1_2M_4780" = "EM500-PP-G1/2M-4780",

	"EM500-PP-G1/2M-4842" = "EM500-PP-G1/2M-4842",
	"EM500_PP_G1_2M_4842" = "EM500-PP-G1/2M-4842",

	/**
	 * 电化学系列，监测一氧化碳
	 */
	"EM500-CO" = "EM500-CO",
	"EM500_CO" = "EM500-CO",

	/**
	 * 电化学系列，硫化氢
	 */
	"EM500-H2S" = "EM500-H2S",
	"EM500_H2S" = "EM500-H2S",

	/**
	 * 电化学，氨气
	 */
	"EM500-NH3" = "EM500-NH3",
	"EM500_NH3" = "EM500-NH3",

	/**
	 * 室内环境监测、监测温度、湿度
	 */
	"AM102" = "AM102",

	/**
	 * 室内环境监测、监测温度、湿度，没有屏幕
	 */
	"AM102L" = "AM102L",

	/**
	 * 室内环境监测、监测温度、湿度、CO2
	 */
	"AM103" = "AM103",

	/**
	 * 室内环境监测、监测温度、湿度、CO2，没有屏幕
	 */
	"AM103L" = "AM103L",

	/**
	 * 室内环境监测，监测温度、湿度、PIR、光照
	 */
	"AM104" =  "AM104",
	
	/**
	 * 室内环境监测，温度、湿度、PIR、光照、CO2、TVOC、大气压
	 */
	"AM107" = "AM107",

	/**
	 * 室内环境监测，温度、湿度、光照、PIR
	 */
	"AM304L" = "AM304L",

	/**
	 * 室内环境监测，温度、湿度、光照、PIR、CO2
	 */
	"AM305L" = "AM305L",
	
	/**
	 * 室内环境传感器：温度、湿度、CO2、PIR、TVOC、光照、大气压、电池电量
	 */
	"AM307" = "AM307",
	"AM307L" = "AM307L",

	/**
	 * 室内环境传感器: 温度、湿度、PIR、光照等级、CO2浓度、大气压、PM2.5、PM10
	 */
	"AM308" = "AM308",
	"AM308L" = "AM308L",

	/**
	 * 室内环境传感器：温度、湿度、CO2、PIR、TVOC、光照、大气压、甲醛、PM2.5、PM10
	 */
	"AM319-HCHO" = "AM319-HCHO",
	"AM319_HCHO" = "AM319-HCHO",
	"AM319-HCHO-IR" = "AM319-HCHO-IR",
	"AM319_HCHO_IR" = "AM319-HCHO-IR",

	"AM319L-HCHO-IR" = "AM319L-HCHO-IR",
	"AM319L_HCHO_IR" = "AM319L-HCHO-IR",

    "AM319-HCHO-IR-W" = "AM319-HCHO-IR-W",
    "AM319_HCHO_IR_W" = "AM319-HCHO-IR-W",

	/**
	 * 室内环境传感器：温度、湿度、CO2、PIR、TVOC、光照、大气压、臭氧、PM2.5、PM10
	 */
	"AM319-O3" = "AM319-O3",
	"AM319_O3" = "AM319-O3",

	"AM319L-O3" = "AM319L-O3",
	"AM319L_O3" = "AM319L-O3",

	/**
	 * 监测温湿度
	 */
	"EM300-TH" = "EM300-TH",
	"EM300_TH" = "EM300-TH",

	"EM300-TH-N00CN" = "EM300-TH-N00CN",
	"EM300_TH_N00CN" = "EM300-TH-N00CN",

	/**
	 * 监测温湿度、水浸
	 */
	"EM300-WL" = "EM300-WL",
	"EM300_WL" = "EM300-WL",

	/**
	 * 区域漏水检测，即绳式
	 */
	"EM300-ZLD" = "EM300-ZLD",
	"EM300_ZLD" = "EM300-ZLD",

	"EM300-ZLD-N00CN" = "EM300-ZLD-N00CN",
	"EM300_ZLD_N00CN" = "EM300-ZLD-N00CN",

	/**
	 * 点式漏水检测，定位式
	 */
	"EM300-SLD" = "EM300-SLD",
	"EM300_SLD" = "EM300-SLD",

	/**
	 * NB版本
	 */
	"EM300-SLD-N00CN" = "EM300-SLD-N00CN",
	"EM300_SLD_N00CN" = "EM300-SLD-N00CN",

	/**
	 * 监测温湿度、门磁
	 */
	"EM300-MCS" = "EM300-MCS",
	"EM300_MCS" = "EM300-MCS",

	/**
	 * NB版本
	 */
	"EM300-MCS-N00CN" = "EM300-MCS-N00CN",
	"EM300_MCS_N00CN" = "EM300-MCS-N00CN",

	/**
	 * 声屏障监测
	 */
	"EM300-SW" = "EM300-SW",
	"EM300_SW" = "EM300-SW",

	"EM300-SW-N00CN" = "EM300-SW-N00CN",
	"EM300_SW_N00CN" = "EM300-SW-N00CN",

	/**
	 * 脉冲计数器
	 */
	"EM300_DI" = "EM300-DI",
	"EM300-DI" = "EM300-DI",
	"EM300_DI_HALL" = "EM300-DI-HALL",
	"EM300-DI-HALL" = "EM300-DI-HALL",

	/**
	 * 电容式液位传感器
	 */
	"EM300_CL" = "EM300-CL",
	"EM300-CL" = "EM300-CL",

	/**
	 * 贴片式水浸传感器
	 */
	"EM300_MLD" = "EM300-MLD",
	"EM300-MLD" = "EM300-MLD",

	/**
	 * 超声波测距传感器
	 */
	"EM310-UDL" = "EM310-UDL",
	"EM310_UDL" = "EM310-UDL",

	/**
	 * 倾斜传感器
	 */
	"EM310-TILT" = "EM310-TILT",
	"EM310_TILT" = "EM310-TILT",

	"EM320-TILT" = "EM320-TILT",
	"EM320_TILT" = "EM320-TILT",

	/**
	 * 温度传感器
	 */
	"EM320-TH" = "EM320-TH",
	"EM320_TH" = "EM320-TH",

	/**
	 * ToF激光测距传感器
	 */
	"EM400-TLD" = "EM400-TLD",
	"EM400_TLD" = "EM400-TLD",

	"EM400-TLD-N03GL" = "EM400-TLD-N03GL",
	"EM400_TLD_N03GL" = "EM400-TLD-N03GL",

	/**
	 * 多功能超声波测距传感器
	 */
	"EM400-MUD-B045" = "EM400-MUD-B045",
	"EM400_MUD_B045" = "EM400-MUD-B045",

	"EM400-MUD-N03GL" = "EM400-MUD-N03GL",
	"EM400_MUD_N03GL" = "EM400-MUD-N03GL",
	
	/**
	 * 超声波测距传感器
	 */
	"EM400-UDL-C050" = "EM400-UDL-C050",
	"EM400_UDL_C050" = "EM400-UDL-C050",

	"EM400-UDL-C100" = "EM400-UDL-C100",
	"EM400_UDL_C100" = "EM400-UDL-C100",

	"EM400-UDL-W050" = "EM400-UDL-W050",
	"EM400_UDL_W050" = "EM400-UDL-W050",

	"EM400-UDL-W100" = "EM400-UDL-W100",
	"EM400_UDL_W100" = "EM400-UDL-W100",

	"EM400-UDL-S050" = "EM400-UDL-S050",
	"EM400_UDL_S050" = "EM400-UDL-S050",

	"EM400-UDL-C050-N03GL" = "EM400-UDL-C050-N03GL",
	"EM400_UDL_C050_N03GL" = "EM400-UDL-C050-N03GL",

	"EM400-UDL-C100-N03GL" = "EM400-UDL-C100-N03GL",
	"EM400_UDL_C100_N03GL" = "EM400-UDL-C100-N03GL",

	"EM400-UDL-W050-N03GL" = "EM400-UDL-W050-N03GL",
	"EM400_UDL_W050_N03GL" = "EM400-UDL-W050-N03GL",

	"EM400-UDL-W100-N03GL" = "EM400-UDL-W100-N03GL",
	"EM400_UDL_W100_N03GL" = "EM400-UDL-W100-N03GL",

	"EM400-UDL-S050-N03GL" = "EM400-UDL-S050-N03GL",
	"EM400_UDL_S050_N03GL" = "EM400-UDL-S050-N03GL",

	/**
	 * 雷达测距传感器
	 */
	"EM410_RDL" = "EM410-RDL",
	"EM410-RDL" = "EM410-RDL",
	/**
	 * 雷达测距传感器Cat版本
	 */
	"EM410_RDL_L0CEU" = "EM410-RDL-L0CEU",
	"EM410-RDL-L0CEU" = "EM410-RDL-L0CEU",

	/**
	 * 防爆版本的雷达测距传感器(功能同EM410-RDL)
	 */
	"EM411_RDL" = "EM411-RDL",
	"EM411-RDL" = "EM411-RDL",

	/**
	 * N1升级版、可充电版
	 */
	"UC501" = "UC501",

	/**
	 * N1升级版、不可充电版
	 */
	"UC502" = "UC502",

	"UC50X" = "UC50X",

	/**
	 * UC50XNB版本
	 */
	"UC501-N03GL" = "UC501-N03GL",
	"UC501_N03GL" = "UC501-N03GL",

	"UC501NB" = "UC501NB",

	"UC501-L0ACN" = "UC501-L0ACN",
	"UC501_L0ACN" = "UC501-L0ACN",

	"UC501-N04GL" = "UC501-N04GL",
	"UC501_N04GL" = "UC501-N04GL",

	"UC502-N03GL" = "UC502-N03GL",
	"UC502_N03GL" = "UC502-N03GL",

	"UC502-L0ACN" = "UC502-L0ACN",
	"UC502_L0ACN" = "UC502-L0ACN",

	"UC502-N04GL" = "UC502-N04GL",
	"UC502_N04GL" = "UC502-N04GL",

	/**
	 * UC50XCAT1
	 */
	'UC501-L0CEU' = 'UC501-L0CEU',
	'UC501_L0CEU' = 'UC501-L0CEU',

	'UC502-L0CEU' = 'UC502-L0CEU',
	'UC502_L0CEU' = 'UC502-L0CEU',

	/**
	 * 电磁阀可充电
	 */
	"UC511" = "UC511",

	/**
	 * 电磁阀带水表
	 */
	"UC511-DI" = "UC511-DI",
	"UC511_DI" = "UC511-DI",

	/**
	 * UC511-DI-L0ACN
	 */
	"UC511-DI-L0ACN" = "UC511-DI-L0ACN",
	"UC511_DI_L0ACN" = "UC511-DI-L0ACN",

	"UC521" = "UC521",
	"UC521-L0ACN" = "UC521-L0ACN",
	"UC521_L0ACN" = "UC521-L0ACN",
	
	/**
	 * 电磁阀不可充电
	 */
	"UC512" = "UC512",

	/**
	 * 电磁阀带水表
	 */
	"UC512-DI" = "UC512-DI",
	"UC512_DI" = "UC512-DI",

	/**
	 * SOS一键报警(智能按键)
	 */
	"WS101" = "WS101",

	/**
	 * 智能余量检测传感器
	 */
	"WS201" = "WS201",

	/**
	 * PIR & 光照传感器
	 */
	"WS202" = "WS202",

	/**
	 * PIR & 温湿度传感器
	 */
	"WS203" = "WS203",

	/**
	 * 无线门磁
	 */
	"WS301" = "WS301",

	/**
	 * 噪声传感器
	 */
	"WS302" = "WS302",

	/**
	 * 智能水浸传感器
	 */
	"WS303" = "WS303",

	/**
	 * 开关面板（国内触控式单火，无电参）
	 * @url https://doc.weixin.qq.com/doc/w3_AaQA1QY0AJkmfzrc3DLQJSAHNVl9X?scode=AMgAYAe8AAYwS5yZ0sAaQA1QY0AJk
	 */

	"WS501-2W" = "WS501-2W",
	"WS501_2W" = "WS501-2W",

	"WS502-2W" = "WS502-2W",
	"WS502_2W" = "WS502-2W",

	"WS503-2W" = "WS503-2W",
	"WS503_2W" = "WS503-2W",

	/**
	 * 开关面板（国内触控式零火，无电参）
	 */

	"WS501-3W" = "WS501-3W",
	"WS501_3W" = "WS501-3W",

	"WS502-3W" = "WS502-3W",
	"WS502_3W" = "WS502-3W",

	"WS503-3W" = "WS503-3W",
	"WS503_3W" = "WS503-3W",

	/**
	 * 开关面板（海外机械式零火，支持电参）
	 */
	"WS501EU" = "WS501EU",
	"WS501EU-3W" = "WS501EU-3W",
	"WS501EU_3W" = "WS501EU-3W",

	"WS502EU" = "WS502EU",
	"WS502EU-3W" = "WS502EU-3W",
	"WS502EU_3W" = "WS502EU-3W",

	"WS503EU" = "WS503EU",
	"WS503EU-3W" = "WS503EU-3W",
	"WS503EU_3W" = "WS503EU-3W",

	"WS501US" = "WS501US",
	"WS501US-3W" = "WS501US-3W",
	"WS501US_3W" = "WS501US-3W",
	
	"WS502US" = "WS502US",
	"WS502US-3W" = "WS502US-3W",
	"WS502US_3W" = "WS502US-3W",

	"WS503US" = "WS503US",
	"WS503US-3W" = "WS503US-3W",
	"WS503US_3W" = "WS503US-3W",

	/**
	 * 开关面板（国内机械式单火，无电参）
	 */
	"WS501EUD" = "WS501EUD",
	"WS501EUD-2W" = "WS501EUD-2W",
	"WS501EUD_2W" = "WS501EUD-2W",

	"WS502EUD" = "WS502EUD",
	"WS502EUD-2W" = "WS502EUD-2W",
	"WS502EUD_2W" = "WS502EUD-2W",

	"WS503EUD" = "WS503EUD",
	"WS503EUD-2W" = "WS503EUD-2W",
	"WS503EUD_2W" = "WS503EUD-2W",

	/**
	 * 开关面板（国内微动）
	 */
	"WS501W-2W" = "WS501W-2W",
	"WS501W_2W" = "WS501W-2W",
	"WS502W-2W" = "WS502W-2W",
	"WS502W_2W" = "WS502W-2W",
	"WS503W-2W" = "WS503W-2W",
	"WS503W_2W" = "WS503W-2W",
	
	"WS501W-3W" = "WS501W-3W",
	"WS501W_3W" = "WS501W-3W",
	"WS502W-3W" = "WS502W-3W",
	"WS502W_3W" = "WS502W-3W",
	"WS503W-3W" = "WS503W-3W",
	"WS503W_3W" = "WS503W-3W",

	/**
	 * 智能插座面板 
	 */
	"WS513" = "WS513",

	"WS515" = "WS515",

	"WS516" = "WS516",

	/**
	 * 智能插座
	 */
	"WS525" = "WS525",
	
	"WS525-10A-CN" = "WS525-10A-CN",
	"WS525_10A_CN" = "WS525-10A-CN",

	"WS525-10A-AU" = "WS525-10A-AU",
	"WS525_10A_AU" = "WS525-10A-AU",
	
	"WS525-10A-US" = "WS525-10A-US",
	"WS525_10A_US" = "WS525-10A-US",

	"WS522-10A-EU" = "WS522-10A-EU",
	"WS522_10A_EU" = "WS522-10A-EU",

	"WS523-13A-UK" = "WS523-13A-UK",
	"WS523_13A_UK" = "WS523-13A-UK",

	"WS523-15A-US" = "WS523-15A-US",
	"WS523_15A_US" = "WS523-15A-US",

	"WS523-16A-CN" = "WS523-16A-CN",
	"WS523_16A_CN" = "WS523-16A-CN",

	"WS523-16A-EU" = "WS523-16A-EU",
	"WS523_16A_EU" = "WS523-16A-EU",

	"WS523-16A-FR" = "WS523-16A-FR",
	"WS523_16A_FR" = "WS523-16A-FR",

	"WS525-16A-EU" = "WS525-16A-EU",
	"WS525_16A_EU" = "WS525-16A-EU",

	/**
	 * 智能灯光控制
	 */
	"WS558" = "WS558",

	/**
	 * 智能情景面板(无电子水墨屏)
	 */
	"WS136" = "WS136",

	/**
	 * 智能情景面板
	 */
	"WS156" = "WS156",

	/**
	 * 家用可燃气体检测
	 */
	"JT-GS101" = "JT-GS101", //甲烷
	"JT_GS101" = "JT-GS101",

	/**
	 * 卫生间异味传感器
	 */
	"GS301" = "GS301",

	/**
	 * 气象站系列
	 */
	"WTS-305" = "WTS-305",
	"WTS_305" = "WTS-305",
	"WTS-505" = "WTS-505",
	"WTS_505" = "WTS-505",
	"WTS-506" = "WTS-506",
	"WTS_506" = "WTS-506",

	/**
	 * 卫生间占用传感器
	 */
	"VS330" = "VS330",

	/**
	 * 工位占用传感器
	 */
	"VS340" = "VS340",
	"VS341" = "VS341",

	/**
	 * 过道人数统计传感器
	 */
	"VS350" = "VS350",
	"VS351" = "VS351",
	"VS360" = "VS360",

	/**
	 * 雷达人在传感器
	 */
	"VS370" = "VS370",

	/**
	 * VA05-T UWB标签
	 */
	"VA05-T" = "VA05-T",
	"VA05_T" = "VA05-T",

	/**
	 * 智慧墨水屏幕(工位)
	 */
	"DS3604" = "DS3604",

	/**
	 * 现场配置工具
	 */
	'SCT01' = 'SCT01',

	/**
	 * 插针式温度传感器
	 */
	'TS101' = 'TS101',

	/**
	 * 廉价版温度传感器
	 */
	'TS201' = 'TS201',

	/**
	 * 温度/门磁传感器（插针式）
	 * 温度+门磁/温度+温度/门磁+门磁传感器（插针式）
	 */
	'TS301' = 'TS301',
	'TS302' = 'TS302',

	/**
	 * TS601（无屏幕无外置探针款，L0DEU：欧版标准版）
	 */
	'TS601-L0DEU' = 'TS601-L0DEU',
	'TS601_L0DEU' = 'TS601-L0DEU',

	/**
	 * TS602（有屏幕有外置探针款，L0DEU：欧版标准版）
	 */
	'TS602-L0DEU' = 'TS602-L0DEU',
	'TS602_L0DEU' = 'TS602-L0DEU',

	/**
	 * TS601（L0FNA：美版标准版）
	 */
	'TS601-L0FNA' = 'TS601-L0FNA',
	'TS601_L0FNA' = 'TS601-L0FNA',
	
	/**
	 * TS602（L0FNA：美版标准版）
	 */
	'TS602-L0FNA' = 'TS602-L0FNA',
	'TS602_L0FNA' = 'TS602-L0FNA',

	/**
	 * TS601（L0DLA：拉美标准版）
	 */
	'TS601-L0DLA' = 'TS601-L0DLA',
	'TS601_L0DLA' = 'TS601-L0DLA',

	/**
	 * TS602（L0DLA：拉美标准版）
	 */
	'TS602-L0DLA' = 'TS602-L0DLA',
	'TS602_L0DLA' = 'TS602-L0DLA',

	/** 定位传感器 */
	"AT101" = "AT101",

	/**
	 * 智能暖气温控阀
	 */
	"WT101" = "WT101",
	"WT102" = "WT102",

	/** 
		* 恒温器
	 */
	"WT201" = "WT201",
	"WT211" = "WT211",

    /** 
		* 恒温器
	 */
	"WT401" = "WT401",

	/**
	 * 智能风机盘管温控器
	 */
	"WT303" = "WT303",

	/**
	 * 智能风机盘管温控器
	 */
	"WT304" = "WT304",

	/**
	 * 智能风机盘管温控器(中文版)
	 */
	"WT303-ZH" = "WT303-ZH",
	"WT303_ZH" = "WT303-ZH",

	/**
	 * 智能风机盘管温控器（中文版）
	 */
	"WT304-ZH" = "WT304-ZH",
	"WT304_ZH" = "WT304-ZH",
	/**
	 * 电子烟探测器
	 */
	"GS601" = "GS601",

	/**
	 * UC711
	 */
	'UC711' = 'UC711',

    /**
	 * 电子烟探测器
	 */
	"VS321" = "VS321",

	/**
	 * 智能电力监测终端
	 */
	"CTH01" = "CTH01",
}

/**
 * 设备型号系列：比如AM104、EM500-SWL
 */
export enum MODEL_SERIES {
	"AM102" = "AM102",
	"AM103" = "AM103",
	'AM104' = 'AM104',
	'AM107' = 'AM107',
	'AM300' = 'AM300',
	'AM319' = 'AM319',
	'UC500' = 'UC500',

	'TS30X' = 'TS30X',
	'UC500NB' = 'UC500NB',
	"UC50XCAT1" = "UC50XCAT1",

	'UC51X' = 'UC51X',
	'UC51X-CAT' = 'UC51X-CAT',

	'UC521' = 'UC521',

	'EM500-CO2' = 'EM500-CO2',
	'EM500_CO2' = 'EM500-CO2',

	'EM500-PAR' = 'EM500-PAR',
	'EM500_PAR' = 'EM500-PAR',

	'EM500-LGT' = 'EM500-LGT',
	'EM500_LGT' = 'EM500-LGT',

	'EM500-PT100' = 'EM500-PT100',
	'EM500_PT100' = 'EM500-PT100',

	'EM500-SMT' = 'EM500-SMT',
	'EM500_SMT' = 'EM500-SMT',

	'EM500-SMTC' = 'EM500-SMTC',
	'EM500_SMTC' = 'EM500-SMTC',

	'EM500-SWL' = 'EM500-SWL',
	'EM500_SWL' = 'EM500-SWL',

	'EM500-UDL' = 'EM500-UDL',
	'EM500_UDL' = 'EM500-UDL',

	'EM500-PP' = 'EM500-PP',
	'EM500_PP' = 'EM500-PP',

	"EM500-CO" = "EM500-CO",
	"EM500_CO" = "EM500-CO",

	"EM500-H2S" = "EM500-H2S",
	"EM500_H2S" = "EM500-H2S",

	"EM500-NH3" = "EM500-NH3",
	"EM500_NH3" = "EM500-NH3",

	"EM300-TH" = "EM300-TH",
	"EM300_TH" = "EM300-TH",

	"EM300-DI" = "EM300-DI",
	"EM300_DI" = "EM300-DI",

	"EM300-WL" = "EM300-WL",
	"EM300_WL" = "EM300-WL",

	"EM300-MCS" = "EM300-MCS",
	"EM300_MCS" = "EM300-MCS",

	"EM300-ZLD" = "EM300-ZLD",
	"EM300_ZLD" = "EM300-ZLD",

	"EM300-SLD" = "EM300-SLD",
	"EM300_SLD" = "EM300-SLD",

	"EM300-SW" = "EM300-SW",
	"EM300_SW" = "EM300-SW",

	"EM300-MLD" = "EM300-MLD",
	"EM300_MLD" = "EM300-MLD",

	"EM300-CL" = "EM300-CL",
	"EM300_CL" = "EM300-CL",

	"EM310-UDL" = "EM310-UDL",
	"EM310_UDL" = "EM310-UDL",

	"EM310-TILT" = "EM310-TILT",
	"EM310_TILT" = "EM310-TILT",

	"EM320-TH" = "EM320-TH",
	"EM320_TH" = "EM320-TH",

	"EM320-TILT" = "EM320-TILT",
	"EM320_TILT" = "EM320-TILT",

	"EM400-TLD" = "EM400-TLD",
	"EM400_TLD" = "EM400-TLD",

	"EM400-UDL" = "EM400-UDL",
	"EM400_UDL" = "EM400-UDL",

	"EM410-RDL" = "EM410-RDL",
	"EM410_RDL" = "EM410-RDL",

	"EM411-RDL" = "EM411-RDL",
	"EM411_RDL" = "EM411-RDL",

	"EM410_RDL_L0CEU" = "EM410-RDL-L0CEU",
	"EM410-RDL-L0CEU" = "EM410-RDL-L0CEU",

	"WS100" = "WS100",

	"WS130" = "WS130",

	"WS150" = "WS150",

	"WS200" = "WS200",

	"WS300" = "WS300",

	"WS500" = "WS500",

	
	/**
	 * WS50X机械式系列（包括国内和海外版本）
	 */
	"WS50X-MECH" = "WS50X-MECH",
	"WS50X_MECH" = "WS50X-MECH",

	"WS51X" = "WS51X",

	"WS520" = "WS520",

	"WS550" = "WS550",

	"JX" = "JX",

	"WTS" = "WTS",

	"GS30X" = "GS30X",

	"VS" = "VS",

	"AT" = "AT",

	/**
	 * 墨水屏系列
	 */
	"DS" = "DS",

	"TS" = "TS",

	"TS60X" = "TS60X",

	"SCT01" = "SCT01",

	"WT101" = "WT101",
	"WT102" = "WT102",

	"WT" = "WT",

	"WT2X1" = "WT2X1",

    "WT401" = "WT401",
	/**
	 * UC711 系列
	 */
	"UC711" = "UC711",

	/**
	 * VA05 系列
	 */
	"VA05" = "VA05",

	"WT30X" = "WT30X",

	"WS50XW" = "WS50XW",

	// 智能电力监测终端
	"CTH01" = "CTH01",
}

/**
 * 传感器
 */
export enum SENSORS {
	/**
	 * 温度
	 */
	temperature = 'temperature',
	temperature_ch1 = 'temperature_ch1',
	temperature_ch2 = 'temperature_ch2',
	/**
	 * 湿度
	 */
	humidity = 'humidity',
	humidity_ch1 = 'humidity_ch1',
	humidity_ch2 = 'humidity_ch2',

	/**
	 * 活跃度（PIR）
	 */
	activity = 'activity',

	/**
	 * 光照强度
	 */
	illumination = 'illumination',

	/**
	 * 二氧化碳浓度
	 */
	co2concentration = 'co2concentration',

	/**
	 * TVOC
	 */
	tvoc = 'tvoc',

	/**
	 * 累积雨量
	 */
	rainfall = 'rainfall',

	/**
	 * 风速
	 */
	windSpeed = 'windSpeed',

	/**
	 * 气压
	 */
	atmosphericpressure = 'atmosphericpressure',
	'atmospheric Pressure' = 'atmospheric Pressure',

	/**
	 * 土壤湿度
	 */
	soilmoisture = 'soilmoisture',

	/**
	 * PAR
	 */
	par = 'par',

	/**
	 * 距离/液位
	 */
	distance = 'distance',

	/**
	 * 液位（水）
	 */
	waterlevel = 'waterlevel',

	/**
	 * 电导率
	 */
	conductivity = 'conductivity',

	/**
	 * 漏水
	 */
	leakage = 'leakage',

	/**
	 * 压力
	 */
	pressure = 'pressure',

	/**
	 * 压力2 UC521-lora特有
	 */
	pressure2 = 'pressure2',
	/**
	 * 门磁
	 */
	magnet = 'magnet',
	magnet_ch1 = 'magnet_ch1',
	magnet_ch2 = 'magnet_ch2',
	/**
	 * 一氧化碳
	 */
	co = 'co',

	/**
	 * 硫化氢
	 */
	h2s = 'h2s',

	/**
	 * 氨气
	 */
	nh3 = 'nh3',

	/**
	 * 防拆
	 */
	installation = 'installation',

	/**
	 * pm1.0
	 */
	pm1 = 'pm1',

	/**
	 * pm2.5
	 */
	pm25 = 'pm25',

	/**
	 * pm10
	 */
	pm10 = 'pm10',

	/**
	 * 甲醛
	 */
	hcho = 'hcho',

	/**
	 * 臭氧
	 */
	o3 = 'o3',

	/**
	 * 噪声
	 */
	loudness = 'loudness',

	/**
	 * 角度
	 */
	angle = 'angle',

	/**
	 * 检测灵敏度 
	 */
	detectionSensitivity = 'detectionSensitivity',

	/**
	 * 设备姿态
	 */
	posture = 'posture',
	/**
	 * 水流阈值
	 */
	waterThreshold = 'waterThreshold',
	/**
	 * 累计用水量
	 */
	waterConsumption = 'waterConsumption',
	/**
	 * 蜂鸣器
	 */
	buzz_ruing = 'buzz_ruing',

	/**
	 * 人数统计
	 */
	peopleCount = 'peopleCount',

	/**
	 * 电子烟指数
	 */
	vapingIndex = 'vapingIndex',

	/**
	 * 篡改状态
	 */
	tamperState = 'tamperState',

	/**
	 * 跌落
	 */
	falling = 'falling',

	/**
	 * 12路电流传感器
	 */
	current1 = 'current1',
	current2 = 'current2',
	current3 = 'current3',
	current4 = 'current4',
	current5 = 'current5',
	current6 = 'current6',
	current7 = 'current7',
	current8 = 'current8',
	current9 = 'current9',
	current10 = 'current10',
	current11 = 'current11',
	current12 = 'current12',

	/**
	 * 3路电压传感器
	 */
	voltage1 = 'voltage1',
	voltage2 = 'voltage2',
	voltage3 = 'voltage3',

	/**
	 * 12路电流总谐波失真度阈值告警
	 */
	currentHarmonicDistortion1 = 'currentHarmonicDistortion1',
	currentHarmonicDistortion2 = 'currentHarmonicDistortion2',
	currentHarmonicDistortion3 = 'currentHarmonicDistortion3',
	currentHarmonicDistortion4 = 'currentHarmonicDistortion4',
	currentHarmonicDistortion5 = 'currentHarmonicDistortion5',
	currentHarmonicDistortion6 = 'currentHarmonicDistortion6',
	currentHarmonicDistortion7 = 'currentHarmonicDistortion7',
	currentHarmonicDistortion8 = 'currentHarmonicDistortion8',
	currentHarmonicDistortion9 = 'currentHarmonicDistortion9',
	currentHarmonicDistortion10 = 'currentHarmonicDistortion10',
	currentHarmonicDistortion11 = 'currentHarmonicDistortion11',
	currentHarmonicDistortion12 = 'currentHarmonicDistortion12',

	/**
	 * 3路电压总谐波失真度传感器
	 */
	voltageHarmonicDistortion1 = 'voltageHarmonicDistortion1',
	voltageHarmonicDistortion2 = 'voltageHarmonicDistortion2',
	voltageHarmonicDistortion3 = 'voltageHarmonicDistortion3',

	/**
	 * 电压三相不平衡度传感器
	 */
	voltageThreePhaseImbalance = 'voltageThreePhaseImbalance',
}

export const SENSOR_KEYS_TYPE = _.keys(SENSORS);

/**
 * TODO: 传感器定义 
 */
export const SENSOR_DEFINITIONS = {
	[SENSORS.temperature]: {
		key: SENSORS.temperature,
		unit: "℃",
		decimalLength: 1,
		unitOptions: [
			{ label: '℃', value: '℃' },
			{ label: '℉', value: '℉' }
		],
		range: [ 20, 70 ]
	},
	[SENSORS.loudness]: {
		unit: "dB",
		decimalLength: 1,
		range: [ 30, 120 ]
	},
};

/**
 * 设备型号支持的传感器
 */
export const MODEL_SUPPORT_SENSORS = {
	[MODELS["AM103L"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" }, 
		{ key: SENSORS.humidity, unit: "%" }, 
		{ key: SENSORS.co2concentration, unit: "ppm" }
	],
	[MODELS["AM103"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" }, 
		{ key: SENSORS.humidity, unit: "%" }, 
		{ key: SENSORS.co2concentration, unit: "ppm" }
	],
	[MODELS["AM102L"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" }, 
		{ key: SENSORS.humidity, unit: "%" }, 
	],
	[MODELS["AM102"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" }, 
		{ key: SENSORS.humidity, unit: "%" }, 
	],
	[MODELS["AM104"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" }, 
		{ key: SENSORS.humidity, unit: "%" }, 
		{ key: SENSORS.activity, unit: "" }, 
		{ key: SENSORS.illumination, unit: 'lux' } 
	],
	[MODELS["AM107"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.tvoc, unit: "ppb" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" }
	],
	[MODELS["AM304L"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'Lux' },
		{ key: SENSORS.activity, unit: null },
	],
	[MODELS["AM305L"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.illumination, unit: 'Lux' },
		{ key: SENSORS.activity, unit: null },
	],
	[MODELS["AM307"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" }
	],

	[MODELS["AM307L"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" }
	],

	[MODELS["AM308"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["AM308L"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["AM319-HCHO"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.hcho, unit: "mg/m³" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["AM319L-HCHO-IR"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.hcho, unit: "mg/m³" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["AM319-HCHO-IR"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.hcho, unit: "mg/m³" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["AM319-HCHO-IR-W"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.hcho, unit: "ppm" },
		{ key: SENSORS.pm25, unit: "ug/m³" },		
	],

	[MODELS["AM319L-O3"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.o3, unit: "ppm" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["AM319-O3"]]: [ 
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.activity, unit: null },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.tvoc, unit: "iaq" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.o3, unit: "ppm" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" }
	],

	[MODELS["EM500-PAR"]]: [{key: SENSORS.par, unit: "μmol·m⁻²·s⁻¹"}],
	[MODELS["EM500-CO2"]]: [
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" }
	],
	[MODELS['EM500-LGT']]: [
		{ key: SENSORS.illumination, unit: 'lux' }
	],

	[MODELS["EM500-SMT-EC5"]]: [{key: SENSORS.soilmoisture, unit: "%"}],
	[MODELS["EM500-SMT-MT05"]]: [{key: SENSORS.soilmoisture, unit: "%"}],
	[MODELS["EM500-SMT-MT10"]]: [{key: SENSORS.soilmoisture, unit: "%"}],
	[MODELS["EM500-SMTC-MEC20"]]: [
		{ key: SENSORS.conductivity, unit: "us/cm" },
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" }
	],
	
	[MODEL_SERIES["EM500-PT100"]]: [{key: SENSORS.temperature, unit: "℃"}],
	[MODELS["EM500-PT100-T050"]]: [{key: SENSORS.temperature, unit: "℃"}],
	[MODELS["EM500-PT100-T200"]]: [{key: SENSORS.temperature, unit: "℃"}],
	[MODELS["EM500-PT100-T500"]]: [{key: SENSORS.temperature, unit: "℃"}],
	[MODELS["EM500-PT100-T800"]]: [{key: SENSORS.temperature, unit: "℃"}],

	[MODEL_SERIES["EM500-UDL"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-W050"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-W100"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-S050"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-S100"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-C020"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-C050"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM500-UDL-C100"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM310-UDL"]]: [{ key: SENSORS.distance, unit: "m" }],
	[MODELS["EM310-TILT"]]: [{ key: SENSORS.angle, unit: "°" }],
	[MODELS["EM320-TILT"]]: [{ key: SENSORS.angle, unit: "°" }],

	[MODEL_SERIES["EM500-SWL"]]: [{ key: SENSORS.waterlevel, unit: "m" }],
	[MODELS["EM500-SWL-KZ"]]: [{ key: SENSORS.waterlevel, unit: "m" }],
	[MODELS["EM500-SWL-L003"]]: [{ key: SENSORS.waterlevel, unit: "m" }],
	[MODELS["EM500-SWL-L005"]]: [{ key: SENSORS.waterlevel, unit: "m" }],
	[MODELS["EM500-SWL-L010"]]: [{ key: SENSORS.waterlevel, unit: "m" }],
	[MODELS["EM500-SWL-L050"]]: [{ key: SENSORS.waterlevel, unit: "m" }],

	[MODEL_SERIES['EM500-PP']]: [
		{key: SENSORS.pressure, unit: 'kPa'}
	],
	[MODELS['EM500-PP-G1/2M-P300']]: [
		{key: SENSORS.pressure, unit: 'kPa'}
	],
	[MODELS['EM500-PP-G1/2M-1002']]: [
		{key: SENSORS.pressure, unit: 'kPa'}
	],
	[MODELS['EM500-PP-G1/2M-4780']]: [
		{key: SENSORS.pressure, unit: 'kPa'}
	],
	[MODELS['EM500-PP-KZ']]: [
		{key: SENSORS.pressure, unit: 'kPa'}
	],
	[MODELS['EM500-PP-G1/2M-4842']]: [
		{key: SENSORS.pressure, unit: 'kPa'}
	],
	[MODELS['EM500-CO']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.co, unit: 'ppm'}
	],
	[MODELS['EM500-H2S']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.h2s, unit: 'ppm'}
	],
	[MODELS['EM500-NH3']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.nh3, unit: 'ppm'}
	],

	[MODELS['EM300-TH']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'}
	],
	[MODELS['EM300-WL']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'},
		{key: SENSORS.leakage, unit: null}
	],
	[MODELS['EM300-ZLD']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'},
		{key: SENSORS.leakage, unit: null}
	],
	[MODELS['EM300-ZLD-N00CN']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'},
		{key: SENSORS.leakage, unit: null}
	],
	[MODELS['EM300-SLD']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'},
		{key: SENSORS.leakage, unit: null}
	],
	[MODELS['EM300-SLD-N00CN']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'},
		{key: SENSORS.leakage, unit: null}
	],
	[MODELS['EM300-MCS']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.magnet, unit: null }
	],
	[MODELS['EM300-MCS-N00CN']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.magnet, unit: null }
	],
	[MODELS['EM300-SW']]: [
		{ key: SENSORS.magnet, unit: null }
	],

	[MODELS['EM300-DI']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'},
		{ key: SENSORS.waterThreshold,unit: null }
	],

	[MODELS['EM300-DI-HALL']]: [
		{ key: SENSORS.waterThreshold,unit: null }
	],

	[MODELS['EM320-TH']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'}
	],

	[MODEL_SERIES['EM400-TLD']]: [
		{key: SENSORS.distance, unit: 'm'},
	],

	[MODEL_SERIES['EM400-UDL']]: [
		{key: SENSORS.distance, unit: 'm'},
	],

	[MODEL_SERIES['EM410-RDL']]: [
		{key: SENSORS.distance, unit: 'm'},
	],

	[MODEL_SERIES['EM411-RDL']]: [
		{key: SENSORS.distance, unit: 'm'},
	],

	[MODEL_SERIES['EM410-RDL-L0CEU']]: [
		{key: SENSORS.distance, unit: 'm'},
	],

	[MODELS['WS201']]: [
		{ key: SENSORS.distance, unit: 'cm' }
	],

	[MODELS['WS202']]: [
		{ key: SENSORS.illumination, unit: 'lux' }
	],

	[MODELS['WS203']]: [
		{key: SENSORS.temperature, unit: '℃'},
		{key: SENSORS.humidity, unit: '%'}
	],

	[MODELS['WS302']]: [
		{ key: SENSORS.loudness, unit: 'dBA' }
	],
	[MODELS['WS515']]: [
		{key: SENSORS.temperature, unit: '℃'},
	],
	[MODELS['WS513']]: [
		{key: SENSORS.temperature, unit: '℃'},
	],
	[MODELS['WS516']]: [
		{key: SENSORS.temperature, unit: '℃'},
	],
	[MODELS['GS301']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.nh3, unit: 'ppm' },
		{ key: SENSORS.h2s, unit: 'ppm' }
	],

	[MODELS['TS101']]: [
		{ key: SENSORS.temperature, unit: "℃" },
	],

	[MODELS['TS201']]: [
		{ key: SENSORS.temperature, unit: "℃" },		
		{ key: SENSORS.humidity, unit: "%" },
	],

	[MODELS['TS601-L0DEU']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.angle, unit: '°' },
		{ key: SENSORS.falling, unit: 'g' },
	],

	[MODELS['TS601-L0FNA']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.angle, unit: '°' },
		{ key: SENSORS.falling, unit: 'g' },
	],

	[MODELS['TS601-L0DLA']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.angle, unit: '°' },
		{ key: SENSORS.falling, unit: 'g' },
	],

	[MODELS['TS602-L0DEU']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.angle, unit: '°' },
		{ key: SENSORS.falling, unit: 'g' },
	],

	[MODELS['TS602-L0FNA']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.angle, unit: '°' },
		{ key: SENSORS.falling, unit: 'g' },
	],

	[MODELS['TS602-L0DLA']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.angle, unit: '°' },
		{ key: SENSORS.falling, unit: 'g' },
	],

	[MODELS['VS350']]: [
		{ key: SENSORS.peopleCount, unit: "" },
		{ key: SENSORS.temperature, unit: "℃" },
	],

	[MODELS['VS351']]: [
		{ key: SENSORS.peopleCount, unit: "" },
		{ key: SENSORS.temperature, unit: "℃" },
	],

	[MODELS['VS360']]: [
		{ key: SENSORS.peopleCount, unit: "" },
	],

	[MODELS['WT101']]:  [
		{ key: SENSORS.temperature, unit: "℃" },
	],

	[MODELS['WT102']]:  [
		{ key: SENSORS.temperature, unit: "℃" },
	],
	[MODELS['CTH01']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: 'currentAlarmSettings[0]', unit: "A" },
		{ key: 'currentAlarmSettings[1]', unit: "A" },
		{ key: 'currentAlarmSettings[2]', unit: "A" },
		{ key: 'currentAlarmSettings[3]', unit: "A" },
		{ key: 'currentAlarmSettings[4]', unit: "A" },
		{ key: 'currentAlarmSettings[5]', unit: "A" },
		{ key: 'currentAlarmSettings[6]', unit: "A" },
		{ key: 'currentAlarmSettings[7]', unit: "A" },
		{ key: 'currentAlarmSettings[8]', unit: "A" },
		{ key: 'currentAlarmSettings[9]', unit: "A" },
		{ key: 'currentAlarmSettings[10]', unit: "A" },
		{ key: 'currentAlarmSettings[11]', unit: "A" },
		{ key: 'voltageAlarmSettings[0]', unit: "V" },
		{ key: 'voltageAlarmSettings[1]', unit: "V" },
		{ key: 'voltageAlarmSettings[2]', unit: "V" },
		{ key: 'currentHarmonicDistortionAlarmSettings[0]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[1]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[2]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[3]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[4]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[5]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[6]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[7]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[8]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[9]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[10]', unit: "%" },
		{ key: 'currentHarmonicDistortionAlarmSettings[11]', unit: "%" },
		{ key: 'voltageHarmonicDistortionAlarmSettings[0]', unit: "%" },
		{ key: 'voltageHarmonicDistortionAlarmSettings[1]', unit: "%" },
		{ key: 'voltageHarmonicDistortionAlarmSettings[2]', unit: "%" },
		{ key: 'voltageThreePhaseImbalanceAlarmSettings', unit: "%" },
	],

	[MODELS['WT201']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],
	[MODELS['WT211']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],
	[MODELS['WT401']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],
	[MODELS['WT303']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],

	[MODELS['WT303-ZH']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],

	[MODELS['WT304']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],

	[MODELS['WT304-ZH']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
	],

	[MODEL_SERIES['UC51X']]: [
		{ key: SENSORS.pressure, unit: 'kPa' }
	],
	[MODEL_SERIES['UC51X-CAT']]: [
		{ key: SENSORS.pressure, unit: 'kPa' }
	],
	[MODELS['GS601']]: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: '%' },
		{ key: SENSORS.tvoc, unit: "ug/m³" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" },
		{ key: SENSORS.pm1, unit: "ug/m³" },
		{ key: SENSORS.vapingIndex }
	],

	All: [
		{ key: SENSORS.temperature, unit: "℃" },
		{ key: SENSORS.humidity, unit: "%" },
		{ key: SENSORS.activity, unit: "" },
		{ key: SENSORS.illumination, unit: 'lux' },
		{ key: SENSORS.co2concentration, unit: "ppm" },
		{ key: SENSORS.tvoc, unit: "ppb³" },
		{ key: SENSORS.atmosphericpressure, unit: "hPa" },
		{ key: SENSORS.soilmoisture, unit: "%" },
		{ key: SENSORS.par, unit: "μmol·m⁻²·s⁻¹" },
		{ key: SENSORS.distance, unit: "m" },
		{ key: SENSORS.waterlevel, unit: "m" },
		{ key: SENSORS.conductivity, unit: "us/cm" },
		{ key: SENSORS.leakage, unit: null },
		{ key: SENSORS.pressure, unit: 'kPa' },
		{ key: SENSORS.magnet, unit: null },
		{ key: SENSORS.co, unit: 'ppm' },
		{ key: SENSORS.h2s, unit: 'ppm' },
		{ key: SENSORS.nh3, unit: 'ppm' },
		{ key: SENSORS.co, unit: 'ppm' },
		{ key: SENSORS.h2s, unit: 'ppm' },
		{ key: SENSORS.nh3, unit: 'ppm' },
		{ key: SENSORS.hcho, unit: "mg/m³" },
		{ key: SENSORS.pm25, unit: "ug/m³" },
		{ key: SENSORS.pm10, unit: "ug/m³" },
		{ key: SENSORS.o3, unit: "ppm" }
	]
};

export const EM_SENSORS = [ SENSORS.soilmoisture, SENSORS.co2concentration, SENSORS.par, SENSORS.temperature, SENSORS.distance, SENSORS.waterlevel, SENSORS.conductivity ];

export enum PARSING_LOCATION {
	app = 'app',
	nfc = 'nfc',
}

export const SUPPORT_UNIT_CHANGE_SENSORS = [ 
	{
		sensor: SENSORS.temperature,
		default: '℃',
		parsingLocation: PARSING_LOCATION.nfc,
		options: [
			{ label: '℃', value: '℃' },
			{ label: '℉', value: '℉' }
		]
	},
	{
		sensor: SENSORS.pressure,
		default: 'kPa',
		parsingLocation: PARSING_LOCATION.app,
		options: [ 
			{ label: 'kPa', value: 'kPa' },
			{ label: 'bar', value: 'bar' },
			{ label: 'MPa', value: 'MPa' }
		]
	},
	{
		sensor: SENSORS.pressure2,
		default: 'kPa',
		parsingLocation: PARSING_LOCATION.app,
		options: [ 
			{ label: 'kPa', value: 'kPa' },
			{ label: 'bar', value: 'bar' },
			{ label: 'MPa', value: 'MPa' }
		]
	}
];

export const HAS_THRESHOLD_SENSORS = [ SENSORS.temperature, SENSORS.humidity, SENSORS.soilmoisture, SENSORS.co2concentration, SENSORS.par, SENSORS.distance, SENSORS.waterlevel, SENSORS.conductivity, SENSORS.atmosphericpressure, SENSORS.leakage, SENSORS.illumination, SENSORS.co, SENSORS.h2s, SENSORS.nh3 ];

export const ALARM_SETTING_SENSORS = [ SENSORS.magnet, SENSORS.leakage, SENSORS.installation, SENSORS.waterThreshold ];

export const EM400NB_SERIES = [
	MODELS['EM400-MUD-N03GL'], MODELS['EM400-TLD-N03GL'], MODELS['EM400-UDL-C050-N03GL'], MODELS['EM400-UDL-C100-N03GL'], MODELS['EM400-UDL-S050-N03GL'], MODELS['EM400-UDL-W050-N03GL'], MODELS['EM400-UDL-W100-N03GL']
];

export const AM300_DISPLAY_MODELS = [ MODELS['AM307'], MODELS['AM308'], MODELS['AM319-HCHO'], MODELS['AM319-HCHO-IR'], MODELS['AM319-O3'], MODELS['AM319-HCHO-IR-W'] ];

export const LORA_PARAMS_KEYS = [
	'joinType',
	'port',
	'deviceAddress',
	'freqRegion',
	'freqMode',
	'freqs',
	'enableFreqIndex',
	'regularReport',
	'alarmReport',
	'applicationKey',
	'networkSessionKey',
	'applicationSessionKey',
	'adr',
	'appEUI',
	'dataRate',
	'txPower',
	'loraVersion',
	'confirmPackages',
	'rejoinMode',
	'classType',
	'channelPlan',
	'multicast',
	'pingSlotPeriod',
	'gwSpecific',
	'window2Dr',
	'window2Freq',
	'd2dCfg',
	'singleChannelMode',
];

export const NEW_EM = _.values(MODELS)
	.filter(model => !_.includes([
		MODELS['AM104'],
		MODELS['AM107'],
		MODELS['EM500-PAR'],
		MODELS['EM500-PT100-T050'],
		MODELS['EM500-PT100-T200'],
		MODELS['EM500-PT100-T500'],
		MODELS['EM500-PT100-T800'],
		MODELS['EM500-SMT-EC5'],
		MODELS['EM500-SMT-MT05'],
		MODELS['EM500-SWL-L003'],
		MODELS['EM500-SWL-L005'],
		MODELS['EM500-SWL-L010'],
		MODELS['EM500-SWL-KZ'],
		MODELS['EM500-UDL-W050'],
		MODELS['EM500-UDL-W100'],
		MODELS['EM500-UDL-S050'],
		MODELS['EM500-UDL-S100']
	], model));

/**
 * 中性型号集合
 */
export const NEUTRAL_MODEL_SET = [
	{
		//标准版本型号前缀
		sPrefix: 'AM',
		//中性版本型号前缀
		nPrefix: 'NB'
	},
	{
		sPrefix: 'EM',
		nPrefix: 'NB'
	},
	{
		sPrefix: 'UC',
		nPrefix: 'NC'
	},
	{
		sPrefix: 'WS',
		nPrefix: 'NE'
	},
	{
		sPrefix: 'VS',
		nPrefix: 'NF'
	},
	{
		sPrefix: 'DS',
		nPrefix: 'NH'
	},
	{
		sPrefix: 'GS',
		nPrefix: 'NI'
	},
	{
		sPrefix: 'JT-GS',
		nPrefix: 'NI'
	},
	{
		sPrefix: 'TS',
		nPrefix: 'NK'
	},
	{
		sPrefix: 'WTS',
		nPrefix: 'NJ'
	},
	{
		sPrefix: 'WT',
		nPrefix: 'NN'
	},
	{
		sPrefix: 'AT',
		nPrefix: 'NL'
	}
];