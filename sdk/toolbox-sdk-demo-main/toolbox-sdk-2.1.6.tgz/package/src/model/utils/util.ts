import { Buffer } from 'buffer';
import _ from 'lodash';
import {
	camelCase, forOwn, get, isArray, isDate, isEmpty, isEqual, isFunction, isNil, isNull, isObject, isRegExp, keyBy, map, reduce, snakeCase,
	transform, values
} from 'lodash';

import { IPSOService } from '../../service/ipso';
import { AttributeDefinition } from '../tsl';
import * as CONSTANTS from '../constants';
import { DeviceInfo } from '../deviceInfo';
import { MODELS, MODEL_SERIES, getDeviceIsNeutral, getNeutralDeviceModel, getDeviceModel, getModelSeries, SENSOR_KEYS_TYPE } from '../';
import { convertTime, REPORTING_INTERVAL_UNIT, isUC500Series } from './migrationUtils';
import { isSupportSettings } from './isSupportSetting';


/**
 * 将对象扁平化
 */
export function flattenObject(obj: any, parentKey: string = '', result: Record<string, any> = {}): Record<string, any> {
	forOwn(obj, (value, key) => {
		const newKey = parentKey ? `${parentKey}.${key}` : key;
		//是对象且不为空，且不是数组且不是null
		if (isObject(value) && !isEmpty(value) && !isArray(value) && !isNull(value)) {
			flattenObject(value, newKey, result);
		} else {
			result[newKey] = value;
		}
	});

	return result;
}


/**
 * 判断属性方向是否匹配
 * @param direction - 属性方向
 * @param target - 目标方向
 */
export function isAttributeDirectionMatch(direction: AttributeDefinition['direction'], target: AttributeDefinition['direction']) {
	return direction === target || direction === 'both';
}

/**
 * 判断属性分组是否匹配
 * @param attributeGroup - 属性分组
 * @param group - 目标分组
 * @returns 是否匹配
 */
export function isAttributeGroupMatch(attributeGroup: string | string[], group: string | string[]) {
	if (Array.isArray(attributeGroup) && Array.isArray(group)) {
		return attributeGroup.some(attrGroup => group.includes(attrGroup));
	}

	if (Array.isArray(attributeGroup) && !Array.isArray(group)) {
		return attributeGroup.includes(group);
	}

	if (!Array.isArray(attributeGroup) && Array.isArray(group)) {
		return group.includes(attributeGroup);
	}

	return attributeGroup === group;
}

/**
 * 获取物模型属性的精度（有效小数位数）
 * @param key - 物模型属性key
 * @param access - 属性访问类型
 * @returns 小数位数
 */
export function getTslAttributeFractionDigits(key: string, access: 'read' | 'write'): number | undefined {
	try {
		const fractionDigits = IPSOService.getResourceAttribute(key, access)?.fractionDigits;

		return fractionDigits;
	} catch (error) {
		return undefined;
	}
}

/**
 * 默认的全局验证器
 * 1. 检查值是否为 null 或 undefined
 * 2. 如果值是对象，检查是否为空对象
 */
function defaultGlobalValidator(value: any): boolean {
	// 检查是否为 null 或 undefined
	if (isNil(value)) {
		return false;
	}

	// 如果值是对象，检查是否为空
	if (isObject(value)) {
		if (isEmpty(value)) {
			return false;
		}

		if (values(value).every(item => isNil(item))) {
			return false;
		}
	}

	return true;
}

/**
 * 从多个数据源中按优先级获取值
 * @param sources - 数据源数组，每个元素包含数据源和对应的路径
 * @param options - 配置选项
 * @returns 找到的第一个符合条件的值，或默认值
 */
export function getValueFromSources<T>(
	sources: Array<{
		/**
		 * 数据来源
		 */
		source: unknown;

		/**
		 * 取值路径
		 */
		path: string | string[];

		/**
		 * 数据验证器
		 * 只有通过验证器的数据返回
		 */
		validator?: (value: T) => boolean;

		/**
		 * 数据转换器
		 */
		transformer?: (value: T) => T;
	}>,
	options: {
		/**
			 * 默认值
			 */
		defaultValue?: T;

		/**
		 * 全局验证器
		 * @default defaultGlobalValidator
		 */
		globalValidator?: (value: T) => boolean;

		/**
		 * 全局转换器
		 */
		globalTransformer?: (value: T) => T;

		/**
		 * 是否禁用全局验证器
		 * @default false
		 */
		disableGlobalValidator?: boolean;
	} = {}
): T | undefined {
	const { defaultValue, globalValidator, globalTransformer, disableGlobalValidator } = options;
	// 确定使用哪个全局验证器
	const effectiveGlobalValidator = disableGlobalValidator
		? undefined
		: (globalValidator || defaultGlobalValidator);

	for (const { source, path, validator, transformer } of sources) {
		const value = get(source, path);

		// 检查局部验证器
		if (validator && !validator(value)) {
			continue;
		}

		// 检查全局验证器
		if (effectiveGlobalValidator && !effectiveGlobalValidator(value)) {
			continue;
		}

		// 确定使用哪个转换器
		const selectedTransformer = transformer || globalTransformer;

		// 如果存在转换器，使用转换器处理值
		if (selectedTransformer) {
			return selectedTransformer(value);
		}

		// 如果没有转换器，直接返回原始值
		return value as T;
	}

	// 如果所有数据源都没有找到符合条件的值，返回默认值
	return defaultValue as T | undefined;
}

/**
 * 将数组填充到指定长度，如果元素不存在则使用默认值
 * @param sourceArray - 源数组
 * @param targetLength - 目标长度
 * @param defaultItem - 默认元素
 * @param options - 配置选项
 * @returns 填充后的数组
 */
export function padArray<T>(
	sourceArray: T[],
	targetLength: number,
	defaultItem: T | ((index: number) => T),
	options: {
		/** 是否保留原数组中的元素 */
		preserveExisting?: boolean;
		/** 是否在数组末尾填充 */
		append?: boolean;
	} = {}
): T[] {
	const { preserveExisting = true, append = false } = options;

	// 如果目标长度小于源数组长度，且需要保留原数组元素，则截取
	if (targetLength < sourceArray.length && preserveExisting) {
		return sourceArray.slice(0, targetLength);
	}

	// 如果目标长度等于源数组长度，直接返回
	if (targetLength === sourceArray.length) {
		return sourceArray;
	}

	// 创建新数组
	const result = new Array(targetLength);

	// 如果需要在末尾填充
	if (append) {
		// 先复制原数组元素
		sourceArray.forEach((item, index) => {
			result[index] = item;
		});
		// 在末尾填充默认值
		for (let i = sourceArray.length; i < targetLength; i++) {
			result[i] = typeof defaultItem === 'function'
				? (defaultItem as (index: number) => T)(i)
				: defaultItem;
		}
	} else {
		// 从头开始填充
		for (let i = 0; i < targetLength; i++) {
			result[i] = preserveExisting && i < sourceArray.length
				? sourceArray[i]
				: (typeof defaultItem === 'function'
					? (defaultItem as (index: number) => T)(i)
					: defaultItem);
		}
	}

	return result;
}

/**
 * 递归地将对象的键转换为蛇形命名（snake_case）。
 * @param obj - 需要转换的对象或数组。
 * @returns 转换后的新对象或数组。
 */
export function keysToSnakeCase(obj: any): any {
	// 如果不是对象或数组，直接返回
	if (!isObject(obj) || isDate(obj) || isRegExp(obj) || isFunction(obj)) {
		return obj;
	}

	// 如果是数组，递归处理数组中的每个元素
	if (isArray(obj)) {
		return map(obj, keysToSnakeCase);
	}

	// 如果是对象，使用 transform 进行转换
	return transform(obj, (result: { [key: string]: any }, value: any, key: string) => {
		const newKey = snakeCase(key);
		// 递归处理值
		result[newKey] = keysToSnakeCase(value);
	}, {}); // 初始化为空对象
}

/**
 * 递归地将对象的键转换为驼峰命名（camelCase）。
 * @param obj - 需要转换的对象或数组。
 * @returns 转换后的新对象或数组。
 */
export function keysToCamelCase(obj: any): any {
	// 如果不是对象或数组，直接返回
	if (!isObject(obj) || isDate(obj) || isRegExp(obj) || isFunction(obj)) {
		return obj;
	}

	// 如果是数组，递归处理数组中的每个元素
	if (isArray(obj)) {
		return map(obj, keysToCamelCase);
	}

	// 如果是对象，使用 transform 进行转换
	return transform(obj, (result: { [key: string]: any }, value: any, key: string) => {
		const newKey = camelCase(key);
		// 递归处理值
		result[newKey] = keysToCamelCase(value);
	}, {}); // 初始化为空对象
}

/**
 * 将字符串按指定的UTF-8字节长度序列分割成多个块。
 * @param originalString 要分割的原始字符串。
 * @param limits 一个数字数组，每个数字代表对应块的最大UTF-8字节数。
 * @returns 返回一个字符串数组，每个字符串是一个块。
 * 如果原始字符串为空/null或limits数组为空，返回空数组。
 * 如果limits数组中某个限制值小于等于0，则处理在此限制前停止，返回已生成的块。
 * 如果某个字符本身的UTF-8字节长度就超过对应块的limit，则处理会在此字符前停止，
 * 该字符及其后续字符不会被包含，函数返回已生成的块。
 * 如果字符串提前用尽，而已处理的块数会少于limits数组的长度。
 */
export function chunkStringByUtf8ByteLimits(
	originalString: string | undefined | null,
	limits: number[]
): string[] {
	if (!originalString || !limits || limits.length === 0) {
		return [];
	}

	const chunks: string[] = [];
	// 使用 Array.from 将字符串转换为真正的 Unicode 字符数组，正确处理代理对
	const characters = Array.from(originalString);
	let currentCharacterIndex = 0; // 指向 characters 数组的当前处理位置

	for (const limit of limits) {
		// 检查当前限制值是否有效
		if (limit <= 0) {
			// 如果限制值无效，则停止处理后续所有块
			return chunks;
		}

		// 如果原始字符串的字符已全部处理完毕
		if (currentCharacterIndex >= characters.length) {
			break;
		}

		let bytesInCurrentChunk = 0;
		const currentChunkChars: string[] = []; // 用于构建当前块的字符
		let charsConsumedForThisChunk = 0; // 记录当前块消耗了多少个字符

		// 尝试为当前 limit 构建一个块
		for (let i = 0; currentCharacterIndex + i < characters.length; i++) {
			const actualChar = characters[currentCharacterIndex + i];
			const charBytes = Buffer.from(actualChar!, 'utf-8').byteLength;

			// 检查如果这是块的第一个字符，它本身是否就超限
			if (currentChunkChars.length === 0 && charBytes > limit) {
				// 此字符无法放入当前块，根据“固定停止”规则，应停止整个分割过程。
				return chunks; // 返回目前为止成功生成的所有块
			}

			if (bytesInCurrentChunk + charBytes <= limit) {
				bytesInCurrentChunk += charBytes;
				currentChunkChars.push(actualChar!);
				charsConsumedForThisChunk++;
			} else {
				// 当前字符无法加入此块，此块构建结束
				break;
			}
		}

		if (currentChunkChars.length > 0) {
			chunks.push(currentChunkChars.join(''));
			currentCharacterIndex += charsConsumedForThisChunk; // 更新到下一个块的起始字符位置
		} else {
			// 如果没有任何字符能组成当前块 (通常因为字符串已耗尽，
			// 或者首字符超限的情况已在上面处理并返回)
			// 则停止整个分割过程。
			break;
		}
	}

	return chunks;
}

export function getLeafPaths(obj: any): string[] {
	const paths: string[] = [];

	function recurse(current: any, path: string) {
		if (Array.isArray(current)) {
			current.forEach((item, index) => {
				recurse(item, `${path}${path ? '.' : ''}${index}`);
			});
		} else if (typeof current === 'object' && current !== null) {
			for (const key in current) {
				recurse(current[key], `${path}${path ? '.' : ''}${key}`);
			}
		} else {
			paths.push(path);
		}
	}

	recurse(obj, '');
	return paths;
}

/**
 * 比较新旧数组，找出新数组中发生变化或新增的项
 * @param oldArray 旧数组
 * @param newArray 新数组
 * @param idKey 用于唯一标识数组项的键名
 * @returns 返回一个包含新数组中所有发生变化或新增的项的数组
 * 注意：如果新旧数组不等长，新数组的删除项，不会出现在返回结果中
 */
export function getDiffArrayItems<TItem extends Record<string, any>>(
	oldArray: TItem[] | undefined | null,
	newArray: TItem[],
	idKey: keyof TItem,
): TItem[] {
	if (!oldArray || oldArray.length === 0) {
		return newArray;
	}

	const oldItemsById = keyBy(oldArray, idKey);
	const changedOrAddedItems = reduce(
		newArray,
		(result, newItem) => {
			const oldItem = oldItemsById[newItem[idKey]];
			if (!oldItem || !isEqual(newItem, oldItem)) {
				result.push(newItem);
			}
			return result;
		},
		[] as TItem[],
	);

	return changedOrAddedItems;
}

/**
 * 获取指定范围内可用的最小 ID
 *
 * 该函数接收一个已存在的 ID 数组，并返回一个在指定范围内可用于新条目的最小 ID。
 * 最小 ID 从 minId 开始递增，并在 maxId 范围内查找，跳过已存在的 ID。
 *
 * @param {number[]} existingIds - 已存在的 ID 数组。
 * @param {number} [minId=1] - 可用 ID 的最小值 (可选，默认为 1)。
 * @param {number} [maxId=65535] - 可用 ID 的最大值 (可选，默认为 65535)。
 * @returns {number | null} 可用于新条目的最小 ID，如果在指定范围内找不到可用 ID，则返回 null。
 *                         如果 minId 大于 maxId，则返回 null。
 */
export function getMinimumAvailableId(existingIds: number[], minId = 1, maxId = 65535) {
	if (minId > maxId) {
		console.warn("minId 大于 maxId，无效的范围");
		return null;
	}

	if (!existingIds || existingIds.length === 0) {
		// 如果没有已存在的 ID，则最小 ID 为 minId
		return minId;
	}

	const existingIdSet = new Set(existingIds);

	// 从 minId 开始循环，查找最小的可用 ID
	let nextId = minId;
	while (nextId <= maxId) {
		if (!existingIdSet.has(nextId)) {
			return nextId;
		}

		nextId++;
	}

	console.warn(`在 [${minId}, ${maxId}] 范围内未找到可用的 ID`);
	return null;
}

/**
 * 根据区域，返回默认的区域频率数组
 *
 * @param {number} freqRegion
 * @returns - 默认的区域频率
 */
export const getDefaultFreqs =
	function (freqRegion: CONSTANTS.FREQUENCY, singleChannelMode: boolean) {
		let defaultFreqs: { value: string | number; index?: string; enable?: boolean }[] = [];
		switch (freqRegion) {
			case CONSTANTS.FREQUENCY.US915:
				defaultFreqs = [
					{ value: '902.3 - 905.3', index: '0 - 15' },
					{ value: '905.5 - 908.5', index: '16 - 31' },
					{ value: '908.7 - 911.7', index: '32 - 47' },
					{ value: '911.9 - 914.9', index: '48 - 63' },
					{ value: '903 - 914.2', index: '64 - 71' }
				];
				break;
			case CONSTANTS.FREQUENCY.AU915:
				defaultFreqs = [
					{ value: '915.2 - 918.2', index: '0 - 15' },
					{ value: '918.4 - 921.4', index: '16 - 31' },
					{ value: '921.6 - 924.6', index: '32 - 47' },
					{ value: '924.8 - 927.8', index: '48 - 63' },
					{ value: '915.9 - 927.1', index: '64 - 71' }
				];
				break;
			case CONSTANTS.FREQUENCY.CN470:
				defaultFreqs = [
					{ value: '470.3 - 473.3', index: '0 - 15' },
					{ value: '473.5 - 476.5', index: '16 - 31' },
					{ value: '476.7 - 479.7', index: '32 - 47' },
					{ value: '479.9 - 482.9', index: '48 - 63' },
					{ value: '483.1 - 486.1', index: '64 - 79' },
					{ value: '486.3 - 489.3', index: '80 - 95' }
				];
				break;
			case CONSTANTS.FREQUENCY.CN470_INTER:
			case CONSTANTS.FREQUENCY.CN470_INTRA:
				defaultFreqs = [];
				break;
			case CONSTANTS.FREQUENCY.AS923:
				defaultFreqs = [
					{ value: 923.2, enable: true },
					{ value: 923.4, enable: true },
					{ value: 922.2, enable: false },
					{ value: 922.4, enable: false },
					{ value: 922.6, enable: false },
					{ value: 922.8, enable: false },
					{ value: 923.0, enable: false },
					{ value: 922.0, enable: false }
				];
				defaultFreqs.length = singleChannelMode ? 3 : defaultFreqs.length;
				break;
			case CONSTANTS.FREQUENCY.KR920:
				defaultFreqs = [
					{ value: 922.1, enable: true },
					{ value: 922.3, enable: true },
					{ value: 922.5, enable: true },
					{ value: 921.9, enable: false },
					{ value: 922.7, enable: false },
					{ value: 922.9, enable: false },
					{ value: 923.1, enable: false },
					{ value: 923.3, enable: false }
				];
				defaultFreqs.length = singleChannelMode ? 4 : defaultFreqs.length;
				break;
			case CONSTANTS.FREQUENCY.EU433:
				defaultFreqs = [
					{ value: 433.175, enable: true },
					{ value: 433.375, enable: true },
					{ value: 433.575, enable: true },
					{ value: 433.775, enable: false },
					{ value: 434.065, enable: false },
					{ value: 434.265, enable: false },
					{ value: 434.465, enable: false },
					{ value: 434.665, enable: false }
				];
				break;
			case CONSTANTS.FREQUENCY.IN865:
				defaultFreqs = [
					{ value: 865.0625, enable: true },
					{ value: 865.4025, enable: true },
					{ value: 865.9850, enable: true },
					{ value: 865.6025, enable: false },
					{ value: 866.185, enable: false },
					{ value: 866.385, enable: false },
					{ value: 866.585, enable: false },
					{ value: 866.785, enable: false },
				];
				defaultFreqs.length = singleChannelMode ? 4 : defaultFreqs.length;
				break;
			case CONSTANTS.FREQUENCY.RU864:
				defaultFreqs = [
					{ value: 868.9, enable: true },
					{ value: 869.1, enable: true },
					{ value: 869.3, enable: false },
					{ value: 867.3, enable: false },
					{ value: 867.5, enable: false },
					{ value: 867.7, enable: false },
					{ value: 867.9, enable: false },
					{ value: 868.1, enable: false }
				];
				defaultFreqs.length = singleChannelMode ? 3 : defaultFreqs.length;
				break;
			case CONSTANTS.FREQUENCY.EU868:
			default:
				defaultFreqs = [
					{ value: 868.1, enable: true },
					{ value: 868.3, enable: true },
					{ value: 868.5, enable: true },
					{ value: 867.1, enable: false },
					{ value: 867.3, enable: false },
					{ value: 867.5, enable: false },
					{ value: 867.7, enable: false },
					{ value: 867.9, enable: false }
				];
				defaultFreqs.length = singleChannelMode ? 4 : defaultFreqs.length;
				break;
		}

		if(singleChannelMode) {
			defaultFreqs = defaultFreqs.map((item, index) => {
				if(index === 0 && Object.keys(item).length > 0) {
					return { ...item, enable: true };
				}
				return { ...item, enable: false };
			});
		}

		return defaultFreqs;
	};
export function mergetButArray(obj: any, src: any) {
	const customMerge = (objValue: any, srcValue: any) => {
		if (Array.isArray(objValue) && Array.isArray(srcValue)) {
			// 源数组覆盖目标数组，而不是合并
			return srcValue;
		}

		return;
	};

	return _.mergeWith(obj, src, customMerge);
}

type ActionState = DeviceInfo;

type ActionPayload = Partial<DeviceInfo>;


export const normalizeReportingInterval = ({
	reportingInterval,
	reportingIntervalUnit,
	reportIntervalUnit
}: {
	reportingInterval?: number,
	reportingIntervalUnit?: 0|1|2,
	reportIntervalUnit?: string
}): {
	reportingInterval: number | undefined,
	reportIntervalUnit: DeviceInfo['reportIntervalUnit']
} | undefined => {
	if (reportingIntervalUnit !== undefined){
		// reportingIntervalUnit为1代表分钟，为2代表小时
		const isNeedConvert = reportingIntervalUnit === 1 || reportingIntervalUnit === 2;
		return {
			// 不管是分钟还是小时，统一转换成秒
			reportingInterval: isNeedConvert && reportingInterval != null ? convertTime(reportingInterval, 's', reportIntervalUnit) : reportingInterval,
			// 将原数据的单位转化为 s|min|hour 等单位
			reportIntervalUnit: (REPORTING_INTERVAL_UNIT)[reportingIntervalUnit] as DeviceInfo['reportIntervalUnit'],
		};
	}
	return undefined;
};

/**
 * 处理DeviceInfo Payload的数据
 * @param state - 当前状态
 * @param payload - 要处理的payload
 */
export const processPayload = (state: ActionState, payload: ActionPayload) => {
	const payloadKeys = _.keys(payload);
	const status = _.has(payload, 'status') ? payload.status : _.get(state, 'status', []);
	const sn = _.get(payload, 'sn', state.sn);
	const deviceEui = _.get(payload, 'deviceEui');
	const upgradeResult = _.get(payload, 'upgradeResult');
	const reportingIntervalUnit = _.get(payload, 'reportingIntervalUnit');
	const reportIntervalUnit = _.get(payload, 'reportIntervalUnit', 'min');
	const applyFromTemplate = _.get(payload, 'applyFromTemplate', false);
	let payloadModel = _.get(payload, 'model');
	const notSupportModel = !_.isNil(payloadModel) && !_.has(MODELS, payloadModel) && !_.has(MODEL_SERIES, payloadModel);

	// 设备的原始model字段内容
	if (_.isString(payloadModel)) {
		payload['rawModel'] = payloadModel;
	}

	//特殊处理11N1的型号显示
	if(_.isString(payloadModel) && payloadModel.startsWith('11N1')) {
		payloadModel = payloadModel.replace('11N1', 'UC11-N1');
	}

	//如果是中性版本，则要做型号的特殊处理
	if(_.isString(payloadModel) && getDeviceIsNeutral(payload?.oem)) {
		payloadModel = getNeutralDeviceModel(payloadModel, payload?.oem);
	}

	//如果model不在当前支持的model列表中，对model做保护写入
	if(notSupportModel) {
		const newModel = getDeviceModel(sn, payloadModel, payload.pn, payload.subModel);
		payload['model'] = _.isNil(newModel) || applyFromTemplate ? payloadModel : newModel;
		payload['statusModel'] = payloadModel; //用于在status，upgrade等页面显示的
	}

	if(payload['updateTime'] && payloadModel) {//应注意payloadModel为undefined
		payload.statusModel = applyFromTemplate ? (payload.statusModel ?? payloadModel) : payloadModel;
		payload['upgradeResult'] = upgradeResult;
		payload['reportIntervalUnit'] = reportIntervalUnit;
		// 防止含有以下字段的设备读取后马上又读取没有该字段的设备的情况（因为payload仅作合并处理，默认情况下多余的字段会保留）
		payload['reportingIntervalUnit'] = reportingIntervalUnit;
		payload['timezoneMin'] = _.get(payload, 'timezoneMin');
		payload['pressure'] = _.get(payload, 'pressure');
		payload['pressure2'] = _.get(payload, 'pressure2');
		payload['humidity'] = _.get(payload, 'humidity');
		if (sn !== undefined) {
			payload['sn'] = _.isString(sn) ? sn.toUpperCase() : sn;
		}
		if (deviceEui !== undefined) {
			payload['deviceEui'] = _.isString(deviceEui) ? deviceEui.toUpperCase() : deviceEui;
		}
	}

	const normalizeReportingIntervalResult = normalizeReportingInterval({reportingInterval: _.get(payload, 'reportingInterval'), reportingIntervalUnit, reportIntervalUnit});
	if (normalizeReportingIntervalResult){
		payload.reportingInterval = normalizeReportingIntervalResult.reportingInterval;
		payload.reportIntervalUnit = normalizeReportingIntervalResult.reportIntervalUnit;
	}

	if(!_.isNil(payload.model) && isUC500Series(payload.model)) {//UC500系列，上报间隔单位强制改为秒
		console.debug('change uc500 reportIntervalUnit to s');
		payload['reportIntervalUnit'] = 's';
	}

	if(_.isString(payload['model'])) {
		payload['modelSeries'] = getModelSeries(payload['model']);
	}

	if(isSupportSettings('workMode', payload['model'] ?? state.model) || payload['workMode']) {
		const workMode = _.get(payload, 'workMode', {
			mode: 0,
			config: []
		});
		const { mode, config = [] } = workMode;
		if(config.length > 0) {
			const { reportingInterval, collectInterval, installHeight } = config[mode] || {};
			payload['reportingInterval'] = reportingInterval ?? payload['reportingInterval'];
			payload['collectInterval'] = collectInterval ?? payload['collectInterval'];
			payload['installHeight'] = installHeight ?? payload['installHeight'];
		}
	}

	if(__DEV__) {
		payload['model'] && console.log('device model', payload['model']);
		payload['modelSeries'] && console.log('device model series', payload['modelSeries']);
	}

	const nextStatus = status?.map(item => {
		const name = item.name;
		const statusValue = item.value;
		//sensor的值需要特殊处理
		let payloadValue = '';
		if (SENSOR_KEYS_TYPE.includes(name)) {
			payloadValue = _.get(payload, `${name}.value`, statusValue || '');
		} else {
			payloadValue = _.isObject(payload[name]) ? statusValue : payload[name];
		}

		if(name === 'model') {
			payloadValue = getDeviceIsNeutral(payload?.oem) || notSupportModel
				? payloadModel ?? statusValue as string
				: statusValue as string; //status显示payload默认传过来的model
		}

		//如果新设置的值跟status中对应的值不相等，则更新status值为最新值
		if(payloadKeys.includes(name) && !_.isEqual(payloadValue, statusValue)) {
			const newStatus = {
				...item,
				value: payloadValue
			};

			if(_.has(payload, `${name}.unit`)) {
				newStatus['unit'] = _.get(payload, `${name}.unit`);
			}

			return newStatus;
		}

		return item;
	});

	return {
		payload,
		status: nextStatus ?? [],
	};
};

export const getOriginPreDeviceInfo = (preDeviceInfo: Partial<DeviceInfo>) => {
	const defaultDeviceInfo = _.cloneDeep(preDeviceInfo);

	//特殊处理：因为deviceInfo中存储的reportingInterval是以秒为单位的，所以需要转换成reportIntervalUnit对应的时间单位
	//否则会因为设备默认的reportingInterval的单位与当前设置的reportingInterval单位不一致，而导致值不一致，预配置的diff就会一直是有变化的
	if(defaultDeviceInfo.reportingInterval != null && defaultDeviceInfo.reportIntervalUnit != null && defaultDeviceInfo.reportingIntervalUnit != null) {
		const nextReportingInterval = convertTime(defaultDeviceInfo.reportingInterval, defaultDeviceInfo.reportIntervalUnit, 's' );
		defaultDeviceInfo.reportingInterval = nextReportingInterval;
	}

	return defaultDeviceInfo as unknown as DeviceInfo;
};
