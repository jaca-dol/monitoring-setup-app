/**
 * 该文件为原本的 utils.js 文件
 * 随着文件内容越来越多，为了方便维护，后续需要逐步将其拆分成多个文件
 * 因为 utils.js 使用的地方众多，为了不影响功能，还是保留了该文件，做了重命名
 * !!! 如需新增请在utils文件夹中创建新的文件，不要在该文件中添加新的代码
 */

import _ from 'lodash';

import {
	DeviceInfo, EM_SENSORS, FREQUENCY, getDeviceIsNeutral, getModelSeries, getNeutralDeviceModel, HAS_THRESHOLD_SENSORS, LORA_PARAMS_KEYS,
	MODEL_SERIES, MODEL_SUPPORT_SENSORS, MODELS, PRIVATE_KEYS, SENSOR_KEYS_TYPE, SensorData, SENSORS, SUPPORT_UNIT_CHANGE_SENSORS,
} from '../';
import translate from '../../utils/translate';
import { math } from '../../utils/util';
import { Version } from '../../utils/util/Version';
import { DeviceConfigManager } from '../config/DeviceConfigManager';
import { identify } from '../identify';
import { isSupportSettings } from './isSupportSetting';

/**
 * 根据区域，返回freq输入的最大值和最小值
 *
 * @param {String} freqRegion
 * @returns -  {min, max}
 */
export const getFreqLimit = 
	function (freqRegion: FREQUENCY) {
		let min, max;

		switch (freqRegion) {
			case FREQUENCY.US915:
				min = 902.3;
				max = 914.2;
				break;
			case FREQUENCY.AU915:
				min = 915.2;
				max = 928.0;
				break;
			case FREQUENCY.CN470:
				min = 470.3;
				max = 489.3;
				break;
			case FREQUENCY.AS923:
				min = 915.0;
				max = 928.0;
				break;
			case FREQUENCY.KR920:
				min = 920.9;
				max = 923.3;
				break;
			case FREQUENCY.EU433:
				min = 433.175;
				max = 434.665;
				break;
			case FREQUENCY.IN865:
				min = 865.0;
				max = 867.0;
				break;
			case FREQUENCY.RU864:
				min = 864.0;
				max = 870.0;
				break;
			case FREQUENCY.EU868:
			default:
				min = 863.0;
				max = 870.0;
				break;
		}

		return { min, max };
	};


export const getShowFreqsLength = (freqRegion: FREQUENCY, singleChannelMode: boolean) => {
	let length = 0;
	switch (freqRegion) {
		case FREQUENCY.US915:
		case FREQUENCY.AU915:
			length = 5;
			break;
		case FREQUENCY.CN470:
			length = 6;
			break;
		case FREQUENCY.CN470_INTER:
		case FREQUENCY.CN470_INTRA:
			length = 0;
			break;
		case FREQUENCY.AS923:
		case FREQUENCY.RU864:
			length = singleChannelMode ? 3 : 8;
			break;
		case FREQUENCY.EU433:
			length = 8;
			break;
		case FREQUENCY.KR920:
		case FREQUENCY.IN865:
		case FREQUENCY.EU868:
		default:
			length = singleChannelMode ? 4 : 8;
			break;
	}

	return length;
};

/**
 *  获取数据速率选项
 * @param {number} freqRegion 
 * @param {string} enableFreqIndex
 */
export function getDataRateOptions(freqRegion: FREQUENCY, enableFreqIndex = "", model: MODELS) {
	let dataRateOptions = [
		{ value: 5, label: 'SF7-DR5' },
		{ value: 4, label: 'SF8-DR4' },
		{ value: 3, label: 'SF9-DR3' },
		{ value: 2, label: 'SF10-DR2' },
		{ value: 1, label: 'SF11-DR1' },
		{ value: 0, label: 'SF12-DR0' }
	];

	if(model === MODELS['WS201']) {
		dataRateOptions = [
			{ value: 5, label: 'SF7-DR5' },
			{ value: 4, label: 'SF8-DR4' },
			{ value: 3, label: 'SF9-DR3' },
			{ value: 2, label: 'SF10-DR2' }
		];
	}

	if(freqRegion === FREQUENCY.AS923) {
		dataRateOptions = [
			{ value: 5, label: 'SF7-DR5' },
			{ value: 4, label: 'SF8-DR4' },
			{ value: 3, label: 'SF9-DR3' },
			{ value: 2, label: 'SF10-DR2' }
		];
	}

	if([ FREQUENCY.US915, FREQUENCY.AU915 ].includes(freqRegion)) {
		
		const { isAbove63, isBelow63 } = getEnableFreqRange(enableFreqIndex);

		if(freqRegion === FREQUENCY.US915) {
			if(isAbove63 && isBelow63 || isBelow63) {
				dataRateOptions = [
					{ value: 3, label: 'SF7-DR3' },
					{ value: 2, label: 'SF8-DR2' },
					{ value: 1, label: 'SF9-DR1' },
					{ value: 0, label: 'SF10-DR0' }
				];
			} else if (isAbove63) {
				dataRateOptions = [
					{ value: 4, label: 'SF8-DR4' }
				];
			}
		}

		if(freqRegion === FREQUENCY.AU915) {
			if(isAbove63 && isBelow63 || isBelow63) {
				dataRateOptions = [
					{ value: 5, label: 'SF7-DR5' },
					{ value: 4, label: 'SF8-DR4' },
					{ value: 3, label: 'SF9-DR3' },
					{ value: 2, label: 'SF10-DR2' }
				];
			} else if (isAbove63) {
				dataRateOptions = [
					{ value: 6, label: 'SF8-DR6' }
				];
			}
		}

		return dataRateOptions;
	}

	return dataRateOptions;
}

/**
 * 深度比较两个object的不同
 * @param  {Object} object Object compared
 * @param  {Object} base   Object to compare with
 * @return {Object}        Return a new object who represent the diff
 */
export function difference(object: Record<string, any>, base: Record<string, any>, excludedKeys: string[] = []) {
	return _.transform(object, (result: Record<string, any>, value, key) => {
		if (!_.isEqual(value, base[key])) {
			if (_.isObject(value) && _.isObject(base[key]) && !excludedKeys.includes(key)) {
				result[key] = difference(value, base[key], excludedKeys);
			} else {
				result[key] = value;
			}
		} else if (excludedKeys.includes(key)) {
			result[key] = value;
		}
	});
}

export function isEncodeKey(key: string) {
	return _.startsWith(key, '*') && _.endsWith(key, '*');
}

/**
 * 根据设置的数据，获取最终发送给DeviceUtils的json数据
 * @param  {Object} object 要设置的对象，可能时diff后的deviceInfo，也可能是全部的deviceInfo(模版模式下)
 * @param {Object} deviceInfo 当前deviceInfo
 * @param {Object| null} prevDeviceInfo 之前的deviceInfo
 * @return {string}        最终发送给lib的json
 */
export function getSettingJSON(object: Record<string, any>, deviceInfo: Partial<DeviceInfo>, _prevDeviceInfo: Partial<DeviceInfo> | null, isTemplateMode: boolean) {
	const SENSORS_KEYS = _.keys(SENSORS);
	const subChildKeys = [
		'password',
		'reportingInterval',
		'cumulative',
		'gps',
		'sleepMode',
		'displayMode',
		'deviceState',
		'alarmReporting',
		'description',
		'powerSupplyState',
		'interface1v3Output',
		'interface2v3Output',
		'solenoidConnectPwrOn',
		'classaResponseTime',
		'reportEnableType',
		'collectInterval',
		'apn',
		'apnUser',
		'apnPassword',
		'CSQ',
		'registerNetworkTime',
		'buttonLight',
		'powerMeter',
		'buttonLock',
		'overcurrentAlarm',
		'overcurrentProtect',
		'proximityEnable',
		'buzzMode',
		'PIRIdleInterval',
		'keyd2d',
		'd2dSlave',
		'd2dOdor',
		'udlSensorSwitch',
		'screenMode',
		'screenBackgroundColor',
		'enableScreenSmart',
		'enableScreenDisplay',
		'enableDataStorage',
		'retransmitEnable',
		'ledMode',
		'enableBuzzStop',
		'soilType',
		'weightFreq',
		'weightTime',
		'buttonLockId',
		'gpioMode1',
		'gpioMode2',
		'keyMode',
		'rainPeriod',
		'exceedCollectInterval',
		'di',
		'tofTestMode',
		'tofTestModeContinueTime',
		'bodyHeight',
		'jitterTime',
		'doubleClick',
		'buttonMode',
		'templateId',
		'leastRefresh',
		'workMode',
		'transmit',
		'linkageSwitch',
		'surPlus',
		'sleepConfig',
		'reportingIntervalUnit',
		'screenLastUpdate',
		'globalCollectInterval',
		'globalAlarmTime',
		'globalDismissReport',
		'screenLeastRefreshInterval',
		'rulesForEngine',
		'reportMode',
		'locateConfig',
		'geoFence',
		'planAngle',
		'applicationMode',
		'cellularConfig',
		'serverPort',
		'ch1',
		'ch2',
		'temperatureUnit',
		'serverAddress',
		'systemEnable',
		'tempCtrlMode',
		'fanMode',
		'fanDelay',
		'fanWorkTime',
		'hour24',
		'targetTemp',
		'targetRange',
		'glblError',
		'autoError',
		'timezone',
		'timezoneMin',
		'daylightSaveTime',
		'wireConnection',
		'tempCtrlPlan',
		'installMode',
		'tempControl',
		'frostProtection',
		'childrenLock',
		'heatingPlan',
		'heatRules',
		'switchMode',
		'pulsedFilterMode',
		'pulsedFilterTime',
		'pressureMode',
		'pressureType',
		'pressureOsl',
		'pressureOsh',
		'interfaceOutput',
		'pressureRangeMin',
		'pressureRangeMax',
		'solenoidRulesEngine',
		'autoConfirmed',
		'reportingCounts',
		'consoleEnable',
		'distanceRange',
		'caseMode',
		'workPattern',
		'enableRps',
		'fanHumiAdjust',
		'humiRange',
		'dehumiCtrl',
		'tstatOwner',
		'reportValveChange',
		'valveConfig',
		'ambientDisplay',
		'validRange',
		'reportingMode',
		'D2DRecv',
		'd2dDataSender',
		'enableTemp',
		'enableHumi',    
		'alarmLed',
		'targetResolution',
		'yauxEnable',
		'buttonLockMask',
		'doubleSetPoint',
		'pirSensitivity',
		'radarSensitivity',
		'sleepTime',
		'illuminationEnable',
		'liquidJudgmentValue0',
		'liquidJudgmentValue1',
		'liquidJudgmentValue2',
		'liquidJudgmentValue3',
		'heatTargetTemp',
		'coolTargetTemp',
		'timedSystemControl',
		'peopleDetection',
		'brightGrade',
		'illumination',
		'customName',
		'airplaneModeTimePeriodSettings',
		'fullStorageAlarm',
		'activatedState',
		'activatedState',
		'occupiedConfig',
		'customLevelConfig',
		'deadBand'
	].concat(SENSORS_KEYS);
	// 如果有以下 key，则需要忽略, 不下发
	const ignoreDeviceInfoKeys = [ 'deviceEui', 'model', 'modelSeries', 'reportIntervalUnit', 'deviceTime', 'deviceState', 'screenCustomImageSource' ]; //设备信息相关的key
	const ignoreTslInfoKeys = [ 'tslVersion', 'batteryInfo', 'checkPasswordReply', 'region', 'productFrequencyBand', 'deviceInformation', 'timestamp' ]; //物模型相关的key
	const ignoreFormStateKey = [ 'changePassword', 'changeDaylightSaveTime', 'timezonePicker', 'offsetTime' ]; //表单层相关的key（在表单层表示表单状态）
	const ignoreKeys = ignoreDeviceInfoKeys.concat(ignoreTslInfoKeys).concat(ignoreFormStateKey);
	// WT30X值为 0 的 retransmitInterval / retrievalInterval 不下发
	// 根本原因是固件bug默认值下错误导致，APP兼容处理
	const model = _.get(deviceInfo, 'model') || _.get(deviceInfo, 'statusModel') || '';
	const isWT30XModel = getModelSeries(model) === MODEL_SERIES['WT30X'];
	if (isWT30XModel) {
		[ 'retransmitInterval', 'retrievalInterval' ].forEach(k => {
			if (object[k] === 0) {
				ignoreKeys.push(k);
			}
		});
	}
	const privateKeys = PRIVATE_KEYS;
	const ucKey = [ 'rs485', 'rs232', 'channels', 'gpioSetting', 'aiSetting', 'sdi12' ];
	const settingObject = _.transform(object, function (result: Record<string, any>, value, key) {
		if (LORA_PARAMS_KEYS.includes(key)) { // LoRa 相关参数处理

			if (key === 'freqs') { //freqs需要全部传递
				result['pLoRaWANParams'][key] = deviceInfo['freqs'];
			} else if (key === 'multicast') { //组播加密需要全部传递，且有加密key时过滤对应key
				_.set(result, 'pLoRaWANParams.multicast', deviceInfo?.multicast?.map(multi => {
					const pickKeys = _.keys(multi).filter(k => !_.includes([ 'address', 'appskey', 'nwkskey' ], k));
					//如果为空表示不覆盖原本设备中的该项配置
					multi.address !== '' && !isEncodeKey(multi.address) && pickKeys.push('address');
					multi.appskey !== '' && !isEncodeKey(multi.appskey) && pickKeys.push('appskey');
					multi.nwkskey !== '' && !isEncodeKey(multi.nwkskey) && pickKeys.push('nwkskey');

					if(multi.freq != null) {
						multi['freq'] = _.toNumber(multi.freq);
					}

					return _.pick(multi, pickKeys);
				}));
			} else if (privateKeys.includes(key)) {
				const isAllStar = value.startsWith('*') && value.endsWith('*');
				if (value != '' && !isAllStar) { //如果为空表示不覆盖原本设备中的该项配置
					result['pLoRaWANParams'][key] = value;
				}
			} else if (key === 'appEUI' || key === 'deviceAddress') {
				if (value != '') {
					result['pLoRaWANParams'][key] = value;
				}
			} else if (key === 'freqRegion') {
				const hasEnableFreqIndexRegion = [ FREQUENCY.CN470, FREQUENCY.AU915, FREQUENCY.US915 ].includes(value);
				const hasFreqs = !hasEnableFreqIndexRegion;

				//如果变更的新频段需要enableFreqIndex，而下发的参数中没有，则需要将其加入到下发参数中
				//因为如果只是变更频段，enableFreqIndex没有变化就不会下发，这里是做特殊处理
				if (hasEnableFreqIndexRegion && !_.has(object, 'enableFreqIndex')) {
					result['pLoRaWANParams']['enableFreqIndex'] = deviceInfo.enableFreqIndex;
				} else if (hasFreqs && !_.has(object, 'freqs')) {
					result['pLoRaWANParams']['freqs'] = deviceInfo.freqs;
				}

				result['pLoRaWANParams'][key] = value;
			} else if (key === 'd2dCfg') {
				const d2dKey = _.get(value, 'key', '');
				const d2dKeyIsAllStar = d2dKey.startsWith('*') && d2dKey.endsWith('*');

				//如果d2d key为全星号，表示不覆盖原本设备中的该项配置，则不下发key
				if(d2dKeyIsAllStar) {
					value = _.omit(value, 'key');
				}

				//去掉key之后，如果value为空对象，则无需下发
				if(!_.isEmpty(value)) {
					result['pLoRaWANParams'][key] = value;
				}
			} else {
				result['pLoRaWANParams'][key] = value;
			}
		} else if (subChildKeys.includes(key)) {
			const notDiffKeys = [ 'd2dSlave', 'buttonLockId', 'sleepConfig', 'rulesForEngine', 'targetTemp', 'targetRange', 'tempCtrlPlan', 'valveConfig',
				'D2DRecv', 'buttonLockMask', 'sleepTime', 'timedSystemControl', 'peopleDetection', 'customLevelConfig' ];

			if(SENSOR_KEYS_TYPE.includes(key) && _.has(value, 'threshold')) {
				const sensorThreshold = _.get(deviceInfo, `${key}.threshold`, value.threshold);
				const thresholdLow = _.get(sensorThreshold, 'low', '');
				const thresholdHigh = _.get(sensorThreshold, 'high', '');
				
				//如果阈值为非空字符串，则要将其转为number
				if(_.isString(thresholdLow) && thresholdLow !== '') {
					_.set(sensorThreshold, 'low', math.toNumber(thresholdLow));
				}

				//如果阈值为非空字符串，则要将其转为number
				if(_.isString(thresholdHigh) && thresholdHigh !== '') {
					_.set(sensorThreshold, 'high', math.toNumber(thresholdHigh));
				}

				_.set(value, 'threshold', sensorThreshold);

				if(_.has(value, 'threshold.continueTime') || _.has(value, 'threshold.lockTime')) {
					_.set(value, `threshold.continueTime`, 0);
					_.set(value, `threshold.lockTime`, 0);
				}
			}

			if(SENSOR_KEYS_TYPE.includes(key) && _.has(value, 'value') || _.has(value, 'rawValue')) {
				value = _.omit(value, [ 'rawValue', 'value' ]);
			}

			if(key === 'keyd2d') {
				const keyD2d = _.get(deviceInfo, 'keyd2d', []);
				value = keyD2d.map(m => _.omit(m, 'label'));
			}

			if(notDiffKeys.includes(key)) {
				value = _.get(deviceInfo, key, value);
			}

			if(key === 'buttonLock' && value === false && isSupportSettings('buttonLockId', deviceInfo?.model ?? '')) {
				key = 'buttonLockId';
				value = [];
			}

			if(key === 'workMode') {
				// workMode 全部下发
				value = deviceInfo['workMode'];
			}

			if(key === 'airplaneModeTimePeriodSettings') {
				// 飞行模式时间段设置全部下发
				value = deviceInfo['airplaneModeTimePeriodSettings'];
			}

			if(key === 'sleepConfig') {
				// sleepConfig 全部下发
				value = deviceInfo['sleepConfig'];
			}

			if(key === 'rulesForEngine') {
				// rulesForEngine 全部下发
				value = deviceInfo['rulesForEngine'];
			}

			if(key === 'solenoidRulesEngine') {
				// solenoidRulesEngine 全部下发
				value = deviceInfo['solenoidRulesEngine'];
			}

			if(key === 'heatingPlan') {
				// heatingPlan内部的字段有更改才全部下发
				if(_.has(value, 'heatPeriod')) {
					_.set(value, 'heatPeriod', _.get(deviceInfo, 'heatingPlan.heatPeriod'));
				}

				if(_.has(value, 'heatRules')) {
					_.set(value, 'heatRules', _.get(deviceInfo, 'heatingPlan.heatRules'));
				}
			}

			if(key === 'transmit') {
				/**
				 * 如果是从模版来的数据，
				 * 则mqtt数据中字段为'*'号表示不下发，
				 * 则要将这些字段过滤
				 */
				const mqttData = _.get(value, 'mqtt');
				//遍历出mqtt数据中 key和value
				_.forOwn(mqttData, (v, k) => {
					//如果字段的值是 “*”
					if (v === '*') {
						//删除该字段
						_.unset(mqttData, k);
					}
				});

				// transmit的值如果是数组，需要全部下发
				_.forOwn(value, (subValue, subKey) => {
					if(Array.isArray(subValue)) {
						value[subKey] = deviceInfo[key][subKey];
					}
				});
			}

			result[key] = value;
		} else if (ucKey.includes(key)) { //控制设备特殊处理逻辑
			if(key === 'rs232' || key === 'rs485' || key === 'sdi12') {
				_.forOwn(value, (subValue, subKey) => {
					if(Array.isArray(subValue)) {
						value[subKey] = deviceInfo[key][subKey];
					}
				});
			}

			result[key] = value;

			if(key === 'channels') {
				result['channels'] = deviceInfo['channels'];
			}
		} else if (!ignoreKeys.includes(key)) { //其他参数处理，如果不是忽略的key，则直接传递
			// 如果是数组，需要全部下发
			if(Array.isArray(value)) {
				value = deviceInfo[key];
			}

			result[key] = value;
		}

		return result;
	}, {
		'pLoRaWANParams': {}
	});

	if(isTemplateMode) {
		_.set(settingObject, 'model', object.model); //template模式传入model用于判断写入的型号与设备信息是否匹配
	}

	//避免出现当修改的新密码为默认密码时，diff不出密码改变，导致新密码无法写入的问题
	if(deviceInfo.changePassword === true && !_.has(settingObject, 'password')) {
		settingObject['password'] = deviceInfo.password;
	}

	//避免出现没修改密码，却将设备密码写入的问题
	if(_.has(settingObject, 'password') && deviceInfo.changePassword !== true) {
		console.debug('getSettingJSON', `setting has password but not change password action, will drop the password -> ${settingObject['password']}`);
		settingObject['password'] = undefined;
	}

	if(deviceInfo.distanceRange){
		// distanceRange 由[12,6,6]变成[12,12,6]会diff成[6]，写入时需要保持完整数组，故不作diff处理
		settingObject['distanceRange'] = deviceInfo.distanceRange;
	}
	
	//过滤出空对象，空值的属性
	const pickedObject = _.pickBy(settingObject, 
		(value, key) => {
			if (_.isNumber(value)) {
				return true;
			}

			if(_.isBoolean(value)) {
				return true;
			}

			if(_.includes([ 'channels', 'buttonLockId' ,'rulesForEngine', 'temperatureControlPlan' ], key)) {
				return true;
			}

			if(_.isArray(value)) {
				return true;
			}
		
			if(_.isObject(value)) {
				const isEmptyObject = _.every(value, v => {
					if(_.isObject(v) && _.isEmpty(v)) {
						return true;
					}

					return false;
				});

				return !isEmptyObject;
			}

			return !_.isEmpty(value);
		}
	);

	// 配合固件hack: 仅修改证书的情况下，如果是aws的证书，写入服务器地址的配置来触发设备重载，如果是mqtt的证书，写入TLS的使能来触发设备重载
	if( deviceInfo?.awsCertificateWriteSuccess && _.isEmpty(_.omit(pickedObject, 'awsCertificateWriteSuccess')) && _.has(deviceInfo, 'transmit.aws.serverIp')) {
		_.set(pickedObject, 'transmit.aws.serverIp', deviceInfo?.transmit?.aws?.serverIp);
		_.unset(pickedObject, 'awsCertificateWriteSuccess');
	}
	if( deviceInfo?.mqttCertificateWriteSuccess && _.isEmpty(_.omit(pickedObject, 'mqttCertificateWriteSuccess')) && _.has(deviceInfo, 'transmit.mqtt.tlsEnable')) {
		_.set(pickedObject, 'transmit.mqtt.tlsEnable', deviceInfo?.transmit?.mqtt?.tlsEnable);
		_.unset(pickedObject, 'mqttCertificateWriteSuccess');
	}
	
	const settingJSON = JSON.stringify(pickedObject);

	console.debug('object: ', JSON.stringify(object));
	console.debug('settingJSON: ', settingJSON);

	return settingJSON;
}

/**
 * 获取设备型号选项
 * 如果该型号不存在于默认型号中，则返回一个选项（该型号）
 * @deprecated 该函数已废弃，请使用useDeviceModelOptions
 * @export
 * @param {Boolean} isTemplateMode
 * @param {Object} deviceInfo
 * @returns Array
 */
export function getDeviceModelOptions(isTemplateMode: boolean, deviceInfo: DeviceInfo) {
	const model = _.get(deviceInfo, 'model', '');
	const statusModel = _.get(deviceInfo, 'statusModel', model); //用于显示的model（带有频率）
	const defaultOptions = _.uniq(_.values(MODELS))
		.filter(v => {
			return v !== MODELS.UNKNOWN;
		})
		.sort()
		.map(value => ({ label: value, value: value }));
	const ownOptions = [{ label: statusModel, value: model }];
	const isInclude = !_.isNil(_.find(defaultOptions, option => option.value === model));

	if (isTemplateMode && isInclude) {
		//如果是中性版本，显示中性版本的型号
		if (getDeviceIsNeutral(deviceInfo?.oem)) {
			return defaultOptions.map(m => ({ ...m, label: getNeutralDeviceModel(m.label, deviceInfo?.oem) }));
		}

		return defaultOptions;
	}

	return ownOptions;
}

/**
 * 格式化输出form错误信息
 *
 * @deprecated 该函数已经迁移到useForm.ts，如果需要使用，请使用useForm
 * @param {Object} error form的错误信息/自定义error{code: 1, message: 'xxxx'}
 * @param {string} formKey 表单的prop
 * @param {Object} extraInfo 额外要传递的信息
 * @returns 
 */
export function formatFormError(error: Record<string, any>, formKey = '', extraInfo: Record<string, any> = {}) {
	
	
	if(_.has(error, 'code') && _.has(error, 'message')) {
		return error;
	}
	
	
	const errors = _.get(error, 'errors', {});
	const keys = _.keys(errors) || [];
	const defaultErrorMessage = `${formKey} Error`;

	if (keys.length > 0) {
		const key = keys[0]!;
		const keyErrors = _.get(getPropInDeepObj(_.get(errors, key, {}), 'errors'), '[0]', []);
		const message = _.get(keyErrors, `[0].message`, defaultErrorMessage);
		const field = _.get(keyErrors, '[0].field', key);
		console.log('formKey Field: ', field);
		const translateField = translate(`setting.${field}`, {defaultValue: key});
		//全局表单字段翻译
		const globalFieldTranslateMap = {
			'freqs': translate('setting.freqs'),
			'calibration.value': `${translate(`status.${key}`)} ${translate('setting.calibrationValue')}`,
			'threshold.high': `${translate(`status.${key}`)} ${translate('setting.overLabel')}`,
			'threshold.low': `${translate(`status.${key}`)} ${translate('setting.belowLabel')}`,
			'threshold.collectInterval': `${translate(`status.${key}`)} ${translate('setting.collectInterval')}`,
			'globalCollectInterval': `${translate('setting.collectInterval')}`,
			'threshold.lock': translate('setting.alarmReportingInterval'),
			'threshold.continue': translate('setting.alarmReportingTimes'),
			'alarmReporting.interval': translate('setting.alarmReportingInterval'),
			'cumulative.count':translate('setting.cumulative'),
			'gps.staticDuration':translate('setting.staticDuration'),
			'gps.reportMove.interval':translate('setting.activityReportingInterval'),
			'gps.moveDuration':translate('setting.moveDuration'),
			'transmit.mqtt.name':translate('setting.username'),
			'transmit.mqtt.password':translate('setting.password'),
			'transmit.aws.serverIp':translate('setting.serverIp'),
			'transmit.aws.serverPort':translate('setting.serverPort'),
			'transmit.tcp.serverIp':translate('setting.serverIp'),
			'transmit.tcp.serverPort':translate('setting.serverPort'),
			'transmit.udp.serverIp':translate('setting.serverIp'),
			'transmit.udp.serverPort':translate('setting.serverPort'),
			'transmit.mqtt.serverIp':translate('setting.MQTTServerIp'),
			'transmit.mqtt.serverPort':translate('setting.serverPort'),
			'overcurrentAlarm.value': '',
			'overcurrentProtect.value': '',
			'buttonLockId': translate('setting.buttonLock.label'),
			'reportMode.fixedMode.timePoint': translate('setting.motionReportTime'),
			'reportMode.regularMode.reportingInterval': translate('setting.reportingInterval'),
			'reportMode.motionMode.reportingInterval': translate('setting.reportingInterval'),
			'distance.abnormalCheck.finalValue': translate('setting.outlierValue'),
			'distance.abnormalCheck.percentage': translate('setting.outlierRange'),
			'saltationValue': translate('setting.saltationValue'),
			'PIRIdleInterval': translate('setting.idleTimeReporting.label'),
			'cellularConfig.pin': translate('setting.pin'),
			'ctrlTime':translate('setting.controlTime.label'),
			'ch1.temperature.threshold.alarmInterval': translate('setting.alarmReportingInterval'),
			'ch2.temperature.threshold.alarmInterval': translate('setting.alarmReportingInterval'),
			'ch1.temperature.threshold.alarmTime': translate('setting.alarmReportingTimes'),
			'ch2.temperature.threshold.alarmTime': translate('setting.alarmReportingTimes'),
			'di.pulseConversion.waterYield': translate('setting.pulseValueConversion'),
			'di.pulseConversion.waterPulse': translate('setting.pulseValueConversion'),
			'di.pulseConversion.unit': translate('setting.pulseValueConversion'),
			'di': translate('setting.counterValues'),
			'waterThreshold.decisionTime': translate('setting.decisionTime'),
			'waterThreshold.flowRunning.excessValue': translate('setting.timeoutInterval'),
			'waterThreshold.flowStopping.excessValue': translate('setting.timeoutInterval'),
		};
		//传入的额外表单字段翻译
		const extraFieldTranslateMap = _.get(extraInfo, 'fieldTranslateMap', {});
		const fieldTranslateMap = _.extend({}, globalFieldTranslateMap, extraFieldTranslateMap);
		const specialFieldTranslate = _.get(fieldTranslateMap, field) || _.find(fieldTranslateMap, (_value, key) => field.includes(key));
		const label = !_.isNil(specialFieldTranslate) ? 
			specialFieldTranslate : 
			translateField;
		const errorMessage = label === '' 
			? message
			: `${label}: ${message}`;
		const omitExtraInfoKeys = ['fieldTranslateMap'];

		return {
			code: 1,
			message: errorMessage,
			..._.omit(extraInfo, omitExtraInfoKeys)
		};
	}

	return defaultErrorMessage;
}

/**
 * 获取object中所有的key的属性值
 *
 * @deprecated 该函数目前仅被formatFormError使用，已经迁移到useForm.ts，如果需要使用，请使用useForm
 * @param {Object} obj
 * @param {string} key
 * @example getPropInDeepObj({ 'a': 1, 'b': 2, 'c': {'d':{'e':7}}}, "d");//[7] 
 * @example getPropInDeepObj({ 'aa': 1, 'bb': 2, 'cc': {'d':{'x':9}}, dd:{'d':{'y':9}}}, 'd');//[ {x: 9}, {y: 9} ]
 * @returns {array} result
 */
export function getPropInDeepObj(obj: Record<string, any>, key: string) {
	if (_.has(obj, key)) {
		return [obj[key]];
	}

	return _.flatten(_.map(obj, (value: any): any[] => {
		return _.isObject(value) ? getPropInDeepObj(value, key) : [];
	}));
}

/**
 * 获取型号支持的传感器
 * @param {string} model
 * @param {object|undefined} deviceInfo 
 */
export function getModelSupportSensors(model: MODELS | 'All' | string, deviceInfo?: DeviceInfo) {
	const modelSeries = getModelSeries(model);
	const supportSensors = _.get(
		MODEL_SUPPORT_SENSORS, 
		model, 
		_.get(MODEL_SUPPORT_SENSORS, modelSeries, [])
	);
	
	if (identify(model).isTS30X()) {
		const currentSensor = getTS30XSupportSensors(deviceInfo);
		supportSensors.push(...currentSensor);
	}

	if (model.includes('UC51') && Version.isLessThan(deviceInfo?.hardwareVersion ?? '', 'v4.0')) {
		const pressureIndex = supportSensors.findIndex((sensor: any) => sensor.key === SENSORS.pressure);
		// uc51x uc51x-cat V4之前的硬件版本都去掉常用设置里面的压力单位配置
		if (~pressureIndex) {
			supportSensors.splice(pressureIndex, 1);
		}
	}

	return supportSensors;
	
}

export function getDefaultSensorData(model: MODELS | 'All' | string, key: SENSORS, deviceInfo: DeviceInfo) {
	const modelSensors = getModelSupportSensors(model, deviceInfo);
	const sensor = _.find(modelSensors, sensor => sensor.key === key);
	let defaultData = {
		key,
		enable: true,
		value: '',
		unit: _.get(sensor, 'unit', ''),
		calibration: {
			enable: false,
			value: ''
		},		
	};
	const isEM = model === 'All' ? true : isEMSeries(model);

	if(HAS_THRESHOLD_SENSORS.includes(key)) {
		_.set(defaultData, 'threshold', {
			enable: false,
			high: '',
			low: '',
			continueTime: 0,
			lockTime: 0,
			collectInterval: 60
		});
	}

	if(isEM && EM_SENSORS.includes(key)) {
		_.set(defaultData, 'abnormalCheck', {
			enable: false,
			range: 50,
			percentage: 20
		});
	}

	// @ts-ignore
	if(isAM107SpecialThresholdSensor(model, key)) {
		_.set(defaultData, 'alarmScreen', {
			enable: false,
			value: ''
		});
	}

	if(key === SENSORS.temperature) {
		_.set(defaultData, `prevUnit`, sensor.unit);
	}

	if(model === MODELS['WS202']) {
		// @ts-ignore
		defaultData = _.omit(defaultData, ['calibration']);
	}

	return defaultData;
}

/**
 * 获取设备设置数据
 * 忽略设备设置中不需要用到的数据（纯状态显示的值、当前设备不支持的传感器数据等）
 *
 * @export
 * @param {Object} deviceInfo
 * @returns deviceInfo 忽略后的设备数据
 */
export function getDeviceSettingInfo(deviceInfo: Partial<DeviceInfo>) {
	const deviceSetting = _.cloneDeep(deviceInfo);
	const model = _.get(deviceInfo, 'model', '');
	const isNBDevice = identify(model).isNBDevice();
	const allSensorKeys = MODEL_SUPPORT_SENSORS['All'].map(sensor => sensor.key);
	// @ts-ignore
	const supportSensorKeys = getModelSupportSensors(model, deviceInfo).map(sensor => sensor.key);
	const omitSensorKeys = allSensorKeys.filter(key => !supportSensorKeys.includes(key));
	const omitOtherKeys = [ 'status', 'battery', 'channelMask', 'downLinkFrameCounter', 'hardwareVersion', 'firmwareVersion', 'joinStatus', 'statusModel', 'sn', 'rssi', 'snr', 'upLinkFrameCounter', 'updateTime', 'applyFromTemplate'  ];
	const omitKeys = omitOtherKeys.concat(omitSensorKeys);
	
	if(_.has(deviceInfo, 'enableFreqIndex')) {
		const hasEnableFreqIndexRegion = [ FREQUENCY.CN470, FREQUENCY.AU915, FREQUENCY.US915 ];

		if(hasEnableFreqIndexRegion.includes(_.get(deviceInfo, 'freqRegion') as FREQUENCY)) {
			omitKeys.push('freqs');
			console.log('omit freqs');
		} else {
			omitKeys.push('enableFreqIndex');
			console.log('omit enableFreqIndex');
		}
	}

	if(_.has(deviceInfo, 'multicast') && !isSupportSettings('multicast', deviceInfo?.model ?? '')) {
		omitKeys.push('multicast');
	}

	//如果设备不支持供暖计划，则忽略供暖计划
	if(_.has(deviceInfo, 'heatingPlan') && !isSupportSettings('heatingPlan', deviceInfo?.model ?? '')) {
		omitKeys.push('heatingPlan');
	}

	//为了避免diff出现问题，这里直接使用表单最新的d2dSlave配置
	if(_.has(deviceInfo, 'd2dSlave')) {
		omitKeys.push('d2dSlave');
	}

	//为了避免diff出现问题，这里直接使用表单最新的D2DRecv配置
	if(_.has(deviceInfo, 'D2DRecv')) {
		omitKeys.push('D2DRecv');
	}

	if(_.has(deviceInfo, 'sleepConfig')) {
		omitKeys.push('sleepConfig');
	}

	if(_.has(deviceInfo, 'sleepTime')) {
		omitKeys.push('sleepTime');
	}

	if (isNBDevice) {
		omitKeys.push(...LORA_PARAMS_KEYS, 'supportRandomKey', 'supportFreq');
	}

	return _.omit(deviceSetting, omitKeys);
}

// export function readFloat16LE(bytes) {
// 	var bits = (bytes[1] << 8) | bytes[0];
// 	var sign = bits >>> 15 === 0 ? 1.0 : -1.0;
// 	var e = (bits >>> 10) & 0x1f;
// 	var m = e === 0 ? (bits & 0x3ff) << 1 : (bits & 0x3ff) | 0x400;
// 	var f = sign * m * Math.pow(2, e - 25);
// 	return f;
// }

/**
 * 阈值输入框根据输入最大值/最小值获取mode字段的取值
 *
 * @param {number | string} high - the high value
 * @param {number | string} low - the low value
 * @return {number} the mode value
 */
export const getMode = (high: number | string, low: number | string) => {

	//禁用
	if (high === '' && low === '') {
		return 0;
	}

	//X < A(threshold_min | low)
	if (high === '' && low !== '') {
		return 1;
	}

	//X > B(threshold_max | high)
	if (low === '' && high !== '') {
		return 2;
	}

	//A(threshold_min | high) < X < B(threshold_max | low)
	if (low > high) {
		return 3;
	}

	//Min < A(threshold_min | low) || X > B(threshold_max | high)
	if (low < high) {
		return 4;
	}

	return 1;
};

/**
 * 计算传感器的原始值
 * 设备端传过来的是原始值 + 校准值 = 最终值，所以要减去校准值
 * @export
 * @param {Number} finalValue
 * @param {Number} calibrationValue
 * @returns {Number} rawValue
 */
export function getSensorRawValue(finalValue: number | string, calibrationValue: number | string) {
	const rawValue = _.toNumber(finalValue) - _.toNumber(calibrationValue);
	const decimalLength = math.getDecimalLength(finalValue);

	return _.isNumber(rawValue) && !_.isNaN(rawValue) ? math.fixedNumber(rawValue, decimalLength) : '-';
}

export function toNumberSensorValue(deviceInfo: DeviceInfo) {
	
	return _.transform(deviceInfo, (result: Record<string, any>, value, key) => {

		if(SENSOR_KEYS_TYPE.includes(key)) {
			const sensorValueKeys = [ 'value', 'calibration.value', 'threshold.value', 'threshold.high', 'threshold.low' ];

			_.forEach(sensorValueKeys, sensorValueKey => {
				if(_.has(value, sensorValueKey)) {
					_.set(value, sensorValueKey, math.toNumber(_.get(value, sensorValueKey)));
				}
			});

			result[key] = value;
		} else {
			result[key] = value;
		}

		return result;
	}, {});
}

/**
 * 获取传感器单位
 * @param sensor
 * @param {object} sensorData
 * @param {object} deviceInfo
 * @param defaultUnit 默认单位
 * @returns {string} unit
 */
export function getSensorUnit(sensor: SENSORS, sensorData: SensorData, deviceInfo: DeviceInfo, defaultUnit: string) {
	if(sensor === SENSORS.loudness) {
		return _.get([ 'dB', 'dBA', 'dBC' ], deviceInfo.weightFreq, 'dB');
	}

	return sensorData.unit ? sensorData.unit : defaultUnit;
}

export const REPORTING_INTERVAL_UNIT = {
	0: 's',
	1: 'min',
	2: 'hour',
	's': 0,
	'min': 1,
	'hour': 2
};
/**
 * 时分秒的互换
 * @export
 * @param {number} time 时间
 * @param {string|number} nextUnit 要转换的单位: s, min, hour
 * @param {string|number} prevUnit 当前的单位: s, min, hour
 * @returns number
 */
export function convertTime(time: number | string, nextUnit: string | number, prevUnit: string | number = 'min'): number {

	if(time === 0) {
		return 0;
	}

	if(!_.isNumber(time) || _.isNaN(_.toNumber(time))) {
		return time as number;
	}

	if (_.isNumber(nextUnit)) {
		// @ts-ignore
		nextUnit = REPORTING_INTERVAL_UNIT[nextUnit];
	}

	if (_.isNumber(prevUnit)) {
		// @ts-ignore
		prevUnit = REPORTING_INTERVAL_UNIT[prevUnit];
	}

	let convertTime = time;

	switch (`${prevUnit}-${nextUnit}`) {
		case 'h-m':
		case 'hour-min':
			convertTime = _.toNumber(time * 60);
			break;
		case 'h-s':
		case 'hour-s':
			convertTime = _.toNumber(time * 3600);
			break;

		case 'min-hour':
		case 'm-h':
			convertTime = _.toNumber(time / 60);
			break;
		case 'min-s':
		case 'm-s':
			convertTime = _.toNumber(time * 60);
			break;

		case 's-h':
		case 's-hour':
			convertTime = _.toNumber(time / 3600);
			break;
		case 's-min':
		case 's-m':
			convertTime = _.toNumber(time / 60);
			break;
		case 's-hms':
			convertTime = _.toNumber(time * 10);
			break;
		case 's-ms':
			convertTime = _.toNumber(time * 1000);
			break;
		
		case 'ms-s':
			convertTime = _.toNumber(time / 1000);
			break;
		case 'ms-hms':
			convertTime = _.toNumber(time / 100);
			break;

		case 'hms-s':
			convertTime = _.toNumber(time / 10);
			break;
		case 'hms-ms':
			convertTime = _.toNumber(time * 100);
			break;

		default:
			convertTime = time;
			break;
	}

	return convertTime;
}

export function isEMSeries(model: MODELS | string) {
	const emModels = _.keys(MODELS).filter(key => key.startsWith('EM'));
	return emModels.includes(model);
}

export function isAMSeries(model: MODELS) {
	return [ MODELS['AM104'], MODELS['AM107'] ].includes(model);
}

export function isEM300Series(model: MODELS) {
	return model.startsWith('EM300');
}

export function isAM107SpecialThresholdSensor(model: MODELS, sensor: SENSORS) {
	return model === MODELS['AM107'] && [ SENSORS['co2concentration'], SENSORS['tvoc'] ].includes(sensor);
}

/**
 * 判断是否为WS50X机械式海外版本
 * @param {string} model 
 * @returns {boolean}
 */
export function isWX50XOverseas(model: MODELS) {
	return model.startsWith('WS50') && (model.includes('EU') || model.includes('US') );
}

/**
 * 判断是否是WS50X机械式国内版
 * @param {string} model 
 * @returns {boolean}
 */
export function isWS50XCN(model: MODELS) {
	return model?.includes('EUD');
}

/**
 * 判断是否是WS50X机械式（海外跟国内）
 * @param {string} model 
 * @returns {boolean}
 */
export function isWS50XMECH(model: MODELS | string) {
	// @ts-ignore
	return isWS50XCN(model) || isWX50XOverseas(model);
}

/**
 * 判断是不是WS558v2
 * @param {string} model 
 * @param {string} sn 
 * @returns 
 */
export function isWS558V2(model: MODELS, sn: string) {
	return model === MODELS['WS558'] && sn.startsWith('6756');
}

/**
 * 获取启用通道的范围是否低于63，或者高于63
 * @param {string} enableFreqIndex 
 */
export function getEnableFreqRange(enableFreqIndex: string) {
	let value = enableFreqIndex;
	if( (!_.isUndefined(value) && value.toLowerCase() === 'all') || value === '') {
		return {
			isBelow63: true,
			isAbove63: true
		};
	}

	value = _.includes(value, '，') ? _.replace(value, /，/g, ',') : value;
	value = _.includes(value, '——') ? _.replace(value, /——/g, '-') : value;
	value = _.includes(value, '-') ? value.split('-').join(',') : value;

	const freqArr = value ? value.split(',') : [];    
	const isBelow63 = freqArr.some(v => _.inRange(_.toNumber(v), 0, 64));
	const isAbove63 = freqArr.some(v => _.inRange(_.toNumber(v), 64, 72));
	
	return {
		isBelow63,
		isAbove63
	};
}

/**
 * 获取支持单位换算的传感器及其单位选项
 */
export const getModelSupportUnitChangeSensors = _.memoize((deviceInfo: DeviceInfo) => {
	const { model, hardwareVersion, firmwareVersion } = deviceInfo;
	const supportSensors = getModelSupportSensors(model as MODELS, deviceInfo);

	if (identify(model).isWTSv2(hardwareVersion, firmwareVersion) || identify(model).isWTSv3(hardwareVersion, firmwareVersion)) {
		supportSensors.push({ key: SENSORS.temperature, unit: "℃" });
	}

	return supportSensors.reduce((result: Record<string, any>[], currentSensor: { key: SENSORS, unit: string }) => {

		const supportUnitChangeSensorIndex = _.findIndex(SUPPORT_UNIT_CHANGE_SENSORS, { sensor: currentSensor.key });
		const hasRepeatSensorKeyIndex = result.findIndex(s => s.sensor === currentSensor.key);

		if(supportUnitChangeSensorIndex != -1 && hasRepeatSensorKeyIndex == -1) {
			// @ts-ignore
			result.push(SUPPORT_UNIT_CHANGE_SENSORS[supportUnitChangeSensorIndex]);
		}

		return result;
	}, []);
}, deviceInfo => deviceInfo.model);


//假设version为vx.x
export const getVersionArr = (version: string) => {

	if(!_.isString(version)) {
		throw new Error('version 必须是个字符串');
	}

	const _version = version.indexOf('-') != -1 
		? version.split('-')[0] 
		: version;
	const allversion = _version?.trim().toLowerCase().startsWith('v') ? 
		_version.slice(1) : 
		_version;

	return allversion?.split('.').map(v => _.toNumber(v));
};

/**
 * 是否大于该版本
 */
export const isGreaterVersion = (targeVersion: string, baseVersion: string) => {
	const targeVersionArr = getVersionArr(targeVersion);
	const baseVersionArr = getVersionArr(baseVersion);
	let isGreater = false;

	if((targeVersionArr && targeVersionArr.length < 1) || (baseVersionArr && baseVersionArr.length < 1)) {
		throw new Error('版本格式不对，应为xx.xx或xx.xx.xx');
	}

	for (let index = 0; index < (targeVersionArr?.length ?? 0); index++) {
		const tVersion = targeVersionArr?.[index] ?? 0;
		const bVersion = baseVersionArr?.[index] ?? 0;

		if(tVersion > bVersion) {
			isGreater = true;
			break;
		} else if (tVersion < bVersion) {
			break;
		}
	}

	return isGreater;
};

/**
 * 是否大于等于指定版本
 * @param {string} targeVersion 
 * @param {string} baseVersion 
 */
export const isGreaterOrEqualVersion = (targeVersion: string, baseVersion: string) => {
	

	const isGreater = isGreaterVersion(targeVersion, baseVersion);

	if(isGreater) {
		return true;
	}

	const targeVersionArr = getVersionArr(targeVersion);
	const baseVersionArr = getVersionArr(baseVersion);
	let equalCount = 0;

	for (let index = 0; index < (targeVersionArr?.length ?? 0); index++) {
		const tVersion = targeVersionArr?.[index] ?? 0;
		const bVersion = baseVersionArr?.[index] ?? 0;

		if(tVersion === bVersion) {
			equalCount += 1;
		} else {
			break;
		}
	}

	return equalCount === (baseVersionArr?.length ?? 0);
};

/**
 * 检查设备固件版本是否支持配置确认包和数据速率
 */
export const getIsSupportConfirmPackageAndDataRate = _.memoize(
	(firmwareVersion, hardwareVersion, model) => {
		if(isEM300Series(model)) {
			return true;
		} else if (isUC500Series(model)) {
			return true;
		} else if (isAMSeries(model)) {
			if(isGreaterOrEqualVersion(hardwareVersion, 'v2.0')) {
				return true;
			}

			return isGreaterOrEqualVersion(firmwareVersion, 'v1.19');
		} else if (isGreaterOrEqualVersion(firmwareVersion, 'v1.16') || isGreaterOrEqualVersion(firmwareVersion, 'v2.16')) {
			return true;
		} else {
			return true;
		}
	}, (firmwareVersion, model) => {
		return `${firmwareVersion}-${model}`;
	});

/**
 * 判断设备是否为UC500系列
 */
export const isUC500Series = _.memoize(model => _.isString(model) && getModelSeries(model) === MODEL_SERIES['UC500']);

/**
 * 获取TS30X系列支持的传感器类型
 */
export const getTS30XSupportSensors = _.memoize(deviceInfo => {
	const { ch1, ch2, model } = deviceInfo;
	let ch1SensorTemperature, ch2SensorTemperature, ch1SensorHumidity, ch2SensorHumidity, ch1SensorMagnet, ch2SensorMagnet;
	if (ch1?.temperature) {
		ch1SensorTemperature = { key: SENSORS.temperature, unit: "℃", rootKey: 'ch1' };
	}
	if (ch1?.humidity) {
		ch1SensorHumidity = { key: SENSORS.humidity, unit: "%", rootKey: 'ch1' };
	}
	if (model === MODELS['TS302'] && ch2?.temperature) {
		ch2SensorTemperature = { key: SENSORS.temperature, unit: "℃", rootKey: 'ch2' };
	}
	if (model === MODELS['TS302'] && ch2?.humidity) {
		ch2SensorHumidity = { key: SENSORS.humidity, unit: "%", rootKey: 'ch2' };
	}
	if (ch1?.magnet) {
		ch1SensorMagnet = { key: SENSORS.magnet, unit: "", rootKey: 'ch1' };
	}
	if (model === MODELS['TS302'] && ch2?.magnet) {
		ch2SensorMagnet = { key: SENSORS.magnet, unit: "", rootKey: 'ch2' };
	}
	return [ ch1SensorTemperature, ch1SensorHumidity, ch2SensorTemperature, ch2SensorHumidity, ch1SensorMagnet, ch2SensorMagnet ].filter(Boolean);
});

/**
 * 判断是否为NB系列
 */
export const isEM300NB = _.memoize((sn, model) => {
	return _.isString(model) && model.indexOf('N00CN') != -1 || _.isString(sn) && (sn.startsWith('6138'));
}, (sn, model) => `${sn}-${model}`);

/**
 * 根据频段获取TXPower的选项
 */
export const getTxPowerOptions = _.memoize(freq => {
	let options = [];

	switch (freq) {
		case FREQUENCY.US915:
			options = [
				{ label: 'TXPower0-22 dBm', value: 0 },
				{ label: 'TXPower1-22 dBm', value: 1 },
				{ label: 'TXPower2-22 dBm', value: 2 },
				{ label: 'TXPower3-22 dBm', value: 3 },
				{ label: 'TXPower4-22 dBm', value: 4 },
				{ label: 'TXPower5-20 dBm', value: 5 },
				{ label: 'TXPower6-18 dBm', value: 6 },
				{ label: 'TXPower7-16 dBm', value: 7 },
				{ label: 'TXPower8-14 dBm', value: 8 },
				{ label: 'TXPower9-12 dBm', value: 9 },
				{ label: 'TXPower10-10 dBm', value: 10 },
				{ label: 'TXPower11-8 dBm', value: 11 },
				{ label: 'TXPower12-6 dBm', value: 12 },
				{ label: 'TXPower13-4 dBm', value: 13 },
				{ label: 'TXPower14-2 dBm', value: 14 }
			]; 
			break;
		case FREQUENCY.AU915:
			options = [
				{ label: 'TXPower0-22 dBm', value: 0 },
				{ label: 'TXPower1-22 dBm', value: 1 },
				{ label: 'TXPower2-22 dBm', value: 2 },
				{ label: 'TXPower3-22 dBm', value: 3 },
				{ label: 'TXPower4-22 dBm', value: 4 },
				{ label: 'TXPower5-20 dBm', value: 5 },
				{ label: 'TXPower6-18 dBm', value: 6 },
				{ label: 'TXPower7-16 dBm', value: 7 },
				{ label: 'TXPower8-14 dBm', value: 8 },
				{ label: 'TXPower9-12 dBm', value: 9 },
				{ label: 'TXPower10-10 dBm', value: 10 },
				{ label: 'TXPower11-8 dBm', value: 11 },
				{ label: 'TXPower12-6 dBm', value: 12 },
				{ label: 'TXPower13-4 dBm', value: 13 },
				{ label: 'TXPower14-2 dBm', value: 14 }
			]; 
			break;
		case FREQUENCY.AS923:
			options = [
				{ label: 'TXPower0-16 dBm', value: 0 },
				{ label: 'TXPower1-14 dBm', value: 1 },
				{ label: 'TXPower2-12 dBm', value: 2 },
				{ label: 'TXPower3-10 dBm', value: 3 },
				{ label: 'TXPower4-8 dBm', value: 4 },
				{ label: 'TXPower5-6 dBm', value: 5 },
				{ label: 'TXPower6-4 dBm', value: 6 },
				{ label: 'TXPower7-2 dBm', value: 7 }
			]; 
			break;
		case FREQUENCY.KR920:
			options = [
				{ label: 'TXPower0-14 dBm', value: 0 },
				{ label: 'TXPower1-12 dBm', value: 1 },
				{ label: 'TXPower2-10 dBm', value: 2 },
				{ label: 'TXPower3-8 dBm', value: 3 },
				{ label: 'TXPower4-6 dBm', value: 4 },
				{ label: 'TXPower5-4 dBm', value: 5 },
				{ label: 'TXPower6-2 dBm', value: 6 },
				{ label: 'TXPower7-0 dBm', value: 7 }
			]; 
			break;
		case FREQUENCY.CN470:
			options = [
				{ label: 'TXPower0-19.15 dBm', value: 0 },
				{ label: 'TXPower1-17.15 dBm', value: 1 },
				{ label: 'TXPower2-15.15 dBm', value: 2 },
				{ label: 'TXPower3-13.15 dBm', value: 3 },
				{ label: 'TXPower4-11.15 dBm', value: 4 },
				{ label: 'TXPower5-9.15 dBm', value: 5 },
				{ label: 'TXPower6-7.15 dBm', value: 6 },
				{ label: 'TXPower7-5.15 dBm', value: 7 }
			];
			break;
		case FREQUENCY.EU433:
			options = [
				{ label: 'TXPower0-12.15 dBm', value: 0 },
				{ label: 'TXPower1-10.15 dBm', value: 1 },
				{ label: 'TXPower2-8.15 dBm', value: 2 },
				{ label: 'TXPower3-6.15 dBm', value: 3 },
				{ label: 'TXPower4-4.15 dBm', value: 4 },
				{ label: 'TXPower5-2.15 dBm', value: 5 }
			];
			break;
		case FREQUENCY.IN865:
			options = [
				{ label: 'TXPower0-22 dBm', value: 0 },
				{ label: 'TXPower1-22 dBm', value: 1 },
				{ label: 'TXPower2-22 dBm', value: 2 },
				{ label: 'TXPower3-22 dBm', value: 3 },
				{ label: 'TXPower4-22 dBm', value: 4 },
				{ label: 'TXPower5-20 dBm', value: 5 },
				{ label: 'TXPower6-18 dBm', value: 6 },
				{ label: 'TXPower7-16 dBm', value: 7 },
				{ label: 'TXPower8-14 dBm', value: 8 },
				{ label: 'TXPower9-12 dBm', value: 9 },
				{ label: 'TXPower10-10 dBm', value: 10 }
			];
			break;
		case FREQUENCY.RU864:
			options = [
				{ label: 'TXPower0-16 dBm', value: 0 },
				{ label: 'TXPower1-14 dBm', value: 1 },
				{ label: 'TXPower2-12 dBm', value: 2 },
				{ label: 'TXPower3-10 dBm', value: 3 },
				{ label: 'TXPower4-8 dBm', value: 4 },
				{ label: 'TXPower5-6 dBm', value: 5 },
				{ label: 'TXPower6-4 dBm', value: 6 },
				{ label: 'TXPower7-2 dBm', value: 7 }
			];
			break;
		case FREQUENCY.EU868:
			options = [
				{ label: 'TXPower0-16 dBm', value: 0 },
				{ label: 'TXPower1-14 dBm', value: 1 },
				{ label: 'TXPower2-12 dBm', value: 2 },
				{ label: 'TXPower3-10 dBm', value: 3 },
				{ label: 'TXPower4-8 dBm', value: 4 },
				{ label: 'TXPower5-6 dBm', value: 5 },
				{ label: 'TXPower6-4 dBm', value: 6 },
				{ label: 'TXPower7-2 dBm', value: 7 }
			];
			break;
		default:
			options = _.fill(Array(15), 'TXPower').map((value, index) => ({ value: index, label: value + index }));
			break;
	}

	return options;
});

export const getClassTypeOptions = (model: MODELS | string) => {
	const deviceSettingService = DeviceConfigManager.getDeviceConfigService(model);
	const serviceClassTypeOptions = deviceSettingService?.getClassTypeOptions != null
		? deviceSettingService.getClassTypeOptions()
		: undefined;

	//如果设备设置服务有返回ClassType选项，则使用设备设置服务的ClassType选项，否则使用全局的ClassType选项
	if(_.isArray(serviceClassTypeOptions)) {
		return serviceClassTypeOptions;
	}

	const modelSeries = getModelSeries(model);
	const supportClassTypeMap = {
		'ClassA': {
			isSupport: (model: MODELS, modelSeries: MODEL_SERIES) => {
				if(isAMSeries(model) || isEMSeries(model)) {
					return true;
				}

				if(_.includes([ MODEL_SERIES['AM103'], MODEL_SERIES['AM102'], MODEL_SERIES['UC500'], MODEL_SERIES['UC51X'], MODEL_SERIES['WS100'], MODEL_SERIES['WS130'], MODEL_SERIES['WS150'], MODEL_SERIES['WS200'], MODEL_SERIES['WS300'], MODEL_SERIES['WTS'], MODEL_SERIES['TS30X'] ], modelSeries)) {
					return true;
				}

				if(_.includes([ MODELS['GS301'], MODELS['AM307'], MODELS['AM307L'], MODELS['AM308'], MODELS['AM308L'], MODELS['AM304L'], MODELS['AM305L'] , MODELS['VS330'], MODELS['DS3604'], MODELS['WS201'], MODELS['TS101'], MODELS['AT101'] , MODELS['VS340'], MODELS['VS341'], MODELS['VS350'], MODELS['VS351'], MODELS['VS360'], MODELS['WT101'], MODELS['TS201'], MODELS['VS321'], MODELS['VS370'], MODELS['UC521'] ], model)) {
					return true;
				}

				return false;
			},
			option: { label: 'Class A', value: 0 }
		},
		'ClassB': {
			isSupport: (model: MODELS, modelSeries: MODEL_SERIES) => {

				if(_.includes([MODEL_SERIES['UC51X']], modelSeries)) {
					return true;
				}

				if(_.includes([ MODELS['WS501-2W'],  MODELS['WS502-2W'], MODELS['WS503-2W'], MODELS['WS501EUD-2W'], MODELS['WS502EUD-2W'], MODELS['WS503EUD-2W'], MODELS['DS3604'], MODELS['UC521'],MODELS['WS501EUD'], MODELS['WS502EUD'], MODELS['WS503EUD'], ], model)) {
					return true;
				}

				return false;
			},
			option: { label: 'Class B', value: 1 }
		},
		'ClassC': {
			isSupport: (model: MODELS, modelSeries: MODEL_SERIES) => {

				if(_.includes([ MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['WS550'] ], modelSeries)) {
					return true;
				}

				if(_.includes([ MODELS['AM319-HCHO'], MODELS['AM319-HCHO-IR'], MODELS['AM319-HCHO-IR-W'], MODELS['AM319-O3'], MODELS['AM319L-HCHO-IR'], MODELS['AM319L-O3'], MODELS['UC501'], MODELS['UC511'], MODELS['UC511-DI'], MODELS['JT-GS101'], MODELS['WT201'], MODELS['WT211'], MODELS['GS601'],  MODELS['WT401'], MODELS['UC521'] ], model)) {
					return true;
				}

				return false;
			},
			option: { label: 'Class C', value: 2 }
		},
		'ClassC to B': {
			isSupport: (model: MODELS) => {
				return _.includes([ MODELS['UC511'], MODELS['UC511-DI'], MODELS['WS501EUD-2W'], MODELS['WS502EUD-2W'], MODELS['WS503EUD-2W'], MODELS['UC521'], MODELS['WS501EUD'], MODELS['WS502EUD'], MODELS['WS503EUD'] ], model);
			},
			option: { label: 'Class C to B', value: 3 }
		}	
	};

	const options = _.values(supportClassTypeMap).reduce((result, currentType) => {
		const isSupportCurrentType = currentType.isSupport(model as MODELS, modelSeries as MODEL_SERIES);

		if(isSupportCurrentType) {
			// @ts-ignore
			result.push(currentType.option);
		}

		return result;
	}, []);
	
	return options;
};

/**
 * 获取d2d频率设置的限制值
 */
export const getD2dFreqLimit = _.memoize(
	function (freqRegion) {
		let min, max;

		switch (freqRegion) {
			case FREQUENCY.US915:
			case FREQUENCY.AU915:
			case FREQUENCY.AS923:
			case FREQUENCY.KR920:
				min = 902.3;
				max = 927.8;
				break;
			case FREQUENCY.CN470:
			case FREQUENCY.EU433:
				min = 470.3;
				max = 509.7;
				break;
			case FREQUENCY.IN865:
			case FREQUENCY.RU864:
			case FREQUENCY.EU868:
			default:
				min = 862.0;
				max = 870.0;
				break;
		}

		return { min, max };
	}
);

// export const parseJSONSafely = jsonString=> {
// 	try {
// 		return JSON.parse(jsonString);
// 	} catch (e) {
// 		console.error('解析 JSON 字符串出错:', e);
// 		// 容错：将不能被正确解析的 JSON 对象的值设为空字符串
// 		return JSON.parse(jsonString, (key, value) => {
// 			if (typeof value === 'string') {
// 				try {
// 					JSON.parse(value);
// 				} catch (e) {
// 					console.error(`解析 JSON 对象 ${key} 出错: 不支持的字符编码`);
// 					return '';
// 				}
// 			}
// 			return value;
// 		});
// 	}
// };

// APP是否为中性版本
export const getApplicationIsNeutral = () => translate.isNeutral;

/**
 * 判断是否需要禁用D2D功能
 * @returns
 */
export const getNeedToDisableD2D = ({
	classType, 
	masterEnable,
	slaveEnable,
	deviceInfo
}: {
	classType: number,
	masterEnable: boolean,
	slaveEnable: boolean,
	deviceInfo: DeviceInfo
}) => {
	const isClassB = classType === 1 || classType === 3;
	const d2dMasterEnable = masterEnable != null
		? masterEnable
		: _.get(deviceInfo, 'd2dCfg.enableMaster');
	const d2dSlaveEnable = slaveEnable != null
		? slaveEnable
		: _.get(deviceInfo, 'd2dCfg.enable');
	const d2dEnable = d2dMasterEnable || d2dSlaveEnable;
	
	return deviceInfo.modelSeries === MODEL_SERIES['WS500'] && isClassB && d2dEnable;
};