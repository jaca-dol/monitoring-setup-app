import { Platform } from 'react-native';

import { extend, has, includes, isArray, isFunction, isNil, memoize } from 'lodash';

import { AM300_DISPLAY_MODELS, EM400NB_SERIES, MODEL_SERIES, MODELS } from '../../model';
import { DeviceSettingServiceExtendSupportSettingKey } from '../../model/';
import { DeviceConfigManager } from '../../model/config';
import { DeviceInfo } from '../../model/deviceInfo';
import { Identify, identify } from '../../model/identify';
import { getModelSeries } from '../../model/model';
import { Version } from '../../utils/util/Version';
import { getModelSupportSensors } from './migrationUtils';

const versionArr = (condition = [false]) => condition.every(Boolean);

/**
 * 支持配置的型号映射表
 */
export const supportSettingMap = {
	/**
	 * LoRaWAN设置
	 */
	'lorawanSettings': {
		isSupport: function(model: MODELS) {
			return !identify(model).isNBDevice();
		}
	},

	/**
	 * 数据采集设置
	 */
	'dataCollectionSettings': {
		supportModels: [ MODELS['AM104'], MODELS['AM107'], MODELS['EM500-SMTC-MEC20'], MODELS['EM500-CO2'] ],
		supportModelSeries: [MODEL_SERIES['AM300']]
	},

	/**
	 * 校准设置
	 */
	'calibrationSettings': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(includes([ MODEL_SERIES['UC51X'], MODEL_SERIES['UC500'], MODEL_SERIES['WS100'], MODEL_SERIES['WS130'], MODEL_SERIES['WS150'], MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['WS550'] ], modelSeries)) {
				return false;
			}
	
			if (includes([ MODEL_SERIES['EM300-SW'], MODELS['EM300-DI-HALL'], MODELS['WS301'], MODELS['EM310-TILT'], MODELS['EM320-TILT'], MODELS['EM400-TLD'], MODELS['EM400-TLD-N03GL'], MODELS['WS201'],MODELS['WS202'] ], model)) {
				return false;
			}

			const supportSensors = getModelSupportSensors(model, deviceInfo);
	
			if(supportSensors && supportSensors.length === 0) {
				return false;
			}
	
			return true;
		}
	},

	/**
	 * 阈值设置
	 */
	'thresholdSettings': {
		isSupport: function (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {

			if (isNil(deviceInfo)) {
				return false;
			}

			if (includes([ MODEL_SERIES['UC51X'], MODEL_SERIES['UC500'], MODEL_SERIES['WS100'], MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['WS550'], MODELS['WT101'] ], modelSeries)) {
				return false;
			}

			if (includes([ MODEL_SERIES['EM300-SW'], MODELS['WS301'], MODELS['EM310-TILT'], MODELS['EM320-TILT'] ], model)) {
				return false;
			}

			if (includes([MODELS['AT101']], model)) {
				return true;
			}

			if (includes([MODEL_SERIES['WTS']], modelSeries) && (identify(model).isWTSv2(deviceInfo.hardwareVersion, deviceInfo.firmwareVersion) || identify(model).isWTSv3(deviceInfo.hardwareVersion, deviceInfo.firmwareVersion))) {
				return true;
			}

			if(model === MODELS['EM300-DI-HALL'] && !Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3')) {
				return false;
			}

			const supportSensors = getModelSupportSensors(model, deviceInfo);

			if (supportSensors && supportSensors.length === 0) {
				return false;
			}

			return true;
		}
	},
	/**
	 * 串口设置
	 */
	'serialSettings': {
		supportModelSeries: [ MODEL_SERIES['UC500'], MODEL_SERIES['UC500NB'] ]
	},

	/**
	 * GPIO设置
	 */
	'gpioSettings': {
		supportModelSeries: [ MODEL_SERIES['UC500'], MODEL_SERIES['UC500NB'] ]
	},

	/**
	 * AI设置
	 */
	'aiSettings': {
		supportModelSeries: [ MODEL_SERIES['UC500'], MODEL_SERIES['UC500NB'] ]
	},

	/**
	 * 接口设置
	 */
	'interfaceSettings': {
		supportModels: [ MODELS['EM300-DI'],MODELS['EM300-DI-HALL'] ]
	},
	/**
	 * 蜂窝网络设置
	 */
	'cellularSettings': {
		isSupport: function (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if (isNil(deviceInfo)) {
				return false;
			}

			if (EM400NB_SERIES.includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3')){
				return true;
			}

			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['UC500NB']]: true,
			};

			return supportModelSeries[modelSeries];

		}
	},

	/**
	 * 应用模式设置
	 */
	'applicationModeSettings': {
		supportModels: EM400NB_SERIES,
	},

	/**
	 * 警报设置
	 */
	'alarmSettings': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['EM300-MCS']]: true,
				[MODEL_SERIES['EM300-WL']]: true,
				[MODEL_SERIES['EM300-SW']]: true,
				[MODEL_SERIES['EM300-ZLD']]: true,
				[MODEL_SERIES['EM300-SLD']]: true,
				[MODEL_SERIES['EM300-MLD']]: true,
				[MODEL_SERIES['EM300-CL']]: true,
				[MODEL_SERIES['EM300-DI']]: Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3') && deviceInfo.di?.mode == 1, // isSupportSettings 的cacheKey 中会用到 deviceInfo.di?.mode，所以在这判断并不会有缓存问题
			};

			const supportModel :Record<string, boolean> = {
				[MODELS['WS303']]: true
			};
			
			return supportModelSeries[modelSeries] || supportModel[model] || false;
		}
	},

	/**
	 * 警报设置-警报项
	 */
	'alarmOption': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['EM300-DI']]: Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3'),
			};
			
			return supportModelSeries[modelSeries] || false;
		}	
	},

	/* 
	 * 脉冲值转换
	 */
	'pulseConversion': {
		isSupport: function (_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if (isNil(deviceInfo)) {
				return false;
			}
			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['EM300-DI']]: Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3'),
			};

			return supportModelSeries[modelSeries] || false;
		}
	},

	/**
	 * 电子水墨屏设置
	 */
	'displaySettings': {
		supportModels: [MODELS['WS156']]
	},

	/**
	 * D2D设置
	 */
	'd2dSettings': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES,deviceInfo?: DeviceInfo) {
			return isSupportSettings('d2dCfg', model, deviceInfo);
		}
	},

	/**
	 * 角度阈值设置
	 */
	'angleThresholdSettings': {
		supportModels: [ MODELS['EM310-TILT'], MODELS['EM320-TILT'] ]
	},

	/**
	 * DS显示模版配置
	 */
	'templateSetting': {
		supportModels: [MODELS['DS3604']]
	},

	/**
	 * 指示灯
	 */
	'buttonLight': {
		supportModelSeries: [ MODEL_SERIES['AM103'], MODEL_SERIES['WS100'], MODEL_SERIES['WS200'], MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['AM102'] ],
		supportModels: [ MODELS['GS301'], MODELS['WS301'], MODELS['WS302'], MODELS['VS340'], MODELS['VS341'], MODELS['WS203'] ]
	},

	'buttonLightTip': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES) {
			const isSupportButtonLight = isSupportSettings('buttonLight', model);
			return isSupportButtonLight && !includes([ MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['AM102'] ], modelSeries) && model != MODELS['WS302'];
		}
	},
	
	/**
	 * PIR空闲时间间隔
	 */
	'PIRIdleInterval': {
		supportModelSeries: [MODEL_SERIES['WS200']],
		supportModels: [ MODELS['VS340'], MODELS['VS341'] ]
	},
	
	/**
	 * 组播
	 */
	'multicast': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			const supportModel: Record<string, boolean> = {
				'UC501': true,
				[MODELS['WT201']]: true,
				[MODELS['WT211']]: true
			};

			const supportModelSeries: Record<string, boolean> = {
				'WS500': true,
				'WS51X': true,
				'WS520': true,
				'WS550': true,
				'DS': true,
				'UC51X': Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0'),
			};
			
			return supportModelSeries[modelSeries] || supportModel[model] || false;
		}
	},
	
	/**
	 * 组播打开接收窗口周期
	 */
	'pingSlotPeriod': {
		supportModelSeries: [ MODEL_SERIES['WS200'], MODEL_SERIES['WS300'], MODEL_SERIES['WS500'], MODEL_SERIES['WS550'], MODEL_SERIES['UC51X'], MODEL_SERIES['DS'] ]
	},
	
	/**
	 * 指定网关
	 */
	'gwSpecific': {
		isSupport: (_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) => {
			if(isNil(deviceInfo)) {
				return false;
			}
			const strategyForModelSeries: Record<string, boolean> = {
				'WS500': (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0') && Version.isLessThan(deviceInfo.firmwareVersion, 'v1.7')) 
						|| (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0') && Version.isLessThan(deviceInfo.firmwareVersion, 'v1.2')),
				'WS550': true,
			};
			return strategyForModelSeries[modelSeries] || false;
		}
	},

	'window2': {
		isSupport: function(_model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const isLinkWANOEM = deviceInfo?.oem === '0001';

			return !isLinkWANOEM;
		}
	},

	/**
	 * d2d全局参数配置
	 */
	'd2dCfg': {
		isSupport: function (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const getSupportModelSeries = () => {
				if (isNil(deviceInfo)) {
					return false;
				}
				const supportModelSeries: Record<string, boolean> = {
					[MODEL_SERIES['WS500']]: true,
					[MODEL_SERIES['WS51X']]: true,
					[MODEL_SERIES['WS520']]: true,
					[MODEL_SERIES['EM300-DI']]: Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3'),
				};
				return supportModelSeries[modelSeries];
			};
			const supportModel: Record<string, boolean> = {
				[MODELS['VS340']]: true,
				[MODELS['VS341']]: true,
				[MODELS['WS101']]: true,
				[MODELS['WS136']]: true,
				[MODELS['WS156']]: true,
				[MODELS['WS202']]: true,
				[MODELS['WS203']]: true,
				[MODELS['WS301']]: true,
				[MODELS['WS303']]: true,
				[MODELS['WS558']]: true,
				[MODELS['GS301']]: true,
				[MODELS['EM300-TH']]: true,
				[MODELS['EM300-MCS']]: true,
				[MODELS['EM300-MLD']]: true,
				[MODELS['EM300-ZLD']]: true,
				[MODELS['EM300-SLD']]: true,
				[MODELS['VS350']]: true,
				[MODELS['VS351']]: true,
				[MODELS['VS360']]: true,
				[MODELS['WT201']]: true,
				[MODELS['WT211']]: true
			};

			return getSupportModelSeries() || supportModel[model] || false;
		}
	},

	/**
	 * 主控配置
	 */
	"keyd2d": {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
	
			const getSupportModelSeries = ()=>{
				if(isNil(deviceInfo)) {
					return false;
				}
				const supportModelSeries: Record<string, boolean> = {
					[MODEL_SERIES['EM300-DI']]: Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3'),
				};
				return supportModelSeries[modelSeries];
			};
	
			const supportModel :Record<string, boolean> = {
				[MODELS['VS340']]: true,
				[MODELS['VS341']]: true,
				[MODELS['WS101']]: true,
				[MODELS['WS136']]: true,
				[MODELS['WS156']]: true,
				[MODELS['WS202']]: true,
				[MODELS['WS203']]: true,
				[MODELS['WS301']]: true,
				[MODELS['WS303']]: true,
				[MODELS['WS501-3W']]: true,
				[MODELS['WS502-3W']]: true,
				[MODELS['WS503-3W']]: true,
				[MODELS['EM300-TH']]: true,
				[MODELS['EM300-MCS']]: true,
				[MODELS['EM300-ZLD']]: true,
				[MODELS['EM300-MLD']]: true,
				[MODELS['EM300-SLD']]: true,
				[MODELS['VS350']]: true,
				[MODELS['WT201']]: true,
				[MODELS['WT211']]: true,
				[MODELS['VS351']]: true,
				[MODELS['VS360']]: true
			};

			if(modelSeries === MODEL_SERIES['WS500'] && model.includes('EUD')) {
				return true;
			}

			if(identify(model).isWS50XEUUSV0102(deviceInfo?.firmwareVersion ?? '')) {
				return true;
			}
			
			return getSupportModelSeries() || supportModel[model] || false;
		}
	},

	/**
	 * LoRaD2D被控设置
	 */
	"d2dSlave": {
		supportModels: [MODELS['WS558']],
		supportModelSeries: [ MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'] ]
	},

	/**
	 * D2D同时支持主控和被控设置
	 * 注意: 支持此项需要再配置 主控(keyd2d) 和 被控(d2dSlave)
	 */
	'd2dMasterAndSlave': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			// 1. 基于型号的判断
			const supportedModels = [
				MODELS['WS501-3W'],
				MODELS['WS502-3W'],
				MODELS['WS503-3W'],
				MODELS['WT201'],
				MODELS['WT211']
			];
			const isSupportedModel = supportedModels.includes(model);

			const isSupportedVersion = deviceInfo 
				? identify(model).isWS50XEUUSV0102(deviceInfo.firmwareVersion ?? '')
				: false;

			const isSupportedEUD = modelSeries === MODEL_SERIES['WS500'] && model.includes('EUD');

			return isSupportedModel || isSupportedVersion || isSupportedEUD;
		}
	},

	/**
	 * D2D按键状态
	 */
	"enableStatus": {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const supportedModels = [
				MODELS['WS501-3W'],
				MODELS['WS502-3W'],
				MODELS['WS503-3W']
			];
			const isSupportedModel = supportedModels.includes(model);

			const isSupportedVersion = deviceInfo 
				? identify(model).isWS50XEUUSV0102(deviceInfo.firmwareVersion ?? '')
				: false;

			const isSupportedEUD = modelSeries === MODEL_SERIES['WS500'] && model.includes('EUD');

			return isSupportedModel || isSupportedVersion || isSupportedEUD;
		}
	},

	/**
	 * D2D气味设置
	 */
	'd2dOdor': {
		supportModels: [MODELS['GS301']]
	},

	/**
	 * 开关机切换按钮
	 */
	'deviceStateSwitch': {
		isSupport: function (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {

			if([ MODELS['WS301'], MODELS['WS303'], MODELS['JT-GS101'], MODELS['WS201'], MODELS['WS202'], MODELS['WT101'], MODELS['WT201'], MODELS['WT211'] ].includes(model)) {
				return false;
			}

			if(includes([ MODEL_SERIES['WS100'], MODEL_SERIES['WS130'], MODEL_SERIES['WS150'], MODEL_SERIES['WS51X'] ], modelSeries)) {
				return false;
			}

			if(isNil(deviceInfo)) {
				return false;
			}

			if(identify(model).isWS50XMECH() || identify(model).isWS50XTouchV2(deviceInfo.hardwareVersion)) {
				return false;
			}

			return true;
		}
	},

	/**
	 * 重启设备
	 */
	'restart': {
		isSupport: function (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {

			if([ MODELS['WS301'], MODELS['WS303'], MODELS['JT-GS101'], MODELS['WS201'], MODELS['WS202'], MODELS['WT101'], MODELS['WT201'], MODELS['WT211'] ].includes(model)) {
				return true;
			}

			if(includes([ MODEL_SERIES['WS100'], MODEL_SERIES['WS130'], MODEL_SERIES['WS150'], MODEL_SERIES['WS51X'], MODEL_SERIES['UC500NB'] ], modelSeries)) {
				return true;
			}

			if(isNil(deviceInfo)) {
				return false;
			}

			if (identify(model).isWS50XMECH() || (modelSeries === MODEL_SERIES['WS500'] && Version.isGreaterThanOrEqualTo(deviceInfo?.hardwareVersion, 'v2.0'))) {
				return true;
			}

			return false;
		}
	},

	/**
	 * 存满告警
	 */
	'fullStorageAlarm': {
		isSupport: function(_model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			return Identify.isEM320THCert(deviceInfo.sn) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.7');
		}
	},
	
	/**
	 * 传感器阈值采集周期
	 */
	'thresholdCollectInterval': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}

			const supportModels = [
				MODELS['EM300-DI'], MODELS['EM300-TH'], MODELS['EM300-SLD'], MODELS['EM300-ZLD'], MODELS['EM300-MCS'],
				MODELS['EM310-UDL'], MODELS['EM320-TH'], MODELS['TS101'], MODELS['WS203']
			];	
			
			const supportModelSeries = [
				MODEL_SERIES['EM500-SWL'], MODEL_SERIES['EM500-LGT'],  MODEL_SERIES['EM500-PP'], MODEL_SERIES['EM500-UDL'],
				MODEL_SERIES['EM500-SMT'], MODEL_SERIES['EM400-UDL'], MODEL_SERIES['EM400-TLD'], MODEL_SERIES['UC500']
			];

			const supportGlobalIntervalModelList = [
				MODEL_SERIES['EM500-CO2'],
				MODEL_SERIES['EM500-SMTC'],
				MODEL_SERIES['EM500-PT100']
			];
			
			if (Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5') && Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0')) {
				return supportModels.includes(model) || supportModelSeries.includes(modelSeries);
			} else {
				const allSupportedModelSeries = [ ...supportModelSeries, ...supportGlobalIntervalModelList ];
				return supportModels.includes(model) || allSupportedModelSeries.includes(modelSeries);
			}

		}
	},

	/**
	 * 全局采集周期（适用于阈值中有多种类型如温度、CO2浓度而只需要一个全局采集周期的情况）
	 */
	'globalCollectInterval': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			const EM500Series = [ MODEL_SERIES['EM500-CO2'], MODEL_SERIES['EM500-SMTC'], MODEL_SERIES['EM500-PT100'] ];
			return EM500Series.includes(modelSeries) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5');
		}
	},

	/**
	 * 超阈值采集间隔
	 */
	'exceedCollectInterval': {
		supportModels: [MODELS['GS301']]
	},

	/**
	 * 异常值防止
	 */
	'abnormalCheck': {
		supportModelSeries: [ MODEL_SERIES['EM500-PAR'], MODEL_SERIES['EM500-UDL'], MODEL_SERIES['EM310-UDL'], MODEL_SERIES['EM400-UDL'] ]
	},

	/**
	 * lora version
	 */
	'loraVersion': {
		isSupport: function() {
			return true;
		}
	},

	/**
	 * 允许被设置为模板
	 */
	'templateEnable': {
		isSupport: function() {
			return true;
		}
	},

	/**
	 * 倾斜与测距联动开关 (EM310-UDL)
	 */
	'udlSensorSwitch': {
		supportModels: [MODELS['EM310-UDL']]
	},

	/**
	 * 蜂鸣器
	 */
	'buzzMode': {
		supportModelSeries: [ MODEL_SERIES['WS100'], MODEL_SERIES['AM300'] ],
		supportModels: [ MODELS['GS301'], MODELS['DS3604'], MODELS['WS303'] ]
	},

	/**
	 * 屏幕显示模式
	 * 1: 模式1, 2: 模式2, 3: 模式3
	 */
	'screenMode': {
		supportModels: AM300_DISPLAY_MODELS
	},

	/**
	 * 屏幕背景
	 */
	'screenBackgroundColor': {
		supportModels: [ MODELS['AM103'], MODELS['AM102'], ...AM300_DISPLAY_MODELS  ]
	},

	/**
	 * 屏幕上次更新
	 */
	'screenLastUpdate': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			return model === MODELS['AM102'] || (model === MODELS['AM103'] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4'));
		}
	},
	/**
	 * 至少刷新时间
	 */
	'screenLeastRefreshInterval': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			return model === MODELS['AM102'] || (model === MODELS['AM103'] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4'));
		}
	},

	/**
	 * AM10X屏幕智能模式
	 */
	'sleepMode': {
		supportModelSeries: [ MODEL_SERIES['AM104'], MODEL_SERIES['AM107'] ],
		supportModels: [ MODELS['AM103'], MODELS['AM102'] ]
	},

	/**
	 * AM10X屏幕显示模式
	 */
	'displayMode': {
		supportModelSeries: [ MODEL_SERIES['AM104'], MODEL_SERIES['AM107'] ]
	},

	'displayModeTip': {
		isSupport: function(model: MODELS) {			
			return model != MODELS['AM319-HCHO-IR-W'];
		}
	},

	/**
	 * 屏幕智能模式
	 */
	'enableScreenSmart': {
		supportModels: AM300_DISPLAY_MODELS
	},

	/**
	 * 屏幕显示
	 */
	'enableScreenDisplay': {
		supportModels: [ MODELS['AM103'], MODELS['AM102'], ...AM300_DISPLAY_MODELS ]
	},

	/**
	 * 数据存储
	 */
	'enableDataStorage': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const strategyForModel = [
				MODELS['EM320-TH'], 
				MODELS['EM300-DI'], 
				MODELS['EM300-DI-HALL'],
				MODELS['EM300-TH'], 
				MODELS['EM300-MCS'], 
				MODELS['EM300-ZLD'], 
				MODELS['EM300-SLD'],
				MODELS['AT101'],
				MODELS['TS101'],
				MODELS['AM102L'],
				MODELS['AM102'],
				MODELS['EM300-MLD'],
				MODELS['WS203'],
				MODELS['WT201'],
				MODELS['WT211'],
				MODELS['VS350'],
				MODELS['TS301'],
				MODELS['TS302'],
				MODELS['VS351'],
				MODELS['VS360'],
			].includes(model);
			const strategyForModelSeries = [ MODEL_SERIES['AM300'], MODEL_SERIES['WTS'] ].includes(modelSeries);
			const strategyForVersion = ()=>{
				if(isNil(deviceInfo)) {
					return false;
				}
				if([ MODEL_SERIES['UC51X'], MODEL_SERIES['UC500'] ].includes(modelSeries)) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0');
				}
				if([ 
					MODELS['EM300-MCS-N00CN'],
					MODELS['EM300-SLD-N00CN'],
					MODELS['EM300-ZLD-N00CN'],
					MODELS['EM300-TH-N00CN'] 
				].includes(model)
				) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
				}
				if ([ MODEL_SERIES['EM500-CO2'], MODEL_SERIES['EM500-LGT'], MODEL_SERIES['EM500-PP'], MODEL_SERIES['EM500-PT100'], MODEL_SERIES['EM500-SMTC'], MODEL_SERIES['EM500-SWL'], MODEL_SERIES['EM500-UDL'] ].includes(modelSeries)){
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5') && Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
				}
				return [ MODELS['AM103'], MODELS['AM103L'] ].includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
			};
			return strategyForModel || strategyForModelSeries || strategyForVersion();
		},
	},

	/**
	 * 数据回传
	 */
	'retransmitEnable': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const strategyForModel = [
				MODELS['EM320-TH'], 
				MODELS['EM300-DI'],
				MODELS['EM300-DI-HALL'],
				MODELS['EM300-TH'], 
				MODELS['EM300-MCS'], 
				MODELS['EM300-ZLD'], 
				MODELS['EM300-SLD'],
				MODELS['EM300-MLD'],
				MODELS['AT101'],
				MODELS['TS101'],
				MODELS['AM102L'],
				MODELS['AM102'],
				MODELS['TS301'],
				MODELS['TS302'],
				MODELS['WS203'],
				MODELS['VS350'],
				MODELS['WT201'],
				MODELS['WT211'],
				MODELS['VS351'],
				MODELS['VS360'],
			].includes(model);
			const strategyForModelSeries = [ MODEL_SERIES['AM300'], MODEL_SERIES['WTS'] ].includes(modelSeries);
			const strategyForVersion = ()=>{
				if(isNil(deviceInfo)) {
					return false;
				}
				if([ MODEL_SERIES['UC51X'], MODEL_SERIES['UC500'] ].includes(modelSeries)) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0');
				}
				if([ 
					MODELS['EM300-MCS-N00CN'],
					MODELS['EM300-SLD-N00CN'],
					MODELS['EM300-ZLD-N00CN'],
					MODELS['EM300-TH-N00CN'] 
				].includes(model)
				) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
				}
				if ([ MODEL_SERIES['EM500-CO2'], MODEL_SERIES['EM500-LGT'], MODEL_SERIES['EM500-PP'], MODEL_SERIES['EM500-PT100'], MODEL_SERIES['EM500-SMTC'], MODEL_SERIES['EM500-SWL'], MODEL_SERIES['EM500-UDL'] ].includes(modelSeries)){
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5') && Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
				}
				return [ MODELS['AM103'], MODELS['AM103L'] ].includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
			};
			return strategyForModel || strategyForModelSeries || strategyForVersion();
		},
	},

	/**
	 * LED 指示灯
	 * /0: close, 1: 常亮, 2: 闪烁
	 */
	'ledMode': {
		supportModelSeries: [MODEL_SERIES['AM300']]
	},

	/**
	 * 自动背景校准（CO2）
	 */
	'autoBackgroundCalibration': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, _deviceInfo?: DeviceInfo) {
			const supportModelSeries = [
				MODEL_SERIES['AM103'],
				MODEL_SERIES['AM300'],
			];
			return supportModelSeries.includes(modelSeries);
		}
	},

	/**
	 * 阈值告警等级
	 */
	'thresholdAlarmLevel': {
		supportModelSeries: [ MODEL_SERIES['AM103'], MODEL_SERIES['AM300'] ]
	},

	/**
	 * 光照采集配置
	 */
	'illuminanceCollection': {
		supportModels: [MODELS['WS202']]
	},

	/**
	 * 导出采集数据
	 */
	"exportData": {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const strategyForModel = [
				MODELS['JT-GS101'],
				MODELS['EM320-TH'], 
				MODELS['EM300-DI'], 
				MODELS['EM300-DI-HALL'],
				MODELS['EM300-TH'], 
				MODELS['EM300-MCS'], 
				MODELS['EM300-ZLD'], 
				MODELS['EM300-MLD'],
				MODELS['EM300-SLD'],
				MODELS['AT101'],
				MODELS['TS101'],
				MODELS['TS301'],
				MODELS['TS302'],
				MODELS['AM102L'],
				MODELS['AM102'],
				MODELS['WS203'],
				MODELS['VS350'],
				MODELS['WT201'],
				MODELS['WT211'],
				MODELS['VS351'],
				MODELS['VS360'],
			].includes(model);
			
			const strategyForModelSeries = (
				[ MODEL_SERIES['AM300'], MODEL_SERIES['WTS'] ].includes(modelSeries)
			);
			
			const strategyForVersion = ()=>{
				if(isNil(deviceInfo)) {
					return false;
				}
				if (([MODEL_SERIES['UC500']].includes(modelSeries) && Platform.OS === 'android')) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0');
				}
				if([ 
					MODELS['EM300-MCS-N00CN'],
					MODELS['EM300-SLD-N00CN'],
					MODELS['EM300-ZLD-N00CN'],
					MODELS['EM300-TH-N00CN'] 
				].includes(model)
				) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
				}
				if ([ 
					MODEL_SERIES['EM500-CO2'], 
					MODEL_SERIES['EM500-LGT'], 
					MODEL_SERIES['EM500-PP'], 
					MODEL_SERIES['EM500-PT100'], 
					MODEL_SERIES['EM500-SMTC'], 
					MODEL_SERIES['EM500-SWL'], 
					MODEL_SERIES['EM500-UDL'] 
				].includes(modelSeries)) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5') && Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
				}
				return [ MODELS['AM103'], MODELS['AM103L'] ].includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
			};
			return strategyForModel || strategyForModelSeries || strategyForVersion();
		},
	},

	/**
	 * 支持导出全部历史数据（无需输入时间）
	 */
	'exportAllData': {
		supportModels: [MODELS['JT-GS101']]
	},

	/**
	 * 清空历史数据
	 */
	'clearData': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const strategyForModel = [
				MODELS['EM320-TH'], 
				MODELS['EM300-DI'], 
				MODELS['EM300-DI-HALL'],
				MODELS['EM300-TH'], 
				MODELS['EM300-MCS'], 
				MODELS['EM300-ZLD'], 
				MODELS['EM300-MLD'],
				MODELS['EM300-SLD'],
				MODELS['AT101'],
				MODELS['TS101'],
				MODELS['TS301'],
				MODELS['TS302'],
				MODELS['AM102L'],
				MODELS['AM102'],
				MODELS['WS203'],
				MODELS['VS350'],
				MODELS['WT201'],
				MODELS['WT211'],
				MODELS['VS351'],
				MODELS['VS360'],
			].includes(model);
			const strategyForModelSeries = [ MODEL_SERIES['AM300'], MODEL_SERIES['WTS'] ].includes(modelSeries);
			const strategyForVersion = ()=>{
				if(isNil(deviceInfo)) {
					return false;
				}
				if([ MODEL_SERIES['UC51X'], MODEL_SERIES['UC500'] ].includes(modelSeries)) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0');
				}
				if([ 
					MODELS['EM300-MCS-N00CN'],
					MODELS['EM300-SLD-N00CN'],
					MODELS['EM300-ZLD-N00CN'],
					MODELS['EM300-TH-N00CN'] 
				].includes(model)
				) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
				}
				if ([ 
					MODEL_SERIES['EM500-CO2'], 
					MODEL_SERIES['EM500-LGT'], 
					MODEL_SERIES['EM500-PP'], 
					MODEL_SERIES['EM500-PT100'], 
					MODEL_SERIES['EM500-SMTC'], 
					MODEL_SERIES['EM500-SWL'], 
					MODEL_SERIES['EM500-UDL'] 
				].includes(modelSeries)) {
					return Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5') && Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
				}
				return [ MODELS['AM103'], MODELS['AM103L'] ].includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
			};
			return strategyForModel || strategyForModelSeries || strategyForVersion();
		},
	},

	/**
	 * 蜂鸣器停止
	 */
	'enableBuzzStop': {
		supportModelSeries: [MODEL_SERIES['AM300']]
	},

	/**
	 * 电流相关
	 */
	'overcurrent': {
		supportModelSeries: [ MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'] ]
	},

	/**
	 * 开关机状态
	 */
	'deviceState': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES) {
			// 解析库会返回，但是需求无需开关机状态，这里特殊处理
			if(includes([ MODEL_SERIES['WS130'], MODEL_SERIES['WS150'], MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['WS550'], MODEL_SERIES['JX'] ], modelSeries)) {
				return false;
			}

			return true;
		}
	},

	/**
	 * 设备升级
	 */
	'deviceUpgrade': {
		isSupport: function() {
			return true;
		}
	},

	/**
	 * 时区选择
	 */
	'timezonePicker': {
		isSupport: function() {
			return false;
		}
	},

	/**
	 * 设备支持差分升级
	 */
	'patchUpgrade': {
		isSupport: (model: MODELS, _modelSeries: MODEL_SERIES, { firmwareVersion, hardwareVersion }: DeviceInfo) => {
			if (!firmwareVersion || !hardwareVersion) {
				return false;
			}

			const identifier = identify(model);

			if (identifier.isAMModelSeriesV0104(firmwareVersion, hardwareVersion)) {
				return true;
			}

			return identifier.select({
				[MODELS['WT201']]: true,
				[MODELS['WT211']]: true,
				default: false
			});

		}
	},

	/**
	 * 电池
	 */
	'battery': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES) {
			if(includes([ MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['WS550'], MODEL_SERIES['JX'], MODEL_SERIES['WT2X1'] ], modelSeries)) {
				return false;
			}

			return true;
		}
	},

	/**
	 * 电磁阀本地设置
	 */
	'solenoidWork': {
		supportModelSeries: [MODEL_SERIES['UC51X']]
	},

	/**
	 * 土壤类型
	 */
	'soilType': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const strategyForModelVersion = () => {
				if(isNil(deviceInfo)) {
					return false;
				}
				const serialMap: Record<string, boolean> = {
					'EM500-SMTC': Version.isGreaterThanOrEqualTo(deviceInfo?.hardwareVersion, 'v2.0'),
				};
				
				return serialMap[modelSeries] || false;
			};
			const strategyForModelSerial = () => {
				return [MODEL_SERIES['EM500-SMT']].includes(modelSeries);
			};
			
			return strategyForModelSerial() || strategyForModelVersion() || false;
		}
	},

	/**
	 * 正常class类型
	 */
	'classType': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES) {
			return modelSeries !== MODEL_SERIES['UC51X'];
		}
	},

	/**
	 * 特别的class类型
	 */
	'specialClassType': {
		supportModelSeries: [MODEL_SERIES['UC51X']]
	},

	/**
	 * 响应时间
	 */
	'classaResponseTime': {
		supportModelSeries: [MODEL_SERIES['UC51X']]
	},

	/**
	 * 频率计权
	 */
	'weightFreq': {
		supportModels: [MODELS['WS302']]
	},

	/**
	 * 时间计权
	 */
	'weightTime': {
		supportModels: [MODELS['WS302']]
	},

	/**
	 * 接口输出供电(旧的3.3v输出供电)
	 */
	'interfaceOuptput': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			return modelSeries === MODEL_SERIES['UC500'] && deviceInfo?.rs485?.interface1v3OutputType == null;
		}
	},

	/**
	 * 3.3v接口输出供电（新）
	 */
	'interfacev3Ouptput': {
		isSupport: function(_model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			return deviceInfo?.rs485?.interface1v3OutputType != null;
		}
	},

	/**
	 * 电量统计
	 */
	'powerMeter': {
		supportModelSeries: [ MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'] ],
		supportModels: [ MODELS['WS501EU'], MODELS['WS502EU'], MODELS['WS503EU'], MODELS['WS501US'], MODELS['WS502US'], MODELS['WS503US'] ]
	},

	/**
	 * 恢复供电设备状态
	 */
	'powerSupplyState': {
		supportModelSeries: [ MODEL_SERIES['UC500'], MODEL_SERIES['UC51X'], MODEL_SERIES['WS500'], MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['WS550'], MODEL_SERIES['WTS'] ]
	},

	/**
	 * 按键接近感应
	 */
	'proximitySensor': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}

			if(identify(model).isWS50XMECH()) {
				return false;
			}

			return modelSeries === MODEL_SERIES['WS500'] && !Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0');
		}
	},
	/**
	 * 24小时制
	 */
	'hour24': {
		supportModelSeries: [MODEL_SERIES['TS30X']]
	},
	/**
	 * 按键锁
	 */
	'buttonLock': {
		isSupport: (model: MODELS, modelSeries: MODEL_SERIES) => {

			if(includes([ MODEL_SERIES['WS51X'], MODEL_SERIES['WS520'], MODEL_SERIES['AM300'], MODEL_SERIES['TS30X'] ], modelSeries)) {
				return true;
			}

			if(identify(model).isWS50XMECH()) {
				return true;
			}

			return false;
		}
	},

	/**
	 * 按键锁配置按键
	 */
	'buttonLockId': {
		isSupport: (model: MODELS, modelSeries: MODEL_SERIES) => {
			return identify(model).isWS50XMECH() || modelSeries === MODEL_SERIES['AM300'] || [ MODELS['WT201'], MODELS['WT211'] ].includes(model);
		}
	},

	/**
	 * 电磁阀接线开关
	 */
	'solenoidConnectPwrOn': {
		supportModelSeries: [MODEL_SERIES['UC51X']]
	},

	/**
	 * 自动回复确认包
	 */
	'autoConfirmed': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}

			return modelSeries === MODEL_SERIES['UC51X'] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v3.3');
		}
	},

	/**
	 * 数据上报
	 */
	'reportEnableType': {
		supportModelSeries: [MODEL_SERIES['UC51X']]
	},

	/**
	 * GPIO1/2 采集类型
	 */
	'gpioMode': {
		supportModelSeries: [MODEL_SERIES['UC51X']]
	},

	/**
	 * 防抖时间
	 */
	'jitterTime': {
		isSupport: function(_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			const supportModelSeries: Record<string, boolean> = {
				'UC51X': true
			};
			return supportModelSeries[modelSeries] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v2.5');
		}
	},

	/**
	 * 阈值解除上报
	 */
	'thresholdDismissReport': {
		supportModels: [MODELS['EM310-UDL']],
		supportModelSeries: [ MODEL_SERIES['EM400-UDL'], MODEL_SERIES['EM400-TLD'] ]
	},

	/**
	 * 累计雨量周期
	 */
	'rainPeriod': {
		supportModels: [MODELS['WTS-506']]
	},

	/**
	 * 测试模式
	 */
	'tofTestMode': {
		supportModels: [MODELS['VS330']]
	},

	/**
	 * 人体高度
	 */
	'bodyHeight': {
		supportModels: [MODELS['VS330']]
	},

	/**
	 * LoRa上行
	 */
	'loraUplink': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			const strategyForModelVersion = () => {
				if(isNil(deviceInfo)) {
					return false;
				}
				const modelMap: Record<string, boolean> = {
					'WS301': versionArr([Version.isGreaterThanOrEqualTo(deviceInfo?.firmwareVersion, 'v1.11')]),
					'EM300-DI': versionArr([Version.isGreaterThanOrEqualTo(deviceInfo?.firmwareVersion, 'v1.3')]),
					'EM300-DI-HALL': versionArr([Version.isGreaterThanOrEqualTo(deviceInfo?.firmwareVersion, 'v1.3')]),
				};
				
				return modelMap[model] || false;
			};
			const strategyForModel = () =>{
				return [ 
					MODELS['VS340'],
					MODELS['VS341'],
					MODELS['WS101'], 
					MODELS['WS202'], 
					MODELS['WS203'],
					MODELS['WS136'], 
					MODELS['WS156'], 
					MODELS['WS303'], 
					MODELS['EM300-TH'], 
					MODELS['EM300-MCS'], 
					MODELS['EM300-ZLD'], 
					MODELS['EM300-MLD'],
					MODELS['EM300-SLD'],
					MODELS['WS203'],
					MODELS['VS350'],
					MODELS['WT201'],
					MODELS['WT211'],
					MODELS['VS351'],
					MODELS['VS360'],
				].includes(model);
			};
			return strategyForModel() || strategyForModelVersion() || false;
		},
	},

	/**
   * 控制时间
   */
	'controlTime':{
		supportModels: [ MODELS['VS340'], MODELS['VS341'], MODELS['WS203'], MODELS['VS350'], MODELS['VS351'], MODELS['VS360'] ]
	},

	/**
	 * LoRa D2D双击使能
	 */
	'enableDoublePress': {
		supportModels: [MODELS['WS101']]
	},
	/**
	 * 屏下按键
	 */
	'buttonMode': {
		supportModels: [MODELS['DS3604']]
	},

	/**
	 * 模版ID
	 */
	'templateId': {
		supportModels: [MODELS['DS3604']]
	},

	/**
     * 蓝牙通配符
     */
	'bleNameWildcards': {
		isSupport: function() {
			return false;
		}
	},

	/**
	 * 屏幕至少刷新周期
	 */
	leastRefresh: {
		supportModels: [MODELS['DS3604']]
	},
	/**
	 * 通道模式
	 */
	'singleChannelMode': {
		isSupport: (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) => {
			if(isNil(deviceInfo)) {
				return false;
			}
			const strategyForModel: Record<string, boolean> = {
				'AM307': versionArr([
					Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0'),
					Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.2')
				]),
				'AM308': versionArr([
					Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0'),
					Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3')
				]),
				'WS136': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5'),
				'WS156': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5'),
				'WS202': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5'),
				'WS301': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.11'),
				'AM103': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4'),
				'AM103L': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4'),
				'EM320-TH': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.3'),
				'EM300-TH': versionArr([
					Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0'),
					Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.6')
				]),
				'EM300-MCS': versionArr([
					Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0'),
					Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.6')
				]),
				'EM300-SLD': versionArr([
					Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0'),
					Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.6')
				]),
				'EM300-ZLD': versionArr([
					Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0'),
					Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.6')
				]),
				'WS101': Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5'),
				'GS301': true,
				'WS303': true,
				'VS330': true,
				'VS340': true,
				'VS341': true,
				'WS201': true,
				'DS3604': true,
				'AM307L': true,
				'AM308L': true,
				'AM319L-HCHO-IR': true,
				'AM319L-O3': true,
				'AM102L': true,
				'AM102': true,
				'EM300-DI':true,
				'WS203': true,
				'VS350': true,
				'VS351': true,
				'VS360': true
			};
			const strategyForModelSeries: Record<string, boolean> = {
				'AM300': model.startsWith('AM319') ? 
					versionArr([
						Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0'),
						Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.2')
					]) : false,
				'WS500': (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0') && Version.isEqual(deviceInfo.firmwareVersion, 'v1.6')) 
					|| (Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v3.0') && Version.isLessThan(deviceInfo.firmwareVersion, 'v1.2')),
				'WS51X': true,
				'WS520': true,
			};
			const isEM5XXv2 = Identify.isEM5XXv2(model,deviceInfo.hardwareVersion);
			return strategyForModel[model] || strategyForModelSeries[modelSeries] || isEM5XXv2 || false;
		}
	},
	/**
	 * 倾斜与测距联动开关(通用)
	 */
	'linkageSwitch': {
		supportModelSeries: [ MODEL_SERIES['EM400-UDL'], MODEL_SERIES['EM400-TLD'] ]
	},
	/**
	 * 累计次数/次
	 */
	'cumulative': {
		supportModels: EM400NB_SERIES
	},
	/**
	 * GPS定位设置
	 */
	'gps': {
		supportModels: EM400NB_SERIES
	},
	/**
	 * 持续运动时间
	 */
	'moveDuration': {
		supportModels: EM400NB_SERIES
	},
	/**
	 * 持续静止时间
	 */
	'staticDuration': {
		supportModels: EM400NB_SERIES
	},
	/**
	 * 运动上报间隔/min
	 */
	'activityReportingInterval': {
		supportModels: EM400NB_SERIES
	},
	/**
	 * 工作模式
	 */
	'workMode': {
		supportModels: [ MODELS['EM400-MUD-B045'], MODELS['EM400-MUD-N03GL'] ],
		supportModelSeries: [MODEL_SERIES['EM400-TLD']]
	},
	/**
	 * 采集间隔(秒)
	 */
	'collectInterval': {
		supportModels: [ MODELS['EM400-MUD-B045'], MODELS['EM400-MUD-N03GL'] ],
	},
	/**
	 * 安装高度(毫米)
	 */
	'installHeight': {
		supportModelSeries: [ MODEL_SERIES['EM400-UDL'], MODEL_SERIES['EM400-TLD'] ]
	},
	/**
	 * 安装高度使能(EM400-TLD 特有)
	 */
	'installHeightEnable': {
		supportModelSeries: [MODEL_SERIES['EM400-TLD']]
	},

	/**
	 * 休眠模式
	 */
	'sleepConfig': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if([ MODELS['WS201'], MODELS['AM102'] ].includes(model)){
				return true;
			}
			if(isNil(deviceInfo)) {
				return false;
			}
			return model === MODELS['AM103'] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
		}
	},
	/**
	 * 休眠时间
	 */
	'sleepTime': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if([ MODELS['WS201'], MODELS['AM102'] ].includes(model)){
				return true;
			}
			if(isNil(deviceInfo)) {
				return false;
			}
			return model === MODELS['AM103'] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4');
		}
	},
	/**
	 * 阈值温度突变
	 */
	'saltationTemperature': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			const models = [MODELS['TS101']];
			const EM500Series = [ MODEL_SERIES['EM500-CO2'], MODEL_SERIES['EM500-SMTC'], MODEL_SERIES['EM500-PT100'] ];
			return models.includes(model) || (
				EM500Series.includes(modelSeries) &&
				Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5') &&
				Version.isGreaterThanOrEqualTo(deviceInfo.hardwareVersion, 'v2.0')
			);
		}
	},
	/**
	 * TVOC模式
	 */
	'tvocMode': {
		isSupport: (model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) => {
			if (!deviceInfo) {
				return false;
			}
			const { firmwareVersion, hardwareVersion } = deviceInfo;
			return identify(model).isAMModelSeriesV0104(firmwareVersion,hardwareVersion);
		}
	},

	/**
	 * 气压补偿
	 */
	'altitudeCalEnable': {
		isSupport: (model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) => {
			if (!deviceInfo) {
				return false;
			}
			const { firmwareVersion, hardwareVersion } = deviceInfo;

			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['EM500-CO2']]: Version.isGreaterThanOrEqualTo(firmwareVersion, 'v1.5') && Version.isGreaterThanOrEqualTo(hardwareVersion, 'v2.0'),
			};

			return supportModelSeries[modelSeries] || identify(model).isAMModelSeriesV0104(firmwareVersion,hardwareVersion) || false;
		}
	},

	/**
	 * 海拔高度校准
	 */
	'altitudeCalibration': {
		isSupport: (_model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) => {
			if (!deviceInfo) {
				return false;
			}

			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['AM103']]: Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.5'),
			};

			return supportModelSeries[modelSeries] || false;
		}
	},

	/**
	 * 上行中断
	 */
	'uplinkInterruption': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)) {
				return false;
			}
			return model === MODELS['AM102'] || (model === MODELS['AM103'] && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.4'));
		}
	},
	/**
	 * 规则引擎
	 */
	'ruleEngine': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(!deviceInfo?.hardwareVersion) {
				return false;
			}

			return identify(model).isUC50Xv3(deviceInfo.hardwareVersion);
		}
	},
	/**
	 * sdi12设置
	 */
	'sdi12Setting': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(!deviceInfo?.hardwareVersion) {
				return false;
			}

			const supportModelSeries: Record<string, boolean> = {
				[MODEL_SERIES['UC500NB']]: true,
			};

			return supportModelSeries[modelSeries] || identify(model).isUC50Xv3(deviceInfo.hardwareVersion);
		}
	},
	/**
	 * 透传模式
	 */
	'throughMode': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(!deviceInfo?.hardwareVersion) {
				return false;
			}

			return identify(model).isUC50Xv3(deviceInfo.hardwareVersion);
		}
	},

	/**
	 * 供电电流
	 */
	'supplyCurrent': {
		isSupport: function(model: MODELS, modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if (!deviceInfo || !deviceInfo.hardwareVersion) {
				return false;
			}
	
			const isUC500ModelSeries = MODEL_SERIES['UC500'] === modelSeries;
			const isUC50Xv3 = identify(model).isUC50Xv3(deviceInfo.hardwareVersion);
			const isUC50Xv2 = identify(model).isUC50Xv2(deviceInfo.hardwareVersion);
	
			return (isUC500ModelSeries && (isUC50Xv3 || isUC50Xv2));
		}
	},

	/**
	 * 上报间隔
	 */
	'reportingInterval': {
		isSupport: function(model: MODELS) {
			if(model === MODELS['AT101']) {
				return false;
			}

			return true;
		}
	},

	/**
	 *TCP&UDP 应用模式
	 */
	'tcpAndUdpMode': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return [
				MODELS['EM300-MCS-N00CN'],
				MODELS['EM300-SLD-N00CN'],
				MODELS['EM300-ZLD-N00CN'],
				MODELS['EM300-TH-N00CN']
			].includes(model) && 
			Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
		}
	},


	/**
	 * 定位设置
	 */
	'locationSettings': {
		supportModels: [MODELS['AT101']],
	},

	/**
	 * 常用设置
	 */
	'reportMode': {
		supportModels: [MODELS['AT101']],
	},

	/**
	 *应用模式
	 */
	'applicationMode': {
		isSupport: function(model: MODELS) {
			return identify(model).isNBDevice();
		}
	},

	/**
	 *客户端ID
	 */
	'clientId': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *用户凭证
	 */
	'receipt': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *用户名
	 */
	'receiptUsername': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *MQTT应用模式的用户凭证密码
	 */
	'receiptPassword': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *TLS
	 */
	'TLS': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *根文件
	 */
	'rootCert': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *客户端证书
	 */
	'clientCert': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 *客户端密钥
	 */
	'clientKey': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(isNil(deviceInfo)){
				return false;
			}

			return EM400NB_SERIES.includes(model);
		}
	},

	/**
	 * 服务器端口
	 */
	'serverPort': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if (!deviceInfo) {
				return false;
			}
	
			const isEM400NBSeries = EM400NB_SERIES.includes(model);
			const isEM300SeriesWithFirmware = [
				MODELS['EM300-MCS-N00CN'],
				MODELS['EM300-SLD-N00CN'],
				MODELS['EM300-ZLD-N00CN'],
				MODELS['EM300-TH-N00CN']
			].includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
	
			return isEM400NBSeries || isEM300SeriesWithFirmware;
		}
	},
	
	'serverIp': {
		isSupport: function(model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if (!deviceInfo) {
				return false;
			}
	
			const isEM400NBSeries = EM400NB_SERIES.includes(model);
			const isEM300SeriesWithFirmware = [
				MODELS['EM300-MCS-N00CN'],
				MODELS['EM300-SLD-N00CN'],
				MODELS['EM300-ZLD-N00CN'],
				MODELS['EM300-TH-N00CN']
			].includes(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.22');
	
			return isEM400NBSeries || isEM300SeriesWithFirmware;
		}
	},	

	/**
   * 设备端支持的上报间隔单位,需要将reportingInterval转换成该单位后写入
   */
	'reportingIntervalUnit':{
		isSupport: function(_model: MODELS, _modelSeries: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			return deviceInfo?.reportingIntervalUnit !== undefined;
		}
	},

	/**
	 * 传感器单位转换
	 */
	'sensorUnitChange': {
		isSupport: function(model: MODELS) {
			return ![ MODELS['VS350'], MODELS['VS351'], MODELS['VS360'] ].includes(model);
		}
	},

	/**
	 * 重置设备
	 */
	'reset': {
		isSupport: function() {
			return true;
		}
	},

	/**
	 * 设备状态显示
	 */
	'deviceStateDisplay': {
		isSupport: function() {
			return true;
		}
	},
	/**
	 * 重置累计值
	 */
	'resetAccumulatedValue': {
		supportModels: [ MODELS['VS350'], MODELS['VS351'], MODELS['VS360'] ],
	},

	/**
	 * 温度上报
	 */
	'reportTemperature': {
		supportModels: [ MODELS['VS350'], MODELS['VS351'], MODELS['VS360'] ],
	},

	/**
	 * 累计值上报
	 */
	'reportAccumulatedValue': {
		supportModels: [ MODELS['VS350'], MODELS['VS351'], MODELS['VS360'] ],
	},

	/**
	 * 电机校准
	 */
	'strokeCalibration': {
		supportModels: [MODELS['WT101']]
	},

	/**
	 * 供暖计划
	 */
	'heatingPlan': {
		supportModels: [MODELS['WT101']],
	},

	/**
	 * 信号类型
	 */
	'switchMode': {
		isSupport(model: MODELS, _models: MODEL_SERIES, deviceInfo?: DeviceInfo) {
			if(!deviceInfo) {
				return false;
			}

			return Identify.isWS1X6(model) && Version.isGreaterThanOrEqualTo(deviceInfo.firmwareVersion, 'v1.6');
		}
	},

	/**
	 * 传感器错误代码
	 * 比如值65535或者65533是正常值，但值出现error或out表示错误或者超量程
	 */
	'sensorErrorCode': {
		isSupport() {
			return false;
		}
	},

	/**
	 * 预配置
	 */
	'preconfig': {
		isSupport() {
			return false;
		}
	},

	/**
	 * 设置页面是否支持卡片风格
	 * 开启后默认内容使用灰色背景，否则使用白色背景
	 * 默认不支持，需要具体型号手动配置支持
	 */
	'settingCardStyle': {
		isSupport() {
			return false;
		}
	}
};

export type SupportSettingKey = keyof (typeof supportSettingMap) | keyof DeviceSettingServiceExtendSupportSettingKey;

export type SupportSettingMap = {
	// eslint-disable-next-line no-unused-vars
	[ key in SupportSettingKey]: {
		supportModelSeries?: string[];
		supportModels?: string[]
		// eslint-disable-next-line no-unused-vars
		isSupport?: (model: string, modelSeries: string, deviceInfo?: DeviceInfo) => boolean;
	}
};

/**
 * 获取支持的设置项
 * @param model - 设备型号
 * @returns - 支持的设置项
 */
const getSupportSettingMap = (model: string) => {
	let settingMap = extend({}, supportSettingMap);
	const serviceSettingMap = DeviceConfigManager.getDeviceConfigService(model)?.getSupportSettingMap();

	if(!isNil(serviceSettingMap)) {
		//全局的设置项和特定设备设置服务的设置项合并，服务的设置项优先级更高
		settingMap = extend({}, settingMap, serviceSettingMap);
	}

	return settingMap;
};

/**
 * 判断是否支持设置项
 * @param {string | string[]} settingKey - 设置项的key值
 * @param {string} model - 当前设备型号
 * @param {DeviceInfo} deviceInfo - 设备信息
 */
export const getIsSupportSetting = (settingKey: SupportSettingKey | SupportSettingKey[], model: string, deviceInfo?: DeviceInfo) => {
	const settingMap = getSupportSettingMap(model) as unknown as SupportSettingMap;

	if(!has(settingMap, settingKey)) {
		console.log('暂不支持该配置的判断: ' + String(settingKey));
		return false;
	}

	const modelSeries = deviceInfo?.modelSeries ?? getModelSeries(model);
	const keys = isArray(settingKey) ? settingKey : [settingKey];

	return keys.every(key => {
		const supportModelSeries = settingMap[key]?.supportModelSeries ?? [];
		const supportModels = settingMap[key]?.supportModels ?? [];
		const isSupport = settingMap[key]?.isSupport;

		if(isFunction(isSupport)) {
			return isSupport(model, modelSeries, deviceInfo);
		}

		return includes(supportModelSeries, modelSeries) || includes(supportModels, model);
	});
};

/**
 * 判断是否支持设置项（有缓存）
 * @param {string | string[]} settingKey - 设置项的key值
 * @param {string} model - 当前设备型号
 * @param {DeviceInfo} deviceInfo - 设备信息
 */
export const isSupportSettings = memoize((settingKey: SupportSettingKey | SupportSettingKey[], model: string, deviceInfo?: DeviceInfo) => {
	return getIsSupportSetting(settingKey, model, deviceInfo);
}, (key, model, deviceInfo) => {
	let cacheKey = `${String(key)}-${deviceInfo?.sn}-${model}-${deviceInfo?.firmwareVersion}-${deviceInfo?.hardwareVersion}`;

	if (identify(model).isTS30X()) {
		const ch1Type = deviceInfo?.status?.find(item => item.name === 'ch1')?.type;
		const ch2Type = deviceInfo?.status?.find(item => item.name === 'ch2')?.type;
		cacheKey = `${String(key)}-${ch1Type}-${ch2Type}-${deviceInfo?.firmwareVersion}`;
	} else if (deviceInfo?.firmwareVersion && identify(model).isEM300DIv3(deviceInfo.firmwareVersion)) {
		const diMode = deviceInfo?.di?.mode;
		cacheKey = `${cacheKey}-${diMode}`;
	} else if(identify(model).isEM41X()) {
		cacheKey = `${cacheKey}-${deviceInfo?.readMode}`;
	}
	return cacheKey;
});

/**
 * 判断是否支持设置项（无缓存）
 * @param {string | string[]} settingKey - 设置项的key值
 * @param {string} model - 当前设备型号
 * @param {DeviceInfo} deviceInfo - 设备信息
 */
export const isSupportSettingsNoCache = (settingKey: SupportSettingKey | SupportSettingKey[], model: string, deviceInfo?: DeviceInfo) => {
	return getIsSupportSetting(settingKey, model, deviceInfo);
};
