
import _, { clamp, isEmpty } from 'lodash';

import { math } from '../../utils/util';

/**
 * 单位换算
 * @param {string | number} value 要转换单位的值
 * @param {string} nextUnit 要转换的单位
 * @param {string} preUnit 之前的单位
 * @param {number} decimalLength 保留小数位数
 * @param {number} constant 转换常量，默认为温度的常量32
 * @returns {number} value 转换单位后的值
 */
export function convertUnit(value: string | number, nextUnit: string, preUnit: string, decimalLength = 3, constant = 32) {
	if(_.isNaN(_.toNumber(value))) {
		return value;
	}

	if(_.toNumber(value) === 0 || value === 0) {
		return 0;
	}

	if (isEmpty(nextUnit) || isEmpty(preUnit)) {
		return value;
	}

	if(nextUnit === preUnit) {
		return value;
	}

	const valueNumber = _.toNumber(value);

	let nextValue;

	if([ 'F', '℉' ].includes(nextUnit)) {
		nextValue = _.toNumber(constant + valueNumber * 1.8);
	}

	if([ 'C', '℃' ].includes(nextUnit)) {
		nextValue = _.toNumber((valueNumber - constant) / 1.8);
	}

	if([ 'm', 'mm' ].includes(nextUnit)) {
		// @ts-ignore
		nextValue = {
			'm-mm': valueNumber * 1000,
			'mm-m': valueNumber / 1000
		}[`${preUnit}-${nextUnit}`];
	}

	if([ 'kPa', 'bar', 'MPa' ].includes(nextUnit)) {
		// @ts-ignore
		nextValue = {
			'MPa-bar': valueNumber * 10,
			'bar-MPa': valueNumber   / 10,
			'bar-kPa': valueNumber * 100,
			'kPa-bar': valueNumber / 100,
			'MPa-kPa': valueNumber * 1000,
			'kPa-MPa': valueNumber / 1000
		}[`${preUnit}-${nextUnit}`];
	}

	return math.isFloat(nextValue) ? math.round(nextValue, decimalLength) : nextValue;
}

/**
 * 实现0.5分辨率的四舍五入
 *
 * @param {*} value 数据精度为两位小数
 * @example 66.25->66.5, 66.24->66.0, 66.75->67.0
 * @return {*} 
 */
export function tempToRound(value: number) {
	const temp = value * 2;
	let result = 0;
	if (temp - Math.floor(temp) >= 0.5) {
		result = Math.floor(temp) + 1;
	} else {
		result = Math.floor(temp);
	}
	return result / 2;
}

/**
 * 将值转换为对应分辨率的值
 * @example convertTempResolution(10.5, 1, { min: 10, max: 19 }) => 11
 * @param value 值
 * @param resolution 分辨率
 * @param bounds 边界值
 * @returns 转换后的值
 */
export const convertTempResolution = ((value: number, resolution: 0.5 | 1, bounds?: { min: number, max: number }) => {
	const decimal = resolution === 0.5 ? 2 : 0;
	const roundedValue = math.round(value, decimal);
	const hasBounds = bounds?.min != null && bounds?.max != null;

	if (resolution === 0.5) {
		return hasBounds
			? clamp(tempToRound(roundedValue), bounds.min, bounds.max)
			: tempToRound(roundedValue);
	}

	return hasBounds
		? clamp(roundedValue, bounds.min, bounds.max)
		: roundedValue;
});

/**
 * 温度单位转换，支持指定温度分辨率
 */
export const convertTemperatureUnit = ({
	value,
	nextUnit,
	prevUnit,
	decimalLength = 3,
	constant = 32,
	resolution,
}: {
	value: number;
	nextUnit: '℃' | '℉';
	prevUnit: '℃' | '℉';
	decimalLength?: number;
	constant?: number;
	resolution?: 0.5 | 1;
}) => {
	const convertedUnitValue = convertUnit(value, nextUnit, prevUnit, decimalLength, constant);

	if(resolution != null) {
		const convertedResolutionValue = convertTempResolution(convertedUnitValue, resolution);
		return convertedResolutionValue;
	}

	return convertedUnitValue;
};