import { get } from 'lodash';

import math from '../../../utils/util/math';
import { TSLAttributeTransformer } from '../../tsl';
import { convertTempResolution, convertUnit } from '../temperature';
import { getTslAttributeFractionDigits } from '../util';

/**
 * 获取温度值转换器
 * @param decimalLength - 小数位数
 * @param constant - 常量
 */
export function getTemperatureValueTransformer({
	transformDataValueDecimalLength,
	transformValueDecimalLength,
	constant = 32,
	tslInfoKey,
}: {
	/**
	 * 摄氏度(tslInfo) -> 摄氏度/华氏度(deviceInfo)的小数位数
	 * @default 1
	 */
	transformDataValueDecimalLength?: number;

	/**
	 * 摄氏度/华氏度(deviceInfo) -> 摄氏度(tslInfo)的小数位数
	 * 如果没有传入，获取对应tslInfoKey的resourceAttribute的fractionDigits
	 * 如果都获取不到，则使用默认值1
	 * @default 1
	 */
	transformValueDecimalLength?: number;

	/**
	 * 物模型属性key
	 */
	tslInfoKey?: string;

	/**
	 * 常量
	 * @default 32
	 */
	constant?: number;
}): TSLAttributeTransformer {
	return {
		// 摄氏度(tslInfo) -> 摄氏度/华氏度(deviceInfo)
		transformDataValue(value: number, data, context) {
			const temperatureUnit = data.temperature_unit ?? context?.tslInfo?.temperature_unit ?? 0;
			const decimalLength = transformDataValueDecimalLength ?? 1;

			if (temperatureUnit == 1) {
				return convertUnit(value as number, 'F', 'C', decimalLength, constant);
			}

			return math.round(value, decimalLength);
		},
		// 摄氏度/华氏度(deviceInfo) -> 摄氏度(tslInfo)
		transformValue(value: number, deviceInfo, context) {
			const temperatureUnit = deviceInfo?.temperature?.unit ?? context?.deviceInfo?.temperature?.unit ?? '℃';
			const fractionDigits = tslInfoKey
				? getTslAttributeFractionDigits(tslInfoKey, 'write')
				: undefined;
			const decimalLength = transformValueDecimalLength ?? fractionDigits ?? 1;

			if (temperatureUnit == '℉') {
				return convertUnit(value as number, 'C', 'F', decimalLength, constant);
			}

			return math.round(value, decimalLength);
		},
	};
}

/**
 * 带分辨率转换的温度值转换器
 * @param resolution - 温度分辨率
 */
export function getTemperatureValueTransformerWithResolution({
	transformDataValueDecimalLength,
	transformValueDecimalLength,
	constant = 32,
	resolution,
	tslInfoKey,
	tslInfoResolutionKey = 'target_temperature_resolution',
}: {
	/**
	 * 摄氏度(tslInfo) -> 摄氏度/华氏度(deviceInfo)的小数位数
	 */
	transformDataValueDecimalLength?: number;

	/**
	 * 摄氏度/华氏度(deviceInfo) -> 摄氏度(tslInfo)的小数位数
	 */
	transformValueDecimalLength?: number;
	constant?: number;
	resolution?: number;
	tslInfoKey?: string;
	/**
	 * 温度分辨率物模型属性key
	 * @default 'target_temperature_resolution'
	 * 支持二级路径，例如：'target_temperature_control_settings.target_temperature_resolution' WT102
	 */
	tslInfoResolutionKey?: string;
}): TSLAttributeTransformer {
	return {
		// 摄氏度(tslInfo) -> 摄氏度/华氏度(deviceInfo) 需要带分辨率转换
		transformDataValue(value: number, data, context) {
			let temperatureResolution = resolution ?? get(data, tslInfoResolutionKey) ?? get(context?.tslInfo, tslInfoResolutionKey);

			if (temperatureResolution === 0) {
				temperatureResolution = 0.5;
			}

			const temperatureTransformer = getTemperatureValueTransformer({
				transformDataValueDecimalLength,
				transformValueDecimalLength,
				constant,
				tslInfoKey,
			}).transformDataValue!;
			const convertedTemperatureValue = temperatureTransformer(value, data, context);

			if(temperatureResolution != null) {
				const convertedTemperatureValueWithResolution = convertTempResolution(convertedTemperatureValue, temperatureResolution as 0.5 | 1);

				return convertedTemperatureValueWithResolution;
			}

			return convertedTemperatureValue;
		},
		// 摄氏度/华氏度(deviceInfo) -> 摄氏度(tslInfo) 不需要做分辨率转换，传入转换单位后的值
		transformValue(value: number, deviceInfo, context) {
			const temperatureTransformer = getTemperatureValueTransformer({
				transformDataValueDecimalLength,
				transformValueDecimalLength,
				constant,
				tslInfoKey
			}).transformValue!;
			const convertedTemperatureValue = temperatureTransformer(value, deviceInfo, context);

			return convertedTemperatureValue;
		},
	};
}
