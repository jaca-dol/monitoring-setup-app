import { TSLAttributeDefinition } from '../../tsl';

/**
 * 全局采集周期转换器
 */
export const globalCollectIntervalTransformer: {
	transformDataValue: TSLAttributeDefinition['transformDataValue'];
	transformValue: TSLAttributeDefinition['transformValue'];
} = {
	transformDataValue(_value, data) {
		const unit = data?.collection_interval?.unit ?? 1;
		const reportingInterval = unit === 0
			? data.collection_interval.seconds_of_time
			: data.collection_interval.minutes_of_time;

		return reportingInterval;
	},
	transformValue(value, deviceInfo, context) {
		const unit = deviceInfo.globalCollectIntervalUnit ?? context?.deviceInfo?.globalCollectIntervalUnit ?? 1;
		const key = unit === 0 ? 'seconds_of_time' : 'minutes_of_time';

		return {
			collection_interval: {
				[key]: value,
				unit: unit
			}
		};
	}
};