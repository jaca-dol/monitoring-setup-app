import { TSLAttributeTransformer } from '../../tsl';

/**
 * 上报周期转换器
 */
export const reportingIntervalTransformer: TSLAttributeTransformer = {
	transformDataValue(_value, data) {
		const unit = data?.reporting_interval?.unit ?? 1;
		const reportingInterval = unit === 0
			? data.reporting_interval.seconds_of_time
			: data.reporting_interval.minutes_of_time;

		return reportingInterval;
	},
	transformValue(value, deviceInfo, context) {
		const unit = deviceInfo.reportingIntervalUnit ?? context?.deviceInfo?.reportingIntervalUnit ?? 1;
		const key = unit === 0 ? 'seconds_of_time' : 'minutes_of_time';

		return {
			reporting_interval: {
				[key]: value,
				unit: unit
			}
		};
	}
};