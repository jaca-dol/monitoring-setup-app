import { Buffer } from 'buffer';

/**
 * 将 channelMask 转换为 enableFreq
 * @param channelMask - 12字节的字符串，每个比特位表示启用一个通道
 * @returns 启用的通道范围字符串
 */
export function channelMaskToEnableFreqIndex(channelMask: string): string {
	if(channelMask === '000000000000000000000000') {
		return '';
	}
	
	// 将 channelMask 转换为 Buffer，并反转字节顺序
	// 解析库返回的 channelMask 是000000ffffffffffffffffff，表示启用了0-71通道，从右往左
	// 我们需要反转成ffffffffffffffffff000000，从左往右，依次读取
	const buffer = Buffer.from(channelMask, 'hex').reverse(); 
	const enabledChannels = [];

	// 遍历 Buffer 中的每个字节
	for (let byteIndex = 0; byteIndex < buffer.length; byteIndex++) {
		// 遍历每个字节中的每个位
		// 注意：虽然大小端的字节序是不一样的，即大端是从左到右，小端是从右到左
		// 但是比特序都是一样的，即最高位是第0位，最低位是第7位
		for (let bitIndex = 0; bitIndex < 8; bitIndex++) {
			// 检查每个位是否被设置为1，如果是则添加到启用通道列表中
			if (buffer[byteIndex]! & (1 << bitIndex)) {
				// 计算通道编号，并添加到启用通道列表中
				enabledChannels.push(byteIndex * 8 + bitIndex);
			}
		}
	}

	// 构建启用通道范围字符串
	let result = '';
	let rangeStart = null;

	for (let i = 0; i < enabledChannels.length; i++) {
		if (rangeStart === null) {
			rangeStart = enabledChannels[i];
		}

		// 检查是否需要结束当前范围
		// 如果当前通道是最后一个通道或者下一个通道不连续
		if (i === enabledChannels.length - 1 || enabledChannels[i]! + 1 !== enabledChannels[i + 1]) {
			if (rangeStart === enabledChannels[i]) {
				result += `${rangeStart},`;
			} else {
				result += `${rangeStart}-${enabledChannels[i]},`;
			}
			rangeStart = null;
		}
	}

	// 去掉最后一个逗号并返回结果
	return result.slice(0, -1);
}

/**
* 将 enableFreq 转换为 channelMask
* @param enableFreq - 启用通道范围字符串
* @returns 12字节的字符串，每个比特位表示启用一个通道
*/
export function enableFreqIndexToChannelMask(enableFreqIndex: string): string {
	if(enableFreqIndex === '') {
		return '000000000000000000000000';
	}

	const enabledChannels = new Set<number>();
	const ranges = enableFreqIndex.split(',');

	// 解析启用通道范围字符串
	ranges.forEach(range => {
		if (range.includes('-')) {
			const [ start, end ] = range.split('-').map(Number);
			for (let i = start!; i <= end!; i++) {
				enabledChannels.add(i);
			}
		} else {
			enabledChannels.add(Number(range));
		}
	});

	// 创建一个长度为 12 的 Buffer
	const buffer = Buffer.alloc(12);

	// 设置对应的比特位
	enabledChannels.forEach(channel => {
		const byteIndex = Math.floor(channel / 8);
		const bitIndex = channel % 8;
		buffer[byteIndex]! |= (1 << bitIndex);
	});

	// 将 Buffer 反转并转换为 16 进制字符串
	return buffer.reverse().toString('hex');
}