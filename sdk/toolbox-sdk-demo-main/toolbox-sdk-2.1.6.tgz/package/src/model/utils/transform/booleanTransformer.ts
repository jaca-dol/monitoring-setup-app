import { TSLAttributeDefinition, TSLAttributeTransformer } from '../../tsl';
import { DeviceTSLInfoKeys } from '../../tsl/DeviceSpecificTSLInfo';

/**
 * 将布尔值转换为数字
 */
export function booleanToNumber(value?: boolean): 0 | 1 {
	if(!value) {
		return 0;
	}

	return value ? 1 : 0;
}

/**
 * 将数字转换为布尔值
 */
export function numberToBoolean(value: number) {
	return Boolean(value);
}

/**
 * boolean转换器
 */
export const booleanTransformer: TSLAttributeTransformer = {
	transformDataValue: numberToBoolean,
	transformValue: booleanToNumber
};

export const booleanTransformerFunc = <DeviceKey extends DeviceTSLInfoKeys = 'all'>() => {
	return {
		transformDataValue: numberToBoolean,
		transformValue: booleanToNumber
	} as {
        transformDataValue: TSLAttributeDefinition<DeviceKey>['transformDataValue'];
        transformValue: TSLAttributeDefinition<DeviceKey>['transformValue'];
    } ;
};
