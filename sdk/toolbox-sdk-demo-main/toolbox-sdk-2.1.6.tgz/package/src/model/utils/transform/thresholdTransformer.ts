import { get, set } from 'lodash';

import { TSLAttributeTransformer } from '../../tsl';
import { getTemperatureValueTransformer } from './temperatureTransformer';

/**
 * 获取阈值条件转换器
 * @param enableKey - 是否启用的key
 * @param setZeroWhenDisabled - 当enable为false时是否将值设为0，默认为true
 */
export function getThresholdConditionTransformer(enableKey: string, setZeroWhenDisabled: boolean = true) {
	return {
		transformValue(value: number, deviceInfo: Record<string, any>) {
			const enable = get(deviceInfo, enableKey, false);
			if (enable) {
				return value;
			}
			return setZeroWhenDisabled ? 0 : value;
		}
	};
}

/**
 * 获取最小阈值转换器
 * @param tslInfoThresholdKey - tslInfo中的阈值key
 * @param deviceInfoThresholdKey - deviceInfo中的阈值key
 * @param setZeroWhenDisabled - 当enable为false时是否将值设为0，默认为true
 */
export function getThresholdMinTransformer(tslInfoThresholdKey: string, deviceInfoThresholdKey: string, setZeroWhenDisabled: boolean = true): TSLAttributeTransformer {
	return {
		transformDataValue(value: number, data, context) {
			const enable = get(data, `${tslInfoThresholdKey}.enable`);
			const condition = get(data, `${tslInfoThresholdKey}.threshold_condition`);
			const isTemperature = tslInfoThresholdKey === 'temperature_alarm_settings';
			// 温度阈值还需要做一个单位转换
			const transformer = isTemperature
				? getTemperatureValueTransformer({
					transformDataValueDecimalLength: 1,
					tslInfoKey: `${tslInfoThresholdKey}.threshold_min`
				}).transformDataValue
				: null;

			if((condition === 0 || condition === 2) || (setZeroWhenDisabled && enable === false)) {
				return '';
			}

			const transformerValue = transformer ? transformer(value, data, context) : value;

			// WITHIN模式下，min -> high
			if(condition === 3) {
				const value = set({}, `${deviceInfoThresholdKey}.high`, transformerValue);

				return value;
			}

			return transformerValue;
		},
		transformValue(value: number, deviceInfo, context) {
			const enable = get(deviceInfo, `${deviceInfoThresholdKey}.enable`);
			const mode = get(deviceInfo, `${deviceInfoThresholdKey}.mode`, 1);
			const isTemperature = tslInfoThresholdKey === 'temperature_alarm_settings';
			// 温度阈值还需要做一个单位转换
			const transformer = isTemperature
				? getTemperatureValueTransformer({
					transformDataValueDecimalLength: 1,
					tslInfoKey: `${tslInfoThresholdKey}.threshold_min`
				}).transformValue
				: null;

			if((mode === 0 || mode === 2) || (setZeroWhenDisabled && enable === false)) {
				return 0;
			}

			const transformerValue = transformer ? transformer(value, deviceInfo, context) : value;

			// WITHIN模式下，low -> max
			if(mode === 3) {
				const value = set({}, [ tslInfoThresholdKey, 'threshold_max' ], transformerValue);

				return value;	
			}

			return transformerValue;
		}
	};
}

/**
 * 获取最大阈值转换器
 * @param tslInfoThresholdKey - tlsInfo中的阈值key
 * @param deviceInfoThresholdKey - deviceInfo中的阈值key
 * @param setZeroWhenDisabled - 当enable为false时是否将值设为0，默认为true
 */
export function getThresholdMaxTransformer(tslInfoThresholdKey: string, deviceInfoThresholdKey: string, setZeroWhenDisabled: boolean = true): TSLAttributeTransformer {
	return {
		transformDataValue(value: number, data, context) {
			const enable = get(data, `${tslInfoThresholdKey}.enable`);
			const condition = get(data, `${tslInfoThresholdKey}.threshold_condition`);
			const isTemperature = tslInfoThresholdKey === 'temperature_alarm_settings';
			// 温度阈值还需要做一个单位转换
			const transformer = isTemperature
				? getTemperatureValueTransformer({
					transformDataValueDecimalLength: 1,
					tslInfoKey: `${tslInfoThresholdKey}.threshold_max`
				}).transformDataValue
				: null;

			if((condition === 0 || condition === 1) || (setZeroWhenDisabled && enable === false)) {
				return '';
			}

			const transformerValue = transformer ? transformer(value, data, context) : value;

			// WITHIN模式下，max -> low
			if(condition === 3) {
				const value = set({}, `${deviceInfoThresholdKey}.low`, transformerValue);

				return value;
			}

			return transformerValue;
		},
		transformValue(value: number, deviceInfo, context) {
			const enable = get(deviceInfo, `${deviceInfoThresholdKey}.enable`);
			const mode = get(deviceInfo, `${deviceInfoThresholdKey}.mode`, 1);
			const isTemperature = tslInfoThresholdKey === 'temperature_alarm_settings';
			// 温度阈值还需要做一个单位转换
			const transformer = isTemperature
				? getTemperatureValueTransformer({
					transformDataValueDecimalLength: 1,
					tslInfoKey: `${tslInfoThresholdKey}.threshold_max`
				}).transformValue
				: null;

			if((mode === 0 || mode === 1) || (setZeroWhenDisabled && enable === false)) {
				return 0;
			}

			const transformerValue = transformer ? transformer(value, deviceInfo, context) : value;

			// WITHIN模式下，high -> min
			if(mode === 3) {
				const value = set({}, [ tslInfoThresholdKey, 'threshold_min' ], transformerValue);

				return value;
			}

			return transformerValue;
		}
	};
}