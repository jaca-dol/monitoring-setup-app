import _ from 'lodash';

import { DeviceInfo } from '../../deviceInfo';
import { getMinimumAvailableId } from '../util';

import { TSLAttributeTransformer } from '../../tsl';
import { UC50XCAT1TSLInfo } from '../../tsl';
import { getDiffArrayItems, padArray } from '../util';

/**
 * 将channels转换为modbus_channel_settings(全部32个通道)
 * @param channels - deviceInfo中的channels
 * @returns tslInfo中的modbus_channel_settings
 */
function getModbusChannelSettingsByChannels(channels: NonNullable<DeviceInfo['channels']>): UC50XCAT1TSLInfo['modbus_channel_settings'] {
	const existIds = channels.map(channel => channel.id);

	return padArray(
		channels.map(channel => {
			return {
				id: channel.id,
				name: channel.name,
				enable: 1,
				slave_id: channel.slaveId,
				register_address: channel.address,
				quantity: channel.quantity,
				data_type: channel.type,
				sign: channel.signed ? 1 : 0,
			};
		}),
		32,
		index => {
			const nextId = getMinimumAvailableId(existIds, 0, 31) ?? index;

			existIds.push(nextId);

			return {
				id: nextId,
				name: '',
				enable: 0 as any,
				slave_id: 1,
				register_address: 0,
				quantity: 1,
				data_type: 0,
				sign: 0,
			};
		});
}

/**
 * 获取旧的modbus通道设置
 */
function getOldModbusChannelSettings(_deviceInfo: DeviceInfo, context: Record<string, any>) {
	const oldChannels = _.get(context, 'prevDeviceInfo.channels', null);

	if(oldChannels != null) {
		const oldModbusChannels = getModbusChannelSettingsByChannels(oldChannels);

		return oldModbusChannels;
	}

	return null;
}

/**
 * modbus通道转换器
 */
export const modbusChannelTransformer: TSLAttributeTransformer = {
	transformDataValue(modbus_channel_settings: UC50XCAT1TSLInfo['modbus_channel_settings']): {
		channels: DeviceInfo['channels'];
	} {
		return {
			channels: modbus_channel_settings.filter(channel => channel.enable === 1).map(channel => {
				return {
					id: channel.id,
					name: channel.name,
					slaveId: channel.slave_id,
					address: channel.register_address,
					quantity: channel.quantity,
					type: channel.data_type,
					signed: channel.sign === 1
				};
			})
		};
	},
	transformValue(channels: NonNullable<DeviceInfo['channels']>, deviceInfo, context): {
		modbus_channel_settings: UC50XCAT1TSLInfo['modbus_channel_settings'];
	} {
		const oldModbusChannelSettings = getOldModbusChannelSettings(deviceInfo, context);
		const newModbusChannelSettings = getModbusChannelSettingsByChannels(channels);
		let nextModbusChannelSettings = oldModbusChannelSettings != null
			? getDiffArrayItems(oldModbusChannelSettings, newModbusChannelSettings, 'id')
			: newModbusChannelSettings;

		//如果变更列表为空，表示没有变化，则不下发
		if(nextModbusChannelSettings.length === 0) {
			nextModbusChannelSettings = undefined as any;
		}

		return {
			modbus_channel_settings: nextModbusChannelSettings
		};
	}
};