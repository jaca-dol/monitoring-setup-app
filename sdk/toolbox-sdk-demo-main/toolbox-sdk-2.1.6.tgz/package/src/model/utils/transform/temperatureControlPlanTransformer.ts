import _ from 'lodash';

import { IWT30XExtendDeviceInfo } from '../../deviceInfo/specific';
import { DeviceInfo } from '../../deviceInfo';
import { getMinimumAvailableId } from '../util';

import { TSLAttributeTransformer, WT30XTSLInfo } from '../../tsl';
import { getTemperatureValueTransformer, getTemperatureValueTransformerWithResolution } from './temperatureTransformer';
import { chunkStringByUtf8ByteLimits } from '../util';

/**
 * @interface TruncatedNameParts
 * @description 定义截断后的名称部分
 */
interface TruncatedNameParts {
	name_first: string; // 名称的第一部分
	name_last: string;  // 名称的第二部分
}

/**
 * 将名称字符串按UTF-8字节长度限制分割为 name_first 和 name_last
 * @param originalName 原始名称字符串
 * @returns 返回一个包含 name_first 和 name_last 的对象
 */
function truncatePlanName(originalName: string | undefined | null): TruncatedNameParts {
	if (!originalName) {
		return { name_first: '', name_last: '' };
	}

	const parts = chunkStringByUtf8ByteLimits(originalName, [ 6, 4 ]);

	return {
		name_first: parts.length > 0 ? parts[0]! : '',
		name_last: parts.length > 1 ? parts[1]! : '', // 只取前两部分
	};
}

/**
 * 获取旧的温控计划\
 * 温控计划对应业务场景的旧计划
 * 1. 读取 -> 写入，旧计划就是读取时候的计划
 * 2. 模板写入，旧计划就是模板中的计划（还没更新到模板时）
 * 3. 模板导出为预配置文件，旧计划就是设备当前的默认配置
 */
function getOldScheduleSettings(deviceInfo: DeviceInfo, context: Record<string, any>) {
	const oldTemperatureControlPlan = _.get(context, 'prevDeviceInfo.temperatureControlPlan', null);

	if(oldTemperatureControlPlan != null) {
		const oldScheduleSettings = getScheduleSettingsByTemperatureControlPlan(oldTemperatureControlPlan, deviceInfo, context);

		return oldScheduleSettings;
	}

	return null;
}

/**
 * 比较新旧计划列表，找出发生变化的计划
 */
export function getDiffScheduleSettings(oldScheduleSetting: WT30XTSLInfo['schedule_settings'], newScheduleSetting: WT30XTSLInfo['schedule_settings']) {
	const oldScheduleSettingsById = _.keyBy(oldScheduleSetting, 'id');
	const changedScheduleSettings = _.reduce(newScheduleSetting, (result, newItem) => {
		const oldItem = oldScheduleSettingsById[newItem.id];

		if (oldItem && !_.isEqual(oldItem, newItem)) {
			result.push(newItem);
		}

		return result;
	}, [] as WT30XTSLInfo['schedule_settings']);

	return changedScheduleSettings;
}

/**
 * 从temperatureControlPlan生成schedule_settings
 */
function getScheduleSettingsByTemperatureControlPlan(...params: Parameters<typeof temperatureControlPlanTransformer.transformValue>): WT30XTSLInfo['schedule_settings'] {
	const [ temperatureControlPlan, deviceInfo, context ] = params;
	const targetTemperatureTransformer = _.partialRight(getTemperatureValueTransformerWithResolution({
		transformDataValueDecimalLength: 1,
		tslInfoKey: 'schedule_settings._item.content.heat_target_temperature'
	}).transformValue!, deviceInfo, context);
	const temperatureToleranceTransformer = _.partialRight(getTemperatureValueTransformer({
		transformDataValueDecimalLength: 1,
		tslInfoKey: 'schedule_settings._item.content.temperature_tolerance',
		constant: 0,
	}).transformValue!, deviceInfo, context);
	const existingIds = temperatureControlPlan.map((p: any) => p.id);
	const schedule_settings = new Array(16).fill(0).map((_i, pIndex) => {
		const plan = temperatureControlPlan[pIndex];

		//没有找到对应的计划，则返回默认的计划
		if(!plan) {
			const nextId = getMinimumAvailableId(existingIds, 0, 15) ?? pIndex;

			existingIds.push(nextId);

			return {
				id: nextId,
				enable: 0 as const,
				name_first: '',
				name_last: '',
				content: {
					fan_mode: 0,
					heat_target_temperature_enable: 1,
					heat_target_temperature: 17,
					cool_target_temperature_enable: 1,
					cool_target_temperature: 26,
					temperature_tolerance_enable: 1,
					temperature_tolerance: 2
				},
				cycle_settings: new Array(16).fill(0).map((_i, index) => ({
					enable: 0,
					id: index,
					execution_time_point: 0,
					execution_day_mon: 0,
					execution_day_tues: 0,
					execution_day_wed: 0,
					execution_day_thu: 0,
					execution_day_fri: 0,
					execution_day_sat: 0,
					execution_day_sun: 0,
					reserved: 0,
				}))
			} as WT30XTSLInfo['schedule_settings'][0];
		}

		const { name_first, name_last } = truncatePlanName(plan.name);

		return {
			id: plan.id,
			enable: 1 as const,
			name_first: name_first,
			name_last: name_last,
			content: {
				fan_mode: plan.fanMode,
				heat_target_temperature_enable: plan.heatTargetTemp === '' ? 0 : 1,
				heat_target_temperature: targetTemperatureTransformer(Number(plan.heatTargetTemp)),
				cool_target_temperature_enable: plan.coolTargetTemp === '' ? 0 : 1,
				cool_target_temperature: targetTemperatureTransformer(Number(plan.coolTargetTemp)),
				temperature_tolerance_enable: plan.targetTempTolerance === '' ? 0 : 1,
				//温度允差不能设置为0，所以如果为空，则使用默认值
				temperature_tolerance: plan.targetTempTolerance === ''
					? 2
					: temperatureToleranceTransformer(Number(plan.targetTempTolerance)),
			} as WT30XTSLInfo['schedule_settings'][number]['content'],
			cycle_settings: new Array(16).fill(0).map((_i, index) => {
				const time = plan.timeList[index];

				if(!time) {
					return {
						enable: 0,
						id: index,
						execution_time_point: 0,
						execution_day_mon: 0,
						execution_day_tues: 0,
						execution_day_wed: 0,
						execution_day_thu: 0,
						execution_day_fri: 0,
						execution_day_sat: 0,
						execution_day_sun: 0,
						reserved: 0,
					} as any;
				}

				return {
					enable: _.toNumber(time.enable),
					id: index,
					execution_time_point: time.time,
					execution_day_mon: _.toNumber(time.mask.includes(1)) ,
					execution_day_tues: _.toNumber(time.mask.includes(2)),
					execution_day_wed: _.toNumber(time.mask.includes(3)),
					execution_day_thu: _.toNumber(time.mask.includes(4)),
					execution_day_fri: _.toNumber(time.mask.includes(5)),
					execution_day_sat: _.toNumber(time.mask.includes(6)),
					execution_day_sun: _.toNumber(time.mask.includes(7)),
					reserved: 0,
				};
			})
		};
	});

	return schedule_settings;
}

/**
 * 温控计划转换器
 */
export const temperatureControlPlanTransformer: TSLAttributeTransformer = {
	transformDataValue(schedule_settings: WT30XTSLInfo['schedule_settings'], data, context): {
		temperatureControlPlan: IWT30XExtendDeviceInfo['temperatureControlPlan'];
	} {
		const targetTemperatureTransformer = _.partialRight(getTemperatureValueTransformerWithResolution({
			transformDataValueDecimalLength: 1,
			tslInfoKey: 'schedule_settings._item.content.heat_target_temperature'
		}).transformDataValue!, data, context);
		const temperatureToleranceTransformer = _.partialRight(getTemperatureValueTransformer({
			transformDataValueDecimalLength: 1,
			tslInfoKey: 'schedule_settings._item.content.temperature_tolerance',
			constant: 0,
		}).transformDataValue!, data, context);
		const temperatureControlPlan = schedule_settings
			.filter(setting => setting.enable === 1)
			.map(setting => {

				return {
					id: setting.id,
					name: setting.name_first + setting.name_last,
					fanMode: setting.content.fan_mode,
					heatTargetTemp: setting.content.heat_target_temperature_enable === 0 ? '' : targetTemperatureTransformer(setting.content.heat_target_temperature),
					coolTargetTemp: setting.content.cool_target_temperature_enable === 0 ? '' : targetTemperatureTransformer(setting.content.cool_target_temperature),
					targetTempTolerance: setting.content.temperature_tolerance_enable === 0 ? '' : temperatureToleranceTransformer(setting.content.temperature_tolerance),
					timeList: setting.cycle_settings
						.filter(time => !_.values(_.omit(time, 'id')).every(v => v === 0))
						.map(time => ({
							enable: time.enable === 1,
							id: time.id,
							time: time.execution_time_point,
							mask: [
								time.execution_day_mon,
								time.execution_day_tues,
								time.execution_day_wed,
								time.execution_day_thu,
								time.execution_day_fri,
								time.execution_day_sat,
								time.execution_day_sun,
							].map((v, i) => v === 1 ? i + 1 : 0).filter(v => v !== 0)
						}))
				};
			});

		return {
			temperatureControlPlan
		};
	},
	transformValue(temperatureControlPlan: IWT30XExtendDeviceInfo['temperatureControlPlan'], deviceInfo, context): {
		schedule_settings: WT30XTSLInfo['schedule_settings'];
	} {
		const oldScheduleSettings = getOldScheduleSettings(deviceInfo, context);
		const newScheduleSettings = getScheduleSettingsByTemperatureControlPlan(temperatureControlPlan, deviceInfo, context);
		let nextScheduleSettings = oldScheduleSettings != null
			? getDiffScheduleSettings(oldScheduleSettings, newScheduleSettings)
			: newScheduleSettings;

		//如果变更计划列表为空，表示没有变化，则不下发
		if(nextScheduleSettings.length === 0) {
			nextScheduleSettings = undefined as any;
		}

		return {
			schedule_settings: nextScheduleSettings
		};
	}
};