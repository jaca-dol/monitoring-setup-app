import _ from 'lodash';

import { TSLAttributeTransformer } from '../../tsl';
import { keysToCamelCase, keysToSnakeCase } from '../util';

/**
 * 对象键转换器
 * tslInfo -> deviceInfo，将对象键转换为驼峰命名(snake_case -> camelCase)
 * deviceInfo -> tslInfo，将对象键转换为蛇形命名(camelCase -> snake_case)
 */
export const getObjectKeysTransformer = ({
	tslInfoKey,
	deviceInfoKey,
	autoHandleReservedKey = false
}: {
	/**
	 * tslInfo的key
	 */
	tslInfoKey: string;

	/**
	 * deviceInfo的key
	 */
	deviceInfoKey: string;

	/**
	 * 是否自动填充tslInfo的reserved字段，并去掉deviceInfo的reserved字段
	 * @default false
	 */
	autoHandleReservedKey?: boolean;
}): TSLAttributeTransformer => {
	return {
		transformDataValue: value => {
			return {
				[deviceInfoKey]: autoHandleReservedKey && _.has(value, 'reserved')
					? _.omit(keysToCamelCase(value), 'reserved')
					: keysToCamelCase(value),
			};
		},
		transformValue: value => {
			return {
				[tslInfoKey]: autoHandleReservedKey && !_.has(value, 'reserved')
					? {
						...keysToSnakeCase(value),
						reserved: 0,
					} : keysToSnakeCase(value),
			};
		}
	};
};
