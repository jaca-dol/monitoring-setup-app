import { NativeModules } from 'react-native';

export interface IDeviceUtils {

	/**
	 * 获取设备主版本号
	 */
	mainVersion(): Promise<string>;

	/**
	 * 获取设备信息
	 */
	getFlashInfo(flashData: number[]): Promise<string>;

	/**
	 * 设置设备信息
	 * @param flashData - flashData
	 * @param settingJSON - settingJSON
	 */
	setFlashInfo(flashData: number[], settingJSON: string): Promise<{
		code: number;
		result: string;
		rawData: number[];
	}>;

	/**
	 * 设置设备USB配置信息
	 * @param flashData - flashData
	 * @param unpData - unpData
	 * @param settingJSON - settingJSON
	 */
	setFlashInfoToUnp(flashData: number[], unpData: number[], settingJSON: string): Promise<{
		resultSize: number;
		flashData: number[];
		unpData: number[];
	}>;

	/**
	 * 压缩数据
	 */
	encodeData(data: number[]): Promise<{
		data: number[];
		size: string;
	}>;

	/**
	 * 解压数据
	 */
	decodeData(data: number[]): Promise<{
		data: number[];
		size: string
	}>;

	/**
	 * 获取卡信息
	 */
	getCardInfo(data: number[]): Promise<{
		keyMode: number;
		cardVersion: number;
		cardStatus: number;
		deviceInfo: string;
		cardData: number[];
	}>;

	/**
	 * 设置卡信息
	 */
	setCardInfo(data: number[], json: string, cardHeaderInfo: {
		cardStatus: number;
		cardVersion: number;
		keyMode: number;
	}): Promise<{
		code: number;
		result: string;
		encodeData: number[];
	}>;

	/**
	 * 获取DS模板
	 */
	getDs3604Template(data: number[]): Promise<string>;

	/**
	 * 设置DS模板信息 
	 */
	setDs3604Template(data: number[], json: string): Promise<{
		code: number;
		result: string;
		rawData: number[];
	}>;

	/**
	 * 获取DS图片数据
	 */
	getDS3604Picture(data: number[]): Promise<string>;

	/**
	 * 设置DS图片数据
	 */
	setDS3604Picture(data: number[]): Promise<number[]>;

	/**
	 * 获取sdi信息
	 */
	getSdiInfo(data: number[]): Promise<string>;

	/**
	 * 设置sdi信息
	 */
	setSdiInfo(data: number[], json: string): Promise<{
		code: number;
		result: string;
		rawData: number[];
	}>;

	/**
	 * 获取 crc32 数据
	 */
	getCrc32(data: number[]): Promise<number>;

	/**
	 * 获取 bmp 数据
	 * 主要用于WS156的hex数据
	 */
	bmp2Hex(bmpData: number[]): Promise<{
		data: number[];
		size: number;
	}>;

	/**
	 * 获取WT30X hex 数据
	 * WT30X所需的图片数据与WS156的图片数据有以下区别
	 * 1. 数据没有自定义协议头部
	 * 2. 数据没有压缩
	 * 3. 数据扫描行是从左上到右下（WS156是左下到右上）
	 * 4. 图片颜色没有做取反处理（0:白色，1:黑色）
	 */
	bmp2WT30XHex(bmpData: number[]): Promise<{
		data: number[];
		size: number;
	}>;

	/**
	 * 获取历史数据
	 */
	getHistoryData(data: number[], model: string, firmwareVersion: string, hardwareVersion: string): Promise<string>;

	/**
	* 根据 uri 获取实际路径(Android 特有)
	*/
	getPathFromUri(uri: string): Promise<string>;

	/**
	 * 解密升级数据
	 */
	decrypUpgradeData(base64EncryptedData: string): Promise<string>;

	/**
	 * 获取设备产品信息
	 */
	getProductInfo(data: number[]): Promise<string>;

	/**
	 * 获取D2d Recv Match信息
	 * @param data 
	 */
	getD2DPairInfo(data: number[]): Promise<string>;
}

export default NativeModules.DeviceUtils as IDeviceUtils;