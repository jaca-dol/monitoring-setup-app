import _ from 'lodash';

interface TranslateFunc {
    (key: string, ..._args: unknown[]): string;
    isNeutral: boolean;
}

let _json = {};
let _translate: ((key: string, ..._args: unknown[]) => string) | undefined = undefined;
const translateFunc: TranslateFunc = (key: string, ..._args: unknown[]) => {
	if (_translate) {
		return _translate(key, ..._args);
	}
	if (_.isEmpty(_json)) {
		const json = require('./base.json');
		_json = json;
	}
	return _.get(_json, key, key);
};
translateFunc.isNeutral = false;

export const setTranslate = (translate: TranslateFunc) => {
	_translate = translate;
	// fix: isNeutral 需通过 getter 动态读取 _translate 上的值
	// 因为 setTranslate 在 sdkInit 阶段调用，此时 translate.isNeutral 尚未被 setI18nConfig 赋值
	// 使用 getter 保持与迁移前通过对象引用动态获取的行为一致
	Object.defineProperty(translateFunc, 'isNeutral', {
		get() {
			return (_translate as any)?.isNeutral ?? false;
		},
		configurable: true,
	});
};

export default translateFunc;