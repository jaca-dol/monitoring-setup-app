const _reducer: Record<string, (...args: any[]) => any> = {};

export const setReducer = (name: string, action: (...args: any[]) => any) => {
	if (_reducer[name]) {
		return;
	}
	_reducer[name] = action;
};

export default _reducer;