import { DeviceInfo } from '../../model/deviceInfo';

let hasSetStore = false;

export const _storeInfo = {
	counter: {},
	device: {
		deviceInfo: {} as DeviceInfo,
		prevDeviceInfo: {} as DeviceInfo,
		rawData: [] as number[],
		settingMode: 'template',
		cardData: [] as number[],
		DSTemplateData: {} as any,
		SDIData: {} as any
	}
};

export type StoreState = typeof _storeInfo;

const _store = {
	dispatch: (_action: any) => {
	},
	getState: () => {
		return _storeInfo;
	}
};

export const setStore = (store: any) => {
	if (hasSetStore) {
		return;
	}
	hasSetStore = true;
	Object.assign(_store, store);	
};

export default _store;