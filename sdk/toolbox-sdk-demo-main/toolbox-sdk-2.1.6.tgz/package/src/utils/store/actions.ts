import reducer from './reducer';
import selectors from './selectors';
import { DeviceInfo } from '../../model/deviceInfo';
import { _storeInfo, StoreState } from './store';

export const saveCounter = (...args: any[]): any => {
	if (reducer.saveCounter) {		
		return reducer.saveCounter(...args);
	} else {
		for (const arg of args) {
			_storeInfo.counter = {
				..._storeInfo.counter,
				...arg
			};
		}
	}
};

export const resetCounter = (counterKey: string): any => {
	if (reducer.resetCounter) {		
		return reducer.resetCounter(counterKey);
	} else {
		_storeInfo.counter = {
			..._storeInfo.counter,
			[counterKey]: {
				total: 0,
				success: 0,
				failed: 0
			}
		};
	}
};

export const getDeviceInfo = (state: StoreState): DeviceInfo => {
	if (selectors.getDeviceInfo) {
		return selectors.getDeviceInfo(state);
	} 
	return _storeInfo.device.deviceInfo;
};

export const setDeviceInfo = (deviceInfo: Partial<DeviceInfo>) => {
	if (reducer.setDeviceInfo) {
		return reducer.setDeviceInfo(deviceInfo);
	}
	_storeInfo.device.deviceInfo = {
		..._storeInfo.device.deviceInfo,
		...deviceInfo
	};
};

export const loadDeviceInfo = (deviceInfo: Partial<DeviceInfo>) => {
	if (reducer.loadDeviceInfo) {
		return reducer.loadDeviceInfo(deviceInfo);
	}
	_storeInfo.device.deviceInfo = {
		..._storeInfo.device.deviceInfo,
		...deviceInfo
	};
};

export const loadPreDeviceInfo = (deviceInfo: Partial<DeviceInfo>) => {
	if (reducer.loadPreDeviceInfo) {
		return reducer.loadPreDeviceInfo(deviceInfo);
	}
	_storeInfo.device.prevDeviceInfo = {
		..._storeInfo.device.prevDeviceInfo,
		...deviceInfo
	};
};

export const setPreDeviceInfo = (deviceInfo: Partial<DeviceInfo>) => {
	if (reducer.setPreDeviceInfo) {
		return reducer.setPreDeviceInfo(deviceInfo);
	}
	_storeInfo.device.prevDeviceInfo = {
		..._storeInfo.device.prevDeviceInfo,
		...deviceInfo
	};
};

export const getPreDeviceInfo = (state: StoreState): DeviceInfo => {
	if (selectors.getPreDeviceInfo) {
		return selectors.getPreDeviceInfo(state);
	}
	return _storeInfo.device.prevDeviceInfo;
};

export const setDeviceRawData = (rawData: number[]) => {
	if (reducer.setDeviceRawData) {
		return reducer.setDeviceRawData(rawData);
	}
	_storeInfo.device.rawData = rawData;
};

export const setSettingMode = (settingMode: string) => {
	if (reducer.setSettingMode) {
		return reducer.setSettingMode(settingMode);
	}
	_storeInfo.device.settingMode = settingMode;
};

export const getRawData = (state: StoreState): number[] => {
	if (selectors.getRawData) {
		return selectors.getRawData(state);
	}
	return _storeInfo.device.rawData;
};

export const setDeviceCardData = (cardData: number[]) => {
	if (reducer.setDeviceCardData) {
		return reducer.setDeviceCardData(cardData);
	}
	_storeInfo.device.cardData = cardData;
};

export const setDSTemplateInfo = (DSTemplateData: any) => {
	if (reducer.setDSTemplateInfo) {
		return reducer.setDSTemplateInfo(DSTemplateData);
	}
	_storeInfo.device.DSTemplateData = DSTemplateData;
};

export const setSDIData = (SDIData: any) => {
	if (reducer.setSDIData) {
		return reducer.setSDIData(SDIData);
	}
	_storeInfo.device.SDIData = SDIData;
};

export const setAllSolenoidWork = (work: any) => {
	if (reducer.setAllSolenoidWork) {
		return reducer.setAllSolenoidWork(work);
	}	
};