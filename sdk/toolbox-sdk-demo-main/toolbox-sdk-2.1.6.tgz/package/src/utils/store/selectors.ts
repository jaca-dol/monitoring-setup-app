const _selectors: Record<string, (...args: any[]) => any> = {};

export const setSelector = (name: string, selector: (...args: any[]) => any) => {
	if (_selectors[name]) {
		return;
	}
	_selectors[name] = selector;
};

export default _selectors;