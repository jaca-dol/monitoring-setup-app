import _ from 'lodash';
import { store } from '../store';
import { saveCounter, resetCounter } from '../store/actions';

class Counter {
	private counters: Record<string, { total: number; success: number; failed: number }>;
	increaseWrite: (type: string, count?: number) => void;
	increaseRead: (type: string, count?: number) => void;
	increaseOperate: (type: string, count?: number) => void;
	constructor() {
		const counterKeys = [ 'read', 'write', 'operate', 'reset', 'upgrade', 'syncTime' ];		

		this.counters = {};
		this.increaseWrite = _.noop;
		this.increaseRead = _.noop;
		this.increaseOperate = _.noop;

		_.forEach(counterKeys, value => {
			this.counters[value] = {
				total: 0,
				success: 0,
				failed: 0
			};
			this.createSetCounterShortMethods(value);
		});
	}

	initCounter(counter: Record<string, { total: number; success: number; failed: number }>) {
		this.counters = _.merge({}, this.counters, counter);
	}

	setCounter(counter: string, type: string, count: number) {
		const preCount = _.get(this.counters, `${counter}.${type}`) as unknown as number;
		const nextCount = preCount + count;

		_.set(this.counters, `${counter}.${type}`, nextCount);
	}

	saveCounter() {
		store.dispatch(saveCounter(this.counters));
	}

	resetCounter(counterKey: string) {

		if(![ 'read', 'write', 'operate', 'reset', 'upgrade', 'syncTime' ].includes(counterKey)) {
			throw new Error('counter 不在范围内');
		}

		_.set(this.counters, `${counterKey}`, {
			total: 0,
			success: 0,
			failed: 0
		});

		store.dispatch(resetCounter(counterKey));
	}

	createSetCounterShortMethods(counterKey: string) {
		// @ts-ignore
		this[`increase${_.upperFirst(counterKey)}`] = (type: string, count: number = 1): void => {
			this.setCounter(counterKey, type, count);
		};
	}

}

export default new Counter();