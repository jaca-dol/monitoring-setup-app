import moment from 'moment';

interface TimeLogs {
	[key: string]: number;
}

export class TimeCounter {
	/**
	 * 计时器的开始时间
	 */
	static timerStarts: TimeLogs = {};

	/**
	 * 记录上一次timeLog的时间戳
	 */
	static lastLogTimes: TimeLogs = {};

	/**
	 * 开始计时器
	 * @param counterKey - 计时器的key
	 */
	static time(counterKey: string) {
		this.timerStarts[counterKey] = Date.now(); // 记录计时器的开始时间
	}

	/**
	 * 计时器打点
	 * @param counterKey - 计时器的key
	 * @param message - 打点的信息
	 */
	static timeLog(counterKey: string, message?: string): {
		counterKey: string;
		message?: string;
		interval: number;
	} | void {
		const startTime = this.timerStarts[counterKey];

		if(!startTime) {
			console.log(`Timer '${counterKey}' does not exist`);
			return;
		}

		const currentTime = Date.now();
		const elapsedTime = currentTime - startTime; // 计算从开始到现在的时间
		const lastLogTime = this.lastLogTimes[counterKey] ?? startTime; // 如果没有上一次记录，则使用开始时间
		const interval = currentTime - lastLogTime; // 计算从上一次timeLog到现在的时间
		const logInterval = interval !== elapsedTime ? interval : elapsedTime;
		const prefix = message ? `${moment(currentTime).format('HH:mm:ss.SSS')} | ${counterKey} | ${message}` : counterKey;
		const suffix = `${logInterval}ms`;

		console.log(prefix, suffix);
		
		this.lastLogTimes[counterKey] = currentTime; // 更新上一次timeLog的时间戳

		return {
			counterKey,
			message,
			interval: logInterval
		};
	}

	/**
	 * 结束计时器
	 * @param counterKey - 计时器的key
	 */
	static timeEnd(counterKey: string) {
		const startTime = this.timerStarts[counterKey];

		if(!startTime) {
			console.log(`Timer '${counterKey}' does not exist`);
			return;
		}

		const currentTime = Date.now();
		const elapsedTime = currentTime - startTime;
		console.log(`${moment(currentTime).format('HH:mm:ss.SSS')} | ${counterKey} ${elapsedTime}ms`);
		delete this.timerStarts[counterKey]; // 停止计时器，并删除开始时间
		delete this.lastLogTimes[counterKey]; // 清除对应的lastLogTime条目

		return elapsedTime;
	}
}