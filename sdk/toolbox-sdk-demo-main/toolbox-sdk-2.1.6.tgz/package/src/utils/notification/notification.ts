const Toast = {
	show: (options: any) => {
		console.log('Toast', options);
		if (options.onShow) {
			options.onShow();
		}
	},
	hide: () => {
		console.log('Toast hide');
	}
};

export const setNotificationToast = (toast: any) => {
	Object.assign(Toast, toast);
};

interface NotificationOptions {
    /**
     * 标题
     */
    title?: string;
    /**
     * 内容
     */
    content: string;
    /**
     * 类型
     */
    type?: 'info' | 'success' | 'error' | 'warning';
    /**
     * 位置
     */
    position?: 'top' | 'bottom';
    /**
     * 是否自动隐藏
     */
    autoHide?: boolean;
    /**
     * 显示时长(ms)，仅在 autoHide 为 true 时生效
     */
    duration?: number;
    /**
     * 延迟时间(ms)，在 onShow 触发后延迟多久执行 resolve
     */
    delay?: number;
    /**
     * 顶部偏移
     */
    topOffset?: number;
    /**
     * 底部偏移
     */
    bottomOffset?: number;
}

/**
 * 通知工具
 */
export const Notification = {
	/**
     * 显示通知
     * @param options 配置选项
     * @returns Promise
     * @example
     * Notification.show({
     *   title: '权限说明',
     *   content: '需要获取相机权限',
     * });
     */
	show: (options: NotificationOptions): Promise<void> => {
		const {
			title,
			content,
			type = 'info',
			position = 'top',
			autoHide = false,
			duration = 3000,
			delay = 300,
			topOffset = 60,
			bottomOffset = 60,
		} = options;

		return new Promise(resolve => {
			Toast.show({
				type,
				text1: title,
				text2: content,
				position,
				autoHide,
				visibilityTime: duration,
				topOffset,
				bottomOffset,
				onShow: () => {
					setTimeout(resolve, delay);
				}
			});
		});
	},

	/**
     * 隐藏通知
     * @param ms 延迟关闭时间(ms)
     */
	hide: (ms?: number) => {
		if(ms) {
			setTimeout(() => {
				Toast.hide();
			}, ms);
		} else {
			Toast.hide();
		}
	}
};
