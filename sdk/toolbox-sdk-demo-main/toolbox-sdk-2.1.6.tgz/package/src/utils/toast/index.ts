export const Toast = {
	fail: (...args: any[]) => {
		console.log('Notice', ...args);
	},
	show: (...args: any[]) => {
		console.log('Notice', ...args);
	}
};

export const setToast = (toast: any) => {
	Object.assign(Toast, toast);
};