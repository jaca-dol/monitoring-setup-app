export interface LoggerType {
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
    error: (...args: unknown[]) => void;
    debug: (...args: unknown[]) => void;
}


const _logger = {
	extend: (tag: string): LoggerType => {
		return {
			info: (...args: unknown[]) => {
				console.info(`[${tag}]`, ...args);
			},
			warn: (...args: unknown[]) => { 
				console.warn(`[${tag}]`, ...args);
			},
			error: (...args: unknown[]) => {
				console.error(`[${tag}]`, ...args);
			},
			debug: (...args: unknown[]) => {
				console.debug(`[${tag}]`, ...args);
			},
		};
	},
};

export const Log = {
	i: (message?: any, ...optionalParams: any[]) => {
		console.info(message, ...optionalParams);
	},
	w: (message?: any, ...optionalParams: any[]) => {
		console.warn(message, ...optionalParams);
	},
	e: (message?: any, ...optionalParams: any[]) => {
		console.error(message, ...optionalParams);
	},
	d: (message?: any, ...optionalParams: any[]) => {
		console.debug(message, ...optionalParams);
	},
};

export const setLog = (log: typeof Log) => {
	Object.assign(Log, log);
};

export type ILogger = typeof _logger;

export type IExtendLoggerFactory = (namespace: string) => LoggerType;

export const setLogger = (logger: typeof _logger) => {
	_logger.extend = logger.extend;
};

export default _logger;
