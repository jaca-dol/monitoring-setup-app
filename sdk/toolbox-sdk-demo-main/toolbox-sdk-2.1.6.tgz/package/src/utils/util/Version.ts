import { compare, CompareOperator, validate } from 'compare-versions';

export class Version {

	static toLowerCase(version: any) {
		if(typeof version != 'string') {
			return version;
		}

		return version.toLowerCase();
	}

	/**
   * 使用指定比较符号比较版本字符串。
   *
   * @param v1 版本号1
   * @param v2 版本号2
   * @param operator 比较符号
   * @returns {boolean}
   *
   * @example
   * ```
   * Version.compare('10.1.8', '10.0.4', '>'); //true
   * Version.compare('10.0.1', '10.0.1', '='); //true
   * Version.compare('10.1.1', '10.2.2', '<'); //true
   * Version.compare('10.1.1', '10.2.2', '<='); //true
   * Version.compare('10.1.1', '10.2.2', '>='); //false
   * ```
   */
	static compare(v1: string, v2: string, operator: CompareOperator): boolean {
		try {
			
			if (!v1 || !v2 || typeof v1 != 'string' || typeof v2 != 'string') {
				return false; 
			}
			
			const version1 = this.toLowerCase(v1.split('-')[0]);
			const version2 = this.toLowerCase(v2.split('-')[0]);
			return compare(version1, version2, operator);
		} catch (error) {
			console.log('error: ', error);
			return false;
		}
	}
	

	/**
	 * 版本号v1是否大于等于v2
	 * @param v1 
	 * @param v2 
	 * @returns 
	 */
	static isGreaterThanOrEqualTo(v1: string, v2: string) {
		return this.compare(v1, v2, '>=');
	}

	/**
	 * 版本号v1是否大于v2
	 * @param v1 
	 * @param v2 
	 */
	static isGreaterThan(v1: string, v2: string) {
		return this.compare(v1, v2, '>');
	}

	/**
	 * 版本号v1是否小于等于v2
	 * @param v1 
	 * @param v2
	 */
	static isLessThanOrEqualTo(v1: string, v2: string) {
		return this.compare(v1, v2, '<=');
	}

	/**
	 * 版本号v1是否小于版本号v2
	 * @param v1 
	 * @param v2 
	 */
	static isLessThan(v1: string, v2: string) {
		return this.compare(v1, v2, '<');
	}

	/**
	 * 版本号v1是否等于v2
	 * @param v1 
	 * @param v2 
	 */
	static isEqual(v1: string, v2: string) {
		return this.compare(v1, v2, '=');
	}

	/**
	 * 版本号是否合法
	 * @param version 
	 */
	static isValid(version: string): boolean {
		try {
			return validate(version);
		} catch (error) {
			console.log('error: ', error);
			return false;
		}
	}
}