import BaseEventEmitter from 'events';

const emitter = new BaseEventEmitter();

emitter.setMaxListeners(100);

export type IEventEmitter = InstanceType<typeof EventEmitter>;

export const EventEmitter = BaseEventEmitter;

export default emitter;