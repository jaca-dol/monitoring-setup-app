export function readFloat16LE(bytes: number[]) {
	const bits = (bytes[1]! << 8) | bytes[0]!;
	const sign = bits >>> 15 === 0 ? 1.0 : -1.0;
	const e = (bits >>> 10) & 0x1f;
	const m = e === 0 ? (bits & 0x3ff) << 1 : (bits & 0x3ff) | 0x400;
	const f = sign * m * Math.pow(2, e - 25);
	return f;
}

export const parseJSONSafely = (jsonString: string) => {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		console.error('解析 JSON 字符串出错:', e);
		// 容错：将不能被正确解析的 JSON 对象的值设为空字符串
		return JSON.parse(jsonString, (key, value) => {
			if (typeof value === 'string') {
				try {
					JSON.parse(value);
				} catch (e) {
					console.error(`解析 JSON 对象 ${key} 出错: 不支持的字符编码`);
					return '';
				}
			}
			return value;
		});
	}
};