import _ from 'lodash';

import { PRIVATE_KEYS } from '../../model/constants';
import { DeviceInfo } from '../../model/deviceInfo';

type PrivateKeyDeviceInfo = Pick<DeviceInfo, 'applicationKey' | 'applicationSessionKey' | 'networkSessionKey' | 'multicast' | 'joinType'>;

/**
 * 私钥key的长度
 */
const PrivateKeysLength = {
	'applicationKey': 32,
	'applicationSessionKey': 32,
	'networkSessionKey': 32,
	'appskey': 32,
	'nwkskey': 32
};

/**
 * 是否为私钥key
 * @param key - key 名称
 */
export const isPrivateKey = (key: string): boolean => {
	return PRIVATE_KEYS.includes(key);
};

/**
 * 加密DeviceInfo中的私钥字段
 * 通常用于写入后隐藏私钥字段
 * @export
 * @param {Object} deviceInfo
 */
export function encodePrivateKeys(deviceInfo: PrivateKeyDeviceInfo) {
	const privateKeys = _.keys(PrivateKeysLength) as (Array<keyof typeof PrivateKeysLength>);
	const newDeviceInfo = _.cloneDeep(deviceInfo);

	privateKeys.map(key => {
		if(_.has(newDeviceInfo, key)) {
			_.set(newDeviceInfo, key, _.pad('', PrivateKeysLength[key], '*'));
		}
	});

	if(_.has(deviceInfo, 'multicast')) {
		const nextMulticastGroups = _.get(newDeviceInfo, 'multicast', []).map(function(multicast) {

			_.set(multicast, 'appskey', _.pad('', PrivateKeysLength['appskey'], '*'));
			_.set(multicast, 'nwkskey', _.pad('', PrivateKeysLength['nwkskey'], '*'));
	
			return multicast;
		});

		_.set(newDeviceInfo, 'multicast', nextMulticastGroups);
	}

	return newDeviceInfo;
}

/**
 * 填充DeviceInfo中的私钥字段
 * 通常用于读取后填充私钥字段
 * @param deviceInfo - 设备信息
 */
export function padPrivateKeys(deviceInfo: PrivateKeyDeviceInfo, isTemplate = false) {
	const privateKeys = _.keys(PrivateKeysLength) as (Array<keyof typeof PrivateKeysLength>);
	const newDeviceInfo = _.cloneDeep(deviceInfo);

	//如果是 LoRaWAN 设备，就填充默认的私钥
	if(deviceInfo.joinType != null) {
		privateKeys.map(key => {
			//如果设备信息里面有对应字段（通常模版文件可能会有，读取不会有），则不填充，否则填充为*
			if(!_.has(newDeviceInfo, key)) {
				_.set(newDeviceInfo, key, _.pad('', PrivateKeysLength[key], '*'));
			}
		});
	}
	//模版下，不填充组播私钥
	if(_.has(deviceInfo, 'multicast') && !isTemplate) {
		const nextMulticastGroups = _.get(newDeviceInfo, 'multicast', []).map(function(multicast) {

			_.set(multicast, 'appskey', _.pad('', PrivateKeysLength['appskey'], '*'));
			_.set(multicast, 'nwkskey', _.pad('', PrivateKeysLength['nwkskey'], '*'));
	
			return multicast;
		});

		_.set(newDeviceInfo, 'multicast', nextMulticastGroups);
	}

	return newDeviceInfo;
}

