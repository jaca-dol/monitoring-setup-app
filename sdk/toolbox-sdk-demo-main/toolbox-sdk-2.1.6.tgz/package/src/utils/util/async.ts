/**
 * 延迟指定毫秒
 * @param ms 
 * @returns 
 */
export const sleep = (ms: number): Promise<number> => new Promise(resolve => setTimeout(() => resolve(0), ms));

/**
 * 同步的延时
 * @param ms 
 * @returns 
 */
export const delay = (ms: number) => {
	const startTime = Date.now();
	let isOk = false;

	while(!isOk) {
		const currentTime = Date.now();

		isOk = currentTime - startTime >= ms;
	}

	return;
};

/**
 * 创建一个定时器，在超时之后返回一个错误。
 *
 * @param {number} ms - 定时器在解决之前等待的时间。
 * @param {string} [message='Timeout'] - 如果定时器解决，则包含在错误中的消息。
 * @return {Object} 包含超时承诺和取消定时器的函数的对象。
 */
export const timer = (ms: number, message = 'Timeout') => {
	let timeoutId: any;
	const timeoutPromise = new Promise((_resolve, reject) => {
		timeoutId = setTimeout(() => {
			const error = new Error(message);
			reject(error);
		}, ms);
	});
	return {
		timeoutPromise,
		cancel: () => {
			clearTimeout(timeoutId);
		},
	};
};

export interface RetryOptions<T = any> {
	/**
	 * 要重试的函数
	 */
	fn: (attempts: number) => Promise<T>;

		/**
		 * 最大重试次数
		 */
	maxRetries?: number;

		/**
		 * 重试间隔时间（毫秒）
		 */
	retryInterval?: number;

		/**
		 * 标签
		 */
	tag?: string;

	/**
	 * 是否打印日志
	 */
	log?: boolean;

	signal?: AbortSignal;

	/**
	 * 判断是否应该重试的函数
	 * @param {any} error - 错误对象
	 * @returns {boolean} true 则继续重试
	 */
	shouldRetry?: (error: any) => boolean;
}

/**
 * 重试给定的函数，直到它成功或达到最大重试次数为止。
 *
 * @param {Function} fn - 要重试的函数。
 * @param {number} maxRetries - 最大重试次数。
 * @param {number} retryInterval - 重试间隔时间（毫秒）。
 * @return {Promise<T>} - 如果函数成功，则返回一个成功的 Promise，否则返回一个拒绝的 Promise。
 */
export async function retry<T = any>(options: RetryOptions<T>): Promise<T> {
	const {
		fn,
		maxRetries = 3,
		retryInterval = 1000,
		tag = 'fn',
		log = __DEV__,
		signal,
		shouldRetry
	} = options;
	let attempts = 0;
	let lastError: any;

	const checkAbort = () => {
		if (signal?.aborted) {
			log && console.log(`${tag} aborted after ${attempts} tries.`);
			throw new Error('RETRY_ABORTED');
		}
	};

	do {
		checkAbort();
		try {
			const result = await fn(attempts);

			if(log && attempts > 0) {
				console.log(`${tag} succeeded after ${attempts + 1} tries.`);
			}

			return result;
		} catch (error) {
			lastError = error;
			attempts++;

			// 如果提供了 shouldRetry 函数，检查是否应该重试
			if (shouldRetry && !shouldRetry(error)) {
				log && console.log(`${tag} failed after ${attempts} tries. shouldRetry returned false, not retrying.`, error);
				return Promise.reject(error);
			}

			log && console.log(`${tag} failed after ${attempts} tries.`, error);
			if (attempts <= maxRetries) {
				await sleep(retryInterval);
			}
		}
	} while (attempts <= maxRetries);

	log && console.log(`${tag} retry limit (${maxRetries}) exceeded. Last error: ${lastError}`);
	return Promise.reject(lastError);
}

/**
 * 运行一个带有指定超时时间的 Promise，并在其在规定时间内解决后返回其结果。
 *
 * @param {Promise<any>} promise - 要在超时时间内运行的 Promise。
 * @param {number} ms - 等待 Promise 解决的毫秒数。
 * @param {string} [message='Timeout'] - 如果 Promise 超时，要使用的可选消息。
 * @returns {Promise<T>} 如果 Promise 在规定时间内解决，它将返回包含 Promise 结果的 Promise。
 */
export const runWithTimeout = async <T = any>(promise: Promise<any>, ms: number, message = 'Timeout', signal?: AbortSignal): Promise<T> => {
	return new Promise((resolve, reject) => {
		const abort = ()=>{
			cancel();
			reject(new Error('RETRY_ABORTED'));
		};
		signal?.addEventListener('abort', abort);

		const { timeoutPromise, cancel } = timer(ms, message);
		Promise.race([ promise, timeoutPromise ]).then(result => {
			cancel();
			resolve(result);
		}).catch(error => {
			reject(error);
		});
	});
};

export class AbortError extends Error {
	constructor(message = 'The operation was aborted.') {
		super(message);
		this.name = 'AbortError';
	}
}

interface SleepOptions {
  /**
   * 一个 AbortSignal，用于在 sleep 完成前取消等待。\
   * 如果提供，并且 signal 被触发 abort，Promise 将会 reject 一个 AbortError。
   */
  signal?: AbortSignal;
}

/**
 * 异步等待指定的毫秒数，支持通过 AbortSignal 取消。
 * @param ms 等待的毫秒数。
 * @param options 包含可选 signal 的配置对象。
 * @returns {Promise<void>} 一个 Promise，在时间到达后 resolve，或者在 signal 被 abort 时 reject。
 */
export const sleepWithSignal = (ms: number, options?: SleepOptions): Promise<void> => {
	const signal = options?.signal;

	return new Promise((resolve, reject) => {
		if (signal?.aborted) {
			return reject(new AbortError());
		}

		const timeoutId = setTimeout(() => {
			if (abortListener) {
				signal?.removeEventListener('abort', abortListener);
			}

			resolve();
		}, ms);

		let abortListener: (() => void) | null = null;

		if (signal) {
			abortListener = () => {
				clearTimeout(timeoutId);
				reject(new AbortError());
			};

			// 添加监听器，使用 once 确保它只触发一次并自动清理
			signal.addEventListener('abort', abortListener, { once: true });
		}
	});
};