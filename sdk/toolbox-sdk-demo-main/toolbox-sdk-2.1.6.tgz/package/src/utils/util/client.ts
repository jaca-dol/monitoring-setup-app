let _sendDevData = (_data: Record<string, any>) => {};
const TOOLBOX_DEBUG_SOCKET_PORT = 22511;

const getEnvString = (value?: string) => (value || '').trim();
const isEnvEnabled = (value?: string) => [ '1', 'true' ].includes(getEnvString(value).toLowerCase());

const sendDevData = (_data: Record<string, any>) => {
	_sendDevData(_data);
};

export const setWebSocketEnable = (enable: boolean) => {

	if (!enable) {
		return;
	}

	if (__DEV__ && typeof WebSocket !== "undefined") {
		const tdEnabled = isEnvEnabled(process.env.TD_ENABLE);
		const server = getEnvString(process.env.TD_SERVER);
		const token = getEnvString(process.env.TD_TOKEN);

		if (!tdEnabled) {
			return;
		}

		if (!server) {
			console.warn('[toolbox-sdk] TD_SERVER is empty, skipping debug socket connection.');
			return;
		}

		const socket = new WebSocket(`ws://${server}:${TOOLBOX_DEBUG_SOCKET_PORT}`);

		socket.onopen = () => {
			console.log('✅ WebSocket connected');
		};

		socket.onerror = e => {
			console.log('❌ WebSocket error:', e.message || e);
		};

		socket.onclose = e => {
			console.log('🔌 WebSocket closed:', e.code, e.reason);
		};
		_sendDevData = (data: Record<string, any>) => {
			try {
				if (socket.readyState === WebSocket.OPEN) {
					const result: Record<string, any> = {};
					result['token'] = token;
					result['data'] = data;
					socket.send(JSON.stringify(result));
				}
			} catch (error) {
				console.error('Failed to send data to DevTools:', error);
			}
		};
	}
};

export default sendDevData;





