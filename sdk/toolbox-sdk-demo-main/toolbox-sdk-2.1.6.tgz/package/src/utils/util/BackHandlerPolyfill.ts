import { BackHandler } from 'react-native';

/**
 * BackHandler Polyfill for React Native 0.77+
 * 为第三方库提供向后兼容的 removeEventListener 方法
 * 
 * 这个 polyfill 直接修改全局的 BackHandler 对象，
 * 所有从 'react-native' 导入 BackHandler 的第三方库都会自动获得兼容性修复
 */

const eventListeners = new Map<() => boolean | null | undefined, { remove: () => void }>();

const originalAddEventListener = BackHandler.addEventListener;

BackHandler.addEventListener = function (eventName: 'hardwareBackPress', handler: () => boolean | null | undefined) {
	const subscription = originalAddEventListener.call(this, eventName, handler);

	eventListeners.set(handler, subscription);

	return subscription;
};

if (!(BackHandler as any).removeEventListener) {
	(BackHandler as any).removeEventListener = function (_eventName: 'hardwareBackPress', handler: () => boolean | null | undefined) {

		const subscription = eventListeners.get(handler);
		if (subscription) {
			subscription.remove();
			eventListeners.delete(handler);
		}
	};
}
