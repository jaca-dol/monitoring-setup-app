import moment from 'moment';
import * as RNLocalize from 'react-native-localize';

import timezoneUS from './timezoneUS.json';

export interface DstConfig {
	/**
	 * 是否启用夏令时
	 */
	enable: boolean;

	/**
	 * 夏令时偏移量（单位分钟）
	 */
	offset: number;

	/**
	 * 夏令时开始时间（utc 时间戳）
	 */
	start: number;

	/**
	 * 夏令时结束时间（utc 时间戳）
	 */
	end: number;
}

/**
 * 获取应用了时区和夏令时的moment对象
 * @param timestamp - 时间戳（utc时间）
 * @param dstConfig - 夏令时配置
 * @param utcOffset - 以分钟为单位的UTC 偏移量
 */
export function getMomentWithTzAndDst(timestamp: number, dstConfig: DstConfig, utcOffset: number): moment.Moment {
	const baseMoment = moment(timestamp);

	if (dstConfig.enable) {
		// 检查当前时间是否在夏令时范围内
		if (timestamp >= dstConfig.start && timestamp <= dstConfig.end) {
			// 如果在夏令时范围内，应用夏令时偏移量
			baseMoment.add(dstConfig.offset, 'minutes');
		}
	}

	// 应用时区偏移
	baseMoment.utcOffset(utcOffset);

	return baseMoment;
}

export interface DaylightItemTime {
	/**
	 * 年份（可选）
	 */
	year?: number;

	/**
	 * 第几月(1-12)
	 */
	month: number;

	/**
	 * 第几周(1-5)
	 */
	weekNum: number;

	/**
	 * 周几(1-7)
	 */
	weekDay: number;

	/**
	 * 分钟数（hour*60+minute）
	 */
	minute: number;
}

/**
 * 获取夏令时的时间戳(以秒为单位)
 */
export function getTimestampForDaylightItem(item: DaylightItemTime, timeZone: number): number {
	const { month, weekDay, minute, year } = item;
	let { weekNum } = item;

	// 计算具体时间
	const hour = Math.floor(minute / 60);
	const minuteOfHour = minute % 60;
	
	// 找到该月的第一天（加上偏移量是因为要计算设备时间的具体年份，如果不加时区，会导致北京时区24年1月1日算出的年份为23年
	const firstDayOfMonth = year != null
		? moment().utc().add(timeZone, 'minutes').year(year).month(month - 1).startOf('month')
		: moment().utc().add(timeZone, 'minutes').month(month - 1).startOf('month');
	// 该月的第一天是星期几
	const firstDayOfMonthWeekDay = firstDayOfMonth.day() === 0 ? 7 : firstDayOfMonth.day();

	//如果该月的第一天正好是第一个指定的星期几，则直接返回该天
	if(weekNum === 1 && firstDayOfMonthWeekDay === weekDay) {
		return firstDayOfMonth.unix();
	}

	// 找到该月的第一个指定的星期几
	const firstWeekDayOfMonth = firstDayOfMonth.clone().day(weekDay);

	// 如果第一个指定的星期几在该月的第一天之前，则往后推一周
	if (firstWeekDayOfMonth.isBefore(firstDayOfMonth)) {
		firstWeekDayOfMonth.add(1, 'week');
	}

	// 如果超过 5 周，则取最后一周
	if (weekNum > 5) {
		weekNum = 5;
	}

	// 计算出目标日期
	const targetDate = firstWeekDayOfMonth.add(weekNum - 1, 'week');

	// 如果目标日期在当前月之后，则往前推一周
	if(targetDate.isAfter(firstDayOfMonth.clone().endOf('month'))) {
		targetDate.subtract(1, 'week');
	}

	// 设置具体时间
	targetDate.set({ hour, minute: minuteOfHour, second: 0, millisecond: 0 });

	// 转换为时间戳
	return targetDate.unix();
}

/**
 * 获取夏令时开始和结束的时间戳
 * @param daylightSaveTime - 夏令时配置
 */
export function getDstTimestamp(daylightSaveTime: {
	start: DaylightItemTime,
	end: DaylightItemTime
	timeZone: number,
}){
	const { start, end, timeZone } = daylightSaveTime;

	return {
		start: getTimestampForDaylightItem(start, timeZone),
		end: getTimestampForDaylightItem(end, timeZone)
	};
}

/**
 * 获取时区偏移量
 * @param tz - IANA时区
 * @param at - 日期
 * @returns 时区偏移量
 */
export function offsetMinutesAt(tz: string, at: Date): number {
	const dtf = new Intl.DateTimeFormat('en-US', {
		timeZone: tz,
		hour12: false,
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
		second: '2-digit',
	});
	const parts = dtf.formatToParts(at);
	const m: Record<string, string> = {};
	for (const p of parts) if (p.type !== 'literal') m[p.type] = p.value;

	const y = Number(m.year), mo = Number(m.month), d = Number(m.day);
	const H = Number(m.hour), M = Number(m.minute), S = Number(m.second);

	// 把“该时区的本地时刻”当作 UTC 构造，再与真实 UTC 时间做差
	const asUTC = Date.UTC(y, mo - 1, d, H, M, S);
	return (asUTC - at.getTime()) / 60000;
}

/**
 * 从IANA时区获取标准时区偏移量
 * @param tz - IANA时区
 * @returns 标准时区偏移量
 */
export function getStandardOffsetMinutesFromIana(tz: string): number {
	const year = new Date().getUTCFullYear();

	// 一般 1/15、7/15 分别处于冬夏季，覆盖南北半球
	const dJan = new Date(Date.UTC(year, 0, 15, 12, 0, 0));
	const dJul = new Date(Date.UTC(year, 6, 15, 12, 0, 0));

	const jan = offsetMinutesAt(tz, dJan);
	const jul = offsetMinutesAt(tz, dJul);

	// 标准时 = 两者中“较小”的那个
	return Math.min(jan, jul);
}

export interface TimeZoneOption {
  id: number;
  timezone: number;     // 小时
  timezoneMin: number;  // 分钟
  timezoneName: string;
}

/**
 * 将标准时区偏移量转换为允许的时区偏移量
 * @param standardMin - 标准时区偏移量
 * @param options - 时区选项列表
 * @returns 最接近的时区偏移量
 */
export function snapToAllowedOffset(
	standardMin: number,
	options: TimeZoneOption[]
): number {
	if (options.length === 0) {
		return standardMin;
	}

	const allowed = options.map(o => o.timezoneMin);

	if (allowed.includes(standardMin)) {
		return standardMin;
	}

	return allowed.reduce((best, current) => {
		return Math.abs(standardMin - current) <
      Math.abs(standardMin - best)
			? current
			: best;
	});
}

/**
 * 获取当前运行环境的时区在当前年份的标准（非夏令时）UTC偏移量
 */
export function getLocalStandardUTCOffset(): number {
	const tz = RNLocalize.getTimeZone();
	const standardMin = getStandardOffsetMinutesFromIana(tz);
	const timezoneMinute = snapToAllowedOffset(standardMin, timezoneUS);
	return timezoneMinute;
}

/**
 * 格式化时间为时、分、秒
 */
export function formatDuration(totalTimeMs: number, t: (key: string) => string): string {
	if (totalTimeMs <= 0) return '';

	const totalSeconds = Math.ceil(totalTimeMs / 1000);
	const hours = Math.floor(totalSeconds / 3600);
	const minutes = Math.floor((totalSeconds % 3600) / 60);
	const seconds = totalSeconds % 60;

	if (hours > 0) {
		const parts: string[] = [];
		parts.push(`${hours}${t('time.hour')}`);
		if (minutes > 0) {
			parts.push(`${minutes}${t('time.minutes')}`);
		}
		if (seconds > 0) {
			parts.push(`${seconds}${t('time.seconds')}`);
		}
		return parts.join('');
	} else if (minutes > 0) {
		const parts: string[] = [];
		parts.push(`${minutes}${t('time.minutes')}`);
		if (seconds > 0) {
			parts.push(`${seconds}${t('time.seconds')}`);
		}
		return parts.join('');
	} else {
		return `${seconds}${t('time.seconds')}`;
	}
}