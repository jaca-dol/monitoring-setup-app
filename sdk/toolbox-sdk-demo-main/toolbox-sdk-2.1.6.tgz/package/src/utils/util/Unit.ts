import { createUnit } from 'mathjs';

export { unit as Unit }  from 'mathjs';

createUnit('kPa', '0.01 bar');
createUnit('MPa', '0.1 bar');
//百毫秒
createUnit('hms', '100 ms');