/* eslint-disable no-redeclare */
import _ from 'lodash';
import { round as mathjsRound } from 'mathjs';

function isFloat(num: any) { 
	return _.isNumber(num) && !_.isInteger(num);
}

//获取小数长度
function getDecimalLength(num: any) {

	if(_.isNaN(_.toNumber(num)) || _.isInteger(num)) {
		return 0;
	} 

	const decimalPortion = _.get(_.split(_.toString(num), '.', 2), '[1]', '');

	return decimalPortion.length;
}

/**
 *  浮点数保留指定的小数位，整数则原样输出
 * 
 * @param {number} num 数字
 * @param {number} digits 要保留的小数位
 * @returns
 */
function fixedNumber(num: number, digits: number) {
	return isFloat(num) && getDecimalLength(num) > digits ? _.toNumber(num.toFixed(digits)) : num;
}

/**
 * 截取小数位，不进行四舍五入
 * @export
 * @param {Number | string} num
 * @param {Number} decimalPlaces
 * @returns 保留小数位后的结果
 */
function truncateDecimal(num: number | string, decimalPlaces: number) {
	const rawNum = num;

	if (decimalPlaces < 0) {
		console.warn('The decimalPlaces should be a positive integer.');
		return rawNum;
	}

	if (typeof num === 'string') {
		const numStr = num.toString();
		const decimalIndex = numStr.indexOf('.');	

		if(isNaN(+num)) {
			return rawNum;
		}

		if (decimalIndex === -1) {
			// 没有小数点，直接返回原始值
			return +num;
		}
		
		const decimalPart = numStr.slice(decimalIndex + 1);
		
		if (decimalPart.length <= decimalPlaces) {
			// 小数位数不超过指定位数，直接返回原始值
			return +num;
		}
		
		const truncatedDecimal = decimalPart.slice(0, decimalPlaces);
		const truncatedNumStr = numStr.slice(0, decimalIndex + 1) + truncatedDecimal;
		const truncatedNum = parseFloat(truncatedNumStr);

		return truncatedNum;
	}

	if (typeof num !== 'number' || isNaN(num)) {
		console.warn('The first parameter should be a number.');
		return rawNum;
	}

	if(_.isInteger(num)) {
		return rawNum;
	}

	const sign = num < 0 ? -1 : 1;
	const absoluteNum = Math.abs(num);
	const factor = Math.pow(10, decimalPlaces);
	const truncatedNum = Math.floor(absoluteNum * factor) / factor;
	const result = truncatedNum * sign;

	return result;
}

/**
 * 返回一个数字四舍五入后的结果
 * @param {number} num - 数字
 * @param {number} decimalPlaces - 保留的小数位
 * @param {boolean} fillZeros - 是否填充零，如果小数位不足需要填充0，返回字符串，如果小数位足够则不填充，返回数字
 * @returns 
 */
function round(num: number, decimalLength: number, fillZeros?: false | undefined): number;
function round(num: number, decimalLength: number, fillZeros: true): string | number;
function round(num: number, decimalPlaces = 0, fillZeros = false): string | number {
	/**
	 * 使用 math.js 的 round 函数将数字四舍五入到指定小数位数
	* 它的四舍五入算法与 Number.prototype.toFixed() 不同
	* 例如，round(1.005, 2) === 1.01，而 1.005.toFixed(2) === 1.00
	* toFixed比较不符合我们常规的四舍五入，所以使用math.js的round
	 */
	const rounded = mathjsRound(num, decimalPlaces);

	if (fillZeros) {
		// 将数字转换为字符串以检查小数位数
		const numStr = String(rounded);
		// 分隔整数部分和小数部分
		const parts = numStr.split('.');
		const integerPart = parts[0];
		let decimalPart = parts[1] || '';

		// 计算需要填充的零的数量
		const zerosToFill = decimalPlaces - decimalPart.length;

		// 如果小数位不足，填充零并返回字符串
		if (zerosToFill > 0) {
			decimalPart += '0'.repeat(zerosToFill);

			return integerPart + (decimalPart ? '.' + decimalPart : '');
		}
	}

	return rounded;
}

/**
 * 转换value为数字
 *
 * @param {*} value
 * @returns 返回数字 如果value是非字符串数字，则返回原本的值
 */
function toNumber(value: any) {
	if(_.isNil(value) || value === '' || _.isObject(value)) {
		return value;
	}

	if(typeof value === 'string' && value.endsWith('.')) {
		return value;
	}

	return _.toNumber(value);
}

/**
 * 16进制的字符串转为10进制
 * @param {string} hex 
 * @returns 
 */
function hexStr2Decimal(hex: string) {
	if(_.isNil(hex) || hex === '') {
		return hex;
	}

	if(!_.isString(hex)) {
		return hex;
	}

	const prefix = hex.toLowerCase().startsWith('0x') ? '' : '0x';
	const decimal = _.toNumber(`${prefix}${hex}`);

	return decimal;
}

/**
 * 10进制转为16进制字符串
 */
function decimal2HexStr(dec?: number | string) {
	if(_.isNil(dec) || dec === '') {
		return dec;
	}

	if(!_.isNumber(dec)) {
		return dec;
	}

	return dec.toString(16);
}

export default {
	isFloat,
	getDecimalLength,
	fixedNumber,
	truncateDecimal,
	toNumber,
	hexStr2Decimal,
	decimal2HexStr,
	round
};