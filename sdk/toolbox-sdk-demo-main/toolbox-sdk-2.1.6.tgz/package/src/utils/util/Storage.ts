import { MMKV } from 'react-native-mmkv';
import { assign, uniqueId } from 'lodash';

export interface StorageOptions {
	/**
	 * 实例的ID。如果想使用多个实例，请确保使用不同的ID！
	 */
	id: string;

	/**
	 * 实例的根路径。默认情况下，MMKV将文件存储在“$（Documents）/MMKV/”中。可以在初始化时自定义MMKV的根目录
	 */
	path?: string;

	/**
	 * Storage实例的加密/解密密钥。
	 * 默认情况下，将所有密钥值以纯文本形式存储在文件中，并依靠iOS的沙盒来确保文件加密。
	 * 如果你担心信息泄露，你可以选择加密。
	 */
	encryptionKey?: string;
}

export class Storage {
	private storage: MMKV | undefined;

	private keyTypeMap = new Map<string, string>();

	constructor(options?: Partial<StorageOptions>) {
		const storageOptions = assign({
			id: uniqueId('storage_'),
			debug: __DEV__
		}, options);

		this.init(storageOptions);
	}

	public init(options: StorageOptions) {
		try {
			this.storage = new MMKV(options);
		} catch (error) {
			console.error('storage init error', error);
		}
	}

	public addOnValueChangedListener(listener: (key: string) => void): {remove: () => void} | undefined {
		return this.storage?.addOnValueChangedListener(listener);
	}

	public set(key: string, value: any) {
		try {
			const type = this.getType(value);

			if(![ 'number', 'string', 'boolean' ].includes(type)) {
				value = JSON.stringify(value);
			}

			this.storage?.set(key, value);
			this.keyTypeMap.set(key, type);
		} catch (error) {
			console.error(`Error setting [${key}] to storage:`, error);
		}
	}

	/**
	 * 通过key获取值
	 * @param key - key to get
	 * @returns
	 */
	public get<T extends string | number | boolean | Record<any, any> | null>(key: string): T | null {
		// If the key is not registered, return a string value
		if(!this.keyTypeMap.has(key)) {
			return this.getString(key) as T;
		}
		
		// Get the type of the key
		const keyType = this.keyTypeMap.get(key);

		// Return the value based on the type
		if(keyType === 'number') {
			return this.getNumber(key) as T;
		}

		if(keyType === 'boolean') {
			return this.getBoolean(key) as T;
		}

		if(keyType === 'object') {
			return this.getObject(key);
		}

		return this.getString(key) as T;
	}

	public getString(key: string) {
		return this.storage?.getString(key) ?? null;
	}

	public getNumber(key: string) {
		return this.storage?.getNumber(key) ?? null;
	}

	public getBoolean(key: string) {
		return this.storage?.getBoolean(key) ?? null;
	}

	public getObject<T extends Record<any, any>>(key: string): T | null {
		try {
			const str = this.storage?.getString(key);

			if(str == null) {
				return null;
			}

			return JSON.parse(str);
		} catch (error) {
			return null;
		}
	}

	public getAllKeys(): string[] {
		return this.storage?.getAllKeys() ?? [];
	}

	public delete(key: string) {
		this.storage?.delete(key);
	}

	public clearAll() {
		this.storage?.clearAll();
	}


	/**
	 * get type from value
	 */
	private getType(value: any) {
		if(value === null) {
			return 'null';
		}

		if(value === undefined) {
			return 'undefined';
		}

		return typeof value;
	}
}

export type IStorage = InstanceType<typeof Storage>;