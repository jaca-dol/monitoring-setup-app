export type DeepKeyOf<T> = T extends Record<string | number, unknown>
  ? {
      [K in keyof T]: `${Extract<K, string>}${T[K] extends Record<
        string | number,
        unknown
      >
        ? "."
        : ""}${DeepKeyOf<T[K]>}`;
    }[keyof T]
  : "";

export type DeepValueOf<T, K extends string> = K extends keyof T
  ? T[K]
  : K extends `${infer P}.${infer R}`
  ? P extends keyof T
    ? DeepValueOf<T[P], R>
    : unknown
  : unknown;

/**
 * 提取对象的所有叶子节点
 * @example "a" | "b" | "nest.c" | "otherNest.c"
 * @link https://stackoverflow.com/a/58436959/10611883
 */
export type Leaves<T> = T extends object
	? {
			[K in keyof T]: `${Exclude<K, symbol>}${Leaves<T[K]> extends never
				? ''
				: `.${Leaves<T[K]>}`}`;
	}[keyof T]
	: never;


//添加对record<string, any>的支持
type _KeyPath<P, I = null> = {
    [K in keyof P]-?:
        K extends string ?
            IsSpecificObject<Exclude<P[K], undefined>> extends true ?
                I extends string ?
                    `${I}.${K}` | _KeyPath<Exclude<P[K], undefined>, `${I}.${K}`>
                :
                    `${K}` | _KeyPath<Exclude<P[K], undefined>, `${K}`>
            :
                I extends string ?
                    `${I}.${K}`
                :
                    `${K}`
        :
            never
}[keyof P]

export type KeyPathDeepOnlyObject<T> = {
    [K in keyof T]-?:
        K extends string ?
            Exclude<T[K], undefined> extends Array<any> ?
                K
            :
            Exclude<T[K], undefined> extends object ?
                K | `${K}.${KeyPathDeepOnlyObject<Exclude<T[K], undefined>>}`
            :
                K

        :
            never
}[keyof T]

type IsSpecificObject<T> = T extends Record<string, any>
  ? (string extends keyof T ? false : true)
  : false;


/**
 * 将对象的某些属性变为可选
 */
export type MakeOptional<T, K extends keyof T> = Partial<Pick<T, K>> & Omit<T, K>;


/**
 * 支持对象数组，
 * Example:
 * {
 *  a: 1,
 *  b: [
 *    2,
 *    {
 *      a: 1,
 *      b: 2
 *    }
 *  ]
 * }
 *
 *  const a: KeyPath<Example> =  'b.1.a' valid
 *  可以配合getP 获取键值
 */
export type KeyPath<P, I = null> = _KeyPath<P, I> & string

export const getP = <P>(obj: any, path: KeyPathDeepOnlyObject<P>) => {
	const keys = path.split('.') as Array<keyof any>;
	return keys.reduce((acc, key) => {
		if (acc && typeof acc === 'object') {
			return acc[key];
		}
		return undefined;
	}, obj as any);
};

export type PartialByKeys<T, K extends keyof T> = Omit<T, K> & {
	[P in K]?: T[P];
};

/**
 * 将 snake_case 字符串类型转换为 camelCase 字符串类型
 * @example 'user_id' -> 'userId'
 */
export type SnakeToCamelCase<S extends string> =
  S extends `${infer Head}_${infer Tail}`
    ? `${Head}${Capitalize<SnakeToCamelCase<Tail>>}`
    : S

/**
 * 递归将对象类型的所有 key 从 snake_case 映射为 camelCase
 * - 支持嵌套对象和数组
 * - 保留值的类型和可选/只读属性
 * - 不改变 Symbol 类型的 key
 * @example { user_id: 1 } -> { userId: 1 }
 */
export type CamelCaseKeys<T> =
  // 如果是数组类型，递归处理其元素类型
  T extends Array<infer U>
    ? Array<CamelCaseKeys<U>>
    : // 如果是对象类型，递归处理每个属性的 key 和 value
    T extends object
      ? {
          [K in keyof T as K extends string
            ? SnakeToCamelCase<K>
            : K]: CamelCaseKeys<T[K]>
        }
      : T // 其它情况（如基础类型），原样返回

/**
 * 忽略数组元素中的指定字段
 * @example OmitArrayFields<Array<{ a: number, b: number, c: number }>, 'b' | 'c'> = Array<{ a: number }>
 */
export type OmitArrayFields<T extends Array<any>, K extends keyof T[number]> = Array<Omit<T[number], K>>;


/**
 * 剥离 Promise 的类型
 */
export type UnwrapPromise<T> = T extends Promise<infer R> ? R : T;