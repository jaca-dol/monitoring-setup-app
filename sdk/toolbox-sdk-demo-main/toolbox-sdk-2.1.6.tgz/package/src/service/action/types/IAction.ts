import { INfcTracker, INfcProtocol } from '../../../service/nfc';

import { PartialDeviceInfo, DeviceInfo } from '../../../model/deviceInfo';

import { NfcProxy } from '../../../service/nfc';
import { NfcCommanderV2 } from '../../../service/nfc';
import { ILogger } from '../../../utils/logger';
import { IIPSOProtocol } from '../../../service/ipso';
import { IDeviceDataModelManager } from '../../../model/tsl';
import { IDeviceDataCodecManager } from '../../../model/codec';
import { BleManager } from '../../DeviceManager/ble/BleManager';
import { BleCommanderV2 } from '../../DeviceManager/ble/BleCommanderV2';
import { BleProtocolV2 } from '../../DeviceManager/protocol/BleProtocolV2';

/**
 * 动作接口
 */
export interface IAction<Params extends any[] = any[], Response = any> {
	/**
	 * 是否支持执行该动作
	 */
	canExecute(): Promise<boolean>;

	/**
	 * 执行动作
	 * @param params - 参数
	 * @returns 返回值
	 */
	execute(...params: Params): Promise<Response>;
}

/**
 * 基础动作API接口
 */
export interface IBaseActionApi {
	/**
	 * IPSO协议
	 */
	ipsoProtocol: IIPSOProtocol;

	/**
	 * 设备数据模型管理器
	 */
	dataModelManager: IDeviceDataModelManager;

	/**
	 * 设备数据编解码器管理器
	 */
	dataCodecManager: IDeviceDataCodecManager;

	/**
	 * 日志打印（控制台日志/文件日志）
	 */
	logger: ILogger;

	/**
	 * 日志记录(redux存储日志)
	 */
	log: {
		/**
		 * 错误日志
		 */
		error(content: string, ...data: any): void;

		/**
		 * 通知日志
		 */
		info(content: string, ...data: any): void;
	};

	/**
	 * 获取当前设备信息
	 */
	getDeviceInfo(): DeviceInfo;

	/**
	 * 设置设备信息
	 */
	setDeviceInfo(deviceInfo: PartialDeviceInfo): void;
}

/**
 * NFC动作API接口
 */
export interface INfcActionApi extends IBaseActionApi {
	/**
	 * NFC代理
	 */
	nfcProxy: InstanceType<typeof NfcProxy>;

	/**
	 * NFC协议
	 */
	nfcProtocol: INfcProtocol;

	/**
	 * NFC跟踪器
	 */
	tracker: INfcTracker;
    /**
	 * NfcCommander
	 */
	commander: InstanceType<typeof NfcCommanderV2>;
}

/**
 * BLE动作API接口
 */
export interface IBleActionApi extends IBaseActionApi {
	/**
	 * BLE管理器
	 */
	bleManager: InstanceType<typeof BleManager>;

	/**
	 * BLE协议
	 */
	bleProtocol: BleProtocolV2;

	/**
	 * BLECommander
	 */
	bleCommander: InstanceType<typeof BleCommanderV2>;
}

/**
 * 动作API类型联合
 */
export type IActionApi = INfcActionApi | IBleActionApi;

/**
 * 动作构造函数类型
 */
export interface IActionConstructor<Api extends IActionApi = IActionApi, Params extends any[] = any[], Response = any> {
	new (api: Api): IAction<Params, Response>;
}

/**
 * 动作API类型
 */
export type ActionApiType = 'nfc' | 'ble';

/**
 * 动作构造函数类型映射
 */
export interface ActionConstructorMap {
	nfc: IActionConstructor<INfcActionApi>;
	ble: IActionConstructor<IBleActionApi>;
}

/**
 * 动作构造函数类型
 */
export type ActionConstructor = IActionConstructor<IActionApi>;
