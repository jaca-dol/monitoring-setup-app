/**
 * 动作类型
 */
export interface ActionTypes {
  /**
   * action名称
   */
  'EXAMPLE_ACTION': {
    /**
     * action 参数
     */
    params: [string];

    /**
     * action 返回值
     */
    response: string;
  }
}

export type ActionName = keyof Omit<ActionTypes, 'EXAMPLE_ACTION'>;