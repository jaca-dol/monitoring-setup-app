import Logger,{ LoggerType } from '../../../utils/logger';

import { ActionConstructor, IAction, IActionApi, ActionApiType, ActionConstructorMap, IActionConstructor } from '../types/IAction';
import { ActionName, ActionTypes } from '../types/IActionTypes';
export class ActionManager {
	private static logger: LoggerType = Logger.extend('ActionManager');

	private static actionMap: Map<string, ActionConstructor> = new Map();

	/**
	 * action注册
	 * @param name - action name
	 */
	static registerAction<ApiType extends ActionApiType>(name: string) {
		return (target: ActionConstructorMap[ApiType]) => {
			this.actionMap.set(name, target as IActionConstructor);
		};
	}

	/**
	 * 获取action实例
	 * @param name - action name
	 * @param api - action api
	 */
	private static getActionInstance(name: string, api: IActionApi): IAction | undefined {
		const actionConstructor = this.actionMap.get(name);

		if (!actionConstructor) {
			return undefined;
		}

		return new actionConstructor(api);
	}

	/**
	 * 获取action
	 */
	static getAction<N extends ActionName>(name: N, api: IActionApi): IAction<ActionTypes[N]['params'], ActionTypes[N]['response']> | undefined {
		const action = this.getActionInstance(name, api);

		return action;
	}

	/**
	 * 获取execute绑定参数的action
	 * @param name - action name
	 * @param api - action api
	 * @param restParams - action params
	 */
	static getActionWithParams<N extends ActionName>(name: N, api: IActionApi, ...restParams: ActionTypes[N]['params']): IAction<any[], ActionTypes[N]['response']> | undefined {
		const action = this.getActionInstance(name, api);

		if (!action) {
			return undefined;
		}

		action.execute = action.execute.bind(action, ...restParams);

		return action;
	}

	/**
	 * 检查action是否可以执行
	 * @param action - action to be executed
	 */
	static async checkActionCanExecute(action?: IAction): Promise<boolean> {
		try {
			if (!action) {
				return false;
			}

			const canExecute = await action.canExecute();

			return canExecute;
		} catch (error) {
			return false;
		}
	}

	/**
	 * action装饰器
	 * @param actionName - action 名称
	 * @param actionApi - action api
	 */
	static withAction<N extends ActionName>(actionName: N, actionApi?: IActionApi) {
		const logger = this.logger;

		return function(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
			const originalMethod = descriptor.value;

			descriptor.value = async function(...args: any[]) {
				const api: IActionApi = actionApi ?? (this as any).actionApi ?? target.actionApi; //假设类的实例或者原型上有api属性

				if (!api) {
					logger.debug('api is not defined run original method');
					return originalMethod.apply(this, args);
				}

				const action = ActionManager.getActionWithParams(actionName, api);

				if (action) {
					const canExecute = await ActionManager.checkActionCanExecute(action);

					if (canExecute) {
						logger.debug(`${propertyKey} | action can be executed, run action ${actionName}`);
						return action.execute(...args as any);
					}
				}

				logger.debug(`${propertyKey} | action ${actionName} cannot be executed, run original method`);

				// 如果Action不能执行，调用原始方法
				return originalMethod.apply(this, args);
			};
		};
	}
}