/**
 * 设备是否支持IPSO动作的缓存
 */
export class SupportIPSOActionCache {
	/**
	 * 缓存
	 */
	static cache: Map<string, boolean> = new Map();

	/**
	 * 返回是否支持IPSO动作
	 * @param id - ID
	 * @returns 'unknown' | 'support' | 'notSupport' - 未知 | 支持 | 不支持
	 */
	static getIsSupportIPSOAction(id: string): 'unknown' | 'support' | 'notSupport' {
		if(this.cache.has(id)) {
			return this.cache.get(id) ? 'support' : 'notSupport';
		}

		return 'unknown';
	}

	/**
	 * 设置是否支持IPSO动作
	 * @param id - ID
	 * @param support - 是否支持IPSO动作
	 */
	static setSupportIPSOAction(id: string, support: boolean) {
		this.cache.set(id, support);
	}

	/**
	 * 移除是否支持IPSO动作
	 * @param id - ID
	 */
	static removeSupportIPSOAction(id: string) {
		this.cache.delete(id);
	}
}