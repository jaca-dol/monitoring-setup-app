import { LoggerType } from '../../../utils/logger';
import { IAction, IActionApi } from '../types/IAction';

export abstract class BaseAction<Params extends any[] = any[], Response = any, Api extends IActionApi = IActionApi> implements IAction<Params, Response> {
	/**
	 * 动作名称
	 */
	name: string;

	/**
	 * 动作API
	 */
	api: Api;

	/**
	 * 动作日志记录器
	 */
	logger: LoggerType;

	constructor(api: Api) {
		this.api = api;
		this.name = this.constructor.name;
		this.logger = api.logger.extend(this.name);
	}

	/**
	 * 错误处理
	 */
	handleError(error: any, logOptions?: {
		/**
		 * 是否记录错误日志
		 */
		logError?: boolean;

		/**
		 * 日志内容
		 */
		logContent?: string;
	}): any {
		const { logError, logContent } = {
			logError: true,
			logContent: `execute ${this.name} error: `,
			...logOptions,
		};

		if(logError) {
			this.api.log.error(logContent, error);
		}

		return Promise.reject(error);
	}

	abstract canExecute(): Promise<boolean>;

	abstract execute(..._params: Params): Promise<Response>;
}