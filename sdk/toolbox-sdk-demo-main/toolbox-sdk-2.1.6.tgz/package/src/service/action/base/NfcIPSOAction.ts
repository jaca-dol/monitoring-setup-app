import { IPSOProtocolError } from '../../../service/ipso';
import { NfcError, NfcUtils } from '../../../service/nfc';
import { TimeCounter } from '../../../utils/counter';
import { SupportIPSOActionCache } from '../SupportIPSOActionCache';
import { INfcActionApi } from '../types/IAction';
import { BaseAction } from './BaseAction';

/**
 * 基础的IPSO相关动作
 * 实现了判断设备是否支持IPSO协议的canExecute方法
 * 方便后面的子类继承复用
 */
export abstract class NfcIPSOAction<Params extends any[] = any[], Response = any> extends BaseAction<Params, Response, INfcActionApi> {

	private async sleepWithProgressUpdate(ms: number): Promise<void> {
		const steps = 60;
		const stepDelay = ms / steps;

		for (let i = 0; i < steps; i++) {
			await NfcUtils.sleepWithMS(stepDelay);
			this.api.tracker.onProgress();
		}
	}

	/**
	 * 判断设备是否支持IPSO协议
	 */
	async canExecute(): Promise<boolean> {
		const tagId = this.api.nfcProxy.tag?.id;

		try {
			TimeCounter.time('IPSOAction | canExecute');
			const supportType = tagId ? SupportIPSOActionCache.getIsSupportIPSOAction(tagId) : 'unknown';

			//如果缓存中有记录，直接返回
			if(supportType !== 'unknown') {
				const supported = supportType === 'support';
				this.logger.debug(`canExecute | from cache: ${tagId} is ${supported ? 'support' : 'not support'} IPSO action`);

				return Promise.resolve(supported);
			}

			const readRequest = this.api.ipsoProtocol.encodeRequest({request_query_all_configurations: 1}, {autoAddCheckPassword: false});
			const readFrame = this.api.nfcProtocol.encodeFrame(readRequest);
			const response = await this.api.commander.send(readFrame, {checkTimeout: 1000});//检查能不能支持 ipso 协议，通常只需要500ms，多做一些冗余

			try {
				this.api.ipsoProtocol.decodeResponse(response);
			} catch (error) {
				if(IPSOProtocolError.isIPSOProtocolError(error)) {
					// 如果是IPSO密码校验失败，说明设备支持IPSO协议
					if(error.name === IPSOProtocolError.ERRORS.CHECK_PASSWORD_ERROR.name) {
						tagId && SupportIPSOActionCache.setSupportIPSOAction(tagId, true);
						return Promise.resolve(true);
					}

					//如果是不支持解析，说明设备支持IPSO协议
					if(error.name === IPSOProtocolError.ERRORS.NOT_SUPPORT_PARSE.name) {
						tagId && SupportIPSOActionCache.setSupportIPSOAction(tagId, true);
						return Promise.resolve(true);
					}
				}
			}

			return Promise.resolve(false);
		} catch (error) {
			this.logger.debug("canExecute | error:", error);

			// 如果收到ackError，说明是旧协议设备
			if(error === NfcError.ackError) {
				this.logger.debug("canExecute | is old protocol device");
				tagId && SupportIPSOActionCache.setSupportIPSOAction(tagId, false);
				return Promise.resolve(false);
			}

			//部分旧设备，如EM500v1/EM300 v2/UC50X v2/v3和WS50X v1存在NFC未切方向的遗留问题，超时失败后需要延迟再执行后续动作
			if(error === NfcError.timeout) {
				this.logger.debug("canExecute | timeout, sleep with progress simulation");
				// 每次调用 onProgress() 让 currentProgress + 1,避免进度条卡住
				await this.sleepWithProgressUpdate(3000);
			}

			return Promise.resolve(false);
		} finally {
			TimeCounter.timeEnd('IPSOAction | canExecute');
		}
	}

	handleError(error: any, logOptions?: {
		/**
		 * 是否记录错误日志
		 */
		logError?: boolean;

		/**
		 * 日志内容
		 */
		logContent?: string;
	}) {
		if(IPSOProtocolError.isIotIpsoProtocolError(error)) {
			return super.handleError(IPSOProtocolError.getErrorByIotIpsoProtocolError(error), logOptions);
		}

		return super.handleError(error, logOptions);
	}

	abstract execute(..._params: Params): Promise<Response>;
}