import { IPSOProtocolError } from '../../../service/ipso';
import { TimeCounter } from '../../../utils/counter';
import { delay } from '../../../utils/util';
import { SupportIPSOActionCache } from '../SupportIPSOActionCache';
import { IBleActionApi } from '../types/IAction';
import { BaseAction } from './BaseAction';

/**
 * 基础的BLE IPSO相关动作
 * 实现了判断设备是否支持IPSO协议的canExecute方法
 * 方便后面的子类继承复用
 */
export abstract class BleIPSOAction<Params extends any[] = any[], Response = any> extends BaseAction<Params, Response, IBleActionApi> {
	/**
	 * 判断设备是否支持IPSO协议
	 */
	async canExecute(): Promise<boolean> {
		const bleId = this.api.bleManager.getCurrentConnectedPeripheral()?.id;

		try {
			TimeCounter.time('BleIPSOAction | canExecute');
			const supportType = bleId ? SupportIPSOActionCache.getIsSupportIPSOAction(bleId) : 'unknown';

			//如果缓存中有记录，直接返回
			if(supportType !== 'unknown') {
				const supported = supportType === 'support';
				this.logger.debug(`canExecute | from cache: ${bleId} is ${supported ? 'support' : 'not support'} IPSO action`);

				return Promise.resolve(supported);
			}

			const readRequest = this.api.ipsoProtocol.encodeRequest({request_query_all_configurations: 1}, {autoAddCheckPassword: false});
			const readFrame = this.api.bleProtocol.encodeFrame(readRequest);
			const response = await this.api.bleCommander.send(readFrame, {checkTimeout: 1500});
			this.api.ipsoProtocol.decodeResponse(response.data);

			return Promise.resolve(true);
		} catch (error: any) {
			this.logger.debug("canExecute | error:", error);

			// 如果是IPSO密码校验失败，说明设备支持IPSO协议
			if(IPSOProtocolError.isIPSOProtocolError(error) && error.name === IPSOProtocolError.ERRORS.CHECK_PASSWORD_ERROR.name) {
				bleId && SupportIPSOActionCache.setSupportIPSOAction(bleId, true);
				return Promise.resolve(true);
			}

			// 如果是旧协议的响应，说明设备不支持IPSO协议
			if(error === 'oldProtocolResponse') {
				this.logger.debug('canExecute | is old protocol device');
				bleId && SupportIPSOActionCache.setSupportIPSOAction(bleId, false);
				return Promise.resolve(false);
			}

			//旧协议设备在发送ee超时失败后需要延迟一会再执行后续动作
			if(error?.message === 'Timeout') {
				this.logger.debug('canExecute | timeout, sleep');
				delay(2500);
			}

			return Promise.resolve(false);
		} finally {
			TimeCounter.timeEnd('BleIPSOAction | canExecute');
		}
	}

	handleError(error: any, logOptions?: {
		/**
		 * 是否记录错误日志
		 */
		logError?: boolean;

		/**
		 * 日志内容
		 */
		logContent?: string;
	}) {
		if(IPSOProtocolError.isIotIpsoProtocolError(error)) {
			return super.handleError(IPSOProtocolError.getErrorByIotIpsoProtocolError(error), logOptions);
		}

		return super.handleError(error, logOptions);
	}

	abstract execute(..._params: Params): Promise<Response>;
}