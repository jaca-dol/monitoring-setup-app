import { IBleActionApi } from '../types/IAction';
import { BaseActionApi, IBaseParams } from './BaseActionApi';
import { BleManager } from '../../DeviceManager/ble/BleManager';
import { BleProtocolV2 } from '../../DeviceManager/protocol/BleProtocolV2';
import { BleCommanderV2 } from '../../DeviceManager/ble/BleCommanderV2';

interface IBleActionParams extends IBaseParams {
	manager: InstanceType<typeof BleManager>;
	protocol: BleProtocolV2;
	commander: InstanceType<typeof BleCommanderV2>;
}

/**
 * BLE动作API
 */
export class BleActionApi extends BaseActionApi implements IBleActionApi {
	/**
	 * BLE管理器
	 */
	bleManager: InstanceType<typeof BleManager>;

	/**
	 * BLE协议
	 */
	bleProtocol: BleProtocolV2;

	/**
	 * BLE命令收发器
	 */
	bleCommander: InstanceType<typeof BleCommanderV2>;

	constructor(params: IBleActionParams) {
		super(params);
		this.bleManager = params.manager;
		this.bleProtocol = params.protocol;
		this.bleCommander = params.commander;
	}
}