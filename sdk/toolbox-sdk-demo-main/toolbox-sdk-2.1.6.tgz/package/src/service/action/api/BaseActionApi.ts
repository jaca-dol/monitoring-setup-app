import { store } from '../../../utils/store';
import { DeviceInfo, PartialDeviceInfo } from '../../../model/deviceInfo';
import { getDeviceInfo, setDeviceInfo } from '../../../utils/store/actions';
import { ILogger } from '../../../utils/logger';
import { IIPSOProtocol } from '../../../service/ipso';
import { IDeviceDataModelManager } from '../../../model/tsl';
import { IDeviceDataCodecManager } from '../../../model/codec';
import { IBaseActionApi } from '../types/IAction';

export interface IBaseParams {
	ipsoProtocol: IIPSOProtocol;
	dataModelManager: IDeviceDataModelManager;
	dataCodecManager: IDeviceDataCodecManager;
	logger: ILogger;
	log: {
		error(content: string, ...data: any): void;
		info(content: string, ...data: any): void;
	};
}

export abstract class BaseActionApi implements IBaseActionApi {
	public ipsoProtocol: IBaseParams['ipsoProtocol'];
	public dataModelManager: IBaseParams['dataModelManager'];
	public dataCodecManager: IBaseParams['dataCodecManager'];
	public logger: IBaseParams['logger'];
	public log: IBaseParams['log'];

	constructor(params: IBaseParams) {
		this.ipsoProtocol = params.ipsoProtocol;
		this.dataModelManager = params.dataModelManager;
		this.dataCodecManager = params.dataCodecManager;
		this.logger = params.logger;
		this.log = params.log;
	}

	getDeviceInfo() {
		return getDeviceInfo(store.getState() as any) as DeviceInfo;
	}

	setDeviceInfo(deviceInfo: PartialDeviceInfo) {
		store.dispatch(setDeviceInfo(deviceInfo));
	}
}
