import { BaseActionApi, IBaseParams } from './BaseActionApi';
import { INfcActionApi } from '../types/IAction';
import { NfcProxy } from '../../../service/nfc';
import { INfcTracker, INfcProtocol } from '../../../service/nfc';
import { NfcCommanderV2 } from '../../nfc/NfcCommanderV2';
interface INfcActionParams extends IBaseParams {
	nfcProxy: InstanceType<typeof NfcProxy>;
	nfcProtocol: INfcProtocol;
	tracker: INfcTracker;
    commander: InstanceType<typeof NfcCommanderV2>;
}

/**
 * NFC动作API
 */
export class NfcActionApi extends BaseActionApi implements INfcActionApi {
	public nfcProxy: INfcActionParams['nfcProxy'];
	public nfcProtocol: INfcActionParams['nfcProtocol'];
	public tracker: INfcActionParams['tracker'];
	public commander: INfcActionParams['commander'];

	constructor(params: INfcActionParams) {
		super(params);
		this.commander = params.commander;
		this.nfcProxy = params.nfcProxy;
		this.nfcProtocol = params.nfcProtocol;
		this.tracker = params.tracker;
	}
}