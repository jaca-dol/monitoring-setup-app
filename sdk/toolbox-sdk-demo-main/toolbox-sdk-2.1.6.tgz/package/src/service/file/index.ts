import { PermissionsAndroid, Platform } from 'react-native';

import { Buffer } from 'buffer';
import { assign, get } from 'lodash';
import DeviceInfo from 'react-native-device-info';
import DocumentPicker, { DocumentPickerOptions } from 'react-native-document-picker';
import FileViewer from 'react-native-file-viewer';
import fs, { StatResult } from 'react-native-fs';
import { unzip, unzipWithPassword } from 'react-native-zip-archive';

import DeviceUtils from '../../model/DeviceUtils';
import Logger from '../../utils/logger';
import { Notification } from '../../utils/notification';
import translate from '../../utils/translate';

const isAndroid = Platform.OS === 'android';

type PickPlatform = 'ios' | 'android' | 'windows';

export interface IFileOptions {
	/**
	 * 名称
	 */
	name: string;

	/**
	 * 路径
	 */
	path: string;

	/**
	 * uri
	 */
	uri: string;

	/**
	 * 内容
	 */
	content: string;

	/**
	 * 编码
	 */
	encoding: 'utf8' | 'base64' | 'ascii';

	/**
	 * 编码
	 */
	dir: string;
}

export class FileService {

	/**
	 * 日志记录器
	 */
	static logger = Logger.extend('FileService');

	/**
	 * 检查写入权限(仅Android)
	 */
	static async checkWritePermission(): Promise<boolean> {
		if(isAndroid) {
			const deviceVersion = DeviceInfo.getSystemVersion();
			
			if (Number(deviceVersion) >= 13){
				return Promise.resolve(true);
			}

			// 先检查是否已经获取权限
			const hasPermission = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE);
			if (hasPermission) {
				return Promise.resolve(true);
			}

			// 显示权限说明通知
			await Notification.show({
				title: translate('permission.file.title'),
				content: translate('permission.write.content'),
			});

			const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE, 
				{
					title: translate('tips.readStoragePermissionTitle'),
					message: translate('tips.readStoragePermissionContent'),
					buttonNegative: translate('button.forbid'),
					buttonPositive: translate('button.alwaysAllow')
				},
			);

			// 权限请求完成后隐藏通知
			Notification.hide(1500);

			if (granted === PermissionsAndroid.RESULTS.GRANTED) {
				return Promise.resolve(true);
			} else if (granted === PermissionsAndroid.RESULTS.DENIED) {
				return this.checkWritePermission();
			} else {
				return Promise.resolve(false);
			}
		}

		return Promise.resolve(true);
	}

	/**
	 * 检查读取权限(仅Android)
	 */
	static async checkReadPermission() {
		if(isAndroid) {
			const deviceVersion = DeviceInfo.getSystemVersion();
			
			//Android 13无需检查该权限，直接返回 true
			if (Number(deviceVersion) >= 13){
				return Promise.resolve(true);
			}

			// 先检查是否已经获取权限
			const hasPermission = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE);
			if (hasPermission) {
				return Promise.resolve(true);
			}

			// 显示权限说明通知
			await Notification.show({
				title: translate('permission.file.title'),
				content: translate('permission.read.content'),
			});

			const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE, 
				{
					title: translate('tips.readStoragePermissionTitle'),
					message: translate('tips.readStoragePermissionContent'),
					buttonNegative: translate('button.forbid'),
					buttonPositive: translate('button.alwaysAllow')
				},
			);

			// 权限请求完成后隐藏通知
			Notification.hide(1500);
	
			if(granted === PermissionsAndroid.RESULTS.GRANTED) {
				return Promise.resolve(true);
			} else {
				return Promise.reject(false);
			}
		}
	
		return Promise.resolve(true);
	}

	/**
	 * 选择文件
	 */
	static async pickFile<OS extends PickPlatform = PickPlatform>(options?: Partial<DocumentPickerOptions<OS>>) {
		try {
			const hasPermission = await this.checkReadPermission();
	
			if(!hasPermission) {
				return Promise.reject(translate('error.PermissionNotGranted'));
			}
			
			const pickOptions = assign({}, {
				type: isAndroid ? [DocumentPicker.types.allFiles] : 'public.data'
			}, options);
	
			const pickResult = await DocumentPicker.pickSingle(pickOptions);
	
			return Promise.resolve(pickResult);
		} catch (error) {
			let msg = error;

			if(DocumentPicker.isCancel(error)) {
				msg = -1;
			}

			//没有读取权限
			if(error === false) {
				msg = translate('error.PermissionNotGranted');
			}
	
			return Promise.reject(msg);
		}
	}

	/**
	 * 读取文件，并返回base64的字符串文件内容
	 *
	 * @param {string} uri
	 * @returns {string} content
	 */
	static async readFile(uri: IFileOptions['uri'], encoding?: IFileOptions['encoding']) {
		try {
			const newUri: StatResult | string = isAndroid ? await fs.stat(uri) : decodeURIComponent(uri); //兼容iOS中文路径
			const content = await fs.readFile(
				isAndroid ?
					(newUri as StatResult).path :
					newUri as string, 
				encoding
			);
	
			return Promise.resolve(content);
		} catch (error) {
			this.logger.error("read file error:", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 删除文件
	 */
	static async deleteFile(path: IFileOptions['path']) {
		if(isAndroid) {
			const stats =	await fs.stat(path);
			path = stats.path;
		} else {
			path = decodeURIComponent(path); //兼容iOS中文路径
		}
	
		return fs.unlink(path);
	}

	/**
	 * 删除文件
	 */
	static async removeFile(
		name: string,
		path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath
	) {
		try {
			const dirPath = this.formatFilePath(path, name);
			const hasPermission = await this.checkReadPermission();

			if(!hasPermission) {
				return Promise.reject(translate('error.PermissionNotGranted'));
			}
	
			await fs.unlink(decodeURIComponent(dirPath));
			console.debug('removeFile success!');

			return Promise.resolve(dirPath);
		} catch (error) {
			console.debug('removeFile error: ', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 下载文件
	 */
	static async downloadFile(options: fs.DownloadFileOptions) {
		return new Promise((resolve, reject) => {
			const { jobId, promise } = fs.downloadFile(options);
	
			promise.then(result => {
				resolve(result);
			}).catch(error => {
				if(jobId) {
					fs.stopDownload(jobId);
				}
				reject(error);
			});
		});
	}

	/**
	 * 写入文件
	 */
	static async writeFile({
		name,
		content,
		encoding = 'utf8',
		path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath
	}: {
		name: IFileOptions['name'];
		content: IFileOptions['content'];
		path?: IFileOptions['path'];
		encoding?: IFileOptions['encoding'];
	}) {
		try {
			const filePath = this.formatFilePath(path, name);
			const decodedFilePath = decodeURIComponent(filePath);
			const hasPermission = await this.checkWritePermission();
	
			if(!hasPermission) {
				return Promise.reject('NOT_PERMISSION');
			}

			// 防止当覆盖写入较短内容时旧文件尾数据被保留，导致文件内容不一致。
			try {
				const isExists = await fs.exists(decodedFilePath);
				if (isExists) {
					await fs.unlink(decodedFilePath);
				}
			} catch (removeError) {
				this.logger.debug(`remove old file before write failed: ${decodedFilePath}`, removeError);
			}

			return fs.writeFile(decodedFilePath, content, encoding)
				.then(()=>{
					this.logger.debug(`write ${filePath} success`);
					return Promise.resolve(filePath);
				})
				.catch(error => {
					// 针对下述情况出现的问题进行解决：
					// 导出模板后，如果卸载app，再重新安装并导出同名的模板，会报错无权限：EACCES (Permission denied)
					// 猜测是因为系统认为该文件的所有者是之前的app，所以无权限覆盖写入
					if(error?.message?.includes('EACCES (Permission denied)')) {
						// 文件冲突时，重新生成文件名再试一次
						const newFileName = name.replace(/(\.[^/.]+$|$)/, `_${new Date().getSeconds()}`);
						const newFilePath = decodeURIComponent(this.formatFilePath(path, newFileName));
						
						return fs.writeFile(newFilePath, content, encoding)
							.then(() => {
								this.logger.debug(`write ${newFilePath} success after retry`);
								return newFilePath;
							})
							.catch(retryError => {
								this.logger.error("write file retry error:", retryError);
								return false;
							});
					}
					this.logger.error("write file error:", error);
					//FIXME: Android无法写入内置存储文件的权限报错问题 https://github.com/itinance/react-native-fs/issues/1042
					return Promise.resolve(false);
				});
		} catch (error) {
			this.logger.error("write file error:", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 追加内容到文件
	 */
	static async appendFile({
		name,
		content,
		encoding = 'utf8',
		path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath
	}: {
		name: IFileOptions['name'];
		content: IFileOptions['content'];
		path?: IFileOptions['path'];
		encoding?: IFileOptions['encoding'];
	}) {
		try {
			const filePath = this.formatFilePath(path, name);
			const hasPermission = await this.checkWritePermission();
			if (!hasPermission) {
				return Promise.reject('NOT_PERMISSION');
			}
			await fs.appendFile(decodeURIComponent(filePath), content, encoding);
			return Promise.resolve(filePath);
		} catch (error) {
			this.logger.error("append file error:", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 创建文件夹
	 */
	static async mkdir(
		name: string, 
		path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath, 
		options?: {
		NSURLIsExcludedFromBackupKey?: boolean // iOS only
		NSFileProtectionKey?: string // IOS only
	}) {
		try {
			const dirPath = this.formatFilePath(path, name);
			const hasPermission = await this.checkWritePermission();

			if(!hasPermission) {
				return Promise.reject(translate('error.PermissionNotGranted'));
			}
	
			await fs.mkdir(dirPath, options);
			this.logger.debug('mkdir success!');

			return Promise.resolve(dirPath);
		} catch (error) {
			this.logger.error('mkdir error: ', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 打开文件
	 * @returns 
	 */
	static async openFile(name: IFileOptions['name'], path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath, options?: FileViewer.RNFileViewerOptions | string) {
		try {
			const filePath = this.formatFilePath(path, name);
			const isExists = await fs.exists(path);
			
			if(isExists === false) {
				return Promise.reject(translate('tips.fileNotExist'));
			}
	
			await FileViewer.open(filePath, options);
			
			return Promise.resolve(filePath);
		} catch (error) {
			this.logger.error('openFile error: ', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 组合路径和文件名
	 */
	static formatFilePath(path: IFileOptions['path'], name: IFileOptions['name']) {
		return path.endsWith('/') ? path + name : `${path}/${name}`;
	}

	/**
 	* 获取用户可以理解的文件路径
 	* @param name 文件名称
 	*/
	static getFormattedFilePath(name: string) {
		if(isAndroid) {
			return `Android/data/com.ursalinknfc/files/${name}`;
		}

		return `On My iPhone/Milesight ToolBox/${name}`;
	}

	/**
 	* 获取下载目录的用户可读路径
 	* @param name 文件名称
 	*/
	static getFormattedDownloadFilePath(name: string) {
		if(isAndroid) {
			return `Download/${name}`;
		}

		return `On My iPhone/Milesight ToolBox/${name}`;
	}

	/**
	 * 获取错误信息
	 * @param error - 错误
	 * @param defaultMsg - 默认错误信息
	 */
	static getErrorMessage(error: any, defaultMsg?: string): string {
		if(typeof error === 'string') {
			return error;
		}

		return error?.message ?? defaultMsg ?? JSON.stringify(error);
	}

	/**
 	* 选择文件夹
 	* @returns 返回选择文件夹的路径
 	*/
	static async pickDirectory() {
		try {
			const pickResult = await DocumentPicker.pickDirectory();
			const hasPermission = await this.checkReadPermission();

			if(!hasPermission) {
				return Promise.reject(translate('error.PermissionNotGranted'));
			}

			const directoryPath = isAndroid 
				? await DeviceUtils.getPathFromUri(pickResult?.uri ?? '')
				: pickResult?.uri;
	
			return Promise.resolve(directoryPath);
		} catch (error) {
			let msg = error;

			if(DocumentPicker.isCancel(error)) {
				msg = -1;
			}

			//没有读取权限
			if(error === false) {
				msg = translate('error.PermissionNotGranted');
			}
	
			return Promise.reject(msg);
		}
	}

	/**
 	* 解压zip
 	* @returns
 	*/
	static async unzipFile(file: string, path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath) {
		try {
			const filePath = path;
			const isExists = await fs.exists(path);
			const targetPath = path.split('/' + file)[0];
			
			if(isExists === false) {
				return Promise.reject(translate('tips.fileNotExist'));
			}
			const resPath = await unzip(filePath, targetPath ?? '');
			const dirPath = this.formatFilePath(resPath ?? '', file.split('.zip')[0]!);
			const list = await fs.readDir(dirPath);

			return Promise.resolve(list);
		} catch (error) {
			this.logger.error('unzipFile error: ', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 判断是否是用户取消了选择
	 */
	static isCancel(error: any) {
		if(error === -1) {
			return true;
		}

		return DocumentPicker.isCancel(error);
	}

	/**
	 * 另存为
	 * 写入文件到用户自己选择的文件夹
	 */
	static async saveAs({
		name,
		content,
		encoding = 'utf8'
	}: {
		name: IFileOptions['name'];
		content: IFileOptions['content'];
		encoding?: IFileOptions['encoding'];
	}) {
		try {
			const pickPath = await this.pickDirectory();
			const writePath = await this.writeFile({
				name,
				path: pickPath,
				content,
				encoding
			});

			return Promise.resolve(writePath);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 另存为
	 * 写入文件到指定的文件夹
	 */
	static async saveToDir({
		name,
		content,
		dir,
		encoding = 'utf8',
		path = isAndroid ? fs.ExternalStorageDirectoryPath : fs.DocumentDirectoryPath
	}: {
		name: IFileOptions['name'];
		content: IFileOptions['content'];
		dir: IFileOptions['dir'];
		path?: IFileOptions['path'];
		encoding?: IFileOptions['encoding'];
	}) {
		try {
			const pathDir = this.formatFilePath(path, isAndroid ? `${dir}/${name}` : `ToolBox/${name}`);
			const hasPermission = await this.checkWritePermission();
	
			if(!hasPermission) {
				return Promise.reject('NOT_PERMISSION');
			}

			return fs.writeFile(pathDir, content, encoding)
				.then(()=>{
					this.logger.debug(`write ${pathDir} success`);

					return Promise.resolve(pathDir);
				})
				.catch(()=>{
					return Promise.resolve(false);
				});
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 获取文件扩展名
	 * @param filename - 文件名
	 */
	static getFileExtension(filename: string): string | undefined {
		if (typeof filename === 'string' && filename) {
			const parts = filename.split('.');

			if (parts.length > 1) {
				return parts.pop();
			}
		}

		return;
	}

	/**
	 * 判断文件是否存在
	 * @param {string} path - 文件路径
	 * @param {boolean} [fullPath=true] - 是否完整路径
	 * @returns {Promise<boolean>}
	 */
	static isExists = async (path: string, fullPath = true, directoryPath = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath) => {
		return fs.exists(fullPath ? path : this.formatFilePath(directoryPath, path));
	};

	/**
	 * 获取解压后的文件夹路径
	 * @param targetDir - 目标文件夹
	 * @param response - 解压后返回的结果
	 */
	private static async getUnzipDir(targetDir: string, response: string[] | string) {
		if(Platform.OS === 'android') {
			//Android 返回的结果可能是两种情况
			//1. 解压后的所有文件列表以：[文件夹\\文件名]的形式，没有具体路径
			//2. 文件夹路径的形式，有具体路径
			//3. 解压后的所有文件列表以：[文件夹/文件名]的形式，没有具体路径
			const dirSeperator = get(response, [0], '').includes('\\') ? '\\' : '/';//分隔符会存在不一致的情况，所以需要判断
			const responseDir: string = Array.isArray(response) ? get(response, [0], '').split(dirSeperator)[0] ?? '' : response;
			const targetDirPath = Array.isArray(response) ? this.formatFilePath(targetDir, responseDir) : responseDir;
			const isFile = await fs.stat(targetDirPath);
			const unzipDir = isFile ? await fs.readDir(targetDir) : await fs.readDir(targetDirPath);

			//如果读取后只有一个文件，且还是一个文件夹，是还有一层文件夹，需要再次读取，才是解压后的文件列表
			if(unzipDir?.length === 1 && unzipDir[0]?.isDirectory()) {
				const nextUnzipDir = await fs.readDir(unzipDir[0]?.path ?? '');

				return nextUnzipDir;
			}

			return unzipDir;
		}

		if(Platform.OS === 'ios') {
			//iOS 返回的结果是解压后的文件夹路径：Documents/XXX，所以需要再次读取一层文件夹，才是解压后的文件列表
			const unzipDir = await fs.readDir(targetDir);

			if(unzipDir?.length === 1 && unzipDir[0]?.isDirectory()) {
				const nextUnzipDir = await fs.readDir(unzipDir[0]?.path ?? '');

				return nextUnzipDir;
			}

			return unzipDir;
		}

		return;
	}

	/**
	 * 创建临时文件夹，如果存在则清空再重新创建
	 */
	private static createTempDir = async (rootDir: string, tempDirName: string) => {
		try {
			const targetDir = this.formatFilePath(rootDir, tempDirName);
			const isExists = await fs.exists(targetDir);

			//如果存在则删除
			if(isExists) {
				await fs.unlink(targetDir);
			}

			await fs.mkdir(targetDir);

			return targetDir;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	static async isZipFile(filePath: string): Promise<boolean> {
		try {
			const path = filePath.replace(/^file:\/\//, "");
			const data = await fs.read(path, 4, 0, "base64");
			const buf = Buffer.from(data, "base64");
      
			// 检查开头是否为 0x50 0x4B
			return buf[0] === 0x50 && buf[1] === 0x4B;
		} catch {
			return false;
		}
	}
      

	/**
 	* 解压zip
 	* @param options - 解压参数
	* @param options.fileName - 文件名
	* @param options.filePath - 文件路径
	* @param options.password - 解压密码
	* @param options.tempDirName - 临时文件夹名称
 	*/
	static async unzip(options: {
		fileName: string;
		filePath: string;
		password?: string;
		tempDirName?: string;
	}) {
		try {
			const { fileName, password, tempDirName } = options;
			const filePath = decodeURIComponent(options.filePath); //兼容iOS中文路径
			const rootDir = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath;
			const fileSuffix = fileName.slice(fileName.lastIndexOf('.'));
			const fileNameWithoutSuffix = fileName.split(fileSuffix)[0];
			const isExists = await fs.exists(filePath);
			//要解压到的文件夹路径
			let targetUnzipPath = this.formatFilePath(rootDir, fileNameWithoutSuffix ?? '');

			if(isExists === false) {
				return Promise.reject({
					isZip: false,
					message: translate('tips.fileNotExist')
				});
			}

			if(tempDirName) {
				//创建临时文件夹
				const tempDir = await this.createTempDir(rootDir, tempDirName);

				targetUnzipPath = this.formatFilePath(tempDir, fileNameWithoutSuffix ?? '');
			}
			
			//解压后的所有文件路径信息
			const res = password != null
				? await unzipWithPassword(filePath, targetUnzipPath, password)
				: await unzip(filePath, targetUnzipPath);
			const unzipDir = await this.getUnzipDir(targetUnzipPath, res);

			return Promise.resolve(unzipDir);
		} catch (error: any) {
			const errorMessage = error.message ?? error ?? '';
			//Android: not a zip file
			//iOS: unable to unzip
			const isZip = await this.isZipFile(options.filePath);
			// const isNotZipError = errorMessage.includes('not a zip file') || errorMessage.includes('unable to unzip');

			return Promise.reject({
				/**
				 * 是否为zip文件
				 */
				isZip,

				/**
				 * 错误信息
				 */
				message: errorMessage
			});
		}
	}

	static async readDir(
		name: string,
		path = isAndroid ? fs.ExternalDirectoryPath : fs.DocumentDirectoryPath
	) {
		try {
			const dirPath = this.formatFilePath(path, name);
			const dirList = await fs.readDir(decodeURIComponent(dirPath));

			return Promise.resolve(dirList);
		} catch (error) {
			return Promise.reject(error);
		}
	}

}

export default FileService;
