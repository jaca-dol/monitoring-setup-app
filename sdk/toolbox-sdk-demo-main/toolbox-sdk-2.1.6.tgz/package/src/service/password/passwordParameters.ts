import { PartialTSLInfo } from '../../model/tsl';

type PasswordType = 'forceNew' | //强制使用新版变长密码校验
                    // 'forceOld' | //强制使用旧版密码校验
					'oldOnlyWhenSix'; //只有密码长度为6时，使用旧版密码校验

const request_change_password = (password?: string, passwordType?: PasswordType): PartialTSLInfo => {
	if (passwordType == 'oldOnlyWhenSix' && password && password.length == 6) {
		return {
			request_password_change: {
				new_password: password
			}
		};
	} 

	return {
		request_security_password_change: {
			new_password: password,
			length: password?.length ?? 0
		}
	};
};

const request_check_password = (password?: string, passwordType?: PasswordType): PartialTSLInfo => {
	if (passwordType == 'oldOnlyWhenSix' && password && password.length == 6) {
		return {
			request_password_check: {
				password: password
			}
		};
	}

	return {
		request_security_password_check: {
			password: password,
			length: password?.length ?? 0
		}
	};
};

export { request_change_password, request_check_password };
export type { PasswordType };
