import Logger from '../../utils/logger';
import { Storage } from '../../utils/util/Storage';

/**
 * SN与ID的关联
 */
interface SnIdAssociation {
	/**
	 * 设备SN
	 */
	sn: string;

	/**
	 * NFC id
	 */
	nfcId?: string;

	/**
	 * BLE id
	 */
	bleId?: string;
}

/**
 * 设备密码管理器
 */
export class DevicePasswordManager {
	/**
	 * SN与ID的关联存储
	 */
	private static snIdAssociationStorage = new Storage({
		id: 'sn_id_association'
	});

	/**
	 * 密码存储
	 */
	private static passwordStorage = new Storage({
		id: 'dp',
		encryptionKey: '7fh4yC5XqG9SkACt2vcvY0333KbbP2lvMK7iDDCGVTE'
	});

	/**
	 * 缓存临时密码
	 */
	private static provisionalPasswordMap = new Map();

	/**
	 * 日志记录器
	 */
	private static logger = Logger.extend('DevicePasswordManager');

	/**
	 * 默认密码ID
	 */
	private static defaultPasswordId = 'DEFAULT_PASSWORD';

	/**
	 * 默认密码
	 */
	private static defaultPassword = '123456';

	/**
	 * 获取密码
	 * @param id - 密码ID
	 */
	private static getPassword(id: string) {
		return this.passwordStorage.get<string>(id);
	}

	/**
	 * 移除密码
	 * @param id - 密码ID
	 * @returns 
	 */
	private static removePassword(id: string) {
		return this.passwordStorage.delete(id);
	}
	
	/**
	 * 设置密码
	 * @param id - 密码ID
	 * @param password - 密码
	 */
	private static setPassword(id: string, password: string) {
		return this.passwordStorage.set(id, password);
	}

	/**
	 * 获取密码
	 * @param id - 密码ID
	 */
	private static getProvisionalPassword(id: string) {
		return this.provisionalPasswordMap.get(id);
	}

	/**
	 * 移除密码
	 * @param id - 密码ID
	 * @returns 
	 */
	private static removeProvisionalPassword(id: string) {
		return this.provisionalPasswordMap.delete(id);
	}
	
	/**
	 * 设置密码
	 * @param id - 密码ID
	 * @param password - 密码
	 */
	private static setProvisionalPassword(id: string, password: string) {
		return this.provisionalPasswordMap.set(id, password);
	}

	/**
	 * 将SN统一转换为大写
	 * @param sn - 设备SN
	 */
	private static normalizeSn(sn: string): string {
		return sn.toUpperCase();
	}

	/**
	 * 获取默认密码
	 */
	public static getDefaultPassword() {
		const curDefaultPassword = this.getPassword(this.defaultPasswordId) || this.defaultPassword;
		this.logger.debug(`get default password`);
		return curDefaultPassword;
	}

	/**
	 * 设置默认密码
	 * @param password - 新的默认密码
	 */
	public static setDefaultPassword(password: string) {
		this.setPassword(this.defaultPasswordId, password);
		this.logger.debug(`new default password set`);
	}

	/**
	 * 根据ID获取密码
	 * @param id - BLE ID / NFC ID
	 * @param defaultPassword - 如果没有密码是否返回默认密码，默认为true
	 */
	public static getPasswordById(id: string, defaultPassword?: true, log?: boolean): {password: string, isRemember: boolean};
	public static getPasswordById(id: string, defaultPassword?: false, log?: boolean): {password: string | null, isRemember: boolean};
	public static getPasswordById(id: string, defaultPassword?: boolean, log?: boolean): {password: string | null, isRemember: boolean};
	public static getPasswordById(id: string, defaultPassword = true, log = __DEV__) {		
		//先取持久化但是不立即返回而是从临时密码缓存中取的目的是判断密码是否记住
		//而不能直接返回持久化密码的原因是，密码在记住的前提下被其他toolbox修改后，本机toolbox连接弹出密码输入框，用不记住密码去连接会导致验证通过但是因为密码未持久化存储，导致命令失败。
		const password = this.getPassword(id);
		if(password) {
			log && this.logger.debug(`password found for id: ${id} but try provisonal first`);			
		}

		const provisionalPassword = this.getProvisionalPassword(id);

		if(provisionalPassword) {
			log && this.logger.debug(`password found for id: ${id} in provional`);
			return {
				password: provisionalPassword, 
				isRemember: password && password.length > 0
			};
		}

		log && this.logger.debug(`no password found for id: ${id} in provional`);
		if(password) {
			log && this.logger.debug(`use password in storage for id: ${id}`);
			return {
				password,
				isRemember: true
			};
		}

		if(defaultPassword) {
			log && this.logger.debug(`use default password`);
		}

		return {
			password: defaultPassword ? this.getDefaultPassword() : null,
			isRemember: false
		};
	}

	/**
	 * 根据SN获取密码
	 * @param sn - 设备sn
	 * @param defaultPassword - 如果没有密码是否返回默认密码，默认为true
	 */
	public static getPasswordBySn(sn: string, defaultPassword?: true): {password: string, isRemember: boolean};
	public static getPasswordBySn(sn: string, defaultPassword?: false): {password: string | null, isRemember: boolean};
	public static getPasswordBySn(sn: string, defaultPassword?: boolean): {password: string | null, isRemember: boolean};
	public static getPasswordBySn(sn: string, defaultPassword = true): {password: string | null, isRemember: boolean} {
		sn = this.normalizeSn(sn);
		const as = this.snIdAssociationStorage.getObject<SnIdAssociation>(sn);

		if(as) {
			const nfcId = as.nfcId;
			const bleId = as.bleId;

			// 优先使用NFC ID的密码
			if(nfcId) {
				return this.getPasswordById(nfcId, defaultPassword);
			}

			if(bleId) {
				return this.getPasswordById(bleId, defaultPassword);
			}
		}

		this.logger.debug(`no id associated with sn: ${sn}`);

		return {
			password: defaultPassword ? this.getDefaultPassword() : null,
			isRemember: false
		};
	}
	
	/**
	 * 根据ID设置密码
	 * @param id - BLE ID / NFC ID
	 * @param password 密码
	 * @param isProvisional 是否临时记住密码
	 */
	public static setPasswordById(id: string, password: string, isProvisional = false): void {
		this.logger.debug(`set password by id: ${id}, isProvisional: ${isProvisional}`);
		if(isProvisional) {
			this.setProvisionalPassword(id, password);
		} else {
			this.setPassword(id, password);
		}
	}
	
	/**
	 * 根据SN设置密码
	 * @param sn - 设备SN
	 * @param password - 密码
	 */
	public static setPasswordBySn(sn: string, password: string, isProvisional = false): void {
		try {
			sn = this.normalizeSn(sn);
			const as = this.snIdAssociationStorage.getObject<SnIdAssociation>(sn);

			if(as) {
				const nfcId = as.nfcId;
				const bleId = as.bleId;

				if(nfcId) {
					this.logger.debug(`set password for nfc id: ${nfcId}`);
					this.setPasswordById(nfcId, password, isProvisional);
				}

				if(bleId) {
					this.logger.debug(`set password for ble id: ${bleId}`);
					this.setPasswordById(bleId, password, isProvisional);
				}
			} else {
				this.logger.warn(`No id associated with sn: ${sn}`);
			}
		} catch (error) {
			this.logger.error(`setPasswordBySn error: ${error}`);
		}
	}
	
	/**
	 * 建立SN与NFC ID的关联
	 * @param sn - 设备SN
	 * @param id - NFC ID
	 */
	public static associateSnWithNFCId(sn: string, id: string): void {
		sn = this.normalizeSn(sn);
		const as = this.snIdAssociationStorage.getObject<SnIdAssociation>(sn);

		if(as) {
			if(as.nfcId !== id) {
				as.nfcId = id;
				this.snIdAssociationStorage.set(sn, as);
				this.logger.debug(`update associate sn with nfc id: ${sn}`, as.nfcId);
			}
		} else {
			this.logger.debug(`new associate sn with nfc id: ${sn}`, id);
			this.snIdAssociationStorage.set(sn, { sn, nfcId: id });
		}
	}
	
	/**
	 * 建立SN与BLE ID的关联
	 * @param sn - 设备SN
	 * @param id - BLE ID
	 */
	public static associateSnWithBLEId(sn: string, id: string): void {
		sn = this.normalizeSn(sn);
		const as = this.snIdAssociationStorage.getObject<SnIdAssociation>(sn) ;

		if(as) {
			if(as.bleId !== id) {
				as.bleId = id;
				this.snIdAssociationStorage.set(sn, as);
				this.logger.debug(`update associate sn with ble id: ${sn}`, as.bleId);
			}
		} else {
			this.snIdAssociationStorage.set(sn, { sn, bleId: id });
			this.logger.debug(`new associate sn with ble id: ${sn}`, id);
		}
	}

	/**
	 * 移除密码
	 * @param id - NFC ID / BLE ID
	 */
	public static removePasswordById(id: string, isProvisional = false) {
		this.logger.debug(`remove password: ${id}`);
		if(isProvisional) {
			this.removeProvisionalPassword(id);
		} else {
			this.removePassword(id);
		}
	}

	/**
	 * 根据SN移除密码
	 * @param sn - 设备SN
	 */
	public static removePasswordBySn(sn: string) {
		try {
			sn = this.normalizeSn(sn);
			const as = this.snIdAssociationStorage.getObject<SnIdAssociation>(sn);

			if(as) {
				const nfcId = as.nfcId;
				const bleId = as.bleId;

				if(nfcId) {
					this.logger.debug(`remove password for nfc id: ${nfcId}`);
					this.removePassword(nfcId);
				}

				if(bleId) {
					this.logger.debug(`remove password for ble id: ${bleId}`);
					this.removePassword(bleId);
				}
			} else {
				this.logger.warn(`No id associated with sn: ${sn}`);
			}
		} catch (error) {
			this.logger.error(`removePasswordBySn error: ${error}`);
		}
	}

	/**
	 * 清除所有数据
	 */
	public static clearAll() {
		this.snIdAssociationStorage.clearAll();
		this.passwordStorage.clearAll();
		this.provisionalPasswordMap.clear();
	}
}