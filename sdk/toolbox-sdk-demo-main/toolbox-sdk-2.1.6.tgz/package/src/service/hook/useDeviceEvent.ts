import { AsyncSeriesWaterfallHook, SyncHook } from 'tapable';

import { DeviceInfo, DeviceSettingInfo } from '../../model/deviceInfo';

export enum DeviceEvent {
	write = 'write',
	writeFinish = 'writeFinish',
	read = 'read',
	// 点击写入按钮后触发
	writeButtonPress = 'writeButtonPress',
	// 点击新增模板后触发
	addTemplate = 'addTemplate',
	// 点击保存模板后触发
	saveTemplate = 'saveTemplate',
	// 点击新增模板并执行过onSave事件后触发
	addTemplateSaved = 'addTemplateSaved',
	// 点击保存模板并执行过onSave事件后触发
	saveTemplateSaved = 'saveTemplateSaved',
}

interface IDeviceEventsCallback {
	[DeviceEvent.write]: (data: DeviceSettingInfo) => Promise<DeviceSettingInfo>;
	[DeviceEvent.writeFinish]: (data: DeviceSettingInfo) => void;
	[DeviceEvent.read]: (data: DeviceInfo) => void;
	[DeviceEvent.writeButtonPress]: () => void;
	[DeviceEvent.addTemplate]: () => void;
	[DeviceEvent.saveTemplate]: () => void;
	[DeviceEvent.addTemplateSaved]: (data: DeviceSettingInfo) => Promise<DeviceSettingInfo>;
	[DeviceEvent.saveTemplateSaved]: (data: DeviceSettingInfo) => Promise<DeviceSettingInfo>;
}

export const DeviceHooks = {
	[DeviceEvent.write]: new AsyncSeriesWaterfallHook<DeviceSettingInfo>(['deviceSettingInfo']),
	[DeviceEvent.read]: new SyncHook<DeviceInfo>(['deviceInfo']),
	[DeviceEvent.writeFinish]: new SyncHook<DeviceSettingInfo>(['deviceSettingInfo']),
	[DeviceEvent.writeButtonPress]: new SyncHook<void>(['writeButtonPress']),
	[DeviceEvent.addTemplate]: new SyncHook<void>(['templateName']),
	[DeviceEvent.saveTemplate]: new SyncHook<void>(['templateName']),
	[DeviceEvent.addTemplateSaved]: new AsyncSeriesWaterfallHook<DeviceSettingInfo>(['deviceSettingInfo']),
	[DeviceEvent.saveTemplateSaved]: new AsyncSeriesWaterfallHook<DeviceSettingInfo>(['deviceSettingInfo']),
};

/**
 * 使用设备事件的钩子
 * @param event 事件名称
 * @returns 
 */
export const useDeviceEvent = <T extends DeviceEvent>(event: T) => {
	const tap = (name: string, callback: IDeviceEventsCallback[T]) => {
		const registerMap = {
			[DeviceEvent.write]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.write.tapPromise(name, cb as IDeviceEventsCallback['write']);
			},
			[DeviceEvent.read]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.read.tap(name, cb as IDeviceEventsCallback['read']);
			},
			[DeviceEvent.writeFinish]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.writeFinish.tap(name, cb as IDeviceEventsCallback['writeFinish']);
			},
			[DeviceEvent.writeButtonPress]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.writeButtonPress.tap(name, cb as IDeviceEventsCallback['writeButtonPress']);
			},
			[DeviceEvent.addTemplate]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.addTemplate.tap(name, cb as IDeviceEventsCallback['addTemplate']);
			},
			[DeviceEvent.saveTemplate]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.saveTemplate.tap(name, cb as IDeviceEventsCallback['saveTemplate']);
			},
			[DeviceEvent.addTemplateSaved]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.addTemplateSaved.tapPromise(name, cb as IDeviceEventsCallback['addTemplateSaved']);
			},
			[DeviceEvent.saveTemplateSaved]: (cb: IDeviceEventsCallback[T]) => {
				DeviceHooks.saveTemplateSaved.tapPromise(name, cb as IDeviceEventsCallback['saveTemplateSaved']);
			}
		};
		const register = registerMap[event];

		if(!register) {
			throw new Error(`Event ${event} is not supported`);
		}

		return register(callback);
	};

	const untap = (name: string) => {
		try {
			// @ts-ignore
			DeviceHooks[event].untap(name);
		} catch (error) {
			console.log(`untap event ${event} error:`, error);
		}	
	};

	const emit = (params: Parameters<IDeviceEventsCallback[T]>) => {
		try {
			const emitMap = {
				[DeviceEvent.write]: (deviceSettingInfo: DeviceSettingInfo) => {
					return DeviceHooks.write.promise(deviceSettingInfo);
				},
				[DeviceEvent.read]: (deviceInfo: DeviceInfo) => {
					return DeviceHooks.read.call(deviceInfo);
				},
				[DeviceEvent.writeFinish]: (deviceSettingInfo: DeviceSettingInfo) => {
					return DeviceHooks.writeFinish.call(deviceSettingInfo);
				},
				[DeviceEvent.writeButtonPress]: () => {
					return DeviceHooks.writeButtonPress.call();
				},
				[DeviceEvent.addTemplate]: () => {
					return DeviceHooks.addTemplate.call();
				},
				[DeviceEvent.saveTemplate]: () => {
					return DeviceHooks.saveTemplate.call();
				},
				[DeviceEvent.addTemplateSaved]: (deviceSettingInfo: DeviceSettingInfo) => {
					return DeviceHooks.addTemplateSaved.promise(deviceSettingInfo);
				},
				[DeviceEvent.saveTemplateSaved]: (deviceSettingInfo: DeviceSettingInfo) => {
					return DeviceHooks.saveTemplateSaved.promise(deviceSettingInfo);
				}
			};
			const emit = emitMap[event];

			if(!emit) {
				throw new Error(`emit event ${event} is not supported`);
			}
			
			return emit(params as any);
		} catch (error) {
			console.log(`emit event ${event} error:`, error);
			return Promise.reject(error);
		}
	};

	return {
		tap,
		untap,
		emit,
	};
};