import _ from 'lodash';
import { DefaultWireConnection, GeneralDeviceInfo, Wire, WireConnection, WireSettingItem } from '../../model/deviceInfo';
import translate from '../../utils/translate';

export enum TempControlMode {
	Heating = 0,
	EmergencyHeating = 1,
	Cooling = 2,
	Auto = 3,
    Off = 10,
    Off2 = 13,//WT201兼容
}

/**
 * 根据温度单位获取安装设置默认值
 * @param temperatureUnit
 */
export const getDefaultWireConnection = (temperatureUnit: string) => {
	const defaultWireConnection: WireConnection = DefaultWireConnection;
	//如果是摄氏度，则将防冻保护温度默认值改成 3
	if (temperatureUnit === '℃') {
		defaultWireConnection.emCfg.frostProtection.threshold = 3;
	}
	return defaultWireConnection;
};

export const defaultTempControlModeAllOptions = (t: any) => [
	{ label: t('setting.heatingMode'), value: TempControlMode.Heating },
	{ label: t('setting.emergencyHeating'), value: TempControlMode.EmergencyHeating },
	{ label: t('setting.coolingMode'), value: TempControlMode.Cooling },
	{ label: t('setting.autoMode'), value: TempControlMode.Auto }
];

/**
 * 获取温控模式Options
 * @param wireConnection
 */
export const getTempControlModeOptions = (wireConnection: WireConnection): Array<{ label: string; value: number }> => {

	const tempControlModeAllOptions = defaultTempControlModeAllOptions(translate);

	const tempControlModeOptions: Array<{ label: string; value: number }> = [];
	try {
		//接线设置数据
		const wire = wireConnection.wire;
		const connectWire = getConnectWireLine(wire);
		//如果接线数据是空则直接返回全部选项
		if (wire == null) {
			return tempControlModeAllOptions;
		}
		//是否有制热标志位 制热：有 Y1(O/B) 或者 Y2(O/B) 或者PEK(O/B) 或者 W1 或者 W2/AUX 其中一个就可以
		const heatFlag = ((connectWire.y1 && connectWire.ob) ||
			(connectWire.y2 && connectWire.ob) || (connectWire.pek && connectWire.ob) ||
			connectWire.w1 || connectWire.w2 || connectWire.aux);
		//是否有制冷标志位 制冷：有 Y1 或者 Y2 或者 PEK 其中一个就可以
		const coolFlag = connectWire.y1 || connectWire.y2 || connectWire.pek;
		//是否有紧急制热标志位 紧急制热: 有 em 就可以
		const emergencyHeatingFlag = connectWire.em;
		//没有 制冷 && 制热 && 紧急制热 && 自动 则返回全部选项
		if (!heatFlag && !coolFlag && !emergencyHeatingFlag) {
			return tempControlModeAllOptions;
		}
		if (heatFlag) {
			//有制热
			tempControlModeOptions.push({ label: translate('setting.heatingMode'), value: 0 });
		}
		if (emergencyHeatingFlag) {
			//有紧急制热
			tempControlModeOptions.push({label: translate('setting.emergencyHeating'), value: 1 });
		}
		if (coolFlag) {
			//有制冷
			tempControlModeOptions.push({ label: translate('setting.coolingMode'), value: 2 });
		}
		if (coolFlag && heatFlag) {
			//自动: 制冷和制热同时存在才有
			tempControlModeOptions.push({ label: translate('setting.autoMode'), value: 3 });
		}
	} catch (e) {
		return tempControlModeAllOptions;
	}
	return tempControlModeOptions;
};

/**
 * 判断传进来的温控模式是否支持
 * @param wireConnection
 * @param mode
 */
export const isSupportTempControlMode = (wireConnection: WireConnection, mode: Array<TempControlMode>) => {
	const resultMode: any = [];
	const options = getTempControlModeOptions(wireConnection);
	try {
		mode.forEach(item => {
			const result = options.find(findItem => findItem.value === item);
			resultMode.push(result != null);
		});
	} catch (e) {
		mode.forEach(_ => {
			resultMode.push(false);
		});
	}
	return resultMode;
};

/**
 * 判断是否有进行安装设置
 * @param wireConnection
 */
export const isInstallSetting = (wireConnection: WireConnection) => {
	try {
		//接线设置数据
		const wire = wireConnection.wire;
		const connectWire = getConnectWireLine(wire);
		//如果接线数据是空则直接返回全部选项
		if (wire == null) {
			return false;
		}
		//判断只要 接线设置(y1、gh、ob、w1、em、pek、di、w2_aux、y2_gl) 只要有一条线连接 则表示有进行过安装设置
		if (connectWire.y1 || connectWire.gh || connectWire.ob ||
			connectWire.w1 || connectWire.em || connectWire.pek ||
			connectWire.di || connectWire.w2 || connectWire.aux ||
			connectWire.y2 || connectWire.gl) {
			return true;
		}
	} catch (e) {
		return false;
	}
	return false;
};

/**
 * 校验安装设置数据
 * @param wireConnection
 * @param isTempF 温度单位 true 华氏度  false 摄氏度
 * @param timeRange 压缩机保护时间范围
 * @return true 成功 false 失败
 */
export const isCheckInstallSetting = (wireConnection: WireConnection, isTempF: boolean, timeRange: {min: number, max: number}) => {
	try {
		//接线设置数据
		const wire = wireConnection.wire;
		const connectWire = getConnectWireLine(wire);

		/**
		 * 辅助加热时间范围10～55分钟
		 * 连接AUX 且辅助加热时间开关开启
		 */
		const auxEnable = _.get(wireConnection, "auxTimeout.enable", false);
		const auxTime = _.get(wireConnection, "auxTimeout.time", 15);
		if (connectWire.aux && auxEnable) {
			//不在10～55分钟范围内
			if (!(auxTime >= 10 && auxTime <= 55)) {
				return false;
			}
		}

		//连接EM
		if (connectWire.em) {
			//紧急加热时间范围5～55分钟
			const emEnable = _.get(wireConnection, "emCfg.emTimeout.enable", false);
			const emTime = _.get(wireConnection, "emCfg.emTimeout.time", 5);
			if (emEnable) {
				//不在5～55分钟范围内
				if (!(emTime >= 5 && emTime <= 55)) {
					return false;
				}
			}
			//防冻保护温度范围1~5℃/33.8~41℉，
			const frostProtectionEnable = _.get(wireConnection, "emCfg.frostProtection.enable", false);
			const frostProtectionValue = _.get(wireConnection, "emCfg.frostProtection.threshold", isTempF ? 37.4 : 3);
			if (frostProtectionEnable) {
				const min = isTempF ? 33.8 : 1;
				const max = isTempF ? 41 : 5;
				if (!(frostProtectionValue >= min && frostProtectionValue <= max)) {
					return false;
				}
			}
		}

		/**
		 * 压缩机保护至少运行时间1～5分钟
		 * 连接y1或者 y2 且压缩机保护开关开启的时候
		 */
		const compEnable = _.get(wireConnection, "comprProtection.enable", false);
		const compTime = _.get(wireConnection, "comprProtection.time", 3);
		if ((connectWire.y1 || connectWire.y2) && compEnable) {
			if (!(compTime >= timeRange.min && compTime <= timeRange.max)) {
				return false;
			}
		}

	} catch (e) {
		return true;
	}
	return true;
};

/**
 * 校验接线设置数据的合法性
 * @param wireConnection
 */
export const isCheckWireSetting = (wireConnection: WireConnection) => {
	//校验是否通过 true 通过， false不通过
	let valid = true;
	let message = '';
	try {
		//接线设置数据
		const wire = wireConnection.wire;
		const connectWire = getConnectWireLine(wire);

		//接了pek时
		if (connectWire.pek) {
			//不能有 y1 或者 gh
			if(connectWire.y1 || connectWire.gh) {
				valid = false;
				message = translate('setting.installSetting.ygAndPekError');
			}
			return {
				isValid: valid,
				message: message
			};
		}

		//接了OB时
		if (connectWire.ob) {
			// pek && y1 && y2 && gh都没接的时候
			if(!connectWire.pek && !connectWire.y1 && !connectWire.y2 && !connectWire.gh) {
				valid = false;
				message = translate('setting.installSetting.unYGPekTip');
				return {
					isValid: valid,
					message: message
				};
			}

			//是否有Y
			let isHaveY = true;
			//同时没有 y1 或 y2
			if(!(connectWire.y1 || connectWire.y2)) {
				isHaveY = false;
			}
			//没y 有g 提示文案
			if (!isHaveY && connectWire.gh) {
				message = translate('setting.installSetting.unYTip');
			}
			//有y  没g 提示文案
			if (isHaveY && !connectWire.gh) {
				message = translate('setting.installSetting.unGTip');
			}
			//只要 Y 和 G 有一个没有就校验不通过 valid 则为false
			valid = !(!isHaveY || !connectWire.gh);

			return {
				isValid: valid,
				message: message
			};
		}

		//接了Y时
		if (connectWire.y1 || connectWire.y2) {
			//没有g的时候
			if (!connectWire.gh) {
				valid = false;
				message = translate('setting.installSetting.unGTip');
			}
			return {
				isValid: valid,
				message: message
			};
		}

	} catch (e) {
		message = `${ e }`;
	}
	return {
		isValid: valid,
		message: message
	};
};

/**
 * 获取接线设置每根线的状态
 * @param wireList
 */
export const getWireStatus = (wireList: Array<WireSettingItem>, hardwareV2?: boolean) => {
	let y1 = 0, gh = 0, ob = 0, w1 = 0,
		em = 0, di = 0, pek = 0;
	let w2Aux = 0, y2Gl = 0;
	try {
		//获取每根接线的数据
		const y1Item = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.y1'));
		const ghItem = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.gh'));
		const obItem = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.ob'));
		const w1Item = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.w1'));
		const emItem = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.em'));
		const diItem = wireList.find(item => {
			if(hardwareV2) {
				return item.leftName === translate('setting.installSetting.wiringSettingsOptions.diV2');
			}
			return item.leftName === translate('setting.installSetting.wiringSettingsOptions.diV1');
		});
		const pekItem = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.pek'));
		const w2AuxItem = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.w2')
			&& item.rightName === translate('setting.installSetting.wiringSettingsOptions.aux'));
		const y2GlItem = wireList.find(item =>
			item.leftName === translate('setting.installSetting.wiringSettingsOptions.y2')
			&& item.rightName === translate('setting.installSetting.wiringSettingsOptions.gl'));

		//0没接 1有接
		y1 = y1Item?.leftSelect ? 1 : 0;
		gh = ghItem?.leftSelect ? 1 : 0;
		ob = obItem?.leftSelect ? 1 : 0;
		w1 = w1Item?.leftSelect ? 1 : 0;
		em = emItem?.leftSelect ? 1 : 0;
		di = diItem?.leftSelect ? 1 : 0;
		pek = pekItem?.leftSelect ? 1 : 0;
		//0没接，1作为w2，2作为aux
		w2Aux = w2AuxItem?.leftSelect ? 1 : w2AuxItem?.rightSelect ? 2 : 0;
		//0没接，1作为y2，2作为gl
		y2Gl = y2GlItem?.leftSelect ? 1 : y2GlItem?.rightSelect ? 2 : 0;
	} catch (e) {
		//
	}
	return {
		y1, gh, ob, w1, em, di, pek, w2Aux, y2Gl
	};
};

/**
 * 获取连接的线
 * @param wire
 */
export const getConnectWireLine = (wire: Wire) => {
	let rc = false;
	let rh = false;
	//是否连接y1 默认没有
	let y1 = false;
	//是否连接G(GH) 默认没有
	let gh = false;
	//是否连接OB 默认没有
	let ob = false;
	let w1 = false;
	let em = false;
	let pek = false;
	let di = false;
	let w2 = false;
	let aux = false;
	//是否连接y2 默认没有
	let y2 = false;
	let gl = false;
	if (wire != null) {
		//0没接 1有接
		rc = wire.rc === 1;
		rh = wire.rh === 1;
		y1 = wire.y1 === 1;
		gh = wire.gh === 1;
		ob = wire.ob === 1;
		//0没接 1有接
		w1 = wire.w1 === 1;
		em = wire.em === 1;
		pek = wire.pek === 1;
		di = wire.di === 1;
		//0没接，1作为w2，2作为aux
		w2 = wire.w2_aux === 1;
		aux = wire.w2_aux === 2;
		//0没接，1作为y2，2作为gl
		y2 = wire.y2_gl === 1;
		gl = wire.y2_gl === 2;
	}
	return {
		rc, rh,
		y1, gh, ob, w1,
		em, pek, di,
		w2, aux, y2, gl
	};
};

/**
 * 如果当前值存在于当前模式选项，则直接返回当前值
 * 如果当前值不存在于当前模式选项，则获取下一个温控模式
 * @param currentMode - 当前模式
 * @param currentModeOptions - 当前模式选项
 * @param allOptions - 所有模式选项
 * @returns {number} - 下一个温控模式
 */
export const getNextTempControlMode = (currentMode: number, currentModeOptions: Array<{ label: string; value: number }>, allOptions?: Array<{ label: string; value: number }>): GeneralDeviceInfo['tempCtrlMode'] => {
	allOptions = allOptions ?? [
		{ label: translate('setting.heatingMode'), value: TempControlMode.Heating },
		{ label: translate('setting.emergencyHeating'), value: TempControlMode.EmergencyHeating },
		{ label: translate('setting.coolingMode'), value: TempControlMode.Cooling },
		{ label: translate('setting.autoMode'), value: TempControlMode.Auto }
	];

	//如果当前模式在当前模式选项里面，则直接返回当前模式
	if(currentModeOptions.find(o => o.value === currentMode)) {
		return currentMode as GeneralDeviceInfo['tempCtrlMode'];
	}

	const currentIndex = allOptions.findIndex(option => option.value === currentMode);

	//如果当前模式不在当前模式选项里面，则获取下一个温控模式
	for (let i = currentIndex + 1; i < currentIndex + allOptions.length + 1; i++) {
		const index = i % allOptions.length;
		const option = allOptions[index];

		if (currentModeOptions.find(o => option?.value === o.value)) {
			return option?.value as GeneralDeviceInfo['tempCtrlMode'];
		}
	}

	return currentMode as GeneralDeviceInfo['tempCtrlMode'];
};