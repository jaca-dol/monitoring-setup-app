import { get } from 'lodash';

import { IPSOProtocolError } from './IPSOProtocolError';
import { ServiceResourceData } from './ServiceResourceData';
import { IIPSOServiceResourceLoader, IServiceResourceData, IServiceResourceMeta, ResourceData, ResourceIdentity } from './types';

export class ServiceResourceLoader implements IIPSOServiceResourceLoader {
	resourceDataCache: IServiceResourceData;

	constructor() {
		this.resourceDataCache = ServiceResourceData;
	}
	
	load(identity: ResourceIdentity): ResourceData {
		const id = [ identity.model, identity.pn, identity.tslVer, identity.schemaVer ].filter(Boolean).join('-');
		const resource = this.resourceDataCache[id];

		if(!resource) {
			const ipsoError = IPSOProtocolError.create('NOT_SUPPORT_PARSE');
			ipsoError.message = ipsoError.message + `: resource ${id} not found`;

			throw ipsoError;
		}

		const resourceContent = resource.load();

		return resourceContent;
	}
	
	getResourceBy(resourceIdentity: ResourceIdentity): ResourceData {
		return this.load(resourceIdentity);
	}

	getResourceByMeta(meta: Partial<IServiceResourceMeta>): ResourceData | null {
		const resource = Object.values(this.resourceDataCache).find(resource => {
			const targetMeta = resource.meta;

			//只要 meta 中对应的值都相等，就认为是匹配的资源
			return Object.keys(meta).every(key => {
				const metaValue = get(meta, key);
				const targetMetaValue = get(targetMeta, key);

				return targetMetaValue === metaValue;
			});
		});

		if(resource) {
			return resource.load();
		}

		return null;
	}
}

export const IPSOServiceResourceLoader = new ServiceResourceLoader();