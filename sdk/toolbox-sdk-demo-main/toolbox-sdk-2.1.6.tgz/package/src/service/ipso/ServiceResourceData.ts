import { IServiceResourceData } from './types';

export const ServiceResourceData: IServiceResourceData = {
	'common-v1.0-v1.0': {
		meta: {
			"name": "common",
			"model": "common",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/common-v1.0-v1.0.resource.json')
	},
	'6850-000-v1.0-v1.0': {
		meta: {
			"name": "GS601",
			"model": "6850",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/GS601-v1.0-v1.0.resource.json')
	},    
	'6409-000-v1.0-v1.0': {
		meta: {
			"name": "WT401",
			"model": "6409",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/WT401-v1.0-v1.0.resource.json')
	},
	'6407-000-v1.0-v1.0': {
		meta: {
			"name": "UC711",
			"model": "6407",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/UC711-v1.0-v1.0.resource.json')
	},
	'6406-001-v1.0-v1.0': {
		meta: {
			"name": "WT303",
			"model": "6406",
			"pn": "001",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/WT303-v1.0-v1.0.resource.json')
	},
	'6406-002-v1.0-v1.0': {
		meta: {
			"name": "WT304",
			"model": "6406",
			"pn": "002",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/WT304-v1.0-v1.0.resource.json')
	},
	'6406-003-v1.0-v1.0': {
		meta: {
			"name": "WT303-ZH",
			"model": "6406",
			"pn": "003",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/WT303-ZH-v1.0-v1.0.resource.json')
	},
	'6406-004-v1.0-v1.0': {
		meta: {
			"name": "WT304-ZH",
			"model": "6406",
			"pn": "004",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/WT304-ZH-v1.0-v1.0.resource.json')
	},
	'6447-000-v1.0-v1.0': {
		meta: {
			"name": "TS601-L0DEU",
			"model": "6447",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/TS601-L0DEU-v1.0-v1.0.resource.json')
	},
	'6448-000-v1.0-v1.0': {
		meta: {
			"name": "TS602-L0DEU",
			"model": "6448",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/TS602-L0DEU-v1.0-v1.0.resource.json')
	},
	'6822-000-v1.0-v1.0': {
		meta: {
			"name": "UC501-L0CEU",
			"model": "6822",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/UC501-L0CEU-v1.0-v1.0.resource.json')
	},
	'6822-001-v1.0-v1.0': {
		meta: {	
			"name": "UC502-L0CEU",
			"model": "6822",
			"pn": "001",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/UC502-L0CEU-v1.0-v1.0.resource.json')
	},
	'6646-000-v1.0-v1.0': {
		meta: {
			"name": "TS602-L0DLA",
			"model": "6646",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/TS602-L0DLA-v1.0-v1.0.resource.json')
	},
	'6645-000-v1.0-v1.0': {
		meta: {
			"name": "TS601-L0DLA",
			"model": "6645",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/TS601-L0DLA-v1.0-v1.0.resource.json')
	},
	'6643-000-v1.0-v1.0': {
		meta: {
			"name": "TS601-L0FNA",
			"model": "6643",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/TS601-L0FNA-v1.0-v1.0.resource.json')
	},
	'6644-000-v1.0-v1.0': {
		meta: {
			"name": "TS602-L0FNA",
			"model": "6644",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/TS602-L0FNA-v1.0-v1.0.resource.json')
	},
	'6527-000-v1.0-v1.0': {
		meta: {
			"name": "WT102",
			"model": "6527",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/WT102-v1.0-v1.0.resource.json')
	},
	'6637-000-v1.0-v1.0': {
		meta: {
			"name": "CTH01",
			"model": "6637",
			"pn": "000",
			"tslVer": "v1.0",
			"schemaVer": "v1.0"
		},
		load: () => require('./resources/CTH01-v1.0-v1.0.resource.json')
	}
};
