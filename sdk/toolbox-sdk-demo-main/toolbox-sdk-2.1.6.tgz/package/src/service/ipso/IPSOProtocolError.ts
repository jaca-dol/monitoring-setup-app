import { IotIpsoProtocol } from '@ursalink-cloud/iot-ipso-service';

import { IPSO_COMMAND_RESPONSE_ERRORS, IPSO_PROTOCOL_ERRORS, IPSOProtocolErrorType } from './types';

export class IPSOProtocolError extends Error {
	/**
	 * 错误码
	 */
	code: number;
	
	/**
	 * 错误原因
	 */
	cause?: any;

	/**
	 * 当前所有错误对象
	 */
	static ERRORS = IPSO_PROTOCOL_ERRORS;

	constructor(error: { name: string; code: number; message: string, cause?: any }) {
		super(error.message);
		this.name = error.name;
		this.code = error.code;
		this.cause = error.cause;
	}

	/**
	 * 抛出错误
	 * @param errorType - 错误类型
	 * @param cause - 错误原因
	 */
	static throw(errorType: IPSOProtocolErrorType, cause?: any) {
		throw new IPSOProtocolError(
			IPSO_PROTOCOL_ERRORS[errorType]
				? { ...IPSO_PROTOCOL_ERRORS[errorType], cause }
				: IPSO_PROTOCOL_ERRORS.UNKNOWN_ERROR
		);
	}
	
	/**
	 * 创建错误对象
	 * @param errorType - 错误类型
	 * @param cause - 错误原因
	 */
	static create(errorType: IPSOProtocolErrorType, cause?: any) {
		return new IPSOProtocolError(
			IPSO_PROTOCOL_ERRORS[errorType]
				? { ...IPSO_PROTOCOL_ERRORS[errorType], cause }
				: IPSO_PROTOCOL_ERRORS.UNKNOWN_ERROR
		);
	}

	/**
	 * 获取错误对象
	 */
	static getError(errorType: IPSOProtocolErrorType) {
		return IPSO_PROTOCOL_ERRORS[errorType] ?? IPSO_PROTOCOL_ERRORS.UNKNOWN_ERROR;
	}

	/**
	 * 判断是否是IPSOProtocolError
	 */
	static isIPSOProtocolError(error: any): error is IPSOProtocolError {
		return error instanceof IPSOProtocolError;
	}

	/**
	 * 判断是否是IotIpsoProtocolError
	 */
	static isIotIpsoProtocolError(error: any): error is IotIpsoProtocol.IpsoProtocolError {
		return error instanceof IotIpsoProtocol.IpsoProtocolError;
	}

	/**
	 * 通过IotIpsoProtocolError获取IPSOError
	 */
	static getErrorByIotIpsoProtocolError(error: IotIpsoProtocol.IpsoProtocolError) {
		let ipsoError: typeof IPSO_PROTOCOL_ERRORS[keyof typeof IPSO_PROTOCOL_ERRORS];

		switch (error.type) {
			case IotIpsoProtocol.ErrorType.INVALID_DECODE_TYPE:
			case IotIpsoProtocol.ErrorType.INVALID_ENCODE_TYPE:
			case IotIpsoProtocol.ErrorType.INVALID_ENDIANNESS:
			case IotIpsoProtocol.ErrorType.UNSUPPORTED_PREDICT_LENGTH_FOR_VALUE_TYPE:
			case IotIpsoProtocol.ErrorType.RESOURCE_DATA_NOT_FOUND:
			case IotIpsoProtocol.ErrorType.SCHEMA_ERROR:
			case IotIpsoProtocol.ErrorType.RESOURCE_ID_NOT_FOUND:
			case IotIpsoProtocol.ErrorType.CMD_RESOURCE_NOT_FOUND:
			case IotIpsoProtocol.ErrorType.DETACHED_SUB_RESOURCE_NOT_FOUND:
			case IotIpsoProtocol.ErrorType.SUB_RESOURCE_NOT_FOUND:
			case IotIpsoProtocol.ErrorType.DETACHED_SUB_RESOURCE_MUST_BE_OBJECT:
			case IotIpsoProtocol.ErrorType.ATTRIBUTE_CONVERT_ERROR:
			case IotIpsoProtocol.ErrorType.DOWNLINK_BYTES_ERROR:
			case IotIpsoProtocol.ErrorType.DELETE_VALUE_ERROR:
			case IotIpsoProtocol.ErrorType.REFERENCE_ERROR:
			case IotIpsoProtocol.ErrorType.TARGET_ERROR:
			case IotIpsoProtocol.ErrorType.PROCESS_UPLINK_BYTES_ERROR:
			case IotIpsoProtocol.ErrorType.REFLECT_RELATION_ERROR:
			case IotIpsoProtocol.ErrorType.SET_VALUE_ERROR:
			case IotIpsoProtocol.ErrorType.VALUE_TYPE_ASSERT_ERROR:
			case IotIpsoProtocol.ErrorType.PARAMETER_ERROR:
				ipsoError = IPSO_PROTOCOL_ERRORS.PARSE_ERROR;
				break;
			default:
				ipsoError = IPSO_PROTOCOL_ERRORS.UNKNOWN_ERROR;
		}

		return new IPSOProtocolError({
			...ipsoError,
			message: `${ipsoError.message}: ${error.message}`,
			cause: error,
		});
	}

	/**
	 * 通过ipso协议响应获取错误对象
	 * @param response ipso协议响应
	 */
	static getErrorByIpsoResponse(response: {
		ans?: {
			id: string;
			res: number;
		}[]
	}) {
		const errorAns = response.ans?.filter(ans => ans.res !== 0);
		let errorMessage = '';

		if(errorAns?.length) {
			const responseErrors = Object.values(IPSO_COMMAND_RESPONSE_ERRORS);
			errorMessage = errorAns?.map(ans => {
				const errorId = ans.id ?? 'unknown';
				const message = responseErrors.find(error => error.code === ans.res)?.message ?? ans.res;

				return errorId !== 'unknown' ? `${errorId}: ${message}` : message;
			}).join(',');
		}

		return new IPSOProtocolError({
			...IPSO_PROTOCOL_ERRORS.COMMAND_RESPONSE_ERROR,
			message: errorMessage,
			cause: response,
		});
	}
}
