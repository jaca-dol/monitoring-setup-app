import { IpsoService } from '@ursalink-cloud/iot-ipso-service';

import { IPSOServiceResourceLoader } from './IPSOServiceResourceLoader';

const loader = IPSOServiceResourceLoader.load.bind(IPSOServiceResourceLoader);

export const IPSOService = new IpsoService(loader);