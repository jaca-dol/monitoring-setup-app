import { Buffer } from 'buffer';

import { AppData } from '@ursalink-cloud/iot-ipso-protocol';

import Logger, { LoggerType } from '../../utils/logger';
import { PasswordType, request_check_password } from '../password/passwordParameters';
import { IPSOProtocolError } from './IPSOProtocolError';
import { IPSOService } from './IPSOService';
import { IIPSOProtocol, IPSOProtocolRequestParams } from './types';

/**
 * 密码获取器
 */
interface PasswordGetter {
	getPassword(id?: string): string;
	getPasswordId(): string;
}

/**
 * IPSO协议(v2版本)
 */
export class IPSOProtocol implements IIPSOProtocol {

	passwordGetter: PasswordGetter;
	passwordType: PasswordType;

	logger: LoggerType;

	constructor(passwordGetter: PasswordGetter, passwordType: PasswordType) {
		this.passwordGetter = passwordGetter;
		this.passwordType = passwordType;
		this.logger = Logger.extend('IPSOProtocol');
	}

	/**
	 * 编码请求
	 */
	encodeRequest(params: IPSOProtocolRequestParams, options: {
		/**
		 * 是否自动添加校验密码的请求
		 */
		autoAddCheckPassword?: boolean;
	}) {
		const { autoAddCheckPassword = true } = options ?? {};

		// 如果请求中没有check_passwd_req字段，使用密码获取器获取密码，并添加到请求中
		if(autoAddCheckPassword && !params.request_security_password_check && !params.request_password_check) {//
			params = {
				...params,
				...request_check_password(this.passwordGetter.getPassword(), this.passwordType)
			};
		}

		const result = IPSOService.write(params);

		return result;
	}

	/**
	 * 解码响应
	 * - 能正常解析，返回解析结果
	 * - 解析有异常，抛出错误
	 */
	decodeResponse(
		data: number[],
		options?: {
			/** 是否打印调试日志 */
			logDebug?: boolean;
		}
	): AppData {
		const { logDebug = true } = options ?? {};
		const result = IPSOService.read(data);
		
		logDebug && this.logger.debug("decodeResponse", result);

		// 如果返回结果中有ans字段，且res为3，抛出错误
		if(result.ans && result.ans.some(res => res.res === 3)) {
			//新版密码校验，增加多次数时间限制
			if (result?.security_password_check_reply) {
				if (result.security_password_check_reply.result != 0) {
					if (result.security_password_check_reply.failed_message?.locked_time > 0) {
						throw IPSOProtocolError.throw('PASSWORD_ERROR_MANY_TIMES', {
							status: 'password_error_many_times',
							milliseconds: result.security_password_check_reply.failed_message.locked_time
						});
					} else {
						IPSOProtocolError.throw('CHECK_PASSWORD_ERROR', {
							...result,
							passwordId: this.passwordGetter.getPasswordId()
						});
					}
				}
			} else {
				IPSOProtocolError.throw('CHECK_PASSWORD_ERROR', {
					...result,
					passwordId: this.passwordGetter.getPasswordId()
				});
			}
		}

		// 如果返回结果中有check_passwd_ans，且code为1，抛出错误
		if(result?.password_check_reply?.result === 1) {
			IPSOProtocolError.throw('CHECK_PASSWORD_ERROR', {
				...result,
				passwordId: this.passwordGetter.getPasswordId()
			});
		}

		// 如果返回结果中有ans字段，且有非0的res字段，抛出错误
		if(result.ans && result.ans.some(res => res.res !== 0 && res.res !== 3)) {
			throw IPSOProtocolError.getErrorByIpsoResponse(result);
		}

		return result;
	}

	/**
	 * 判断是否为IPSO读取上来的数据
	 * @param data - 数据
	 * @returns
	 */
	isIPSOData(data: number[]): boolean {
		try {
			if(data.length === 0) {
				return false;
			}

			const header = data.slice(0, 5);
			const headerHex = Buffer.from(header).toString('hex');

			// 判断是否为IPSO数据
			if(headerHex === 'fb00ef01ee') {
				return true;
			}

			return false;
		} catch (error) {
			return false;
		}
	}

	/**
	 * 重置IPSO服务上下文
	 * 避免新的解析上下文被上一次的解析上下文所影响，导致解析错误
	 */
	resetIPSOServiceContext() {
		IPSOService.reset();
	}
}