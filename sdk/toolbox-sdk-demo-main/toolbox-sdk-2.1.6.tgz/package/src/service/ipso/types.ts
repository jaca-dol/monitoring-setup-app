import { PartialTSLInfo, TSLInfo } from '../../model/tsl';
import translate from '../../utils/translate';

import type { IpsoService, IotIpsoProtocol } from '@ursalink-cloud/iot-ipso-service';

export type ResourceData = IotIpsoProtocol.ResourceData;

export type ResourceIdentity = IotIpsoProtocol.ResourceIdentity;

export type ServiceReadResult = {
	/**
	 * 请求（0xEF）
	 */
	req?: Record<string, any>;

	/**
	 * 应答（0xEF）
	 */
	ans?: Record<string, any>;
} & TSLInfo;


/**
 * IPSO服务
 */
export type IIPSOService = InstanceType<typeof IpsoService>;

/**
 * IPSO服务资源加载器
 */
export interface IIPSOServiceResourceLoader {
	/**
	 * 加载资源
	 */
	load(resourceIdentity: ResourceIdentity): ResourceData;

	/**
	 * 根据条件获取资源内容
	 */
	getResourceBy(resourceIdentity: ResourceIdentity): ResourceData;
}

/**
 * 服务资源元数据
 */
export type IServiceResourceMeta = ResourceIdentity & {
	/**
	 * 型号名称（与我们的MODELS相同）
	 * @example	GS601
	 */
	name: string;
};

/**
 * 服务资源数据
 */
export type IServiceResourceData = Record<
	string,
	{
		/**
		 * 资源元数据
		 */
		meta: IServiceResourceMeta;

		/**
		 * 加载资源
		 */
		load: () => ResourceData;
	}
>;

/**
 * IPSO协议错误
 */
export const IPSO_PROTOCOL_ERRORS = {
	/**
	 * 未知错误
	 */
	UNKNOWN_ERROR: {
		name: 'UNKNOWN_ERROR',
		code: -1,
		get message() {
			return translate('tips.unknownError');
		}
	},

	/**
	 * 解析错误
	 */
	PARSE_ERROR: {
		name: 'PARSE_ERROR',
		code: 1,
		get message() {
			return translate('tips.parseError');
		}
	},

	/**
	 * 不支持解析
	 */
	NOT_SUPPORT_PARSE: {
		name: 'NOT_SUPPORT_PARSE',
		code: 2,
		get message() {
			return translate('tips.unableParse');
		}
	},

	/**
	 * 密码校验错误
	 */
	CHECK_PASSWORD_ERROR: {
		name: 'CHECK_PASSWORD_ERROR',
		code: 3,
		get message() {
			return translate('tips.wrongPassword');
		}
	},

	/**
	 * 数据异常
	 */
	INVALID_DATA: {
		name: 'INVALID_DATA',
		code: 4,
		get message() {
			return translate('tips.invalidData');
		}
	},

	/**
	 * 命令应答错误
	 */
	COMMAND_RESPONSE_ERROR: {
		name: 'COMMAND_RESPONSE_ERROR',
		code: 5,
		get message() {
			return translate('tips.commandResponseError');
		}
	},

	/**
	 * 不支持写入
	 * @example 当一个不支持写入的属性/服务/事件被写入时的报错
	 */
	NOT_SUPPORT_WRITE: {
		name: 'NOT_SUPPORT_WRITE',
		code: 6,
		get message() {
			return translate('tips.notSupportWrite');
		}
	},

	/**
	 * 密码错误次数过多
	 */
	PASSWORD_ERROR_MANY_TIMES: {
		name: 'PASSWORD_ERROR_MANY_TIMES',
		code: 12,
		get message() {
			return translate('tips.passwordErrorTooManyTimes');
		}
	}
};

/**
 * IPSO协议错误类型
 */
export type IPSOProtocolErrorType = keyof typeof IPSO_PROTOCOL_ERRORS;

/**
 * IPSO命令应答错误集合
 * 参考物模型协议的0xEF应答错误码
 * @see https://doc.weixin.qq.com/doc/w3_AMgAowYGACUx7AXNVvpQry6iGZx8m?scode=AMgAYAe8AAY07JRGMVAMgAowYGACU
 */
export const IPSO_COMMAND_RESPONSE_ERRORS = {
	/**
	 * 无法解析
	 */
	UNKNOWN: {
		name: 'UNKNOWN',
		code: 1,
		get message() {
			return translate('tips.unableParse');
		}
	},

	/**
	 * 顺序错误
	 */
	SEQUENCE_ERROR: {
		name: 'SEQUENCE_ERROR',
		code: 2,
		get message() {
			return translate('tips.sequenceError');
		}
	},

	/**
	 * 密码错误
	 */
	PASSWROD_ERROR: {
		name: 'PASSWROD_ERROR',
		code: 3,
		get message() {
			return translate('tips.wrongPassword');
		}
	},

	/**
	 * 读参数错误
	 */
	READ_PARAMS_ERROR: {
		name: 'READ_PARAMS_ERROR',
		code: 4,
		get message() {
			return translate('tips.readParamsError');
		}
	},

	/**
	 * 写参数错误
	 */
	WRITE_PARAMS_ERROR: {
		name: 'WRITE_PARAMS_ERROR',
		code: 5,
		get message() {
			return translate('tips.writeParamsError');
		}
	},

	/**
	 * 读执行错误
	 */
	READ_EXECUTION_ERROR: {
		name: 'READ_EXECUTION_ERROR',
		code: 6,
		get message() {
			return translate('tips.readExecutionError');
		}
	},

	/**
	 * 写执行错误
	 */
	WRITE_EXECUTION_ERROR: {
		name: 'WRITE_EXECUTION_ERROR',
		code: 7,
		get message() {
			return translate('tips.writeExecutionError');
		}
	},

	/**
	 * 读应用错误
	 */
	READ_APPLY_ERROR: {
		name: 'READ_APPLY_ERROR',
		code: 8,
		get message() {
			return translate('tips.readApplyError');
		}
	},

	/**
	 * 写应用错误
	 */
	WRITE_APPLY_ERROR: {
		name: 'WRITE_APPLY_ERROR',
		code: 9,
		get message() {
			return translate('tips.writeApplyError');
		}
	},

	/**
	 * 关联错误
	 */
	ASSOCIATION_ERROR: {
		name: 'ASSOCIATION_ERROR',
		code: 10,
		get message() {
			return translate('tips.associationError');
		}
	}
};


export type IPSOProtocolRequestParams = PartialTSLInfo;

/**
 * IPSO协议（v2）
 */
export interface IIPSOProtocol {
	/**
	 * 编码请求
	 */
	encodeRequest(params: IPSOProtocolRequestParams, options?: {
		/**
		 * 是否自动添加校验密码的请求
		 */
		autoAddCheckPassword?: boolean;
	}): number[];

	/**
	 * 解码响应
	 *
	 * - 能正常解析时，返回解析结果
	 * - 解析异常时，抛出错误
	 */
	decodeResponse(
		data: number[],
		options?: {
			/**
			 * 是否输出日志
			 */
			logDebug?: boolean;
		}
	): Record<string, any>;

	/**
	 * 判断是否为IPSO数据
	 * @param data - 数据
	 */
	isIPSOData(data: number[]): boolean;
	
	/**
	 * 重置IPSO服务上下文
	 * 避免新的解析上下文被上一次的解析上下文所影响，导致解析错误
	 */
	resetIPSOServiceContext(): void;
}