/* eslint-disable no-unused-vars */
import { NfcManager } from 'react-native-nfc-manager';

export { NfcTech, NfcEvents } from 'react-native-nfc-manager';

export { Ndef }  from 'react-native-nfc-manager';

export interface Nfc extends NfcManager {
	/**
	 * 全平台(iOS/Android)通用的transceive方法
	 */
	transceiveCommand(bytes: number[]): Promise<number[]>;
}

/**
 * NFC标签返回信息
 */
export interface NfcTag {
	ndefMessage: Array<{
    id?: number[];
    tnf: number;
    type: number[];
    payload: any[];
  }>;
	maxSize?: number;
	type?: string;
	techTypes?: string[];
	id?: number[];
}

/**
 * NFC返回数据
 */
export type NfcResponse = number[];

/**
 * NFC发送数据
 */
export type NfcPayload = number[];

/**
 * Nfc配置
 */
export interface NfcProxyConfig {
	/**
	 * 是否为debug
	 */
	debug: boolean;
	
	/**
	 * 失败重试发送次数
	 */
	maxRetries: number; 

	/**
	 * 设置收发(byte[])超时时间，单位为毫秒。
	 * 超时仅适用于此对象上的transceive(byte[])，并在调用close()时重置为默认值。
	 * 在执行需要较长处理时间（例如密钥生成）的标记的事务时，设置较长的超时可能很有用。
	 */
	transceiveTimeout: number;

	/**
	 * 发送命令前（checkWriteEnable）的延时
	 */
	sendCommandDelay: number;

	/**
	 * 发送完命令（read/write等）后，发送[checkReadEnable]/getAck前的延时
	 */
	afterSendCommandDelay: number;

	/**
	 * 发送数据前的延时
	 */
	sendDataDelay: number;

	/**
	 * 发送完全部数据之后的延时
	 */
	afterSendDataDelay: number;

	/**
	 * 失败后重新注册监听事件的延时
	 */
	registerDelay: number;

	/**
	 * 发送升级数据每2048个字节的延时
	 */
	sendUpgradeDataDelay: number;

	/**
	 * NFC数据传输模式
	 */
	mode: 'p2p' | 'card';

	/**
	 * 自动复位设备NFC\
	 * 在会话结束前，自动发送nfc复位命令给设备，让设备先关掉NFC，在timeout毫秒后再启动NFC\
	 * 使得Android手机可以不需要手动拿开再靠近设备，就可以自动重新触发NFC事件\
	 * 主要用于NFC自动化测试相关功能
	 */
	autoResetDeviceNfc: {
		/**
		 * 是否启用
		 */
		enable: boolean;

		/**
		 * 启动延时（ms）
		 */
		timeout: number;
	}
}

/**
 * Nfc错误
 */
export enum NfcError {
	/**
	 * 不支持NFC功能
	 */
	notSupport = 'notSupport',

	/**
	 * NFC未启用
	 */
	notEnabled = 'notEnabled',

	/**
	 * 发送命令失败
	 */
	sendFailed = 'sendFailed',

	/**
	 * 用户取消启用NFC
	 */
	userCancelEnable = 'USER_CANCEL_ENABLE',

	/**
	 * 重复请求
	 */
	duplicateRequest = 'DUPLICATE_REQUEST',

	/**
	 * 检测超时
	 */
	detectionTimeout = 'DETECTION_TIMEOUT',

	/**
	 * 未识别到tag
	 */
	tagNotFound = 'TAG_NOT_FOUND',

	/**
	 * tag连接丢失(iOS)
	 * NFCError:100
	 */
	tagConnectionLost = 'TAG_CONNECTION_LOST',

	/**
	 * 重试次数过多(iOS)
	 * NFCError:101
	 */
	retryExceeded = 'RETRY_EXCEEDED',

	/**
	 * tag响应错误(iOS)
	 * NFCError:102
	 */
	tagResponseError = 'TAG_RESPONSE_ERROR',

	/**
	 * 会话无效(iOS)
	 * NFCError:103
	 */
	sessionInvalidated = 'SESSION_INVALIDATE',

	/**
	 * tag未连接(iOS)
	 * NFCError:104
	 */
	tagNotConnected = 'TAG_NOT_CONNECTED',

	/**
	 * 数据包过长(iOS)
	 * NFCError:105
	 */
	packetTooLong = 'PACKET_TOO_LONG',

	/**
	 * 取消会话(iOS)
	 * NFCError:200
	 */
	detectionCancelled = 'DETECTION_CANCELLED',

	/**
	 * NFC 会话超时(iOS)
	 * NFCError:201
	 */
	sessionTimeout = 'SESSION_TIMEOUT',

	/**
	 * NFC 会话被意外终止(iOS)
	 * NFCError:202
	 */
	terminatedUnexpectedly = 'TERMINATED_UNEXPECTEDLY',

	/**
	 * 系统正忙（iOS）
	 * NFCError:203
	 */
	systemBusy = 'SYSTEM_BUSY',

	/**
	 * 获取ack数据失败
	 */
	ackError = 'ackError',

	/**
	 * 卡数据长度有误
	 */
	cardDataLengthError = 'cardDataLengthError',

	/**
	 * 卡数据版本过低
	 */
	cardDataVersionTooLow = 'cardDataVersionTooLow',

	/**
	 * 不支持随机密钥
	 */
	notSupportRandomKey = 'notSupportRandomKey',

	/**
	 * 读取寄存器地址失败
	 */
	readRegisterError = 'readRegisterError',


	/**
	 * 型号不匹配(app端判断)
	 */
	unmatchedDeviceModel = 'unmatchedDeviceModel',

	/**
	 * 频段不匹配
	 */
	unmatchFreq = 'unmatchFreq',

	/**
	 * 升级校验失败
	 */
	upgradeCheckFailed = 'upgradeCheckFailed',

	/**
	 * 数据错误
	 */
	dataError = -1,

	/**
	 * 交互超时
	 */
	timeout = 2,

	/**
	 * 密码错误
	 */
	wrongPassword = 3,

	/**
	 * 写入失败
	 */
	writeFailed = 4,

	/**
	 * 型号不匹配(设备端判断)
	 */
	unmatchedDevice = 5,

	/**
	 * crc校验错误
	 */
	crcError = 6,

	/**
	 * 采集中
	 */
	collecting = 8,

	/**
	 * 升级处于bootloader中
	 */
	inBootloader = 9,

	/**
	 * 内存不足
	 */
	patchOutOfMemory = 10,

	/**
	 * 补丁头部错误
	 */
	patchHeaderError = 11,

	/**
	 * 补丁数据错误
	 */
	patchCrcError = 12,

	/**
	 * 产品型号错误
	 */
	patchModelError = 13,
}

/**
 * NFC状态
 */
export enum NfcState {
	/**
	 * 初始化
	 */
	initial = 'initial',

	/**
	 * 准备
	 */
	ready = 'ready',

	/**
	 * 支持nfc
	 */
	supportNfc = 'supportNfc',

	/**
	 * 不支持nfc
	 */
	notSupportNfc = 'notSupportNfc',

	/**
	 * 启用nfc
	 */
	enabledNfc = 'enabledNfc',

	/**
	 * 检测芯片中
	 */
	detecting = 'detecting',

	/**
	 * 没有检测
	 */
	notDetect = 'notDetect',

	/**
	 * 开始检测芯片
	 */
	detectedTag = 'detectedTag',

	/**
	 * 准备发送命令
	 */
	readySend = 'readySend',

	/**
	 * 等待设备准备完成
	 */
	waitDeviceReady = 'waitDeviceReady',

	/**
	 * 检查设备是否可写
	 */
	checkDeviceWriteable = 'checkDeviceWriteable',

	/**
	 * 发送命令
	 */
	sendCommand = 'sendCommand',

	/**
	 * 检查设备是否可读
	 */
	checkDeviceReadable = 'checkDeviceReadable',

	/**
	 * 接收ACK数据
	 */
	receiveAckData = 'receiveAckData',

	/**
	 * 接收数据
	 */
	receiveData = 'receiveData',

	/**
	 * 发送数据
	 */
	sendData = 'sendData',

	/**
	 * 检查是否写入成功
	 */
	checkWriteSuccess = 'checkWriteSuccess',

	/**
	 * 发送成功
	 */
	sendSuccess = 'sendSuccess',

	/**
	 * 发送失败
	 */
	sendFailed = 'sendFailed'
}

/**
 * Nfc的事件
 */
export enum NfcTrackerEvents {

	beforeStart = 'beforeStart',

	start = 'start',

	progress = 'progress',

	success = 'success',

	error = 'error',

	sessionClose = 'sessionClose',

	stateChange = 'stateChange'
}

/**
 * 发送命令
 */
export type NfcCommand = number[];

/**
 * 命令名称
 */
export enum NfcCommandName {
	writeable = 'writeable',
	readable = 'readable',
	ack = 'ack',
	receiveData = 'receiveData',
	readStatus = 'readStatus',
	readFlash = 'readFlash',
	writeFlash = 'writeFlash',
	powerOn = 'powerOn',
	powerOff = 'powerOff',
	reset = 'reset',
	restart = 'restart',
	syncTime = 'syncTime',
	manualCalibration = 'manualCalibration',
	factoryCalibration = 'factoryCalibration',
	calibrateMotor = 'calibrateMotor',
	collect = 'collect',
	fetch = 'fetch',
	gpioSwitch = 'gpioSwitch',
	readCounterCtrl = 'readCounterCtrl',
	writeCounterCtrl = 'writeCounterCtrl',
	gasCalibration = 'gasCalibration',
	controlValve = 'controlValve',
	controlElectricValve = 'controlElectricValve',
	readElectricValve = 'readElectricValve',
	testElectricValve = 'testElectricValve',
	upgrade = 'upgrade',
	checkUpgrade = 'checkUpgrade',
	upgradeDataSize = 'upgradeDataSize',
	sendUpgradeData = 'sendUpgradeData',
	resetPowerMeter = 'resetPowerMeter',
	readCard = 'readCard',
	readCardPage = 'readCardPage',
	writeCard = 'writeCard',
	writeCardDataLength = 'writeCardDataLength',
	checkCardPassword = 'checkCardPassword',
	startSwitchCardSection = 'startSwitchCardSection',
	switchCardSection = 'switchCardSection',
	writeImgData = 'writeImgData',
	readHistoryData = 'readHistoryData',
	writeDSTemplate = 'writeDSTemplate',
	readDSTemplate = 'readDSTemplate',
	receiveHistoryData = 'receiveHistoryData',
	relativeInitialSurface = 'relativeInitialSurface',
	writeClear = 'writeClear',
	controlDevice = 'controlDevice',
	getSDI12Setting = 'getSDI12Setting',
	setSDI12Setting = 'setSDI12Setting',
	getChannelAddress = 'getChannelAddress',
	setChannelAddress = 'setChannelAddress',
	writeEM400NBCertificate = 'writeEM400NBCertificate',
	writeCertificate = 'writeCertificate',
	debuggerOn = 'debuggerOn',
	debuggerOff = 'debuggerOff',
	readyPatchUpgrade = 'readyPatchUpgrade',
	sendPatchUpgrade = 'sendPatchUpgrade',
	atDebugger = 'atDebugger',
	distanceCalibration = 'distanceCalibration',
	distanceBlindZoneCalibration = 'distanceBlindZoneCalibration',
	getSDIChannelOrFetch = 'getSDIChannelOrFetch',
	strokeCalibration = 'strokeCalibration',
	getProductInfo = 'getProductInfo',
	readLog = 'readLog',
	readD2dRecvMatch = 'readD2dRecvMatch',
	collectSNRValue = 'collectSNRValue',
    nh3Calibration = 'nh3Calibration',
	clearTVOC = 'clearTVOC',
	powerConsumptionTest = 'powerConsumptionTest',
	valveDebugger = 'valveDebugger',
	/**
	 * 通用命令，无实义，专门用于注册占位使用
	 */
	common = 'operate',

	/**
	 * 设备NFC复位命令（仅供调试适用）
	 */
	resetDeviceNfc = 'resetDeviceNfc'
}

/**
 * 命令类型
 */
export enum NfcCommandType {
	read = 'read',
	write = 'write',
	operate = 'operate',
	fetch = 'fetch',
	upgrade = 'upgrade'
}

// eslint-disable-next-line @typescript-eslint/consistent-type-definitions
export type NfcTrackerCallback = {
	[NfcTrackerEvents.beforeStart]: (commandName: NfcCommandName, commandType: NfcCommandType) => void;
	[NfcTrackerEvents.sessionClose]: (evt: any) => void;
	[NfcTrackerEvents.start]: (commandName: NfcCommandName, percentageProgress: number) => void;
	[NfcTrackerEvents.stateChange]: (state: NfcState) => void;
	[NfcTrackerEvents.success]: (commandName: NfcCommandName) => void;
	[NfcTrackerEvents.error]: (error: any, errorMessage: string, commandName: NfcCommandName) => void;
	[NfcTrackerEvents.progress]: (currentProgress: number, commandName: NfcCommandName) => void;
}

export interface INfcTracker {

	state: NfcState;

	currentCommand: NfcCommandName | undefined;

	currentProgress: number;

	totalProgress: number;

	setState(state: NfcState): void;

	onStateChange(state: NfcState): void;

	beforeStart(commandName: NfcCommandName, commandType: NfcCommandType): void;

	onStart(): void;

	onProgress(progress?: number): void;

	onSuccess(): void;

	onSessionClose(): void;

	onError(error: any, errorMessage?: string): void;

	getDefaultTotalProgress(commandType: NfcCommandType, commandName: NfcCommandName): void;

	setTotalProgressFromSendCount(sendCount: number, commandName: NfcCommandName): void;

	setTotalProgress(progress: number): void;

	setCurrentCommand(commandName: NfcCommandName): void;

	checkAndSmoothProgressToComplete(threshold?: number): Promise<void>;

	addEventListener<E extends NfcTrackerEvents>(eventName: E, callback: NfcTrackerCallback[E]): void;

	removeEventListener<E extends NfcTrackerEvents>(eventName: E, callback: NfcTrackerCallback[E]): void;
}

export interface INfcProtocol {
	/**
	 * 协议版本
	 */
	version: number;

	/**
	 * 一帧大小
	 */
	frameSize: number;

	/**
	 * 编码帧数据
	 * @param data - 帧数据
	 */
	encodeFrame(data: number[]): number[];

	/**
	 * 解码帧数据
	 * @param data - 帧数据
	 */
	decodeFrame(data: number[]): {
		/**
		 * 前导码
		 * 0x00: 表示当前帧为最后一帧数据
		 * 0xff: 表示继续接收，需要继续接收下一帧数据
		 */
		preamble: number;

		/**
		 * 协议版本
		 */
		protocolVersion: number;

		/**
		 * 帧数据大小
		 */
		dataSize: number;

		/**
		 * crc32校验码
		 */
		crc32: number;

		/**
		 * 数据
		 */
		data: number[];
	};

	/**
	 * 将数据编码为数据块
	 * @param data - 数据
	 */
	encodeDataChunk(data: number[], chunkSize?: number): {
		chunkCount: number;
		chunks: number[][];
	};

	/**
	 * 编码NFC状态检查请求
	 */
	encodeNfcStatusCheckRequest(): number[];

	/**
	 * 解码NFC状态检查响应
	 */
	decodeNfcStatusCheckResponse(response: number[]): 'readable' | 'writeable' | 'unknown';

	/**
	 * 编码NFC读取请求
	 */
	encodeNfcReadRequest(): number[];

	/**
	 * 编码NFC写入请求
	 */
	encodeNfcWriteRequest(): number[];

	/**
	 * 根据数据大小获取要发送的次数
	 */
	getSendCount(dataSize: number): number;

	/**
	 * 根据数据大小获取要发送的帧次数
	 */
	getFrameCount(dataSize: number): number;

	/**
	 * 判断响应是否为NFC协议(v1)的ack错误
	 */
	isAckError(response: number[]): boolean;
}