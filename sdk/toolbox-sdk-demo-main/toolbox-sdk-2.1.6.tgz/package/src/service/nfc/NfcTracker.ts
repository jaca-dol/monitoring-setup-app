import { EventEmitter } from 'events';
import _ from 'lodash';

import Logger from '../../utils/logger';
import { INfcTracker, NfcCommandName, NfcCommandType, NfcState, NfcTrackerCallback, NfcTrackerEvents } from './types';

export class NfcTracker implements INfcTracker {

	state: NfcState = NfcState.initial;

	currentCommand: NfcCommandName | undefined;

	currentProgress = -1;

	percentageProgress = 0;

	totalProgress = 1;

	eventEmitter: InstanceType<typeof EventEmitter>;

	logger = Logger.extend('NfcTracker');

	constructor() {
		this.eventEmitter = new EventEmitter();
		this.eventEmitter.setMaxListeners(50);
	}

	setState(state: NfcState) {
		this.state = state;
		this.onStateChange(state);
	}

	onStateChange(state: NfcState) {
		this.eventEmitter.emit(NfcTrackerEvents.stateChange, state);
	}

	beforeStart(commandName: NfcCommandName, commandType: NfcCommandType) {
		this.setState(NfcState.detecting);
		this.currentCommand = commandName;
		this.totalProgress = this.getDefaultTotalProgress(commandType, commandName);
		this.eventEmitter.emit(NfcTrackerEvents.beforeStart);
	}

	onStart() {
		this.currentProgress = 1;
		this.percentageProgress = 0;
		this.eventEmitter.emit(NfcTrackerEvents.start, this.currentCommand, this.percentageProgress);
	}

	onProgress(progress = 1) {
		this.setState(NfcState.sendCommand);
		
		this.currentProgress = progress === 1 
			? this.currentProgress + 1
			: progress;

		const nextPercentProgress = this.getPercentProgress(this.currentProgress, this.totalProgress);
		this.percentageProgress = nextPercentProgress;

		this.eventEmitter.emit(NfcTrackerEvents.progress, nextPercentProgress, this.currentCommand);
	}

	onSuccess(message?: string) {
		this.setState(NfcState.sendSuccess);
		this.currentProgress = this.totalProgress;
		this.percentageProgress = 1;
		this.eventEmitter.emit(NfcTrackerEvents.success, this.currentCommand, message);
	}

	onSessionClose() {
		this.setState(NfcState.notDetect);
		this.eventEmitter.emit(NfcTrackerEvents.sessionClose);
	}

	onError(error: any, errorMessage?: string, relisten?: boolean) {
		this.setState(NfcState.sendFailed);

		this.eventEmitter.emit(NfcTrackerEvents.error, error, errorMessage, this.currentCommand, relisten);
	}

	getDefaultTotalProgress(commandType: NfcCommandType, commandName?: NfcCommandName) {

		let total = 43;

		//读取counter状态命令
		if(commandName === NfcCommandName.readCounterCtrl) {
			return 86;
		}

		if(commandName === NfcCommandName.readCard) {
			return 6;
		}

		if(commandName === NfcCommandName.writeCard) {
			return 200;
		}

		if(commandName === NfcCommandName.checkUpgrade) {
			return 3;
		}

		if(commandName === NfcCommandName.readHistoryData) {
			return 20;
		}

		switch (commandType) {
			case NfcCommandType.read:
				total = 69;
				break;
			case NfcCommandType.fetch:	
				total = 43;
				break;
			case NfcCommandType.write:
				total = 41;
				break;
			case NfcCommandType.operate:		
			default:
				total = 5;
				break;
		}

		return total;
	}

	addEventListener<E extends NfcTrackerEvents>(eventName: E, callback: NfcTrackerCallback[E]) {
		this.eventEmitter.addListener(eventName, callback);
	}

	removeEventListener<E extends NfcTrackerEvents>(eventName: E, callback: NfcTrackerCallback[E]) {
		this.eventEmitter.removeListener(eventName, callback);
	}

	/**
	 * 根据发送次数，动态设置tracker总进度数
	 * @param sendCount
	 */
	setTotalProgressFromSendCount(sendCount: number, commandName: NfcCommandName) {
		let basicCommandStep = 5;

		switch (commandName) {
			case NfcCommandName.sendUpgradeData:
				basicCommandStep = 7;
				break;
			case NfcCommandName.receiveHistoryData:
				basicCommandStep = 10;
				break;
			case NfcCommandName.writeFlash:
				basicCommandStep = 5;
				break;
			case NfcCommandName.readFlash:
			default:
				basicCommandStep = 5;
				break;
		}

		const nextTotalProgress = basicCommandStep + sendCount * 2;

		this.totalProgress = Math.max(nextTotalProgress, this.totalProgress);
	}

	setTotalProgress(progress: number) {
		this.totalProgress = progress;
	}

	/**
	 * 转换进度为0-1之间的数，保留两位小数
	 * @param {string} state 
	 * @param {number} total 
	 * @return {number} 
	 */
	getPercentProgress(currentProgress: number, total: number) {
		const nextPercentProgress = _.toNumber(_.toNumber(currentProgress / total).toFixed(2));

		//兼容currentProgress大于total的情况
		if(nextPercentProgress >= 1) {
			return 0.99;
		}

		return nextPercentProgress;
	}

	/**
	 * 设置当前命令名称
	 * @param commandName - 当前命令名称
	 */
	setCurrentCommand(commandName: NfcCommandName) {
		this.currentCommand = commandName;
	}

	/**
	 * 检查当前进度与100%的差距，如果过大则做平滑过渡
	 * @param threshold 阈值，当前进度小于此值时触发平滑过渡，默认0.8（80%）
	 * @returns Promise，在动画完成后resolve
	 */
	async checkAndSmoothProgressToComplete(threshold: number = 0.8): Promise<void> {
		if (this.percentageProgress >= 0.95) {
			this.currentProgress = this.totalProgress;
			this.percentageProgress = 1;
			this.eventEmitter.emit(NfcTrackerEvents.progress, 1, this.currentCommand);
			return Promise.resolve();
		}
		
		if (this.percentageProgress < threshold) {
			this.logger.debug('进度差距过大，开始平滑过渡', {
				from: this.percentageProgress,
				to: 1
			});
			return this.startSmoothProgressTransition();
		} else {
			this.currentProgress = this.totalProgress;
			this.percentageProgress = 1;
			this.eventEmitter.emit(NfcTrackerEvents.progress, 1, this.currentCommand);
			return Promise.resolve();
		}
	}

	/**
	 * 启动平滑的进度过渡动画到100%
	 * @returns Promise，在动画完成后resolve
	 */
	private startSmoothProgressTransition(): Promise<void> {
		return new Promise(resolve => {
			const currentPercentage = this.percentageProgress;
			const targetPercentage = 1;
			const progressGap = targetPercentage - currentPercentage;
			
			// 使用递减步长，开始大，接近结束时变小
			const stepRatios = [ 0.5, 0.4, 0.3, 0.2, 0.1 ]; 
			let cumulativeProgress = currentPercentage;
			
			this.logger.debug('开始平滑过渡动画', {
				from: currentPercentage,
				to: targetPercentage,
			});
			
			let step = 0;
			const transitionInterval = setInterval(() => {
				if (step >= stepRatios.length) {
					clearInterval(transitionInterval);
					this.percentageProgress = 1;
					this.currentProgress = this.totalProgress;
					this.logger.debug('平滑过渡完成');
					this.eventEmitter.emit(NfcTrackerEvents.progress, 1, this.currentCommand);
					resolve();
					return;
				}
				
				const stepSize = progressGap * stepRatios[step]!;
				cumulativeProgress += stepSize;
				const newPercentage = Math.min(cumulativeProgress, targetPercentage);
				
				this.percentageProgress = newPercentage;
				this.logger.debug(`平滑过渡第${step + 1}步`, { 
					percentage: newPercentage,
					stepSize: stepSize,
					ratio: stepRatios[step]
				});
				this.eventEmitter.emit(NfcTrackerEvents.progress, newPercentage, this.currentCommand);
				
				step++;
			}, 100); 
		});
	}
}