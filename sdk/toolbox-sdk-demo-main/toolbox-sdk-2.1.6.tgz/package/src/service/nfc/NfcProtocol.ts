import { Buffer } from 'buffer';

import NfcUtils from './NfcUtils';
import { INfcProtocol } from './types';

/**
 * NFC协议（v2）
 * 支持IPSOv2协议
 */
export class NfcProtocol implements INfcProtocol {
	/**
	* 前导码
	* 0x00: 通常表示当前帧为最后一帧
	* 0xff: 通常表示当前帧不是最后一帧，需要继续接收下一帧
	*/
	private	preamble = 0x00;

	/**
	 * 协议版本
	 */
	version = 0x01;

	/**
	 * 一帧大小，由帧头（8） + 若干个数据块组成(x * 64 = 4096)
	 * 4096: 取决于设备的内存大小，通常为4096，可能每个设备内存都不一样
	 */
	frameSize = 8 + 4096;

	/**
	 * NFC芯片命令
	 */
	private NfcCommands = {
		/**
		 * 向芯片写入数据
		 */
		writeCmd: [ 0xa6, 0xf0, 0xff ],

		/**
		 * 检查芯片状态
	 	*/
		statusCheckCmd: [ 0x3a, 0xed, 0xed ],

		/**
		 * 向芯片读取数据
		 */
		readCmd: [ 0x3a, 0xf0, 0xff ]
	}

	/**
	 * 发送数据块大小（writeCmd(3) + data(64)）
	 */
	private sendChunkSize = 67;

	/**
	 * 数据块大小
	 */
	private chunkSize = 64;

	encodeFrame(data: number[]): number[] {
		const headerBuffer = Buffer.alloc(8);
		const dataBuffer = Buffer.from(data);
		const crc32 = NfcUtils.getCrc32(data);
		headerBuffer.writeUInt8(this.preamble, 0);
		headerBuffer.writeUInt8(this.version, 1);
		headerBuffer.writeUInt16LE(data.length, 2);
		headerBuffer.writeUInt32LE(crc32, 4);
		return [
			...headerBuffer,
			...dataBuffer
		];
	}

	decodeFrame(frame: number[]): ReturnType<INfcProtocol['decodeFrame']> {
		const headerBuffer = Buffer.from(frame.slice(0, 8));
		const preamble = headerBuffer.readUInt8(0);
		const protocolVersion = headerBuffer.readUInt8(1);
		const dataSize = headerBuffer.readUInt16LE(2);
		const crc32 = headerBuffer.readUInt32LE(4);
		const frameData = frame.slice(8, 8 + dataSize);

		return {
			preamble,
			protocolVersion,
			dataSize,
			crc32,
			data: frameData
		};
	}

	encodeDataChunk(data: number[], chunkSize = this.chunkSize): ReturnType<INfcProtocol['encodeDataChunk']> {
		const chunkHeader = Buffer.from(this.NfcCommands.writeCmd);
		const dataBuffer = Buffer.from(data);
		const chunks = [];
		const chunkCount = this.getSendCount(dataBuffer.length);

		for (let index = 0; index < chunkCount; index++) {
			const start = index * chunkSize;
			const end = Math.min(start + chunkSize, dataBuffer.length);
			const chunkData = dataBuffer.subarray(start, end);
			const chunk = [
				...chunkHeader,
				...chunkData
			];

			//不足发送数据块大小的数据用0补齐
			if(chunk.length < this.sendChunkSize) {
				chunk.push(...Array(this.sendChunkSize - chunk.length).fill(0x00));
			}

			chunks.push(chunk);
		}

		return {
			chunkCount,
			chunks
		};
	}

	encodeNfcStatusCheckRequest(): number[] {
		return this.NfcCommands.statusCheckCmd;
	}

	decodeNfcStatusCheckResponse(response: number[]): 'readable' | 'writeable' | 'unknown' {
		if(response.length < 3) {
			return 'unknown';
		}

		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		const [ _b1, _b2, status ] = response;

		if((status! & 0x29) === 0x29) {
			return 'readable';
		}
		
		if((status! & 0x21) === 0x21) {
			return 'writeable';
		}
		
		return 'unknown';
	}

	encodeNfcReadRequest(): number[] {
		return this.NfcCommands.readCmd;
	}

	encodeNfcWriteRequest(): number[] {
		return this.NfcCommands.writeCmd;
	}

	getSendCount(dataSize: number): number {
		return Math.ceil(dataSize / this.chunkSize);
	}

	getFrameCount(dataSize: number): number {
		return Math.ceil(dataSize / this.frameSize);
	}

	isAckError(response: number[]): boolean {
		if(Array.isArray(response)) {
			const isAckError = [ 77, 60, 43, 26, 120, 86, 52, 18, 1, 1 ].every((value, index) => {
				return response[index] === value;
			});

			return isAckError;
		}

		return false;
	}
}