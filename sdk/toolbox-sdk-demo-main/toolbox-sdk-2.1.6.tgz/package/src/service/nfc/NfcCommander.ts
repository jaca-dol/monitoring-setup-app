import { Buffer } from 'buffer';
import _ from 'lodash';

import { Metric } from '@ursalink-cloud/core-sdk/lib';

import DeviceUtils from '../../model/DeviceUtils';
import { TimeCounter } from '../../utils/counter';
import Logger, { LoggerType } from '../../utils/logger';
import { shouldIgnoreTransceiveFail } from './NfcCompatibility';
import nfcConverter from './NfcConverter';
import { NfcProxy } from './NfcProxy';
import NfcUtils from './NfcUtils';
import { INfcTracker, NfcCommand, NfcCommandName, NfcCommandType, NfcError } from './types';

interface CommandObject {
	name: NfcCommandName;
	command: ((data: any) => NfcCommand) | NfcCommand;
	type: NfcCommandType
}

type Commands = {
	[key in NfcCommandName]: CommandObject;
};

/**
 * 提取出command的参数
 */
export type ExtractCommandParam<T extends Commands> = {
	[P in keyof T]:
		T[P] extends CommandObject 
			? T[P]['command'] extends (data: infer Data) => NfcCommand
				? Data 
				: NfcCommand 
			: never  
};

export type NfcCommandParam = ExtractCommandParam<typeof commands>;

const NFC_MAGIC = '4d3c2b1a78563412';
const NFC_VERSION = '01';

const NFC_STATUS_CHECK_COMMAND = '3AEDED';
const NFC_READ_DEVICE_DATA_COMMAND = '3AF0FF';
const NFC_SEND_DEVICE_COMMAND = 'A6F0FF';
const NFC_COMMAND_PREFIX = `${NFC_SEND_DEVICE_COMMAND}${NFC_MAGIC}${NFC_VERSION}` as const;
const NFC_WRITE_CARD_DATA_COMMAND = 'A2';
const NFC_READ_CARD_DATA_COMMAND = '3A';

const NFC_READ_PKT = '01';
const NFC_WRITE_PKT = '02';

const NFC_WRITE_FLASH = '01';
const NFC_POWER_ON = '02';
const NFC_POWER_OFF = '03';
const NFC_UPGRADE = '04';

/**
 * 所有支持的NFC命令
 */
const commands = {

	/**
	 * 检查设备是否可写
	 */
	[NfcCommandName.writeable]: {
		name: NfcCommandName.writeable,
		command: nfcConverter.encodeCommand(NFC_STATUS_CHECK_COMMAND),
		type: NfcCommandType.read
	},

	/**
	 * 检查设备是否可读
	 */
	[NfcCommandName.readable]: {
		name: NfcCommandName.readable,
		command: nfcConverter.encodeCommand(NFC_STATUS_CHECK_COMMAND),
		type: NfcCommandType.read
	},

	/**
	 * 获取ack
	 */
	[NfcCommandName.ack]: {
		name: NfcCommandName.ack,
		command: nfcConverter.encodeCommand(NFC_READ_DEVICE_DATA_COMMAND),
		type: NfcCommandType.read
	},

	/**
	 * 接收数据
	 */
	[NfcCommandName.receiveData]: {
		name: NfcCommandName.receiveData,
		command: nfcConverter.encodeCommand(NFC_READ_DEVICE_DATA_COMMAND),
		type: NfcCommandType.read
	},

	/**
	 * 读取状态
	 */
	[NfcCommandName.readStatus]: {
		name: NfcCommandName.readStatus,
		command: nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}05`, true),
		type: NfcCommandType.read
	},

	/**
	 * 读取flash
	 */
	[NfcCommandName.readFlash]: {
		name: NfcCommandName.readFlash,
		command: nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}05`, true),
		type: NfcCommandType.read
	},

	/**
	 * 写入配置
	 */
	[NfcCommandName.writeFlash]: {
		name: NfcCommandName.writeFlash,
		command: (data: { dataSize: number; password: string }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}${NFC_WRITE_FLASH}${nfcConverter.convertNumber(data.dataSize)}0000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.write
	},

	/**
	 * 读取NFC卡内容的页数
	 * 第五页存储需要读取的数据大小
	 */
	[NfcCommandName.readCardPage]: {
		name: NfcCommandName.readCardPage,
		command: () => {
			return nfcConverter.encodeCommand(`${NFC_READ_CARD_DATA_COMMAND}0505`);
		},
		type: NfcCommandType.read
	},

	/**
	 * 读取NFC卡内容
	 */
	[NfcCommandName.readCard]: {
		name: NfcCommandName.readCard,
		command: (data: { startAddress: number, endAddress: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_READ_CARD_DATA_COMMAND}${nfcConverter.convertNumber(data.startAddress)}${nfcConverter.convertNumber(data.endAddress)}`
			);
		},
		type: NfcCommandType.read
	},

	/**
	 * 检查卡密码
	 */
	[NfcCommandName.checkCardPassword]: {
		name: NfcCommandName.checkCardPassword,
		command: () => [ 27, 135, 101, 67,  33 ], //1B8654321
		type: NfcCommandType.read
	},

	/**
	 * 写入NFC卡内容
	 */
	[NfcCommandName.writeCard]: {
		name: NfcCommandName.writeCard,
		command: () => nfcConverter.encodeCommand(NFC_WRITE_CARD_DATA_COMMAND),
		type: NfcCommandType.write
	},

	/**
	 * 在第五页中写入数据长度和写入标志位
	 */
	[NfcCommandName.writeCardDataLength]: {
		name: NfcCommandName.writeCard,
		command: (data: {dataSize: number}) => nfcConverter.encodeCommand(`${NFC_WRITE_CARD_DATA_COMMAND}05${nfcConverter.convertNumber(data.dataSize)}0055`),
		type: NfcCommandType.write
	},

	/**
	 * 切换NFC卡区域
	 */
	[NfcCommandName.startSwitchCardSection]: {
		name: NfcCommandName.startSwitchCardSection,
		command: () => nfcConverter.encodeCommand('c2ff'),
		type: NfcCommandType.read
	},

	/**
	 * 指定要切换卡的区域
	 */
	[NfcCommandName.switchCardSection]: {
		name: NfcCommandName.switchCardSection,
		command: (data: { cardSetion: 0 | 1 }) => [ data.cardSetion, 0, 0, 0 ],
		type: NfcCommandType.write
	},

	/**
	 * 开机
	 */
	[NfcCommandName.powerOn]: {
		name: NfcCommandName.powerOn,
		command: (data: { password: string }) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}${NFC_POWER_ON}00000000${nfcConverter.convertPassword(data.password)}`,
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * 关机
	 */
	[NfcCommandName.powerOff]: {
		name: NfcCommandName.powerOff,
		command: (data: { password: string }) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}${NFC_POWER_OFF}00000000${nfcConverter.convertPassword(data.password)}`,
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * 升级
	 */
	[NfcCommandName.upgrade]: {
		name: NfcCommandName.upgrade,
		command: (data: { password: string, headerSize: number,  reboot: boolean, moduleId: number }) => {
			const reboot = data.reboot ?? false;
			const moduleId = data.moduleId ?? 0;
			const payload = reboot ? `0000${nfcConverter.convertNumber(moduleId,2)}` : `5a5a${nfcConverter.convertNumber(moduleId,2)}`;
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}${NFC_UPGRADE}${nfcConverter.numberToHextStr(data.headerSize, 4)}${nfcConverter.convertPassword(data.password)}0000000000000000${payload}`,
				true
			);
		},
		type: NfcCommandType.upgrade
	},

	/**
	 * 升级校验
	 */
	[NfcCommandName.checkUpgrade]: {
		name: NfcCommandName.checkUpgrade,
		command: (data: { data: number[] }) => nfcConverter.hexStrToDecimalArr(NFC_SEND_DEVICE_COMMAND).concat(data.data), //A6 F0 FF + data
		type: NfcCommandType.upgrade
	},

	/**
	 * 升级镜像大小
	 */
	[NfcCommandName.upgradeDataSize]: {
		name: NfcCommandName.upgradeDataSize,
		command: (data: { data: number[], password: string, upgradeDataStartPosition: number, reboot: boolean, moduleId: number }) => {
			try {
				const reboot = data.reboot ?? false;
				const moduleId = data.moduleId ?? 0;
				const payload = reboot ? `0000${nfcConverter.convertNumber(moduleId,2)}` : `5a5a${nfcConverter.convertNumber(moduleId,2)}`;
				const dataLength = nfcConverter.numberToHextStr(data.data.length - data.upgradeDataStartPosition, 4);
				const cmd = nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}${NFC_UPGRADE}${dataLength}${nfcConverter.convertPassword(data.password)}0000000000000000${payload}`, true);

				return cmd;
			} catch (error) {
				console.log('error: ', error);
			}
			
			return [];
		},
		type: NfcCommandType.upgrade
	},

	/**
	 * 发送升级数据（仅声明，具体实现在sendUpgradeData函数中）
	 */
	[NfcCommandName.sendUpgradeData] : {
		name: NfcCommandName.sendUpgradeData,
		command: (data: number[]) => data,
		type: NfcCommandType.upgrade
	},

	/**
	 * UC500 fetch命令/ EM410-RDL 采集命令
	 */
	[NfcCommandName.fetch]: {
		name: NfcCommandName.fetch,
		command: (data: { type: Metric.COLLECT_METRIC | 'sdi';  index: number; password: string; }) => {
			let channelType = '03';
			switch (data.type) {
				case Metric.COLLECT_METRIC.AI: 
					channelType = '01';
					break;
				case Metric.COLLECT_METRIC.CHN:
					channelType = '02';
					break;
				case 'sdi':
					channelType = '04';
					break;
			}
			const channelIndex = data.index < 10 
				? `0${data.index}` 
				: data.index.toString(16).length < 2 
					? `0${data.index.toString(16)}` 
					: data.index.toString(16);

			const command = nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}0600000000${nfcConverter.convertPassword(data.password)}${channelType}${channelIndex}`,
				true
			);
			
			return command;
		},
		type: NfcCommandType.fetch
	},

	/**
	 * NB SDI12读取地址/读取采集数据
	 */
	[NfcCommandName.getSDIChannelOrFetch]: {
		name: NfcCommandName.getSDIChannelOrFetch,
		command: (data: { password: string, id: number, type: 'channel' | 'fetch' })=>{
			const ctrl = data.type === 'channel' ? '00' : '01';
			const command = nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}0600000000${nfcConverter.convertPassword(data.password)}04${nfcConverter.convertNumber(data.id)}${ctrl}`, true);
			return command;
		},
		type: NfcCommandType.read
	},

	/**
	 * 重置
	 */
	[NfcCommandName.reset]: {
		name: NfcCommandName.reset,
		command: (data: {password: string}) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0700000000${nfcConverter.convertPassword(data.password)}02`, //2代表重置后设备开关机状态保持不变
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * 读取counter状态
	 * index: 1 - counter1、 2 - counter2
	 * 返回值：0 - stop、1 - start
	 */
	[NfcCommandName.readCounterCtrl]: {
		name: NfcCommandName.readCounterCtrl,
		command: (data: { password: string; index: 1 | 2 }) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}0800000000${nfcConverter.convertPassword(data.password)}0${data.index}`,
			true
		),
		type: NfcCommandType.operate
	},


	/**
	 * 读历史数据请求
	 */
	[NfcCommandName.readHistoryData]: {
		name: NfcCommandName.readHistoryData,
		command: (data: { 
			startTime: number; 
			endTime: number; 
			currentTime: number, 
			password: string, 
			type: number //历史数据类型，0 | 1 | 2 表示不同的存储分区
		}) => {
			
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}0900000000${nfcConverter.convertPassword(data.password)}0101${nfcConverter.longNumberToHexStr(data.endTime, true)}${nfcConverter.longNumberToHexStr(data.startTime, true)}${nfcConverter.longNumberToHexStr(data.currentTime, true)}0${data.type}`,
				true
			);
		},
		type: NfcCommandType.read
	},

	/**
 	* 读取设备日志
 	*/
	[NfcCommandName.readLog]: {
		name: NfcCommandName.readLog,
		command: nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}10`, true),
		type: NfcCommandType.read
	},

	/**
	 * 获取指定个数历史数据
	 */
	[NfcCommandName.receiveHistoryData]: {
		name: NfcCommandName.receiveHistoryData,
		command: (data: { action: number, count: number }) => {
			const hexDataCount = nfcConverter.numberToHextStr(data.count, 4, false);
			const action = data.action ?? 2; //2: 读，3：结束读
			
			return nfcConverter.encodeCommand(
				`${NFC_SEND_DEVICE_COMMAND}090${action}${hexDataCount}`,
				true
			);
		},
		type: NfcCommandType.read
	},

	/**
	 * 重启设备
	 */
	[NfcCommandName.restart]: {
		name: NfcCommandName.restart,
		command: (data: { password: string; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0b00000000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 同步时间
	 */
	[NfcCommandName.syncTime]: {
		name: NfcCommandName.syncTime,
		command: (data: { password: string; time: number; timeZone: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0c00000000${nfcConverter.convertPassword(data.password)}${nfcConverter.longNumberToHexStr(data.time, true)}${nfcConverter.convertNumber(data.timeZone)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * AM102 手动校准命令
	 */
	[NfcCommandName.manualCalibration]: {
		name: NfcCommandName.manualCalibration,
		command: (data: { password: string }) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0d00000000${nfcConverter.convertPassword(data.password)}03`,
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * AM102 恢复出厂校准命令
	 */
	[NfcCommandName.factoryCalibration]: {
		name: NfcCommandName.factoryCalibration,
		command: (data: { password: string }) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0d00000000${nfcConverter.convertPassword(data.password)}00`,
			true
		),
		type: NfcCommandType.operate
	},
	/**
	 * UC500 采集命令
	 */
	[NfcCommandName.collect]: {
		name: NfcCommandName.collect,
		command: (data: { password: string; index: number; type:  Metric.COLLECT_METRIC | 'sdi', instruction?: string }) => {
			let channelType = '01';
			switch (data.type) {
				case Metric.COLLECT_METRIC.CHN: 
					channelType = '02';
					break;
				case 'sdi':
					channelType = '04';
					break;
			}
			const channelIndex = data.index < 10 ? 
				`0${data.index}` : 
				data.index.toString(16).length < 2 ? `0${data.index.toString(16)}` : data.index.toString(16);

			const instruction = data.instruction || '';
			let hexStr = '';

			Buffer.from(instruction).forEach(num=>{
				hexStr += nfcConverter.numberToHextStr(num, 1);
			});
			
			const command = nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0e00000000${nfcConverter.convertPassword(data.password)}${channelType}${channelIndex}${hexStr}`,
				true
			);
		
			return command;
		},
		type: NfcCommandType.operate
	},

	/**
	 * UC500 gpio 控制命令
	 */
	[NfcCommandName.gpioSwitch]: {
		name: NfcCommandName.gpioSwitch,
		command: (data: { gpioIndex: 1 | 2; gpioValue: 0 | 1; password: string;  }) => {

			const gpioIndex = `0${data.gpioIndex}`;
			const gpioValue = `0${data.gpioValue}`;

			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}0f00000000${nfcConverter.convertPassword(data.password)}${gpioIndex}${gpioValue}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 气体校准命令
	 */
	[NfcCommandName.gasCalibration]: {
		name: NfcCommandName.gasCalibration,
		command: (data: { type: number; password: string; value: number; }) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1000000000${nfcConverter.convertPassword(data.password)}0${data.type}${nfcConverter.convertNumber(data.value)}`,
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * 相对初始面以及G值标定
	 */
	[NfcCommandName.relativeInitialSurface]: {
		name: NfcCommandName.relativeInitialSurface,
		command: (data: { password: string; type: 'setting' | 'clear' | 'zero-setting' | 'zero-clear' }) => {
			//仅第一个字节有效，后面的ff字节是填充位，为了兼容其他校准命令
			const commandType = {
				'setting': 'ffff',
				'clear': 'feff',
				'zero-setting': 'fdff',//零点校准以及G值标定的命令
				'zero-clear': 'fcff'
			}[data.type ?? 'setting'];

			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1000000000${nfcConverter.convertPassword(data.password)}${commandType}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 氨气/硫化氢校准命令
	 */
	[NfcCommandName.nh3Calibration]: {
		name: NfcCommandName.nh3Calibration,
		command: (data: { password: string; type: 'nh3' | 'h2s', action: 'clear' | 'setting', value: number }) => {
			const type = data.type === 'nh3' ? '00' : '01';
			const action = data.action === 'clear' ? '00' : '01';
			const value = nfcConverter.numberToHextStr(data.value, 1, false);
			const commandPayload = `${type}${action}${value}`;

			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1000000000${nfcConverter.convertPassword(data.password)}${commandPayload}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 写入counter控制
	 * index: 1 - counter1、 2 - counter2
	 * value: 0 - write、 1 - stop、 2 - start 
	 * count: 写入值，0表示清零
	 */
	[NfcCommandName.writeCounterCtrl]: {
		name: NfcCommandName.writeCounterCtrl,
		command: (data: { password: string; index: 1 | 2; value: 0 | 1 | 2; count: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1100000000${nfcConverter.convertPassword(data.password)}0${data.index}0${data.value}${nfcConverter.numberToHextStr(data.count, 4)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 控制电磁阀
	 * index 电磁阀索引，1/2
	 * 0 - 关闭、 1 - 开启
	 */
	[NfcCommandName.controlValve]: {
		name: NfcCommandName.controlValve,
		command: (data: { index: 1 | 2; status: 0 | 1; password: string; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1200000000${nfcConverter.convertPassword(data.password)}0${data.index}0${data.status}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 控制电磁阀
	 * index 电磁阀索引，1/2
	 * status 开度1-200
	 */
	[NfcCommandName.controlElectricValve]: {
		name: NfcCommandName.controlElectricValve,
		command: (data: { index: 1 | 2; status: number; password: string; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1200000000${nfcConverter.convertPassword(data.password)}0${data.index}${nfcConverter.numberToHextStr(data.status, 1)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	[NfcCommandName.readElectricValve]: {
		name: NfcCommandName.readElectricValve,
		command: (data: { id: 1 | 2 }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}36000000000${data.id}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	[NfcCommandName.testElectricValve]: {
		name: NfcCommandName.testElectricValve,
		command: (data: { id: 1 | 2; password: string; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}3600000000${nfcConverter.convertPassword(data.password)}0${data.id}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 重置电量统计
	 */
	[NfcCommandName.resetPowerMeter]: {
		name: NfcCommandName.resetPowerMeter,
		command: (data: { password: string; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1300000000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 写入图片数据
	 */
	[NfcCommandName.writeImgData]: {
		name: NfcCommandName.writeImgData,
		command: (data: { password: string; dataSize: number; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}14${nfcConverter.convertNumber(data.dataSize)}0000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.write
	},

	/**
	 * 写入模板
	 */
	[NfcCommandName.writeDSTemplate]: {
		name: NfcCommandName.writeDSTemplate,
		command: (data: { password: string; dataSize: number; logoSize: number; baseSize: number; header: number[]; templateId: number }) => {
			const crc = data.header.slice(0,4);
			const template_size = data.header.slice(6,8);
			const block_pic_size = Array.from(Buffer.from(nfcConverter.numberToHextStr(data.logoSize, 2), 'hex'));
			const base_pic_size = Array.from(Buffer.from(nfcConverter.numberToHextStr(data.baseSize, 2), 'hex'));
			const spliceData = [data.templateId].concat(crc).concat(template_size).concat(block_pic_size).concat(base_pic_size);
			const convertData = nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}15${nfcConverter.convertNumber(data.dataSize)}0000${nfcConverter.convertPassword(data.password)}`,
				true
			);
			spliceData.map((num, i)=> convertData[24 + i] = num);
			
			return convertData;
		},
		type: NfcCommandType.write
	},

	/**
	 * 读取模板
	 */
	[NfcCommandName.readDSTemplate]: {
		name: NfcCommandName.readDSTemplate,
		command: (data: { password: string, templateId: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}15${nfcConverter.convertNumber(data.templateId)}000000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.read
	},

	/**
	 * 读取SDI12
	 */
	[NfcCommandName.getSDI12Setting]: {
		name: NfcCommandName.getSDI12Setting,
		command: nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}16`, true),
		type: NfcCommandType.read
	},

	/**
	 * 写入SDI12
	 */
	[NfcCommandName.setSDI12Setting]: {
		name: NfcCommandName.setSDI12Setting,
		command: (data: { dataSize: number; password: string }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}21${nfcConverter.convertNumber(data.dataSize)}0000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.write
	},
	/**
	 * 读取通道地址
	 */
	[NfcCommandName.getChannelAddress]: {
		name: NfcCommandName.getChannelAddress,
		command: (data: { password: string, id: number })=>{
			const command = nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}1700000000${nfcConverter.convertPassword(data.password)}${nfcConverter.convertNumber(data.id)}3f21`, true);
									
			return command;
		},
		type: NfcCommandType.read
	},

	/**
	 * 修改通道地址
	 */
	[NfcCommandName.setChannelAddress]: {
		name: NfcCommandName.setChannelAddress,
		command: (data: { password: string, id: number, preAddress: string, address: string })=>{
			let hexStr = '';

			Buffer.from(`${data.preAddress}A${data.address}!`).forEach(num=>{
				hexStr += nfcConverter.numberToHextStr(num, 1);
			});
			const command = nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}2300000000${nfcConverter.convertPassword(data.password)}${nfcConverter.convertNumber(data.id)}${hexStr}`, 
				true
			);
			
			return command;
		},
		type: NfcCommandType.write
	},

	/**
	 * 通用控制设备指令
	 * 后续有类似控制指令可在payload进行扩展, 可枚举
	 * payload: 0 - 中止蜂鸣器响
	 */
	[NfcCommandName.controlDevice]: {
		name: NfcCommandName.controlDevice,
		command: (data: { password: string, payload: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1600000000${nfcConverter.convertPassword(data.password)}${nfcConverter.convertNumber(data.payload)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 距离校准
	 */
	[NfcCommandName.distanceCalibration]: {
		name: NfcCommandName.distanceCalibration,
		command: (data: { password: string }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1700000000${nfcConverter.convertPassword(data.password)}01`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 距离盲区校准
	 */
	[NfcCommandName.distanceBlindZoneCalibration]: {
		name: NfcCommandName.distanceBlindZoneCalibration,
		command: (data: { password: string }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1700000000${nfcConverter.convertPassword(data.password)}02`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 电机行程校准
	 */
	[NfcCommandName.strokeCalibration]: {
		name: NfcCommandName.strokeCalibration,
		command: (data: { password: string }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}1B00000000${nfcConverter.convertPassword(data.password)}`,
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 清空数据
	 * @param {number} type: 0：清空雨量，1：清空历史记录，2：清空累计进入人数，3：清空累计离开人数
	 */
	[NfcCommandName.writeClear]: {
		name: NfcCommandName.writeClear,
		command: (data: { password: string; type: number; }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}2000000000${nfcConverter.convertPassword(data.password)}0${data.type}`,
				true
			);
		},
		type: NfcCommandType.operate
	},
	
	/**
	 * 写入证书，EM400NB特有
	 */
	[NfcCommandName.writeEM400NBCertificate]: {
		name: NfcCommandName.writeEM400NBCertificate,
		command: (data: { password: string, dataSize: number, type: 1 | 2 | 3, mode: number, checkData: number }) =>
			nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}21${nfcConverter.convertNumber(data.dataSize)}0000${nfcConverter.convertPassword(data.password)}0${data.mode}0${data.type}00${nfcConverter.numberToHextStr(data.checkData, 4, true)}`, 
				true
			),
		type: NfcCommandType.write
	},
	
	/**
	* 开启EM400NB的日志串口
	*/
	[NfcCommandName.debuggerOn]: {
		name: NfcCommandName.debuggerOn,
		command: (data: {password: string}) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}2200000000${nfcConverter.convertPassword(data.password)}000000`, 
			true
		),
		type: NfcCommandType.write
	},

	/**
	* 关闭EM400NB的日志串口
	*/
	[NfcCommandName.debuggerOff]: {
		name: NfcCommandName.debuggerOff,
		command: (data: {password: string}) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}2300000000${nfcConverter.convertPassword(data.password)}000000`, 
			true
		),
		type: NfcCommandType.write
	},

	/**
	* 写入AT指令
	*/
	[NfcCommandName.atDebugger]: {
		name: NfcCommandName.atDebugger,
		command: (data: { password: string, dataSize: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}26${nfcConverter.convertNumber(data.dataSize)}000000${nfcConverter.convertPassword(data.password)}000000`, 
				true
			);
		},
		type: NfcCommandType.write
	},

	/**
	* 写入电动阀调试指令
	*/
	[NfcCommandName.valveDebugger]: {
		name: NfcCommandName.valveDebugger,
		command: (data: { password: string, dataSize: number }) => {
			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}37${nfcConverter.convertNumber(data.dataSize)}000000${nfcConverter.convertPassword(data.password)}000000`, 
				true
			);
		},
		type: NfcCommandType.write
	},

	/**
	 * 获取设备产品信息
	 */
	[NfcCommandName.getProductInfo]: {
		name: NfcCommandName.getProductInfo,
		command: () => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}3400000000`, 
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * 写入证书
	 * 因原EM400NB证书指令地址和写入SDI指令地址冲突，故新增，后续建议此为标准写入证书指令
	 */
	[NfcCommandName.writeCertificate]: {
		name: NfcCommandName.writeCertificate,
		command: (data: { password: string, dataSize: number, type: 1 | 2 | 3, mode: number, checkData: number }) =>
			nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}27${nfcConverter.convertNumber(data.dataSize)}0000${nfcConverter.convertPassword(data.password)}0${data.mode}0${data.type}00${nfcConverter.numberToHextStr(data.checkData, 4, true)}`, 
				true
			),
		type: NfcCommandType.write
	},
	/**
	 * 发送命令让设备进入 bootloader，准备差分升级
	 */
	[NfcCommandName.readyPatchUpgrade]: {
		name: NfcCommandName.readyPatchUpgrade,
		command: (data: {password: string}) => nfcConverter.encodeCommand(
			`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}3500000000${nfcConverter.convertPassword(data.password)}000000`, 
			true
		),
		type: NfcCommandType.operate
	},

	/**
	 * 发送差分升级数据
	 */
	[NfcCommandName.sendPatchUpgrade]: {
		name: NfcCommandName.sendPatchUpgrade,
		command: (data: {password: string, dataSize: number, crc?: string, reboot?: boolean}) => {
			const crc = data.crc ?? '00000000';
			//是否需要重启设备（一般只在最后一次差分升级完成后才需要重启）
			const reboot = data.reboot ?? false;
			const payload = reboot ? '0000' : '5a5a';

			return nfcConverter.encodeCommand(
				`${NFC_COMMAND_PREFIX}${NFC_WRITE_PKT}3600000000${nfcConverter.convertPassword(data.password)}00${crc}${nfcConverter.convertNumber(data.dataSize)}${payload}`, 
				true
			);
		},
		type: NfcCommandType.operate
	},

	/**
	 * 读取 D2D Recv Match 值
	 */
	[NfcCommandName.readD2dRecvMatch]: {
		name: NfcCommandName.readD2dRecvMatch,
		command: nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}3100000000`, true),
		type: NfcCommandType.operate
	},

	/**
	 * 采集SNR值
	 */
	[NfcCommandName.collectSNRValue]: {
		name: NfcCommandName.collectSNRValue,
		command: ()=>{
			const command = nfcConverter.encodeCommand(`${NFC_COMMAND_PREFIX}${NFC_READ_PKT}3700000000`, true);	
			return command;
		},
		type: NfcCommandType.operate
	},

	/**
	* 由IPSO协议实现，此处仅作占位
	*/
	[NfcCommandName.clearTVOC]: {
		name: NfcCommandName.clearTVOC,
		command: [],
		type: NfcCommandType.operate
	},

	/**
	 * 功耗测试模式
	 * 无实际命令，由相关动作处理，此处仅作占位
	 */
	[NfcCommandName.powerConsumptionTest]: {
		name: NfcCommandName.powerConsumptionTest,
		command: [],
		type: NfcCommandType.operate
	},

	/**
	 * 电机校准
	 */
	[NfcCommandName.calibrateMotor]: {
		name: NfcCommandName.calibrateMotor,
		command: [],
		type: NfcCommandType.operate
	},

	/**
	* 无实际命令，由相关动作处理，此处仅作占位
	*/
	[NfcCommandName.common]: {
		name: NfcCommandName.common,
		command: [],
		type: NfcCommandType.operate
	},

	/**
	 * 重置设备NFC
	 */
	[NfcCommandName.resetDeviceNfc]: {
		name: NfcCommandName.resetDeviceNfc,
		command: (data: { timeout: number }) => {
			const sendDeviceCommand: number[] = nfcConverter.encodeCommand(`${NFC_SEND_DEVICE_COMMAND}`);
			const testCommandBytes: number[] = [...Buffer.from(`nfc_reset ${data.timeout}`, 'utf8')];
			const commandBytes: number[] = [ ...sendDeviceCommand, ...testCommandBytes ];
			const targetLength = 67;
			const paddingLength = Math.max(0, targetLength - commandBytes.length);
			const paddingBytes: number[] = Array(paddingLength).fill(0);
			const finalCommand: number[] = [ ...commandBytes, ...paddingBytes ];

			return finalCommand;
		},
		type: NfcCommandType.operate
	}
};

/**
 * 用于获取、编码、解码、发送命令
 */
export class NfcCommander {

	commands: Commands;

	nfcProxy: InstanceType<typeof NfcProxy>;

	tracker: INfcTracker;

	logger: LoggerType;

	/**
	 * 检查超时时间
	 */
	checkTimeout = 5000;

	constructor(nfcProxy: InstanceType<typeof NfcProxy>, tracker: INfcTracker) {
		this.nfcProxy = nfcProxy;
		this.commands = commands;
		this.tracker = tracker;
		this.logger = Logger.extend('NfcCommander');
	}

	/**
	 * 根据命令名称、数据返回命令
	 * @param {string} command 
	 * @param {any} data 
	 * @returns {Object} result
	 * @returns {number[]} result.command - 命令的整数数组
	 * @returns {string} result.commandType - 当前命令的类型
	 * @returns {string} result.commandName - 当前命令的名称
	 */
	getCommand<T extends NfcCommandName>(command: T, data?: NfcCommandParam[T]) {
		if(!_.has(NfcCommandName, command) || _.isNil(this.commands[command])) {
			throw new Error(`not support this command ${command}`);
		}

		const cmd = this.commands[command].command;
		const type = this.commands[command].type;
		const name = this.commands[command].name;
		const finalCommand = _.isFunction(cmd) ? cmd(data) : cmd;

		// console.log('command: ', finalCommand);
		// console.log('command hex: ', nfcConverter.decodeCommand(finalCommand));

		return {
			command: finalCommand,
			commandType: type,
			commandName: name
		};
	}

	/**
	 * 检查设备是否可读
	 */
	async checkReadable(checkTimeout = this.checkTimeout, updateProgress = true) {
		const callback = this.createCheckFunc(
			this.commands.readable.command as NfcCommand,
			response => {
				return (_.get(response, '[2]') & 0x29) === 0x29; //hex: 0x29 decimal: 41
			},
			{
				timeout: checkTimeout,
				tag: 'checkReadable'
			}
		);

		try {
			await callback();	
			updateProgress && this.tracker.onProgress();
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 检查设备是否可写
	 */
	async checkWriteable(checkTimeout = this.checkTimeout, updateProgress = true) {
		const callback = this.createCheckFunc(
			this.commands.writeable.command as NfcCommand,
			response => {
				return (_.get(response, '[2]') & 0x21) === 0x21; //hex: 0x21 decimal: 33
			},
			{
				timeout: checkTimeout,
				tag: 'checkWriteable'
			}
		);

		try {
			await callback();
			updateProgress && this.tracker.onProgress();
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 检查写入是否成功
	 */
	async checkWriteSuccess() {
		try {
			const command = this.commands.ack.command as NfcCommand;
			const response = await this.nfcProxy.transceiveCommand(command);

			//正常返回的响应
			//[77, 60, 43, 26, 120, 86, 52, 18, 1, x, ...]
			//交互有问题时，可能会返回异常的响应
			//[54, 54, 54, 54, 54, 54, 0, 0, 0, 0, ...]
			//这里做头部校验，如果是异常的响应，直接抛出错误
			if(Array.isArray(response)) {
				if(_.get(response, [0]) != 77 && _.get(response, [1]) != 60) {
					throw NfcError.ackError;
				}
			}

			if(_.get(response, '[9]') != 0) {
				throw _.get(response, '[9]', 1);
			}

			this.tracker.onProgress();
		
			return Promise.resolve();
		} catch (error) {
			let errorCode = NfcError.writeFailed;

			if(_.isNumber(error)) {
				errorCode = error;
			}

			return Promise.reject(errorCode);
		}
	}

	/**
	 * 校验升级数据
	 * @param password 密码
	 * @param checkData 升级校验数据
	 * @param checkSendCount 是否需要指定发送升级校验数据次数
	 */
	async checkUpgradeData({ password, checkData, checkSendCount, moduleId = 0, reboot = false }:
		{ password: string, checkData: number[], checkSendCount?: number| null, moduleId?: number, reboot?: boolean }
	) {
		try {
			this.logger.debug("check upgrade data");

			const result = await this.sendCommand(NfcCommandName.upgrade, { password, headerSize: checkData.length ,reboot, moduleId});	
			this.logger.debug('upgrade request result: ', result);

			await NfcUtils.sleepWithMS(10);
			const sendDataCount = checkSendCount != null 
				? checkSendCount 
				: this.getSendCount(checkData.length);
			this.logger.debug('sendDataCount: ', sendDataCount);
			for (let index = 0; index < sendDataCount; index++) {
				let sendData = _.slice(checkData, index * 64, index * 64 + 64);
				this.logger.debug('sendData: ', sendData);
	
				if (sendData.length < 64) {
					const filledData = Array(64 - sendData.length).fill(0);
					sendData = sendData.concat(filledData);
				}
				const { command } = this.getCommand(NfcCommandName.checkUpgrade, { data: sendData });
				await this.nfcProxy.transceiveCommand(command);	
				NfcUtils.delay(10);
			}
			await NfcUtils.sleepWithMS(this.nfcProxy.config.afterSendCommandDelay);
			await this.checkReadable();
			const ackResult = await this.getAckDataLength();
			this.logger.debug('ackResult: ', ackResult);

			return Promise.resolve(0);
		} catch (error) {
			if(error === NfcError.inBootloader) {
				this.logger.debug('in bootloader');
				return Promise.reject(NfcError.inBootloader);
			}

			return Promise.reject(error);
		}
	}

	/**
	 * 获取ack数据，可以获得接下来要读取的数据长度/响应数据
	 * @param response 是否需要返回响应数据
	 */
	async getAckDataLength(needResponse?: boolean) {
		try {
			const command = this.commands.ack.command as NfcCommand;
			const response = await this.nfcProxy.transceiveCommand(command);
			const getDataLength = (data: number[]) => {
				const buffer = Buffer.from(data.slice(10, 14));
		
				return buffer.readUInt32LE(0);
			};

			if (_.get(response, '[9]') !== 0) {
				//密码错误
				if(_.get(response, '[9]') === NfcError.wrongPassword) {
					return Promise.reject(NfcError.wrongPassword);
				}
				
				//设备卡在升级bootloader中
				if(_.get(response, '[9]') === NfcError.inBootloader) {
					return Promise.reject(NfcError.inBootloader);
				}

				if(_.get(response, '[9]') === NfcError.collecting) {
					return Promise.reject(NfcError.collecting);
				}
				
				return Promise.reject(NfcError.ackError);
			}

			const dataLength = getDataLength(response);

			this.tracker.onProgress();
			return Promise.resolve(needResponse ? response : dataLength);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送基本命令，如read、write、powerOff、reset等命令
	 * @param command - 命令
	 * @param data - 命令数据
	 * @param response - 是否需要返回响应(默认返回ack结果)
	 */
	async sendCommand<T extends NfcCommandName>(cmdName: T, data?: NfcCommandParam[T], response?: boolean, config?: {
		checkReadableTimeout?: number;
	}) {
		try {
			const { checkReadableTimeout } = config ?? {checkReadableTimeout: this.checkTimeout};
			const { command } = this.getCommand(cmdName, data);
			const transceiveCommandWithCheck = this.createCheckFunc(
				command,
				response => {
					return response.length > 0;
				},
				{
					timeout: this.checkTimeout,
					tag: 'sendCommand',
					shouldIgnoreError: this.shouldIgnoreTransceiveError
				}
			);

			NfcUtils.delay(300);
			this.logger.debug('sendCommand: ', cmdName);
			await this.checkWriteable();
			await transceiveCommandWithCheck();
			await this.checkReadable(checkReadableTimeout);
			const result:any = await this.getAckDataLength(response);
			this.tracker.onProgress();
			this.logger.debug('sendCommand success: ', cmdName);
			return Promise.resolve(result);
		} catch (error) {
			this.logger.error('sendCommand error: ', error);	
			return Promise.reject(error);
		}
	}

	/**
	 * 接收flash数据
	 * @param {Number} dataLength 
	 */
	async receiveFlashData(dataLength: number) {
		try {
			let finalData: number[] = [];
			const sendCount = this.getSendCount(dataLength);
			
			this.logger.debug('receiveData sendCount', sendCount);

			for (let index = 0; index < sendCount; index++) {
				await this.checkReadable();
				const data = await this.nfcProxy.transceiveCommand(this.commands.receiveData.command as NfcCommand);
				this.tracker.onProgress();
				finalData = finalData.concat(data);
			}
			this.logger.debug('receiveFlashData success');
			return Promise.resolve(finalData);
		} catch (error) {
			return Promise.reject(error);
		} 
	}

	async receiveHistoryData(dataLength: number, model: string, firmwareVersion: string, hardwareVersion: string) {
		try {
			let receiveHistoryData: Array<Record<string, any>> = [];
			let isLastFrame = false;
			let receiveHistoryDataSize = 0;
			// 没有数据提前退出，不进行后续读取解析
			if(dataLength === 0) {
				return Promise.resolve({
					receiveHistoryData,
					receiveHistoryDataSize
				});
			}
			
			while(!isLastFrame) {
				this.logger.debug('start receive history data', dataLength);
				const receiveDataSize = await this.sendCommand(NfcCommandName.receiveHistoryData, { action: 2, count: dataLength });
				// 可能出现dataLength（设备内有数据，但不在时间范围）, 1表示时间范围内没有数据
				const CURRENT_TIME_NOT_DATE = 1;
				if(receiveDataSize === CURRENT_TIME_NOT_DATE) {
					return Promise.resolve({
						receiveHistoryData,
						receiveHistoryDataSize
					});
				}
				this.logger.debug('receiveDataSize: ', receiveDataSize);
				const data = await this.receiveFlashData(receiveDataSize);
				//每次都要用实际的数据长度（设备给的数据长度）去解析
				//而不是实际接收到的数据长度（可能会因为64不能整除，而多接受64个字节）
				const slicedData = data.slice(0, receiveDataSize);
				this.logger.debug('slicedData: ', slicedData.length);
				let historyDataJson = '{}';
				try {
					historyDataJson = await DeviceUtils.getHistoryData(slicedData, model, firmwareVersion, hardwareVersion);
				} catch (error) {
					historyDataJson = '{}';
				}
				const parsedData = JSON.parse(historyDataJson);
				const { historyData = [], lastFrame = false } = parsedData || {};
				const availableData = historyData.filter((d: any) => d.timestamp !== '0');
				
				receiveHistoryData = receiveHistoryData.concat(availableData);
				isLastFrame = lastFrame === true;
				receiveHistoryDataSize += slicedData.length;
				this.tracker.onProgress();
			}

			await this.sendCommand(NfcCommandName.receiveHistoryData, { action: 3, count: 0 });
			this.logger.debug('receiveHistoryData: ', receiveHistoryData.length);

			return Promise.resolve({
				receiveHistoryData,
				receiveHistoryDataSize
			});
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送flash数据
	 * @param {number[]} data 
	 */
	async sendFlashData(data: number[] | { dataSize: number; data: number[] }) {
		__DEV__ && TimeCounter.time('sendFlashData');
		const dataSize = _.get(data, 'dataSize', 1030);
		const sendFinalData = nfcConverter.encodeData(_.has(data, 'data') ? _.get(data, 'data') : data);
		const sendDataPrefix = nfcConverter.encodeCommand(NFC_SEND_DEVICE_COMMAND);
		const sendDataCount = this.getSendCount(dataSize);
		this.logger.debug("start send flash data:", dataSize);

		try {
			for (let index = 0; index < sendDataCount; index++) {
				const suffixData = _.slice(sendFinalData, index * 64, index * 64 + 64);
				let transceiveData = sendDataPrefix.concat(suffixData); //A6 F0 FF + DATA

				if (transceiveData.length < 67) {
					const filledData = Array(67 - transceiveData.length).fill(0);
					transceiveData = transceiveData.concat(filledData);
				}

				const transceiveDataWithCheck = this.createCheckFunc(
					transceiveData,
					response => {
						return Array.isArray(response) && response.length > 0;
					},
					{
						timeout: 2000,
						tag: 'sendFlashData',
						shouldIgnoreError: this.shouldIgnoreTransceiveError
					}
				);

				await this.checkWriteable();
				await transceiveDataWithCheck();
				this.tracker.onProgress();
			}
			return Promise.resolve();
		} catch (error) {
			this.logger.error("sendFlashData error", error);
			return Promise.reject(error);
		} finally {
			__DEV__ && TimeCounter.timeEnd('sendFlashData');
		}
	}

	/**
	 * 发送升级镜像数据
	 */
	async sendUpgradeData(upgradeParams: {
		password: string;
		data: number[];
		upgradeDataStartPosition: number;
		reboot?: boolean;
		moduleId?: number;
		checkTimeout?: number;
	}) {
		const { password, data, upgradeDataStartPosition, checkTimeout = this.checkTimeout, reboot = false, moduleId = 0 } = upgradeParams;
		try {
			const { sendUpgradeDataDelay, maxRetries } = this.nfcProxy.config;
			const sendFinalData = _.slice(data, upgradeDataStartPosition); //去掉开头字节的设备信息
			const sendDataPrefix = nfcConverter.encodeCommand(NFC_SEND_DEVICE_COMMAND);
			const sendDataCount = this.getSendCount(data.length - upgradeDataStartPosition); //去掉开头字节的设备信息
			const sendDataWithCount = this.createRunWithCount({
				callback: async transceiveData => {
					try {
						await this.nfcProxy.transceiveCommand(transceiveData);
						return Promise.resolve();
					} catch (error) {
						if(this.shouldIgnoreTransceiveError(error)) {
							return Promise.resolve();
						}

						return Promise.reject(error);
					}
				},
				allCount: maxRetries
			});
			//快速检查是否可写，省略了检查超时，更新进度条的步骤，只做4次检查
			const quickCheckWriteable = this.createRunWithCount({
				callback: async () => {
					try {
						const response = await this.nfcProxy.transceiveCommand(this.commands.writeable.command as NfcCommand);
						if((_.get(response, '[2]') & 0x21) === 33) {
							return Promise.resolve(response);
						}

						return Promise.reject(response);
					} catch (error) {
						return Promise.reject(error);
					}
				},
				checkCondition: () => true,
				errorHandler: async () => {
					NfcUtils.delay(1);
					return Promise.resolve();
				},
				allCount: 4
			});

			const response = await this.sendCommand(NfcCommandName.upgradeDataSize, {
				data,
				password,
				upgradeDataStartPosition,
				reboot,
				moduleId
			}, true);
			//是否支持快速升级
			const isSupportFastUpgrade = _.get(response, '[62]') === 0xaa;
			this.logger.debug('is support fast upgrade: ', isSupportFastUpgrade);
			this.logger.debug('send upgrade data');

			for (let index = 0; index < sendDataCount; index++) {
				const suffixData = _.slice(sendFinalData, index * 64, index * 64 + 64);
				let transceiveData = sendDataPrefix.concat(suffixData); //A6 F0 FF + DATA
	
				if (transceiveData.length < 67) {
					const filledData = Array(67 - transceiveData.length).fill(0);
					transceiveData = transceiveData.concat(filledData);
				}
				
				//每发送2K的数据就要等待设备处理
				if(index > 0 && index * 64 % 2048 === 0) {
					await NfcUtils.sleepWithMS(sendUpgradeDataDelay);
					this.tracker.onProgress();
				}

				if(isSupportFastUpgrade) { //如果支持快速升级，则不需要检查是否可写
					await sendDataWithCount(transceiveData);
					//异步的延时可能延时不准确，所以这里使用同步的延时
					NfcUtils.delay(10);
				} else if (checkTimeout > this.checkTimeout) { //如果检查超时时间较大，则需要使用默认的检查是否可写的方法
					await this.checkWriteable(checkTimeout, false);
					await sendDataWithCount(transceiveData);
				} else { //如果检查超时时间较小，则使用快速检查是否可写的方法
					await quickCheckWriteable();
					await sendDataWithCount(transceiveData);
				}
			}

			await NfcUtils.sleepWithMS(10);
			await this.checkReadable(checkTimeout);
			await this.checkWriteSuccess();
			this.logger.debug('send upgrade data success');

			return Promise.resolve();
		} catch (error) {
			this.logger.error("sendUpgradeData error", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 读取卡数据长度
	 */
	async getCardDataLength() {
		try {
			const { command } = this.getCommand(NfcCommandName.readCardPage);
			const response = await this.nfcProxy.transceiveCommand(command); 
			const buffer = Buffer.from(response.slice(0, 2).reverse());//前两个字节才是数据长度，且小端需要反转
			const hexStr = '0x' + buffer.toString('hex');
			let dataLength = Number(hexStr); //密文长度
			this.logger.debug('before dataLength: ', dataLength);

			if(dataLength === 0) {
				return Promise.reject(NfcError.cardDataLengthError);
			}

			//转换为读所有数据（包括明文和密文）
			if(dataLength % 16) {
				dataLength = dataLength + (16 - dataLength % 16);
			}
			dataLength = dataLength + 128;
			dataLength += 8;

			this.logger.debug('读取数据长度', dataLength);
			this.tracker.onProgress();

			if(dataLength > 4096) {
				return Promise.reject(NfcError.cardDataLengthError);
			}

			return Promise.resolve(dataLength);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 读取nfc卡的数据
	 * @param {number} dataLength - 卡数据长度
	 */
	async readCardData(dataLength: number) {
		try {
			const maxAddressStep = 60; //一次读取支持的最大页数，超过就容易失败
			const firstStep = maxAddressStep;
			const firstStartAddress = 4; //new card mode 第一块地址
			// const firstStartAddress = 6; //old 第一块地址
			const firstEndAddress =  223; //第一块结束地址
			const firstChunkSize = 872; //第一块数据容量
			const firstSendCount = Math.ceil((firstEndAddress - firstStartAddress) / firstStep); 
			let data: number[] = [];

			//切换到第一块
			//(避免出现写入之前的读取会切换到第二块后，如果没有再切回第一块，导致写入失效的问题)
			const { command: startSwitchCardSectionCommand } = this.getCommand(NfcCommandName.startSwitchCardSection);
			const { command: switchCardSectionCommand } = this.getCommand(NfcCommandName.switchCardSection, { cardSetion: 0 });

			await this.nfcProxy.transceiveCommand(startSwitchCardSectionCommand);
			try { //android因为没有返回数据内容(ios返回空数组)，导致nfcmanger认为它是失败的，这里做一个兼容处理
				await this.nfcProxy.transceiveCommand(switchCardSectionCommand);
			} catch (error) {
				this.logger.debug('switchCardSectionCommand error', error);
			}

			//读取第一块的内容
			for (let index = 0; index < firstSendCount; index++) {
				const offset = index * 1;
				const start = firstStartAddress + firstStep * index + offset;
				const end = start + firstStep > firstEndAddress 
					? firstEndAddress 
					: start + firstStep;
				const { command } = this.getCommand(NfcCommandName.readCard, { startAddress: start, endAddress: end });
				const response = await this.nfcProxy.transceiveCommand(command);

				data = data.concat(response);
				this.tracker.onProgress();
			}

			if(dataLength > firstChunkSize) {
				const secondStartAddress = 0;
				//第二块结束地址，每一页只能存储4字节，所以需要得到剩下第二块的数据长度，然后再去与开始地址进行偏移
				const secondEndAddress = secondStartAddress + Math.ceil((dataLength - firstChunkSize) / 4);
				const secondStep = secondEndAddress - secondStartAddress > maxAddressStep 
					? maxAddressStep 
					: secondEndAddress - secondStartAddress;
				const secondSendCount = Math.ceil((secondEndAddress - secondStartAddress) / secondStep);
				//切换到第二块
				const { command: startSwitchCardSectionCommand } = this.getCommand(NfcCommandName.startSwitchCardSection);
				const { command: switchCardSectionCommand } = this.getCommand(NfcCommandName.switchCardSection, { cardSetion: 1 });

				await this.nfcProxy.transceiveCommand(startSwitchCardSectionCommand);
				try { //android因为没有返回数据内容(ios返回空数组)，导致nfcmanger认为它是失败的，这里做一个兼容处理
					await this.nfcProxy.transceiveCommand(switchCardSectionCommand);
				} catch (error) {
					this.logger.debug('switchCardSectionCommand error', error);
				}
				
				//校验密码
				const { command: checkPasswordCommand } = this.getCommand(NfcCommandName.checkCardPassword);
				const checkPasswordResponse = await this.nfcProxy.transceiveCommand(checkPasswordCommand);

				if(!_.isEqual(checkPasswordResponse, [ 79, 75 ])) {
					return Promise.reject(NfcError.wrongPassword);
				}

				this.tracker.onProgress();

				//读取第二块的内容
				for (let index = 0; index < secondSendCount; index++) {
					const offset = index * 1;
					const start = secondStartAddress + secondStep * index + offset;
					const end = start + secondStep > secondEndAddress 
						? secondEndAddress 
						: start + secondStep;
					const { command } = this.getCommand(NfcCommandName.readCard, { startAddress: start, endAddress: end });
					const response = await this.nfcProxy.transceiveCommand(command);

					if(_.isEqual(response, [0])) {
						return Promise.reject(NfcError.sendFailed);
					}

					data = data.concat(response);
					this.tracker.onProgress();
				}
			}

			const cardData = data.slice(0, dataLength);
			this.logger.debug('读取成功', cardData.length);
			return Promise.resolve(cardData);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送卡数据
	 * @param data 卡数据
	 */
	async sendCardData(data: number[]) {
		try {
			const chunkedData = _.chunk(data, 4);  
			const firstChunkStart = 4;
			const firstChunkEnd = data.length > 872 
				? 224
				: Math.ceil(data.length / 4) + firstChunkStart;
			const firstChunkDataCount = firstChunkEnd - firstChunkStart;
			const firstChunkSize = 872;
			const commandPrefix = nfcConverter.hexStrToDecimalArr(NFC_WRITE_CARD_DATA_COMMAND); //A2

			//校验密码
			const { command: checkPasswordCommand } = this.getCommand(NfcCommandName.checkCardPassword);
			const checkPasswordResponse = await this.nfcProxy.transceiveCommand(checkPasswordCommand);

			if(!_.isEqual(checkPasswordResponse, [ 79, 75 ])) {
				return Promise.reject(NfcError.wrongPassword);
			}

			//切到第一块
			//(避免出现写入之前的读取会切换到第二块后，如果没有再切回第一块，导致写入失效的问题)
			const { command: startSwitchCardSectionCommand } = this.getCommand(NfcCommandName.startSwitchCardSection);
			const { command: switchCardSectionCommand } = this.getCommand(NfcCommandName.switchCardSection, { cardSetion: 0 });
			
			await this.nfcProxy.transceiveCommand(startSwitchCardSectionCommand);

			try { //android因为没有返回数据内容(ios返回空数组)，导致nfcmanger认为它是失败的，这里做一个兼容处理
				await this.nfcProxy.transceiveCommand(switchCardSectionCommand);
			} catch (error) {
				this.logger.debug('switchResponse error', error);
			}

			for (let index = 0; index < firstChunkDataCount; index++) {
				const pageSizeCommand = [index + firstChunkStart];
				let chunkData = commandPrefix.concat(pageSizeCommand).concat(chunkedData[index]!);

				//兼容到最后取不到值的情况，发送数据默认填充0
				if(!_.isArray(chunkData)) {
					chunkData = [ 162, 90, 0, 0, 0, 0 ];
				} else if (chunkData.length < 6) {
					chunkData = chunkData.concat(_.fill(Array(6 - chunkData.length), 0));
				}
				
				const response = await this.nfcProxy.transceiveCommand(chunkData);

				if(!_.isEqual(response, [10])) {
					return Promise.reject(NfcError.sendFailed);
				}

				this.tracker.onProgress();
			}

			this.tracker.onProgress();
			
			//如果数据大小超过第一块，则再切换到第二块写入
			if(data.length > firstChunkSize) {
				//切换到第二块
				const secondChunkStart = 0;
				const secondChunkEnd = Math.ceil((data.length - firstChunkSize) / 4);
				const secondChunDataCount = secondChunkEnd - secondChunkStart;
				const { command: startSwitchCardSectionCommand } = this.getCommand(NfcCommandName.startSwitchCardSection);
				const { command: switchCardSectionCommand } = this.getCommand(NfcCommandName.switchCardSection, { cardSetion: 1 });
				
				await this.nfcProxy.transceiveCommand(startSwitchCardSectionCommand);

				try { //android因为没有返回数据内容(ios返回空数组)，导致nfcmanger认为它是失败的，这里做一个兼容处理
					await this.nfcProxy.transceiveCommand(switchCardSectionCommand);
				} catch (error) {
					this.logger.debug('switchResponse error', error);
				}

				//校验密码
				const checkPassword2Response = await this.nfcProxy.transceiveCommand(checkPasswordCommand);

				if(!_.isEqual(checkPassword2Response, [ 79, 75 ])) {
					return Promise.reject(NfcError.wrongPassword);
				}
				this.tracker.onProgress();

				for (let index = 0; index < secondChunDataCount; index++) {
					const pageSizeCommand = [index + secondChunkStart];
					let chunkData = chunkedData[firstChunkDataCount + index];

					//兼容到最后取不到值的情况，发送数据默认填充0
					if(!_.isArray(chunkData)) {
						chunkData = [ 0, 0, 0, 0 ];
					} else if (chunkData.length < 4) {
						chunkData = chunkData.concat(_.fill(Array(4 - chunkData.length), 0));
					}
					
					const sendData = commandPrefix.concat(pageSizeCommand).concat(chunkData);
					const response = await this.nfcProxy.transceiveCommand(sendData);
					
					if(!_.isEqual(response, [10])) {
						return Promise.reject(NfcError.sendFailed);
					}

					this.tracker.onProgress();
				}
			}

			return Promise.resolve(1);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送图片数据
	 * @param data 图片数据
	 */
	async sendImgData(data: number[]) {
		const { sendDataDelay, maxRetries } = this.nfcProxy.config;
		const dataSize = _.get(data, 'length', 1070);
		const sendDataPrefix = nfcConverter.encodeCommand(NFC_SEND_DEVICE_COMMAND);
		const sendDataCount = this.getSendCount(dataSize);
		const sendDataWithCount = this.createRunWithCount({
			callback: async transceiveData => {
				try {
					await this.nfcProxy.transceiveCommand(transceiveData);
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			}, 
			allCount: maxRetries
		});

		try {
			for (let index = 0; index < sendDataCount; index++) {
				const suffixData = _.slice(data, index * 64, index * 64 + 64);
				let transceiveData = sendDataPrefix.concat(suffixData); //A6 F0 FF + DATA
	
				if (transceiveData.length < 67) {
					const filledData = Array(67 - transceiveData.length).fill(0);
					transceiveData = transceiveData.concat(filledData);
				}
				
				await this.checkWriteable();
				await NfcUtils.sleepWithMS(sendDataDelay);
				await sendDataWithCount(transceiveData);
				this.tracker.onProgress();
			}

			return Promise.resolve();
		} catch (error) {
			this.logger.debug(`sendImgData: ${error}`);
			return Promise.reject(error);
		}
	}

	async setDS3604Picture(img: {width: number, height: number, data: number[]}) {
		const header = nfcConverter.encodeCommand(`aa55${NFC_VERSION}00000000${_.padEnd(nfcConverter.convertNumber(img.width), 4, '0')}${_.padEnd(nfcConverter.convertNumber(img.height), 4, '0')}${_.padEnd(nfcConverter.convertNumber(img.data.length), 4, '0')}`);
		const imageData = header.concat(img.data);
		const newData:number[] = await DeviceUtils.setDS3604Picture(imageData);
		return newData;
	}

	/**
	 * 发送图片数据
	 * @param data 图片数据
	 */
	async sendTempImgData(data: number[]) {
		const { sendDataDelay, maxRetries } = this.nfcProxy.config;
		const dataSize = _.get(data, 'length', 1070);
		const sendDataPrefix = nfcConverter.encodeCommand(`${NFC_SEND_DEVICE_COMMAND}`);		
		const sendDataCount = this.getSendCount(dataSize);
		const sendDataWithCount = this.createRunWithCount({
			callback: async transceiveData => {
				try {
					await this.nfcProxy.transceiveCommand(transceiveData);
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			}, 
			allCount: maxRetries
		});

		try {
			for (let index = 0; index < sendDataCount; index++) {
				const suffixData = _.slice(data, index * 64, index * 64 + 64);
				let transceiveData = sendDataPrefix.concat(suffixData); //A6 F0 FF + DATA
	
				if (transceiveData.length < 67) {
					const filledData = Array(67 - transceiveData.length).fill(0);
					transceiveData = transceiveData.concat(filledData);
				}
				
				await this.checkWriteable();
				await NfcUtils.sleepWithMS(sendDataDelay);
				await sendDataWithCount(transceiveData);
				this.tracker.onProgress();
			}
			return Promise.resolve();
		} catch (error) {
			this.logger.debug(`sendImgData: ${error}`);
			return Promise.reject(error);
		}
	}

	/**
	 * 发送命令让设备进入 bootloader，准备差分升级
	 * @param password 密码
	 * @returns 
	 */
	async readyPatchUpgrade(password: string) {
		try {
			await this.sendCommand(NfcCommandName.readyPatchUpgrade, { password });

			return Promise.resolve({
				inBootloader: false
			});
		} catch (error) {
			if(error === NfcError.inBootloader) {
				return Promise.resolve({
					inBootloader: true
				});
			}

			//如果是ackError（设备不支持差分升级）或者发送失败，则认为其是准备升级失败，用于显示错误信息
			if(error === NfcError.ackError || this.checkIsTransceiveFail(error as any)) {
				return Promise.reject(NfcError.upgradeCheckFailed);
			}

			return Promise.reject(error);
		}
	}

	/**
	 * 发送差分升级数据
	 */
	async sendPatchUpgradeData(data: number[], password: string, crc: string, reboot?: boolean) {
		try {
			this.logger.debug("send patch upgrade command");
			await this.sendCommand(NfcCommandName.sendPatchUpgrade, { dataSize: data.length, password, crc, reboot });
			this.logger.debug('send patch upgrade data command success');

			await this.sendFlashData({
				data,
				dataSize: data.length
			});
			await NfcUtils.sleepWithMS(10);
			await this.checkReadable();
			await this.checkWriteSuccess();
			this.logger.info('send patch upgrade data success');

			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 检查是否是准备好继续升级
	 */
	async checkIsReadyUpgrade() {
		const checkCount = this.createRunWithCount({
			callback: async () => {
				try {
					this.logger.debug("send get upgrade info");
					const dataLength = await this.sendCommand(NfcCommandName.getProductInfo);
					const data = await this.receiveFlashData(dataLength);

					return data;
				} catch (error) {
					return Promise.reject(error);
				}
			},
			allCount: 5,
			checkCondition() {
				return true;
			},
			errorHandler: async() => {
				await NfcUtils.delay(500);
				return Promise.resolve();
			}
		});

		try {
			const checkResult = await checkCount();	
			this.logger.debug("checkIsReadyUpgrade checkResult:", checkResult);
			return Promise.resolve();
		} catch (error) {
			this.logger.error("checkIsReadyUpgrade error:", error);
			return Promise.reject(error);
		}
	}

	async sendResetDeviceNfc(timeout: number) {
		try {
			const { command } = this.getCommand(NfcCommandName.resetDeviceNfc, {timeout});
			const transceiveCommandWithCheck = this.createCheckFunc(
				command,
				() => {
					//设备支持与不支持该调试命令，response都是返回[10]
					//所以这里无需进行判断
					return true;
				},
				{
					tag: 'sendResetDeviceNfc',
					timeout: 1000,
					shouldIgnoreError: this.shouldIgnoreTransceiveError
				}
			);

			await this.checkWriteable(1000);
			await transceiveCommandWithCheck();
			return Promise.resolve();
		} catch (error) {
			this.logger.error('sendResetDeviceNfc error:', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 检查是否是发送命令失败
	 * @param {any} error 
	 */
	checkIsTransceiveFail(error: string) {
		return _.includes(error, 'transceive fail');
	}

	/**
	 * 根据数据长度判断需要发送多少次命令
	 * @param dataLength - 数据长度
	 */
	getSendCount(dataLength: number) {
		return Math.ceil(dataLength / 64);
	}

	/**
	 * 创建一个检查nfc命令是否发送成功的函数
	 * @param command - 要发送的命令
	 * @param checkCondition - 检查条件的函数
	 * @param timeout - 超时时间
	 * @param tag - 标签
	 * @param options - 选项
	 */
	private createCheckFunc(
		command: NfcCommand,
		checkCondition: (data: number[]) => boolean,
		options?: {
			timeout?: number,
			tag?: string,
			shouldIgnoreError?: (error: any) => boolean,
			retryDelay?: number,
		}
	): () => Promise<number[] | undefined> {
		const {
			timeout = this.checkTimeout,
			tag = 'createCheckFunc',
			retryDelay = 50,
			shouldIgnoreError = () => false,
		} = options ?? {};

		return async () => {
			let isOk = false;
			let response: number[] | undefined;
			const startTime = new Date().getTime();

			while (!isOk) {
				try {
					const currentTime = new Date().getTime();

					if (currentTime - startTime > timeout) {
						this.logger.error(`${tag} | timeout:`, timeout);
						return Promise.reject(NfcError.timeout);
					}

					response = await this.nfcProxy.transceiveCommand(command);
					isOk = checkCondition(response);
				} catch (error) {
					NfcUtils.delay(retryDelay);

					if (shouldIgnoreError(error)) {
						break;
					} else {
						this.logger.error(`${tag} | transceive command error:`, error);
						return Promise.reject(error);
					}
				}
			}

			return Promise.resolve(response);
		};
	}

	/**
	* 创建一个在某个条件下，重复执行指定次数的函数
	* @param {Object} config - 配置
	* @param {function} config.callback - 要运行的回调函数 
	* @param {function} [config.checkCondition] - 检查条件的函数
	* @param {number} [config.allCount=4] - 重复执行次数
	* @param {function} [config.errorHandler] - 错误处理函数
	*/
	private createRunWithCount({
		callback, 
		checkCondition = this.checkIsTransceiveFail, 
		allCount = 4, 
		errorHandler
	}: { 
		callback: (...args: any[]) => Promise<any>; 
		checkCondition?: (error: any) => boolean; 
		allCount?: number; 
		errorHandler?: () => Promise<any> 
	}) {
		return async function runWithCount(...argument: any[]) {
			let count = 0;

			async function runFunc(): Promise<any> {
				try {
					const response = await callback(...argument);
					return Promise.resolve(response);
				} catch (error) {
					if(count < allCount && checkCondition(error)) {
						count += 1;

						if(_.isFunction(errorHandler)) {
							await errorHandler();
						}

						return runFunc();
					}
		
					if(count > allCount) {
						count = 0;
					}
		
					return Promise.reject(error);
				}
			}
		
			try {
				const result = await runFunc();
				return Promise.resolve(result);
			} catch (error) {
				return Promise.reject(error);
			}
		};
	}

	/**
	 * 是否忽略传输错误
	 */
	private shouldIgnoreTransceiveError(error: any) {
		return shouldIgnoreTransceiveFail(error);
	}
}

export default NfcCommander;