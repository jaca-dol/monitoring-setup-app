import { Platform } from 'react-native';

import _ from 'lodash';

import Logger, { LoggerType } from '../../utils/logger';
import { retry } from '../../utils/util';

import { TimeCounter } from '../../utils/counter';
import NfcUtils from './NfcUtils';
import { Ndef, Nfc, NfcCommand, NfcError, NfcEvents, NfcProxyConfig, NfcState, NfcTag, NfcTech } from './types';

const NfcDebug = false;

export const defaultNfcProxyConfig: NfcProxyConfig = {
	debug: NfcDebug,
	maxRetries: 1,
	transceiveTimeout: 1200,
	sendCommandDelay: NfcDebug ? 1500 : 500,
	afterSendCommandDelay: NfcDebug ? 1355 : 250,
	afterSendDataDelay: NfcDebug ? 1455 : 200,
	registerDelay: 2000,
	sendDataDelay: 3,
	sendUpgradeDataDelay: 100,
	mode: 'p2p',
	autoResetDeviceNfc: {
		enable: false,
		timeout: 6000
	}
};

export class NfcProxy {
	nfc: Nfc;

	/**
	 * 卡信息
	 */
	tag: {
		/**
		 * 卡UID
		 */
		id: string;

		/**
		 * NFC芯片类型
		 * @description NT3H2111 常用的类型，在大部分设备上使用
		 * @description FM17660K 目前仅在UC711等设备使用
		 */
		type: 'NT3H2111' | 'FM17660K' | 'unknown';

		/**
		 * iOS特有
		 */
		tech?: NfcTech;

		/**
		 * Android特有
		 */
		techTypes?: NfcTech[];
	} | null;

	tech: NfcTech;

	tagDiscovertyListener: any;

	config: NfcProxyConfig;

	state: NfcState = NfcState.initial;

	/**
	 * 会话开始时间（时间戳（毫秒））
	 */
	sessionStartTime: number | null;

	/**
	 * 会话结束时间（时间戳（毫秒））
	 */
	sessionEndTime: number | null;

	/**
	 * 会话持续时间（秒）
	 */
	sessionDuration: number | null;

	/**
	 * 会话超时时间(秒)
	 */
	sessionTimeout: number;

	/**
	 * 上一次重新开启会话的时间（时间戳（毫秒））
	 */
	restartSessionLastTime: number | null;

	/**
	 * 是否会话重启时间较长
	 */
	isLongRestartDetectionTime: boolean;

	logger: LoggerType;

	constructor(nfc: Nfc, config?: Partial<NfcProxyConfig>) {
		this.config =  _.merge(_.cloneDeep(defaultNfcProxyConfig), config);
		this.nfc = nfc;
		this.tech = NfcTech.NfcA;
		this.tag = null;
		this.sessionStartTime = null;
		this.sessionEndTime = null;
		this.sessionDuration = null;
		this.restartSessionLastTime = null;
		//iOS的session超时时间为20秒（iOS系统限制）
		//Android的session超时时间为30分钟（Android系统未限制，自定义的参数）
		this.sessionTimeout = Platform.OS === 'ios' ? 20 : 30 * 60;
		this.isLongRestartDetectionTime = false;
		this.logger = Logger.extend('NfcProxy');

		this.nfc.start();
	}

	/**
	 * 获取nfc设置
	 */
	getConfig() {
		return this.config;
	}

	/**
	 * 设置proxy配置
	 */
	setConfig(config: Partial<NfcProxyConfig>) {
		this.config = _.merge(this.config, config);
	}

	/**
	 * 重置nfc配置
	 */
	resetConfig() {
		this.config = _.cloneDeep(defaultNfcProxyConfig);
	}


	/**
	 * 获取当前监听函数
	 */
	getTagDiscoveryListener() {
		return this.tagDiscovertyListener;
	}

	/**
	 * 获取NFC芯片类型
	 * 根据UID第一个字节的制造商ID判断芯片类型
	 */
	getTagType(id: string) {
		if(id.startsWith('04')) {
			return 'NT3H2111';
		}

		if(id.startsWith('1D')) {
			return 'FM17660K';
		}

		return 'unknown';
	}

	/**
	 * 监听NFC相关事件
	 */
	addNfcEventListener(eventName: NfcEvents, callback: (...args: any[]) => void) {
		this.nfc.setEventListener(eventName, (...args: any[]) => {
			callback(...args);

			if(eventName === NfcEvents.SessionClosed) {
				this.sessionEndTime = Date.now();
				this.sessionDuration = this.sessionStartTime && (this.sessionEndTime - this.sessionStartTime) / 1000;
				this.logger.debug(`session closed, session duration ${this.sessionDuration}s`);
			}

			this.nfc.setEventListener(eventName, null);
		});
	}

	/**
	 * 开始检测芯片
	 */
	async startDetection(tech: NfcTech, alertMessage: string) {
		try {
			await this.nfc.cancelTechnologyRequest();
			this.logger.debug('start detection');

			this.tech = tech;
			this.sessionStartTime = Date.now();

			//@ts-ignore
			await this.nfc.requestTechnology(tech, {
				alertMessage
			});

			this.tag = await this.nfc.getTag();
			this.logger.debug("detection tag", this.tag);

			return Promise.resolve(this.tag);
		} catch (error: any) { 
			return Promise.reject(this.handleErrorMessage('startDetection', error));
		}
	}

	/**
	 * 停止检测芯片
	 * @param waitForSessionClose - 是否等待session关闭(仅适用于iOS)
	 */
	async stopDetection(waitForSessionClose?: boolean): Promise<void> {
		try {
			await this.nfc.cancelTechnologyRequest();
			this.tag = null;
			this.logger.debug('stop detection');

			if (Platform.OS === 'ios' && waitForSessionClose) {
				return new Promise(resolve => {
					this.addNfcEventListener(NfcEvents.SessionClosed, () => {
						resolve();
					});
				});
			}

			return Promise.resolve();
		} catch (error: any) {
			return Promise.reject(this.handleErrorMessage('stopDetection', error));
		}
	}

	/**
	 * 重新开始检测芯片
	 * 通常只用于iOS的特殊场景
	 */
	async restartDetection(alertMessage: string, tech = this.tech) {
		try {
			TimeCounter.time('restartDetection');
			let restartDetectionAttempts = 0;

			await retry({
				fn: async () => {
					try {
						restartDetectionAttempts++;
						await this.stopDetection();

						//需要延迟一段时间，否则在部分机型会出现system busy的错误
						Platform.OS === 'ios' && NfcUtils.delay(3500);

						await this.startDetection(tech, alertMessage);

						return Promise.resolve();
					} catch (error) {
						return Promise.reject(error);
					}
				},
				maxRetries: 10,
				retryInterval: 100,
				tag: 'restartDetection'
			});
			this.restartSessionLastTime = Date.now();
			const endTime = TimeCounter.timeEnd('restartDetection') ?? 0;
			const restartDetectionDuration = endTime / 1000;
			//如果会话重启时间较长超过7秒，则认为会话重启时间较长
			this.isLongRestartDetectionTime = restartDetectionDuration > 7;

			return Promise.resolve({
				restartDetectionAttempts,
				restartDetectionDuration,
				isLongRestartDetectionTime: this.isLongRestartDetectionTime
			});
		} catch (error: any) {
			TimeCounter.timeEnd('restartDetection');
			return Promise.reject(this.handleErrorMessage('restartDetection', error));
		}
	}

	/**
	 * 读取tag
	 */
	async readTag() {
		try {
			await this.nfc.requestTechnology(NfcTech.Ndef);

			this.tag = await this.nfc.getTag();

			if(this.tag?.id) {
				this.tag.type = this.getTagType(this.tag.id);
			}

			return Promise.resolve(this.tag);
		} catch (err: any) {
			return Promise.reject(this.handleErrorMessage('readTag', err));
		}
	}


	readNdef(): Promise<NfcTag | void> {
		const cleanUp = () => {
			this.nfc.setEventListener(NfcEvents.DiscoverTag, null);
			this.nfc.setEventListener(NfcEvents.SessionClosed, null);
		};
	
		return new Promise(resolve => {
			let tagFound: NfcTag | null = null;
	
			this.nfc.setEventListener(NfcEvents.DiscoverTag, (tag: NfcTag) => {
				tagFound = tag;
				resolve(tagFound);
				this.nfc.unregisterTagEvent().catch(() => 0);
			});
	
			this.nfc.setEventListener(NfcEvents.SessionClosed, () => {
				cleanUp();
				if (!tagFound) {
					resolve();
				}
			});
	
			this.nfc.registerTagEvent();
		});
	}

	async writeNdef({type, value, alertMessage}: {type: string; value: any; alertMessage?: string}) {
		let result = false;
		try {
			//@ts-ignore
			await this.nfc.requestTechnology(NfcTech.Ndef, {
				alertMessage: alertMessage || 'Ready to write some NDEF'
			});

			let bytes: any = [];
			if (type === 'TEXT') {
				bytes = Ndef.encodeMessage([Ndef.textRecord(value)]);
			} else if (type === 'URI') {
				bytes = Ndef.encodeMessage([Ndef.uriRecord(value)]);
			} else if (type === 'WIFI_SIMPLE') {
				bytes = Ndef.encodeMessage([Ndef.wifiSimpleRecord(value)]);
			}

			const message = bytes.map((b: number) => b);

			if (bytes) {
				await this.nfc.writeNdefMessage(message);

				return Promise.resolve();
			}

			result = true;
		} catch (ex) {
			this.logger.error(ex);
		}

		this.abort();
		return result;
	}

	/**
	 * 发送命令
	 * @param command - 命令
	 */
	async transceiveCommand(command: NfcCommand) {
		try {
			const result = await this.nfc.transceiveCommand(command);
			return Promise.resolve(result);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 检查设备是否支持NFC
	 */
	async isSupport() {
		try {
			const isSupport = await this.nfc.isSupported();

			return Promise.resolve(isSupport);
		} catch (error) {

			return Promise.reject(false);
		}
	}

	/**
	 * 检查NFC是否启用
	 */
	async isEnabled() {
		try {
			const isEnabled = await this.nfc.isEnabled();
			

			return Promise.resolve(isEnabled);
		} catch (error) {

			return Promise.reject(error);
		}
	}

	/**
	 * 跳转到nfc设置
	 */
	async goToNfcSetting() {
		return this.nfc.goToNfcSetting();
	}

	async abort() {
		this.nfc.unregisterTagEvent().catch(() => 0);
		this.nfc.cancelTechnologyRequest().catch(() => 0);
	}

	/**
	 * 处理错误信息
	 * @param {string} callFuncName - 错误发生的函数
	 * @param {string} error - 错误信息
	 */
	handleErrorMessage(callFuncName: string, error: string | number) {
		let errorMessage = error;

		if(_.isNumber(error)) {
			return errorMessage;
		}

		if(_.isError(error)) {
			errorMessage = error.message;
		}

		//iOS错误代码对照链接：https://developer.apple.com/documentation/corenfc/nfcreadererror/code
		if(_.isString(error) && error.indexOf('NFCError') != -1) {
			switch (error) {
				case 'NFCError:100':
					errorMessage = NfcError.tagConnectionLost;
					break;
				case 'NFCError:101':
					errorMessage = NfcError.retryExceeded;
					break;
				case 'NFCError:102':
					errorMessage = NfcError.tagResponseError;
					break;
				case 'NFCError:103':
					errorMessage = NfcError.sessionInvalidated;
					break;
				case 'NFCError:104':
					errorMessage = NfcError.tagNotConnected;
					break;
				case 'NFCError:105':
					errorMessage = NfcError.packetTooLong;
					break;
				case 'NFCError:200':
					errorMessage = NfcError.detectionCancelled;
					break;
				case 'NFCError:201':
					errorMessage = NfcError.sessionTimeout;
					break;
				case 'NFCError:202':
					errorMessage = NfcError.terminatedUnexpectedly;
					break;
				case 'NFCError:203':
					errorMessage = NfcError.systemBusy;
					break;
				default:
					errorMessage = error;
					break;
			}

			return errorMessage;
		} 
		
		if(error === 'cancelled') {
			return NfcError.detectionCancelled;
		}
		
		if(error === 'duplicate tech request, please call cancelTechnologyRequest to cancel previous one') {
			return NfcError.duplicateRequest;
		}

		return `${callFuncName} -> ${errorMessage}`;
	}
}