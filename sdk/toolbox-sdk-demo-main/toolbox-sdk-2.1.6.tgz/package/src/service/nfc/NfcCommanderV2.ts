import { Buffer } from 'buffer';

import Logger, { LoggerType } from '../../utils/logger';
import { shouldIgnoreTransceiveFail } from './NfcCompatibility';
import { NfcProxy } from './NfcProxy';
import NfcUtils from './NfcUtils';
import { INfcProtocol, INfcTracker, NfcCommand, NfcError } from './types';

export class NfcCommanderV2 {
	nfcProxy: InstanceType<typeof NfcProxy>;
	
	nfcProtocol: INfcProtocol;

	tracker: INfcTracker;
	
	logger: LoggerType;

	/**
	 * 检查超时时间
	 */
	checkTimeout = 5000;

	constructor(nfcProxy: InstanceType<typeof NfcProxy>, nfcTracker: INfcTracker, nfcProtocol: INfcProtocol) {
		this.nfcProxy = nfcProxy;
		this.tracker = nfcTracker;
		this.nfcProtocol = nfcProtocol;
		this.logger = Logger.extend('NfcCommanderV2');
	}

	/**
	 * 检查NFC是否可读
	 */
	async checkReadable(params?: {checkTimeout?: number; updateProgress?: boolean;}) {
		const { checkTimeout, updateProgress } = Object.assign({}, { checkTimeout: this.checkTimeout, updateProgress: true }, params);
		const callback = this.createCheckFunc(
			this.nfcProtocol.encodeNfcStatusCheckRequest(),
			response => {
				const decodeResult = this.nfcProtocol.decodeNfcStatusCheckResponse(response);

				return decodeResult === 'readable';
			},
			{
				timeout: checkTimeout,
				tag: 'checkReadable'
			}
		);
	
		try {
			await callback();	
			updateProgress && this.tracker.onProgress();
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}
	
	/**
	* 检查NFC是否可写
	*/
	async checkWriteable(params?: {checkTimeout?: number;updateProgress?: boolean;}) {
		const { checkTimeout, updateProgress } = Object.assign({}, { checkTimeout: this.checkTimeout, updateProgress: true }, params);
		const callback = this.createCheckFunc(
			this.nfcProtocol.encodeNfcStatusCheckRequest(),
			response => {
				const decodeResult = this.nfcProtocol.decodeNfcStatusCheckResponse(response);

				return decodeResult === 'writeable';
			},
			{
				timeout: checkTimeout,
				tag: 'checkWriteable'
			}
		);
	
		try {
			await callback();
			updateProgress && this.tracker.onProgress();
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送数据并接收响应(一帧数据)
	 * @param {number[]} data - 要发送的数据
	 * @param {object} options - 发送选项
	 */
	async send(data: number[], options?: {
		/**
		 * 钩子
		 */
		hooks?: {
			/**
			 * 发送完数据时的钩子
			 */
			onSendData?: (data: number[]) => void;

			/**
			 * 接收数据大小时的钩子
			 * @param {number} receiveDataSize - 要接收的数据大小
			 * @param {number} alreadyReceiveDataSize - 已经接收的数据大小
			 * @param {boolean} isLastFrame - 是否为最后一帧，如果为true，则表示数据接收完毕
			 */
			onReceiveDataSize?: (receiveDataSize: number, alreadyReceiveDataSize: number, isLastFrame: boolean) => void;
		};

		/**
		 * 检查超时时间
		 */
		checkTimeout?: number;

		/**
		 * 是否更新进度
		 */
		updateProgress?: boolean;
	}) {
		try {
			const { hooks, checkTimeout, updateProgress } = Object.assign({
				hooks: {},
				checkTimeout: this.checkTimeout,
				updateProgress: true
			}, options);
			await this.sendData(data, { checkTimeout, updateProgress});
			hooks.onSendData && hooks.onSendData(data);
			let receiveDone = false;
			let receiveAllData: number[] = [];

			do {
				const { receiveDataSize, frameData, isLastFrame, crc32 } = await this.receiveFrameHeader({checkTimeout, updateProgress});
				hooks.onReceiveDataSize && hooks.onReceiveDataSize(receiveDataSize, frameData.length, isLastFrame);
				const response = await this.receiveData(receiveDataSize, frameData, {checkTimeout, updateProgress});
				const calculatedCrc32 = NfcUtils.getCrc32(response);

				if(calculatedCrc32 !== crc32) {
					this.logger.debug(`crc32 error, calculated: ${calculatedCrc32} received: ${crc32}`);
				}

				receiveAllData = receiveAllData.concat(response);
				receiveDone = isLastFrame;
			} while (!receiveDone);
			this.logger.debug("send success");

			return Promise.resolve(receiveAllData);
		} catch (error) {
			this.logger.debug("send error:", error);
			return Promise.reject(error);
		}
	}
	
	/**
	* 发送数据
	*/
	async sendData(data: number[], options?: {
		checkTimeout?: number;
		updateProgress?: boolean;
	}) {
		try {
			const { checkTimeout, updateProgress } = Object.assign({ checkTimeout: this.checkTimeout, updateProgress: true }, options);
			const dataSize = data.length;
			const { chunkCount, chunks } = this.nfcProtocol.encodeDataChunk(data);

			for (let index = 0; index < chunkCount; index++) {
				const chunk = chunks[index];
				const transceiveChunkWithCheck = this.createCheckFunc(
					chunk!,
					response => {
						return response.length > 0;
					},
					{
						timeout: checkTimeout,
						tag: 'transceiveChunk',
						shouldIgnoreError: this.shouldIgnoreTransceiveError
					}
				);

				await this.checkWriteable({updateProgress: false, checkTimeout});
				await transceiveChunkWithCheck();
				updateProgress && this.tracker.onProgress();
			}

			this.logger.debug(`sendData success | dataSize ${dataSize}, count ${chunkCount}`);
			return Promise.resolve();
		} catch (error) {
			this.logger.debug('sendData error: ', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 接收帧头部数据
	 */
	async receiveFrameHeader(options?: {
		checkTimeout?: number;
		updateProgress?: boolean;
	}) {
		try {
			const { checkTimeout, updateProgress } = Object.assign({ checkTimeout: this.checkTimeout, updateProgress: false }, options);
			const currentProtocolVersion = this.nfcProtocol.version;

			await this.checkReadable({checkTimeout, updateProgress});
			const receiveHeaderDataWithCheck = this.createCheckFunc(
				this.nfcProtocol.encodeNfcReadRequest(),
				response => {
					return response.length > 8;
				},
				{
					timeout: checkTimeout,
					tag: 'receiveFrameHeader'
				}
			);
			const headerData = await receiveHeaderDataWithCheck() as number[];

			if(!headerData || headerData.length < 8) {
				this.logger.debug("receiveFrameHeader | invalid header data:", Buffer.from(headerData).toString('hex'), headerData);
				return Promise.reject('invalid frame header data');
			}

			if(this.nfcProtocol.isAckError(headerData)) {
				return Promise.reject(NfcError.ackError);
			}

			const { preamble, protocolVersion, dataSize, data: frameData, crc32 } = this.nfcProtocol.decodeFrame(headerData);
			const receiveProtocolVersion = protocolVersion;
			const receiveDataSize = dataSize;

			if(!receiveProtocolVersion || currentProtocolVersion < receiveProtocolVersion) {
				this.logger.debug('receiveFrameHeader | protocol version error', currentProtocolVersion, receiveProtocolVersion, headerData);
				return Promise.reject('protocolVersion error');
			}
			this.logger.debug(`receiveFrameHeader | receive data size ${receiveDataSize}, header frame data size ${frameData.length}`);

			return Promise.resolve({
				receiveDataSize,
				frameData,
				isLastFrame: preamble === 0x00,
				crc32
			});
		} catch (error) {
			this.logger.debug("receiveFrameHeader | error:", error);
			return Promise.reject(error);	
		}
	}

	/**
	 * 接收数据
	 * @param {number} receiveDataSize - 要接收的数据大小
	 * @param {number[]} frameData - 帧数据(已经在头部接收的帧数据)
	 */
	async receiveData(receiveDataSize: number, frameData: number[], options?: {
		checkTimeout?: number;
		updateProgress?: boolean;
	}) {
		const { checkTimeout, updateProgress } = Object.assign({ checkTimeout: this.checkTimeout, updateProgress: true }, options);
		let receiveAllData: number[] = frameData;

		try {
			//前面接收头部数据的时候已经接收到了一部分数据，所以需要减去已经接收到的数据长度
			const sendCount = this.nfcProtocol.getSendCount(receiveDataSize - frameData.length);

			// 如果第一次接收头部数据就已经接收完毕，则直接返回
			if(receiveAllData.length >= receiveDataSize) {
				this.logger.debug('receiveData | data already received');
				return Promise.resolve(receiveAllData);
			}

			this.logger.debug('receiveData | receiveCount', sendCount);
	
			for (let index = 0; index < sendCount; index++) {
				await this.checkReadable({updateProgress: false, checkTimeout});
				const data = await this.nfcProxy.transceiveCommand(this.nfcProtocol.encodeNfcReadRequest());
				receiveAllData = receiveAllData.concat(data);
				updateProgress && this.tracker.onProgress();
			}
			receiveAllData = receiveAllData.slice(0, receiveDataSize);

			this.logger.debug('receiveData success', receiveAllData.length);
			return Promise.resolve(receiveAllData);
		} catch (error) {
			this.logger.debug("receiveData | error:", error);
	
			//超时代表数据接收完毕
			if(error === NfcError.timeout && receiveDataSize > 0 && receiveAllData.length >= receiveDataSize) {
				this.logger.debug('receiveData timeout done');
				return Promise.resolve(receiveAllData);
			}

			return Promise.reject(error);
		}
	}

	/**
	 * 发送设备调试指令
	 * @param testCommand - 设备调试指令
	 */
	async sendTestCommand(testCommand: string) {
		try {
			const writeCommandBytes: number[] = this.nfcProtocol.encodeNfcWriteRequest();
			const testCommandBytes: number[] = [...Buffer.from(testCommand, 'utf8')];
			const commandBytes: number[] = [ ...writeCommandBytes, ...testCommandBytes ];
			const targetLength = 67;
			const paddingLength = Math.max(0, targetLength - commandBytes.length);
			const paddingBytes: number[] = Array(paddingLength).fill(0);
			const finalCommand: number[] = [ ...commandBytes, ...paddingBytes ];
			const transceiveCommandWithCheck = this.createCheckFunc(
				finalCommand,
				() => {
					//设备支持与不支持该调试命令，response都是返回[10]
					//所以这里无需进行判断
					return true;
				},
				{
					tag: 'sendTestCommand',
					timeout: 1000,
					shouldIgnoreError: this.shouldIgnoreTransceiveError
				}
			);

			await this.checkWriteable({checkTimeout: 1000});
			await transceiveCommandWithCheck();
			return Promise.resolve();
		} catch (error) {
			this.logger.error('sendTestCommand error:', error);
			return Promise.reject(error);
		}
	}

	/**
	 * 创建一个检查是否发送成功的函数
	 * @param {number[]} command - 要发送的命令
	 * @param {function} checkCondition - 条件检查函数
	 */
	private createCheckFunc(
		command: NfcCommand, 
		checkCondition: (data: number[]) => boolean, 
		options?: {
			timeout?: number, 
			tag?: string,
			shouldIgnoreError?: (error: any) => boolean,
			retryDelay?: number,
		}
	): () => Promise<number[] | undefined> {
		const {
			timeout = this.checkTimeout,
			tag = 'createCheckFunc',
			retryDelay = 50,
			shouldIgnoreError = () => false,
		} = options ?? {};

		return async () => {
			let isOk = false;
			let response: number[] | undefined;
			const startTime = new Date().getTime();
			const messageTag = tag || 'createCheckFunc';

			while (!isOk) {
				try {
					const currentTime = new Date().getTime();

					if (currentTime - startTime > timeout) {
						this.logger.error(`${messageTag} | timeout:`, timeout);
						return Promise.reject(NfcError.timeout);
					}

					response = await this.nfcProxy.transceiveCommand(command);
					isOk = checkCondition(response);
				} catch (error) {
					NfcUtils.delay(retryDelay);

					if (shouldIgnoreError(error)) {
						break;
					} else {
						this.logger.error(`${messageTag} | transceive command error:`, error);
						return Promise.reject(error);
					}
				}
			}

			return Promise.resolve(response);
		};
	}

	/**
	 * 是否忽略传输错误
	 */
	private shouldIgnoreTransceiveError(error: any) {
		return shouldIgnoreTransceiveFail(error);
	}
}