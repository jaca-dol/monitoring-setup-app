import DeviceInfo from 'react-native-device-info';

const TRANSCEIVE_FAIL_IGNORE_MODEL_PATTERNS: Record<string, string[]> = {
	huawei: [ 'CLS', 'ADY', 'HBN', 'ALN', 'BRA', 'MNA', 'PLA', 'HED', 'LMR', 'VDE', 'PLR', 'MRT' ],
	oneplus: ['PLY110'],
	realme: ['RMX6688']
};

/**
 * 部分手机会误报 transceive fail，但设备实际已收到命令。
 */
export function shouldIgnoreTransceiveFail(error: unknown) {
	if (typeof error !== 'string' || !error.includes('transceive fail')) {
		return false;
	}

	const brand = DeviceInfo.getBrand().toLowerCase();
	const model = DeviceInfo.getModel();
	const modelPatterns = TRANSCEIVE_FAIL_IGNORE_MODEL_PATTERNS[brand] ?? [];

	return modelPatterns.some(pattern => model.includes(pattern));
}
