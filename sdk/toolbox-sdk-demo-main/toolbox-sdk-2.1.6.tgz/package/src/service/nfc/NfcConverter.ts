import { Buffer } from 'buffer';
import _ from 'lodash';

class Converter {

	/**
	 * 将16进制的字符串转为10进制的数组
	 *
	 * @param {string} str 16进制的字符串
	 * @returns {Number[]} array
	*/
	hexStrToDecimalArr(str: string) {
		const arr: number[] = [];
		//buffer from返回的是unit8数组，必须将其转为普通数组
		Buffer.from(str, "hex").forEach(v => arr.push(v));  
		return arr;
	}

	/**
	 * 16进制的数组转换为十进制的数组
	 * @param {Array} data 
	 */
	hexArrToDecimalArr(data: any[]) {
		const arr: number[] = [];
		//@ts-ignore
		Buffer.from(data, "hex").forEach(v => arr.push(v));  //buffer from返回的是unit8数组，必须将其转为普通数组
		return arr;
	}

	/**
	 * 十进制的数组转为16进制的字符串
	 * @param {Number[]} arr 需要转换的数组
	 * @return {String} str 16进制的字符串
	 */
	decimalArrToHexStr(arr: number[]) {
		return Buffer.from(arr).toString('hex');
	}

	/**
	 * 将字符串转换为16进制的Unicode编码点值的字符串
	 * @param {String} str 需要转换的字符串
	 * @param {Boolean} needReverse 是否需要反转字符串
	 * @return {String} 16进制的Unicode编码点值的字符串
	 */
	strToCharCodeHexStr(str: string, needReverse = false) {
		const charCodeArr = Array.from(str);
	
		return needReverse ? 
			charCodeArr.reverse().map(v => v.charCodeAt(0).toString(16)).join('') :
			charCodeArr.map(v => v.charCodeAt(0).toString(16)).join('');
	}

	/**
	 * 数字转换为16进制的字符串(小端)
	 * @param {Number} num 数字
	 * @param {Number} size 字节大小
	 * @param {Boolean} sign 有无符号
	 * @return {String} 16进制的字符串
	 */
	numberToHextStr(num: number, size: number, sign = false) {
		const buffer = Buffer.alloc(size);
	
		if(size === 4) {
			if(sign) {
				buffer.writeInt32LE(num, 0);
			} else {
				buffer.writeUInt32LE(num, 0);
			}
		} else if (size === 1) {
			if(sign && num <= 127) {
				buffer.writeInt8(num, 0);
			} else {
				buffer.writeUInt8(num, 0);
			}
		} else if (size === 2) {
			if(sign) {
				buffer.writeInt16LE(num, 0);
			} else {
				buffer.writeUInt16LE(num, 0);
			}
		}

		return buffer.toString("hex");
	}

	/**
	 * 转换一个较长的数字（比如时间戳）为16进制字符串
	 * 负数转换为16进制字符串请使用`numToEndianHex`方法
	 * @param {Number} num 
	 * @param {Boolean} needReverse 
	 */
	longNumberToHexStr(num: number, needReverse = false) {
		const numString = num.toString(16);
		return needReverse ? Buffer.from(numString, "hex").reverse().toString('hex') :
			Buffer.from(numString, "hex").toString('hex');
	}

	/**
	 * 将数据转为整数数组
	 * @param {number[]} data 
	 */
	encodeData(data: number[]) {
		return this.hexArrToDecimalArr(data);
	}

	/**
	 * 将命令转换为整数数组
	 * @param {string} command 
	 * @param {Boolean} needPad 
	 */
	encodeCommand(command: string, needPad = false) {
		return this.hexStrToDecimalArr(
			needPad ? 
				this.padCommand(command) : 
				command
		);
	}

	/**
	 * 将整数数组转换为16进制字符串
	 * @param {number[]} command 
	 */
	decodeCommand(command: number[]) {
		return this.decimalArrToHexStr(command);
	}

	/**
	 * 用另一个字符串填充当前字符串(重复，如果需要的话)，以便产生的字符串达到给定的长度。
	 * 填充从当前字符串的开始(右侧)应用的
	 * @param {string} command 
	 * @param {string} padString 
	 * @param {number} targetLength 
	 */
	padCommand(command: string, padString = '0', targetLength = 134) {
		return _.padEnd(command, targetLength, padString);
	}

	/**
	 * 将密码转换为16进制的Unicode编码点值的字符串
	 * @param {string} password 
	 */
	convertPassword(password: string) {
		return this.strToCharCodeHexStr(password);
	}

	/**
	 * 将数字转换为16进制的字符串
	 * @param {number} number 
	 */
	convertNumber(number: number, size?: number) {
		const numberSize = size ?? (number >= 0 && number <= 255 
			? 1 
			: number > 32767 
				? 4 
				: 2);

		return this.numberToHextStr(number, numberSize, true);
	}

	base64ToArrayBuffer(b64string: string) {
		const arr: number[] = [];
		
		Buffer.from(b64string, 'base64').forEach(v => arr.push(v));

		return arr;
	}

	strToDecimalArr(str: string, type: BufferEncoding): number[] {
		return Buffer.from(str, type).toJSON().data;
	}

	/**
	 * 将十进制数组转换为16进制数组
	 * @param {number[]} intArray 十进制数组
	 * @return {string[]} 16进制数组
	 */
	convertToHexArray(intArray: number[]): string[] {
		const buffer = Buffer.from(intArray.map(num => {
			if (num < 0) {
				num = num + 256;
			}
			return num;
		}));

		return _.map(buffer, byte => '0x' + byte.toString(16).padStart(2, '0'));
	}
}

export default new Converter();