import { Alert, Platform } from 'react-native';

import { Buffer } from 'buffer';
import _ from 'lodash';
import moment from 'moment';
import NfcManager, { NfcEvents } from 'react-native-nfc-manager';

import { Context, Device, Metric } from '@ursalink-cloud/core-sdk';

import {
	INfcProtocol, Nfc, NfcCommander, NfcCommanderV2, NfcCommandName, NfcCommandType, NfcConverter, NfcError, NfcProtocol, NfcProxy,
	NfcProxyConfig, NfcState, NfcTech, NfcTracker, NfcTrackerCallback, NfcTrackerEvents, NfcUtils,
} from '../';
import { DataCodecManager } from '../../../model/codec';
import { EM400NB_SERIES, MODEL_SERIES, MODELS } from '../../../model/constants';
import { DataModelManager } from '../../../model/DataModel';
import { LORA_REPORT_SERVICE } from '../../../model/DeviceConverter';
import { DeviceInfo, DeviceProductInfo, FetchChannelDataType, SDI12Setting } from '../../../model/deviceInfo';
import DeviceUtils from '../../../model/DeviceUtils';
import { getDeviceModel, getModelSeries } from '../../../model/model';
import { difference, getDeviceSettingInfo, getOriginPreDeviceInfo, getSettingJSON, processPayload } from '../../../model/utils';
import { getLocalStandardUTCOffset } from '../../../utils';
import { Counter, TimeCounter } from '../../../utils/counter';
import { default as Logger, Log, LoggerType } from '../../../utils/logger';
import {
	getDeviceInfo, getPreDeviceInfo, loadDeviceInfo, loadPreDeviceInfo, setAllSolenoidWork, setDeviceCardData, setDeviceInfo,
	setDeviceRawData, setDSTemplateInfo, setPreDeviceInfo, setSDIData, setSettingMode,
} from '../../../utils/store/actions';
import store from '../../../utils/store/store';
import { Toast } from '../../../utils/toast';
import translate from '../../../utils/translate';
import { encodePrivateKeys, Notification, padPrivateKeys, parseJSONSafely, readFloat16LE } from '../../../utils/util';
import { Version } from '../../../utils/util/Version';
import { ActionManager, ActionName, ActionTypes, IAction, INfcActionApi, NfcActionApi, SupportIPSOActionCache } from '../../action';
import { Reader } from '../../DeviceManager/protocol';
import { DeviceHooks } from '../../hook';
import { IIPSOProtocol, IPSO_PROTOCOL_ERRORS, IPSOProtocol } from '../../ipso';
import { DevicePasswordManager } from '../../password';
import { UpgradeHelper } from '../../upgrade/UpgradeHelper';

const isAndroid = Platform.OS === 'android';
const isiOS = Platform.OS === 'ios';
const IOS_SESSION_TIMEOUT = 20; //iOS session超时时间，单位秒
const LOGI = _.partial(Log.i, 'NFC');
const LOGE = _.partial(Log.e, 'NFC');

Context.libraries.buffer = Buffer;

/**
 * 负责连接整个NFC功能的类
 */
export class NfcController {

	nfcProxy: InstanceType<typeof NfcProxy>;

	commander: InstanceType<typeof NfcCommander>;

	tracker: InstanceType<typeof NfcTracker>;

	sleepTimer: ReturnType<typeof setInterval> | null = null;

	reListened = false;

	/**
	 * 是否需要压缩卡模式的数据
	 */
	needCompressCardData: boolean;

	/**
	 * 当前发现标签后执行的事件
	 */
	tagDiscovertyListener: any;

	/**
	 * 当前发现标签后执行的动作
	 */
	tagDiscoveryAction: IAction | undefined;

	currentCommandName!: NfcCommandName;

	currentCommandType!: NfcCommandType;

	logger: LoggerType;

	actionApi: INfcActionApi;

	nfcProtocol: INfcProtocol;

	nfcCommanderV2: InstanceType<typeof NfcCommanderV2>;

	ipsoProtocol: IIPSOProtocol;

	constructor(config?: Partial<NfcProxyConfig>) {
		const nfc = NfcManager as Nfc;
		nfc.transceiveCommand = Platform.OS === 'ios' 
			? NfcManager.sendMifareCommandIOS 
			: NfcManager.transceive;
		this.nfcProxy = new NfcProxy(nfc, config);
		this.tracker = new NfcTracker();
		this.nfcProtocol = new NfcProtocol();
		this.ipsoProtocol = new IPSOProtocol({
			getPassword: this.getDevicePassword.bind(this),
			getPasswordId: this.getPasswordId.bind(this)
		}, 'oldOnlyWhenSix');
		this.commander = new NfcCommander(this.nfcProxy, this.tracker);
		this.nfcCommanderV2 = new NfcCommanderV2(this.nfcProxy, this.tracker, this.nfcProtocol);
		this.needCompressCardData = false;
		this.logger = Logger.extend('NFCController');
		this.tagDiscoveryAction = undefined;
		this.actionApi = new NfcActionApi({
			commander: this.nfcCommanderV2,
			tracker: this.tracker,
			nfcProxy: this.nfcProxy,
			nfcProtocol: this.nfcProtocol,
			ipsoProtocol: this.ipsoProtocol,
			dataModelManager: DataModelManager,
			dataCodecManager: DataCodecManager,
			logger: Logger,
			log: {
				error: LOGE,
				info: LOGI
			}
		});
	}

	/**
	 * 设置iOS弹出框消息
	 * @param {string} message 消息
	 */
	async setAlertMessage(message: string) {
		if(Platform.OS != 'ios') {
			return Promise.resolve();
		}

		try {
			await NfcManager.setAlertMessageIOS(message);

			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 设置iOS错误消息
	 * @param {String} message 消息
	 */
	async setErrorAlertMessage(message: string) {
		if(Platform.OS != 'ios') {
			return Promise.resolve();
		}

		try {
			await NfcManager.invalidateSessionWithErrorIOS(message);

			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 获取当前模式
	 */
	getMode() {
		const config = this.getConfig();

		return config.mode;
	}

	/**
	 * 获取nfc设置
	 */
	getConfig() {
		return this.nfcProxy.getConfig();
	}

	/**
	 * 获取动作
	 * @param name - 动作名称
	 * @param params - 动作参数
	 */
	getAction<N extends ActionName>(name: N, ...params: ActionTypes[N]['params']) {
		return ActionManager.getActionWithParams(name, this.actionApi, ...params);
	}

	/**
	 * 设置nfc配置
	 */
	setConfig(config: Partial<NfcProxyConfig>) {
		this.nfcProxy.setConfig(config);
	}

	/**
	 * 重置nfc配置
	 */
	resetConfig() {
		this.nfcProxy.resetConfig();
	}

	/**
	 * 导航至NFC设置页面（only Android）
	 */
	navigateToNfcSetting() {
		if(isiOS) {
			return Promise.reject(NfcError.notSupport);
		}

		// 显示权限说明通知
		Notification.show({
			title: translate('permission.nfc.title'),
			content: translate('permission.nfc.content'),
		});

		return new Promise((resolve, reject) => {
			Alert.alert(
				'',
				translate('tips.enableNFCTip'),
				[
					{
						text: translate('button.cancel'),
						onPress: () => {
							reject(NfcError.userCancelEnable);
							Notification.hide(1500);
						},
						style: 'cancel'
					},
					{
						text: translate('button.go'),
						onPress: async () => {
							try {
								await this.nfcProxy.goToNfcSetting();
								resolve(1);
							} catch (error) {
								reject(NfcError.notEnabled);
							} finally {
								Notification.hide(1500);
							}
						}
					}
				]
			);
		});
	}

	/**
	 * 在发送命令前的处理，检查是否支持nfc，是否启用nfc
	 * 仅Android
	 *
	 * @returns
	 */
	async preProcess() {

		const isSupport = await this.nfcProxy.isSupport();

		if(!isSupport) {
			return Promise.reject(NfcError.notSupport);
		}

		try {
			const isEnabled = await this.nfcProxy.isEnabled();

			if (!isEnabled) {
				this.logger.debug('NFC not enabled');
				// eslint-disable-next-line no-async-promise-executor
				return new Promise(async (resolve, reject) => {
					try {
						await this.navigateToNfcSetting();
						this.logger.debug('navigate to NFC Setting success');
						setTimeout(async() => {
							const isEnabled = await this.nfcProxy.isEnabled();
							this.logger.debug('Set timer check NFC is enabled', isEnabled);
							if(isEnabled) {
								resolve(1);
							} else {
								reject(NfcError.notEnabled);
							}
						}, 3000);
					} catch (error) {
						reject(error);
					}
				});
			}

			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);	
		}
	}

	/**
	 * 注册发现标签的监听事件
	 *
	 * @param {string} tech 要监听的芯片类型
	 * @param {String} listener 要监听的事件
	 * @param {String} alertMessage - iOS要提示的信息
	 * @param {Boolean} reListen 失败后重新注册监听
	 */
	async setTagDiscoveryListener(
		{ listener,
			tech = isiOS ? NfcTech.MifareIOS : NfcTech.NfcA,
			commandName,
			commandType,
			alertMessage = translate('tips.approachTip'),
			successMessage,
			reListen = true,
			reListenCount = 5,
			action,
			stopDetection = true
		}: {
				listener?: () => Promise<any>;
				commandName: NfcCommandName;
				commandType: NfcCommandType;
				tech?: NfcTech;
				alertMessage?: string;
				successMessage?: string;
				reListen?: boolean;
				reListenCount?: number;
				action?: IAction;
				stopDetection?: boolean;
			}): Promise<any> {
		const sessionStartTime = this.nfcProxy.sessionStartTime ?? 0;
		const autoResetDeviceNfcConfig = this.getConfig().autoResetDeviceNfc;
		let sessionEndTime = 0;
		let sessionDuration = 0;
		let result;

		try {
			if(isAndroid) {
				await this.preProcess();
			}

			if(!_.isFunction(listener) && !action) {
				throw new Error('no listener or action');
			}

			this.tagDiscovertyListener = listener;
			this.tagDiscoveryAction = action;
			this.currentCommandName = commandName;
			this.currentCommandType = commandType;

			this.tracker.beforeStart(commandName, commandType);

			this.nfcProxy.addNfcEventListener(NfcEvents.SessionClosed, () => {				
				this.tracker.onSessionClose();
			});

			await this.nfcProxy.startDetection(tech, alertMessage);

			this.tracker.onStart();

			await NfcUtils.sleepWithMS(300);
			const canExecuteAction = await ActionManager.checkActionCanExecute(action);

			//如果有action，且支持执行，则执行action，否则执行listener
			if (action && canExecuteAction) {
				this.logger.debug("setTagDiscoveryListener run with action");
				result = await action.execute();
			} else if (listener) {
				this.logger.debug("setTagDiscoveryListener run with listener");
				result = await listener();
			} else {
				if(action && !canExecuteAction) {
					throw new Error('action not supported');
				}

				throw new Error('no listener or action');
			}

			//如果有要结束当前会话，且当前会话存在，且要启用自动重置设备NFC，则在会话结束前发送重置命令
			if(stopDetection && this.nfcProxy.tag != null && autoResetDeviceNfcConfig.enable && autoResetDeviceNfcConfig.timeout != null) {
				await this.commander.sendResetDeviceNfc(autoResetDeviceNfcConfig.timeout);
				this.logger.debug(`reset device nfc ${autoResetDeviceNfcConfig.timeout}ms before stop detection`);
			}

			this.tracker.onSuccess(successMessage);

			stopDetection && await this.stopDetection();

			sessionEndTime = moment().unix();
			sessionDuration = sessionEndTime - sessionStartTime;
			this.tagDiscovertyListener = null;
			this.tagDiscoveryAction = undefined;

			return Promise.resolve(result);
		} catch (error: any) {
			sessionEndTime = moment().unix();
			sessionDuration = sessionEndTime - sessionStartTime;

			this.logger.debug('setTagDiscoveryListener ->', error);

			let errorMessage = _.isError(error)
				? error.message
				: error;

			if (_.includes([NfcError.duplicateRequest], error)) {
				this.logger.debug(`setTagDiscoveryListener duplicate request ${error}`);
				await this.nfcProxy.stopDetection();
				return Promise.resolve(error);
			} 
				
			//stop detection后会触发
			if(this.isCancel(error)) { 
				this.logger.debug(`setTagDiscoveryListener stop detection ${error}`);
				return Promise.resolve(error);
			} 

			//用户未启用NFC/取消启用NFC
			if(error === NfcError.userCancelEnable || error === NfcError.notEnabled) {
				this.logger.debug(`user not enable nfc ${error}`);
				return Promise.resolve(error);
			}

			if(error === NfcError.wrongPassword || error?.message === IPSO_PROTOCOL_ERRORS.CHECK_PASSWORD_ERROR.message) {
				errorMessage = translate('tips.wrongPassword');
				reListenCount = 30;
				this.tracker.onError(error, errorMessage, reListen);
				return this.handleReListenDiscoveryEvent({tech, errorMessage, commandName, commandType, reListenCount});
			} 
			
			if (error === NfcError.notSupport) {
				reListen = false;
				errorMessage = translate('tips.noSupportNFC');

				Toast.fail(errorMessage);
			}

			if (error === NfcError.collecting) {
				errorMessage = translate('setting.collecting');
			}

			if(error === NfcError.readRegisterError) {
				errorMessage = translate('tips.readRegisterError');
			}
			
			if (_.isString(error) && error.indexOf('NFCError') != -1) { //iOS专有
				//如果是iOS NFC session超时
				if(sessionStartTime !== 0 && sessionEndTime !== 0 && sessionDuration >= IOS_SESSION_TIMEOUT) {
					errorMessage = NfcError.sessionTimeout;
				} else {
					errorMessage = this.nfcProxy.handleErrorMessage('setTagDiscoveryListener', error);
				}
			}

			//如果有启用自动重置设备NFC，则在会话结束前发送重置命令
			if(stopDetection && this.nfcProxy.tag != null && autoResetDeviceNfcConfig.enable && autoResetDeviceNfcConfig.timeout != null) {
				this.commander.sendResetDeviceNfc(autoResetDeviceNfcConfig.timeout)
					.then(() => {
						this.logger.debug(`reset device nfc ${autoResetDeviceNfcConfig.timeout}ms on error`);
					})
					.catch(_.noop);
			}

			if (isAndroid && reListen) {
				this.tracker.onError(error, errorMessage, reListen);
				return this.handleReListenDiscoveryEvent({tech, errorMessage, commandName, commandType, reListenCount});
			}

			//非传输过程中的错误，也需要触发onError
			if(!_.isNil(errorMessage)) {
				this.tracker.onError(error, _.toString(errorMessage ?? error ?? 'unknown error'), reListen);
			}
			
			return Promise.reject(errorMessage ?? error);
		}
	}

	/**
	 * 重新发送上一次的命令
	 * 
	 * @deprecated 请使用reListenDiscoveryEvent代替，因为resendCommand重新开启新的会话后无法继续上一次会话后续的逻辑
	 */
	async resendCommand() {
		if(_.isFunction(this.tagDiscovertyListener)) {
			return this.setTagDiscoveryListener({
				listener: this.tagDiscovertyListener,
				action: this.tagDiscoveryAction,
				commandName: this.currentCommandName,
				commandType: this.currentCommandType
			});
		} 

		return Promise.reject('resendCommand tagDiscovertyListener is not a function');
	}

	async isSupport() {

		if(__DEV__) {
			return Promise.resolve(true);
		}

		return this.nfcProxy.isSupport();
	}

	/**
	 * 判断是否取消了NFC操作
	 * @param error 错误信息
	 * @returns 
	 */
	isCancel(error: any) {
		return _.includes([ NfcError.detectionCancelled, NfcError.detectionTimeout ], error);
	}

	/**
	 * 停止检测芯片
	 * @param {Boolean} waitForSessionClose 是否等待会话关闭（仅 iOS 有效）
	 */
	async stopDetection(waitForSessionClose?: boolean): Promise<void> {
		try {
			await this.nfcProxy.stopDetection();

			if (Platform.OS === 'ios' && waitForSessionClose) {
				return new Promise(resolve => {
					this.nfcProxy.addNfcEventListener(NfcEvents.SessionClosed, () => {
						resolve();
					});
				});
			}

		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 写入设备数据
	 * @param {string} settingJSON - 有修改的配置信息
	 * @param {Object} newDeviceSettingInfo - 最新的设备设置信息
	 */
	async write(settingJSON: string, newDeviceSettingInfo: DeviceInfo) {
		try {
			const { mode } = this.nfcProxy.config;
			const result = mode === 'card' 
				? await this.newWriteCardData(settingJSON, newDeviceSettingInfo)
				: await this.writeFlash(settingJSON, newDeviceSettingInfo);

			return Promise.resolve(result);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 写入设备数据(对外暴露的接口，内部不使用)
	 * @param deviceInfo 设备信息
	 * @returns 
	 */
	async writeData(deviceInfo: Partial<DeviceInfo>) {
		try {
			const deviceSettingInfo = _.cloneDeep(deviceInfo) as DeviceInfo;		
			const prevDeviceInfo = getPreDeviceInfo(store.getState());
			const defaultPreDeviceInfo = getOriginPreDeviceInfo(prevDeviceInfo);
			const diffSetting = difference(deviceSettingInfo, defaultPreDeviceInfo, [
				'reportMode',
				'dismissReport',
			]) as Partial<DeviceInfo>;

			const preDeviceSettingInfo = getDeviceSettingInfo(
				prevDeviceInfo
			);

			const newDeviceSettingInfo = _.merge({}, preDeviceSettingInfo, diffSetting);

			const finalJSON = getSettingJSON(
				diffSetting,
				newDeviceSettingInfo,
				prevDeviceInfo,
				false
			);

			const result = await this.write(finalJSON, newDeviceSettingInfo as DeviceInfo);
			//触发写入设备信息完成事件
			DeviceHooks.writeFinish.call(newDeviceSettingInfo as DeviceInfo);
			return Promise.resolve(result);
		} catch (error: any) {
			return Promise.reject(error);
		}
	}

	/**
     * 读取设备便利函数(对外暴露的接口，内部不使用)
     */
	async readData() {
		{
			try {
				const { deviceInfo, rawData } = await this.readFlash();
    
				if (!deviceInfo || !rawData) {
					return;
				}
    
				store.dispatch(setDeviceRawData(rawData));
				store.dispatch(setSettingMode('device'));
				store.dispatch(loadDeviceInfo(deviceInfo));
				store.dispatch(loadPreDeviceInfo(deviceInfo));
    
				if (_.has(deviceInfo, 'solenoidWork')) {
					store.dispatch(setAllSolenoidWork(deviceInfo.solenoidWork));
				}
    
				//触发读取设备信息完成事件
				DeviceHooks.read.call(deviceInfo as DeviceInfo);

				const { payload, status } = processPayload(store.getState().device.deviceInfo, deviceInfo);    
				return {...payload, status} as Partial<DeviceInfo>;
			} catch (error) {
				return Promise.reject(error);
			}
		}
	}

	/**
	 * 读取设备flash数据
	 */
	async readFlash() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					TimeCounter.time('readFlash');
					Counter.increaseRead('total'); 
					this.logger.debug('readFlash start');
					const dataLength = await this.commander.sendCommand(NfcCommandName.readFlash);
					const sendCount = this.commander.getSendCount(dataLength);
				
					this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.readFlash);

					const readFlashData = await this.commander.receiveFlashData(dataLength);
					//每次都要用实际的数据长度（设备给的数据长度）去解析
					//而不是实际接收到的数据长度（可能会因为64不能整除，而多接受64个字节）
					const slicedFlashData = _.slice(readFlashData, 0, dataLength);
					//前128个字节是状态，需要去掉
					const rawData = _.slice(slicedFlashData, 128);
					const flashInfo = await DeviceUtils.getFlashInfo(slicedFlashData);
					const parseFlashInfo = parseJSONSafely(flashInfo);

					_.forIn(parseFlashInfo, (value, key) => {
						if(value === 'false') {
							parseFlashInfo[key] = false;
						}
					});
	
					const deviceInfo = _.merge({}, parseFlashInfo, {
						updateTime: _.now(),
						readMode: 'nfc',
						//告诉 reducer 要处理 payload
						processPayload: true
					});
					const encodedNewDeviceInfo = padPrivateKeys(deviceInfo);
					const isDataError = _.get(encodedNewDeviceInfo, 'status.length') === 0;

					//如果状态页没有状态内容就认为是数据错误/不支持的设备，提醒版本过低
					if(isDataError) {
						Log.e('NFC', 'is not support device info', flashInfo);
						return Promise.reject(NfcError.dataError);
					}

					//如果crc校验错误，则报错
					if(_.get(parseFlashInfo, 'code') === NfcError.crcError) {
						return Promise.reject(NfcError.crcError);
					}
	
					if(__DEV__) {
						this.logger.debug('read flash info', flashInfo);
					}
					LOGI('read flash deviceInfo', encodedNewDeviceInfo);
					//关联设备sn和NFC tag的Id
					if(deviceInfo.sn && this.nfcProxy.tag?.id) {
						DevicePasswordManager.associateSnWithNFCId(deviceInfo.sn, this.nfcProxy.tag?.id);

						// 如果缓存中没有记录，且读取flash成功，则表示不支持IPSO协议
						SupportIPSOActionCache.getIsSupportIPSOAction(this.nfcProxy.tag?.id) === 'unknown' && SupportIPSOActionCache.setSupportIPSOAction(this.nfcProxy.tag?.id, false);
					}
					await this.tracker.checkAndSmoothProgressToComplete();
					Counter.increaseRead('success'); 
					TimeCounter.timeEnd('readFlash');
					return Promise.resolve({
						deviceInfo: encodedNewDeviceInfo,
						rawData
					});
				} catch (error) {
					Counter.increaseRead('failed');
					TimeCounter.timeEnd('readFlash');
					Log.e('NFC', 'read flash failed', error);
					return Promise.reject(error);
				}
			},
			action: this.getAction('NfcReadIPSOData'),
			commandName: NfcCommandName.readFlash,
			commandType: NfcCommandType.read
		});
	}

	/**
	 * 写入设备配置命令（包括模版配置）
	 * @param {string} settingJSON - 有修改的配置信息
	 * @param {Object} newDeviceSettingInfo - 最新的设备设置信息
	 */
	async writeFlash(settingJSON: string, newDeviceSettingInfo: DeviceInfo) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseWrite('total');
					let isSetTotalProgress = false;
					const password = this.getDevicePassword();
					const isChangePassword = _.get(newDeviceSettingInfo, 'changePassword', false);
					let rawData = _.get(store.getState(), 'device.rawData', []) as number[];
					const applyFromTemplate = _.get(newDeviceSettingInfo, 'applyFromTemplate', false);

					//如果没有flash数据，则需要先去读取flash数据，再进行后面的步骤
					if(rawData.length === 0 || applyFromTemplate) {
						this.logger.debug('read flash first');
						const dataLength = await this.commander.sendCommand(NfcCommandName.readFlash);

						//如果需要接收数据，则提前设置好总进度
						if(!isSetTotalProgress) { 
							const sendCount = this.commander.getSendCount(dataLength);
							this.tracker.setTotalProgressFromSendCount(sendCount * 2 + 2, NfcCommandName.writeFlash);
							isSetTotalProgress = true;
						}

						rawData = await this.commander.receiveFlashData(dataLength);
						//必须要先getFlash，修改标识位
						await DeviceUtils.getFlashInfo(rawData);
						
						rawData = _.slice(rawData, 128);
					}

					// 如果是IPSO数据，不能写入到flash
					if(this.ipsoProtocol.isIPSOData(rawData)) {
						throw NfcError.unmatchedDevice;
					}
	
					const flashInfo = await DeviceUtils.setFlashInfo(rawData, settingJSON);
						
					if(flashInfo.code != 1) {
						// this.NfcCore.onError(flashInfo.code, `DeviceUtils.setFlashInfo has error code: ${flashInfo.code}`, NFC_COMMAND_NAMES.setFlash);
						throw flashInfo.code;
					}
	
					rawData = flashInfo.rawData;
					const dataSize = JSON.parse(flashInfo.result).datasize;

					//写入flash数据
					await this.commander.sendCommand(NfcCommandName.writeFlash, { dataSize, password });

					if(!isSetTotalProgress) {
						const sendDataCount = this.commander.getSendCount(dataSize);
						this.tracker.setTotalProgressFromSendCount(sendDataCount, NfcCommandName.writeFlash);
						isSetTotalProgress = true;
					}
					
					await this.commander.sendFlashData({data: rawData, dataSize});
					// 默认为5秒超时时间，额外增加1秒超时时间，否则UC50x等数据量大的设备会超时
					await this.commander.checkReadable(6000);
					await this.commander.checkWriteSuccess();
	
					//当非修改密码时，password以存储密码为值，修改密码时以新密码为值
					if(_.get(newDeviceSettingInfo, 'password', '') != password) {
						const sn = getDeviceInfo(store.getState() as any).sn;

						if(!isChangePassword) {
							this.logger.debug('password changed');
							_.set(newDeviceSettingInfo, 'password', password);
						}

						//是否记住密码
						const {isRemember} = DevicePasswordManager.getPasswordBySn(sn, false);
						if(isRemember) {
							DevicePasswordManager.setPasswordBySn(sn, newDeviceSettingInfo['password']);
						}
						DevicePasswordManager.setPasswordBySn(sn, newDeviceSettingInfo['password'], true);
					}

					if(applyFromTemplate === true) {
						newDeviceSettingInfo['applyFromTemplate'] = true;
					}
	
					const encodedNewdeviceInfo = encodePrivateKeys(newDeviceSettingInfo);

					store.dispatch(setDeviceRawData(rawData));
					store.dispatch(setDeviceInfo(encodedNewdeviceInfo));
					store.dispatch(setPreDeviceInfo(encodedNewdeviceInfo)); 
					LOGI('write flash deviceInfo', JSON.parse(settingJSON));
					Counter.increaseWrite('success');
					return Promise.resolve(rawData);
				} catch (error) {
					Counter.increaseWrite('failed');
					Log.e('NFC', 'write flash error', error);
					return Promise.reject(error);
				}
			},
			action: this.getAction('NfcWriteIPSOData', settingJSON, newDeviceSettingInfo),
			commandName: NfcCommandName.writeFlash,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 读取卡数据
	 * @deprecated
	 */
	async readCardData() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					this.logger.debug('read card data start');
					Counter.increaseRead('total');
					const cardDataLength = await this.commander.getCardDataLength();
					let readCardData = await this.commander.readCardData(cardDataLength);

					//新的card data要解压数据
					if(cardDataLength < 1000) {
						const decodeResult = await DeviceUtils.decodeData(_.slice(readCardData, 0, cardDataLength)); //每次都会读第一块的所有数据，但是实际上只有cardDataLength的数据有效，所以需要截取
						readCardData = decodeResult.data;
						this.needCompressCardData = true;
					} else {
						this.needCompressCardData = false;
					}
					
					const prefixFillData = _.fill(Array(128), 0);
					readCardData = prefixFillData.concat(readCardData); //要在最前面插入128个字节的0，才是完整的数据

					const flasInfo = await DeviceUtils.getFlashInfo(readCardData);
					const parseFlashInfo = JSON.parse(flasInfo);
					
					_.forIn(parseFlashInfo, (value, key) => {
						if(value === 'false') {
							parseFlashInfo[key] = false;
						}
					});
	
					const deviceInfo = _.merge({}, parseFlashInfo, {
						updateTime: _.now()
					});
					const encodedNewdeviceSettingInfo = padPrivateKeys(deviceInfo);
					const slicedData = _.slice(readCardData, 128);
					const isDataError = _.get(deviceInfo, 'status.length') === 0;

					//如果状态页没有状态内容就认为是数据错误/不支持的设备，提醒版本过低
					if(isDataError) {
						return Promise.reject(NfcError.dataError);
					}

					store.dispatch(setDeviceCardData(slicedData));
					store.dispatch(setSettingMode('device'));
					store.dispatch(loadDeviceInfo(encodedNewdeviceSettingInfo));
					store.dispatch(loadPreDeviceInfo(encodedNewdeviceSettingInfo));
					Counter.increaseRead('success');

					LOGI('read card deviceInfo', encodedNewdeviceSettingInfo);

					return Promise.resolve(slicedData);
				} catch (error) {
					let msg = error;
					
					if(error === NfcError.sendFailed) {
						msg = translate('tips.readFailed');
					}

					Counter.increaseRead('failed');

					return Promise.reject(msg);
				}
			},
			commandName: NfcCommandName.readCard,
			commandType: NfcCommandType.read
		});
	}

	/**
	 * 获取读取到的卡信息
	 * @param readCardData 读取到的卡数据
	 */
	async getReadCardInfo(readCardData: number[]): Promise<{
		deviceInfo: DeviceInfo; //解析后的设备信息
		cardData: number[] //解析后的卡数据
	}> {
		try {
			const cardInfo = await DeviceUtils.getCardInfo(readCardData);
			const parseDeviceInfo = JSON.parse(cardInfo.deviceInfo);
			const isDataError = _.get(parseDeviceInfo, 'status.length') === 0;

			//如果状态页没有状态内容就认为是数据错误/不支持的设备
			if(isDataError) {
				return Promise.reject(NfcError.dataError);
			}

			//如果crc校验错误，则报错
			if(_.get(parseDeviceInfo, 'code') === NfcError.crcError) {
				return Promise.reject(NfcError.crcError);
			}
			
			_.forIn(parseDeviceInfo, (value, key) => {
				if(value === 'false') {
					parseDeviceInfo[key] = false;
				}
			});

			const deviceInfo = _.merge({}, parseDeviceInfo, {
				updateTime: _.now(),
				keyMode: cardInfo.keyMode,
				cardVersion: cardInfo.cardVersion,
				cardStatus: cardInfo.cardStatus,
				readMode: 'nfc'
			});
			this.logger.debug('cardStatus: ', cardInfo.cardStatus);
			this.logger.debug('cardVersion: ', cardInfo.cardVersion);
			this.logger.debug('keyMode: ', cardInfo.keyMode);
			this.logger.debug('supportRandomKey', parseDeviceInfo.supportRandomKey);
			this.logger.debug('cardData length', cardInfo.cardData.length);

			return {
				deviceInfo,
				//读出来的时候要去掉头部的128个字节，方便写入
				//写入的时候，接口根据头部信息组装好前128个字节再拼接flash数据部分，所以写入的时候不需要前128个字节
				cardData: _.slice(cardInfo.cardData, 128) 
			};
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
 	* 读取卡数据(新卡模式)
 	*/
	async newReadCardData() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseRead('total');
					const cardDataLength = await this.commander.getCardDataLength();
					const readCardData = await this.commander.readCardData(cardDataLength);
					const cardInfo = await this.getReadCardInfo(readCardData);
					const deviceInfo = {
						...cardInfo.deviceInfo,
						//告诉 reducer 要处理 payload
						processPayload: true
					};
					const encodedNewDeviceInfo = padPrivateKeys(deviceInfo);
					store.dispatch(setDeviceCardData(cardInfo.cardData));
					store.dispatch(setSettingMode('device'));
					store.dispatch(loadDeviceInfo(encodedNewDeviceInfo));
					store.dispatch(loadPreDeviceInfo(encodedNewDeviceInfo));
					Counter.increaseRead('success');

					//触发读取设备信息完成事件
					DeviceHooks.read.call(encodedNewDeviceInfo as DeviceInfo);

					LOGI('read card deviceInfo', encodedNewDeviceInfo);

					return Promise.resolve(encodedNewDeviceInfo);
				} catch (error) {
					Counter.increaseRead('failed');

					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.readCard,
			commandType: NfcCommandType.read
		});
	}

	/**
	 * 获取要写卡的数据
	 * @param cardData 读到的卡模式数据
	 * @param settingJSON 要设置的json 
	 * @param currentDeviceInfo 当前的设备信息
	 * @param readDeviceInfo 写入时先读取的的设备信息
	 */
	async getWriteCardInfo({
		readCardData,
		settingJSON,
		deviceInfo, 
		readDeviceInfo
	}: {
		readCardData: number[],
		settingJSON: string, 
		deviceInfo: DeviceInfo, 
		readDeviceInfo: DeviceInfo
	}) {
		const readDeviceModel = getDeviceModel(readDeviceInfo.sn, readDeviceInfo.model, readDeviceInfo.pn, readDeviceInfo.subModel);
		const currentDeviceModel = deviceInfo.model;

		//型号不匹配
		if(readDeviceModel != currentDeviceModel) {
			return Promise.reject(NfcError.unmatchedDeviceModel);
		}

		/**
		 * 支持的频段不匹配
		 * 
		 * 如果没有Lora设置是不存在supportFreq，所以readDeviceInfo.supportFreq 不为空时
		 * &&
		 * supportFreq不相等时
		 * 
		 */
		if(readDeviceInfo.supportFreq != undefined && readDeviceInfo.supportFreq != deviceInfo.supportFreq) {
			return Promise.reject(NfcError.unmatchFreq);
		}

		//如果卡的版本大于当前写入的数据版本，则报错
		if(readDeviceInfo.cardVersion > deviceInfo.cardVersion) {
			return Promise.reject(NfcError.cardDataVersionTooLow);
		}

		//被写入设备不支持随机密钥时,则报错
		if(!readDeviceInfo.supportRandomKey && deviceInfo.keyMode === 1) {
			return Promise.reject(NfcError.notSupportRandomKey);
		}

		const isSupportNewCardMode = readDeviceInfo.cardVersion > 0;
		const cardHeader = isSupportNewCardMode 
			? {
				/**
				 * 卡模式下写入
				 * 1、先从状态页读取了设备信息 deviceInfo中keyMode和cardVersion是有值存在
				 * 2、如果状态页不读取,直接在设置页面选择设备型号，直接用设置页默认配置的模板写入时keyMode和cardVersion就应该从readDeviceInfo
				 * 3、deviceInfo和readDeviceInfo都不存在keyMode和cardVersion，则给默认初始值0和1
				 */
				keyMode: deviceInfo.keyMode ?? readDeviceInfo.keyMode ?? 0,
				cardVersion: deviceInfo.cardVersion ?? readDeviceInfo.cardVersion ?? 1,
				cardStatus: 1
			}
			: {
				cardVersion: readDeviceInfo.cardVersion ?? 0,
				keyMode: readDeviceInfo.cardVersion ?? 0,
				cardStatus: readDeviceInfo.cardVersion ?? 1
			};
		const setCardResult = await DeviceUtils.setCardInfo(readCardData, settingJSON, cardHeader);
		const writeCardData = setCardResult.encodeData;

		//如果code不是1，就代表写入失败
		if(setCardResult.code != 1) {
			return Promise.reject(setCardResult.code);
		}

		return {
			cardHeader,
			cardData: writeCardData,
			cardDataSize: writeCardData.length,
			settingJSON
		};
	}

	/**
	 * 写入卡数据
	 */
	async newWriteCardData(settingJSON: string, deviceInfo: DeviceInfo) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseWrite('total');
					let isSetTotalProgress = false;
					const password = this.getDevicePassword();

					//需要先去读数据，再进行后面的步骤
					const cardDataLength = await this.commander.getCardDataLength();

					//接收数据，则提前设置好总进度
					if(!isSetTotalProgress) { 
						const sendCount = Math.ceil(cardDataLength / 8) + 1;
						this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.writeCard);
						isSetTotalProgress = true;
					}

					const readCardData = await this.commander.readCardData(cardDataLength);
					const readCardInfo = await this.getReadCardInfo(readCardData);
					const writeCardInfo = await this.getWriteCardInfo({
						readCardData: readCardInfo.cardData,
						readDeviceInfo: readCardInfo.deviceInfo,
						deviceInfo,
						settingJSON
					});
					
					if(!isSetTotalProgress) {
						const sendDataCount = Math.ceil(writeCardInfo.cardDataSize / 8);
						this.tracker.setTotalProgressFromSendCount(sendDataCount, NfcCommandName.writeCard);
						isSetTotalProgress = true;
					}

					await NfcUtils.sleepWithMS(300);
					await this.commander.sendCardData(writeCardInfo.cardData);
					//TODO: 将redux的相关操作移动到redux中，移除业务逻辑
					const isChangePassword = _.get(deviceInfo, 'changePassword', false);

					//当非修改密码时，password以存储密码为值，修改密码时以新密码为值
					if(_.get(deviceInfo, 'password', '') != password) {
						if(!isChangePassword) {
							this.logger.debug('password changed');
							_.set(deviceInfo, 'password', password);
						}
					}
	
					const encodedNewdeviceInfo = encodePrivateKeys(deviceInfo);

					store.dispatch(setDeviceCardData(writeCardInfo.cardData));
					store.dispatch(setDeviceInfo(encodedNewdeviceInfo));
					store.dispatch(setPreDeviceInfo(encodedNewdeviceInfo)); 
					LOGI('write card device info', JSON.parse(writeCardInfo.settingJSON));
					Counter.increaseWrite('success');

					return Promise.resolve(writeCardInfo.cardData);
				} catch (error) {
					Counter.increaseWrite('failed');

					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.writeCard,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 写入卡数据
	 * @deprecated
	 */
	async writeCardData(settingJSON: string, newDeviceSettingInfo: DeviceInfo) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseWrite('total');
					let isSetTotalProgress = false;
					const password = this.getDevicePassword();
					let cardData = _.get(store.getState(), 'device.cardData', []);

					//如果没有card数据，则需要先去读数据，再进行后面的步骤
					if(cardData.length === 0) {
						const cardDataLength = await this.commander.getCardDataLength();

						//如果需要接收数据，则提前设置好总进度
						if(!isSetTotalProgress) { 
							const sendCount = Math.ceil(cardDataLength / 4 / 2) + 1;
							this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.writeCard);
							isSetTotalProgress = true;
						}

						const readCardData = await this.commander.readCardData(cardDataLength);
						
						cardData = _.slice(readCardData, 128);
					}

					this.logger.debug('cardData: ', cardData);
					const flashInfo = await DeviceUtils.setFlashInfo(cardData, settingJSON);
					const isChangePassword = _.get(newDeviceSettingInfo, 'changePassword', false);

					//如果code不是1，就代表写入失败
					if(flashInfo.code != 1) {
						throw new Error(flashInfo.code as unknown as string);
					}
	
					cardData = flashInfo.rawData;
					let dataSize = JSON.parse(flashInfo.result).datasize;
					let compressedData: number[] = []; //已经被压缩过的card data

					if(this.needCompressCardData) {
						const result = await DeviceUtils.encodeData(cardData);
						dataSize = result.size;
						compressedData = result.data;
					}
					
					if(!isSetTotalProgress) {
						const sendDataCount = Math.ceil(dataSize / 4 / 2);
						this.tracker.setTotalProgressFromSendCount(sendDataCount, NfcCommandName.writeCard);
						isSetTotalProgress = true;
					}

					await NfcUtils.sleepWithMS(300);
					const result = await this.commander.sendCardData(this.needCompressCardData ? compressedData : cardData);
					this.logger.debug('result: ', result);

					//当非修改密码时，password以存储密码为值，修改密码时以新密码为值
					if(_.get(newDeviceSettingInfo, 'password', '') != password) {
						if(!isChangePassword) {
							this.logger.debug('password changed');
							_.set(newDeviceSettingInfo, 'password', password);
						}
					}
	
					const encodedNewdeviceInfo = encodePrivateKeys(newDeviceSettingInfo);

					store.dispatch(setDeviceCardData(cardData));
					store.dispatch(setDeviceInfo(encodedNewdeviceInfo));
					store.dispatch(setPreDeviceInfo(encodedNewdeviceInfo)); 
					LOGI('write card deviceInfo', JSON.parse(settingJSON));
					Counter.increaseWrite('success');

					return Promise.resolve(cardData);
				} catch (error) {
					let msg = error;

					if(error === 'wrongPassword') {
						msg = translate('tips.wrongPassword');
					}

					if(error === NfcError.sendFailed) {
						msg = translate('tips.writeFailed');
					}

					Counter.increaseWrite('failed');

					return Promise.reject(msg);
				}
			},
			commandName: NfcCommandName.writeCard,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 发送开机命令
	 */
	async powerOn() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					Counter.increaseOperate('total');
					this.logger.debug('start powerOn');
					await this.commander.sendCommand(NfcCommandName.powerOn, {password});
					store.dispatch(setDeviceInfo({
						deviceState: 1
					}));

					Counter.increaseOperate('success');
		
					return Promise.resolve();
				} catch (error) {
					Counter.increaseOperate('failed');
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.powerOn,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcPowerOn')
		});
	}

	/**
	 * 写入证书，EM400NB特有
	 * ⚠️EM400NB设备上传证书设备端需要预留100000ms将证书导入MCU，设备端无法实现，目前由前端限制10S进度。
	 * @param {number} type 证书类型：「根文件证书」为1，「客户端证书」为2，「客户端密钥」为3	
	 * @param {number} mode 应用模式：「AWS」为3，「MQTT」为4
	 * @param {string} data 证书内容
	 * @param {number} checkData 证书校验值
	 * @param {number} waitTime 等待时间，单位秒
	 * @param {string} firmwareVersion 固件版本，用于判断使用新逻辑还是旧逻辑
	 */
	async writeEM400NBCertificate(type: 1 | 2 | 3, mode: number, data: string, checkData: number, waitTime: number = 0, firmwareVersion?: string) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseOperate('total');
					
					const password = this.getDevicePassword();
					const dataArr = NfcConverter.strToDecimalArr(data, 'utf-8');
					const dataSize = dataArr.length;
					const isFirmwareGreaterThan1_4 = firmwareVersion ? Version.isGreaterThan(firmwareVersion, 'v1.4') : false;
					
					if (!isFirmwareGreaterThan1_4) {
						waitTime && await NfcUtils.sleepWithMS(waitTime * 0.2 * 1000);
					}
					
					await this.commander.sendCommand(NfcCommandName.writeEM400NBCertificate, { password, mode, dataSize, type, checkData });
					await this.commander.sendFlashData({
						data: dataArr, 
						dataSize
					});
					
					if (isFirmwareGreaterThan1_4) {
						await this.commander.checkReadable(45000);
						await this.commander.checkWriteSuccess();
					} else {
						waitTime && await NfcUtils.sleepWithMS(waitTime * 0.8 * 1000);
					}
					
					Counter.increaseOperate('success');
					return Promise.resolve('success');
				} catch (error) {
					Counter.increaseOperate('failed');
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.writeEM400NBCertificate,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 写入证书
	 * 因原EM400NB证书指令地址和写入SDI指令地址冲突，故新增，后续建议此为标准写入证书指令
	 * @param {number} type 证书类型：「根文件证书」为1，「客户端证书」为2，「客户端密钥」为3	
	 * @param {number} mode 应用模式：「AWS」为3，「MQTT」为4
	 * @param {string} data 证书内容
	 * @param {number} checkData 证书校验值
	 */
	async writeCertificate(type: 1 | 2 | 3, mode: 3 | 4, data: string, checkData: number, newDeviceSettingInfo: DeviceInfo) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const dataArr = NfcConverter.strToDecimalArr(data, 'utf-8');
					const dataSize = dataArr.length;
					await this.commander.sendCommand(NfcCommandName.writeCertificate, { password, mode, dataSize, type, checkData });
					await this.commander.sendFlashData({
						data: dataArr, 
						dataSize
					});
					await this.commander.checkReadable(20000);
					await this.commander.checkWriteSuccess();
					return Promise.resolve('success');
				} catch (error) {
					return Promise.reject(error);
				}
			},
			action: this.getAction('NfcWriteCertificateFile', type, mode, 0, data, newDeviceSettingInfo),
			commandName: NfcCommandName.writeCertificate,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 写入AT指令
	 * @param {string} command 指令内容
	 */
	async writeATCommand(command: string) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const dataArr = NfcConverter.strToDecimalArr(command, 'utf-8');
					const dataSize = dataArr.length;
					await this.commander.sendCommand(NfcCommandName.atDebugger, { password, dataSize });
					await this.commander.sendFlashData({
						data: dataArr, 
						dataSize
					});
					await this.commander.checkReadable(90000);
					const dataLength: any = await this.commander.getAckDataLength();		
					const finalData = await this.commander.receiveFlashData(dataLength);
					const finalDataStr = String.fromCharCode(...finalData);
					return Promise.resolve(finalDataStr);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.atDebugger,
			commandType: NfcCommandType.write,
			action: this.getAction('NfcWriteATCommand', command)
		});
	}
	

	/**
	 * 开启EM400NB的串口日志模式
	 */
	async setDebuggerOn() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseOperate('total');
	
					const password = this.getDevicePassword();
					await this.commander.sendCommand(NfcCommandName.debuggerOn, {password});
				
					Counter.increaseOperate('success');
					return Promise.resolve('success');
				} catch (error) {
					Counter.increaseOperate('failed');
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.debuggerOn,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 关闭EM400NB的串口日志模式
	 */
	async setDebuggerOff() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseOperate('total');
		
					const password = this.getDevicePassword();
					await this.commander.sendCommand(NfcCommandName.debuggerOff, {password});
					
					Counter.increaseOperate('success');
					return Promise.resolve('success');
				} catch (error) {
					Counter.increaseOperate('failed');
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.debuggerOff,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 发送关机命令
	 */
	async powerOff() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseOperate('total');
					const password = this.getDevicePassword();
	
					this.logger.debug('start powerOff');
					await this.commander.sendCommand(NfcCommandName.powerOff, {password});
		
					store.dispatch(setDeviceInfo({
						deviceState: 0
					}));
					Counter.increaseOperate('success');
					return Promise.resolve();
				} catch (error) {
					Counter.increaseOperate('failed');
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.powerOff,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcPowerOff')
		});
	}

	/**
	 * 获取命令（UC500特有）
	 * @param {number} gpioIndex gpio索引，1/2
	 * @param {number} gpioValue 0: 关闭、1: 开启
	 */
	async gpioSwitch(gpioIndex: 1 | 2, gpioValue: 0 | 1) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start gpioSwitch');
					const result = await this.commander.sendCommand(NfcCommandName.gpioSwitch, {password, gpioIndex, gpioValue});
		
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.gpioSwitch,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 发送同步时间的命令
	 * @param timestamp 时间戳
	 * @param timezoneMin 时区偏移分钟数
	 */
	async syncTime(
		{timestamp, timezoneMin} :
		{timestamp?: number, timezoneMin?: number}
	) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const time = timestamp ?? moment().unix();
					const timezoneMinute = timezoneMin ?? getLocalStandardUTCOffset();
					//时区偏移小时 * 10
					const timezoneHour = timezoneMinute / 60 * 10;
					const timezoneKey = timezoneMin != null ? 'timezoneMin' : 'timezone';
					const timezoneValue = timezoneMin != null ? timezoneMinute : timezoneHour;
					const password = this.getDevicePassword();

					await this.commander.sendCommand(NfcCommandName.syncTime, {password, time, timeZone: timezoneValue});

					let rawData = _.get(store.getState(), 'device.rawData', []);
					const flashInfo = await DeviceUtils.setFlashInfo(rawData, JSON.stringify({[timezoneKey]: timezoneValue}));

					if(flashInfo.code != 1) {
						throw flashInfo.code;
					}

					rawData = flashInfo.rawData;
					store.dispatch(setDeviceRawData(rawData));
					store.dispatch(setDeviceInfo({deviceTime: time, [timezoneKey]: timezoneValue}));
	
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.syncTime,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcSyncTime', timestamp, timezoneMin)
		});
	}

	/**
	 * 发送设备重置的命令
	 */
	async reset() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					this.logger.debug('start reset');
					const password = this.getDevicePassword();
					const sn = getDeviceInfo(store.getState() as any).sn;
					await this.commander.sendCommand(NfcCommandName.reset, {password});
	
					store.dispatch(setDeviceInfo({
						password: '123456'
					}));

					//是否记住密码
					const {isRemember} = DevicePasswordManager.getPasswordBySn(sn, false);
					if(isRemember) {
						DevicePasswordManager.setPasswordBySn(sn, '123456');
					}
					DevicePasswordManager.setPasswordBySn(sn, '123456', true);

					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.reset,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcReset')
		});	
	}

	/**
	 * 发送设备重启命令
	 */
	async restart() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					this.logger.debug('start restart');
	
					const password = this.getDevicePassword();
					await this.commander.sendCommand(NfcCommandName.restart, {password});
	
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.restart,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcReboot')
		});
	}

	/**
	 * 手动校准命令
	 */
	async manualCalibration() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start manualCalibration');
					await this.commander.sendCommand(NfcCommandName.manualCalibration, {password});
		
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.manualCalibration,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 恢复出厂校准命令
	 */
	async factoryCalibration() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start factoryCalibration');
					await this.commander.sendCommand(NfcCommandName.factoryCalibration, {password});
		
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.factoryCalibration,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 气体校准命令
	 * @param {number} value 标定值，0/50
	 * @param {number} type 0: 灵敏度标定、1: 灵敏度设置
	 */
	async gasCalibration(value: number, type: 0 | 1) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start gasCalibration');
					await this.commander.sendCommand(NfcCommandName.gasCalibration, {password, value, type});
		
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.gasCalibration,
			commandType: NfcCommandType.operate
		});
	}
	
	/**
	 * 电机校准 WT102
	*/
	async calibrateMotor() {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcCalibrateMotor'),
			commandName: NfcCommandName.calibrateMotor,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 设置相对初始面（以下功能都复用该命令）
	 * 1. 设置相对初始面
	 * 2. G值标定
	 * 3. 电机行程校准
	 */
	async relativeInitialSurface(type: 'setting' | 'clear' | 'zero-setting' | 'zero-clear') {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start relativeInitialSurface');
					await this.commander.sendCommand(NfcCommandName.relativeInitialSurface, {password, type });
		
					return Promise.resolve();
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.relativeInitialSurface,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcRelativeInitialSurface', type)
		});
	}

	/**
	 * 氨气/硫化氢校准命令
	 * @param type nh3/h2s
	 * @param action clear/setting
	 * @param value 标定值
	 */
	async nh3Calibration(type: 'nh3' | 'h2s', action: 'clear' | 'setting', value: number) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					this.logger.debug('start nh3Calibration');
					const password = this.getDevicePassword();

					await this.commander.sendCommand(NfcCommandName.nh3Calibration, {password, type, action, value});

					return Promise.resolve();
				} catch (error) {
					Log.e('NFC', 'calibration error', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.nh3Calibration,
			commandType: NfcCommandType.operate
		});
	}


	/**
	 * 采集命令（UC500特有）
	 * @param {string} type 通道类型，ai/modbus/sdi
	 * @param {number} index 0：所有通道、1：通道 1、 2：通道2、以此类推
	 * @param {string} instruction 指令
	 * @param {boolean} shouldSendInstructionFlash 是否单独将指令发送一次透传
	 */
	async collect(type: Metric.COLLECT_METRIC | 'sdi', index: number, instruction?: string, shouldSendInstructionFlash?: boolean) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					let result = '';
					this.logger.debug('start collect');

					if (instruction && shouldSendInstructionFlash) {
						result = await this.commander.sendCommand(NfcCommandName.collect, { password, type, index });
						const dataArr = NfcConverter.strToDecimalArr(instruction, 'utf-8');
						const dataSize = dataArr.length;
						await this.commander.sendFlashData({
							data: dataArr,
							dataSize
						});
						await this.commander.checkReadable();
						await this.commander.checkWriteSuccess();
					} else {
						result = await this.commander.sendCommand(NfcCommandName.collect, { password, type, index, instruction });
					}

					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.collect,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 发送获取命令
	 * @param {number[]} command 
	 * @param {object} data 
	 */
	async sendFetchCommand(data: {
		type: Metric.COLLECT_METRIC | 'sdi',
		index: number;
		password: string;
		aiType?: 0 | 1;
		signed?: boolean | boolean[];
		firmware?: string;
		hardware?: string;
		isUC50xV3?: boolean;		
	}) {
		try {
			const dataLength = await this.commander.sendCommand(NfcCommandName.fetch, data);
			this.tracker.setTotalProgressFromSendCount(this.commander.getSendCount(dataLength), NfcCommandName.fetch);
			const finalData = await this.commander.receiveFlashData(dataLength);

			let value;
			if(data.type !== 'sdi') {
				if(data.isUC50xV3) {
					const buffer = Buffer.from(finalData);
					// 以小端序解释 Buffer 中的字节序列为 16 位整数
					const intValue = buffer.readUInt16LE(2);  // 从第 3 个字节开始读取
					if (intValue === 65533) {
						value = 65533;
					} else {
						const hexData = readFloat16LE(_.slice(finalData, 2, 4));
						value = hexData.toFixed(2);
					}
				} else {
					const decodePayload = Buffer.from(_.slice(finalData, 0, dataLength)).toString('base64');
					const device = Device.create(Device.MODEL.UC501);
					device.data.firmware = data.firmware;
					device.data.hardware = data.hardware;
		
					device.metrics().pick(Metric.CollectMetric).list().forEach(m => {
						if(m.type === Metric.COLLECT_METRIC.AI) {
							m.applySettings({
								enabled: true,
								dataType: data.aiType === 0 ? Metric.AIN_DATA_TYPE.CURRENT : Metric.AIN_DATA_TYPE.VOLTAGE
							});
						} else {
							m.applySettings({enabled: true});
						}
					});
					device.metrics().pick(Metric.ChannelCollectMetric).list().forEach((m, i) => {
						const signed = _.isArray(data.signed) ? _.get(data.signed, i , false) : data.signed;
						m.applySettings({signed: signed || false});
					});
					const reportService = device.componentInstance(
						LORA_REPORT_SERVICE,
						device,
					);
					await reportService.handleReportData(decodePayload);
		
					//0代表获取所有通道的值
					if(data.index === 0) {
						const metricType = data.type === Metric.COLLECT_METRIC.CHN ? 
							Metric.ChannelCollectMetric : 
							data.type === Metric.COLLECT_METRIC.AI ? Metric.AinCollectMetric : Metric.DioCollectMetric;
						const values = device.metrics().pick(metricType).list().map(m => {
							return m.getText();
						});
						this.logger.debug('sendFetchCommand device: ', device.data);
						this.logger.debug('sendFetchCommand values: ', values);
						return Promise.resolve(values);
					}
		
					const metric = device.metrics().get(data.type + data.index);
					value = metric?.getText();
				}
			} else {
				const getValue = (arr: number[]) => {
					return  Buffer.from(arr).toString();
				};
				if(data.index === 0) {
					const valueMap = new Map();
					for(let i = 0; i < finalData.length; i += 37) {
						const arr = finalData.slice(i, i + 37);
						const result = getValue(arr);
						valueMap.set(arr[0], result);
					}
					value = valueMap;
					this.logger.debug('valueMap', valueMap);
				} else {
					value = getValue(finalData);
				}				
			}			

			this.logger.debug('sendFetchCommand success');

			return Promise.resolve(value);
		} catch (error) {
			this.logger.debug('sendFetchCommand error: ', error);
			if(error === 8) {
				return Promise.reject(8);
			}
			return Promise.resolve('-');
		}
	}

	/**
	 * 获取命令（UC500特有）
	 * @param {Object} params - 参数
	 * @param {string} params.type - 通道类型，ain/chn/gpio
	 * @param {number} params.index - 0：所有通道、1：通道1、2：通道2、以此类推
	 * @param {number} [params.aiType] - 0: 4-20mA、1: 0-10v
	 * @param {boolean | boolean[]} [params.signed = false] - 是否有符号, 数组boolean表示多通道的signed（通道）
	 */
	async fetch(params: {
		type: Metric.COLLECT_METRIC | 'sdi',
		index: number;
		aiType?: 0 | 1;
		signed?: boolean | boolean[];
		firmware?: string;
		hardware?: string;
		isUC50xV3?: boolean;
	}) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start fetch');
					const result = await this.sendFetchCommand({...params, password});
		
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.fetch,
			commandType: NfcCommandType.fetch
		});
	}

	/**
	 * 读取counter状态命令（UC500特有）
	 * @param {number} index gpio索引，1/2
	 * @param {any} type 端口类型
	 * @return fetchResult：读取结果、 readCounterCtrlResult：0 - stop、1 - start
	 */
	async readCounterCtrl(index: 1 | 2, type:  Metric.COLLECT_METRIC) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const fetchResult = await this.sendFetchCommand({type, index, password});
					NfcUtils.sleepWithMS(500);
					const dataLength = await this.commander.sendCommand(NfcCommandName.readCounterCtrl, {index, password});
					const finalData = await this.commander.receiveFlashData(dataLength);
		
					this.logger.debug('finalData: ', finalData);
					this.logger.debug('fetchResult: ', fetchResult);
		
					return Promise.resolve({ fetchResult, readCounterCtrlResult: finalData[0] });
				} catch (error) {
					return Promise.reject(error);	
				}
			},
			commandName: NfcCommandName.readCounterCtrl,
			commandType: NfcCommandType.read
		});
	}

	/**
	 * 写入counter控制命令（UC500、EM300-DI有）
	 * @param {number} gpioIndex gpio索引，1/2
	 * @param {number} value 0 - write、 1 - stop、 2 - start 
	 * @param {number} count number - 写入值、 0 - clear
	 */
	async writeCounterCtrl(gpioIndex: 1 | 2, value: 0 | 1 | 2, count = 0) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start writeCounterCtrl', gpioIndex, value, count);
					const result = await this.commander.sendCommand(NfcCommandName.writeCounterCtrl, {password, index: gpioIndex, value, count});
		
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.writeCounterCtrl,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 写入counter控制命令（UC500特有）
	 * @param {number} valveIndex 电磁阀索引，1/2
	 * @param {number} status 0 - 关闭、 1 - 开启
	 */
	async controlValve(valveIndex: 1 | 2, status: 0 | 1) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();

					this.logger.debug('start controlValve', valveIndex, status);
					const result = await this.commander.sendCommand(NfcCommandName.controlValve, {password, index: valveIndex, status});
	
					store.dispatch(setDeviceInfo({
						[valveIndex === 1 ? 'solenoidState1' : 'solenoidState2']: status
					}));
		
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.controlValve,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 电磁阀写入
	 * @param {number} valveIndex 电磁阀索引，1/2
	 * @param {number} valveState 开度1-200
	 */
	async controlElectricValve(valveIndex: 1 | 2, valveState: number) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const result = await this.commander.sendCommand(NfcCommandName.controlElectricValve, {password, index: valveIndex, status: valveState});
					store.dispatch(setDeviceInfo({
						[valveIndex === 1 ? 'valveState1' : 'valveState2']: valveState
					}));
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.controlElectricValve,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 读取电磁阀
	 * @param {number} valveIndex 电磁阀索引，1/2
	 */
	async readElectricValve(valveIndex: 1 | 2) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const dataLength = await this.commander.sendCommand(NfcCommandName.readElectricValve, {id: valveIndex});
					const result = await this.commander.receiveFlashData(dataLength);
					const deviceInfo = getDeviceInfo(store.getState() as any);
					const valveConfig = _.get(deviceInfo, 'valveConfig', []);
					if(valveConfig.length > 0) {
						valveConfig[valveIndex === 2 ? 1 : 0]!.totalReferenceValue = result[0];
						valveConfig[valveIndex === 2 ? 1 : 0]!.totalRightReferenceValue = result[1];
					}
					store.dispatch(setDeviceInfo({
						['valveConfig']: valveConfig
					}));
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.readElectricValve,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 测试电磁阀
	 * @param {number} valveIndex 电磁阀索引，1/2
	 */
	async testElectricValve(valveIndex: 1 | 2) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const result = await this.commander.sendCommand(NfcCommandName.testElectricValve, {password, id: valveIndex});
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.testElectricValve,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 检查升级，校验镜像数据
	 * @param data 升级镜像数据
	 */
	async checkUpgrade({ data, reboot, moduleId, listenTag, isSubModule }: { data: number[], reboot?: boolean, moduleId?: number, listenTag?: boolean, isSubModule?: boolean }) {
		const handler = async () => {
			this.logger.debug("check upgrade");
			const password = this.getDevicePassword();
			const deviceInfo = getDeviceInfo(store.getState() as any);
			const modelSeries = getModelSeries(deviceInfo.model) as MODEL_SERIES;
			const { upgradeDataStartPosition, checkData, checkUpgradeDataSendCount } = UpgradeHelper.getUpgradeCheckData(data, modelSeries);
			//仅在IPSO的动作中使用，这里仅做占位
			const frameDataSize = data.length - upgradeDataStartPosition!;

			try {
				await this.commander.checkUpgradeData({ password, checkData, checkSendCount: checkUpgradeDataSendCount, reboot, moduleId });
			
				return Promise.resolve({
					inBootloader: false,
					frameDataSize
				});
			} catch (error) {
				this.logger.error("checkUpgrade error:", error);
				if(error === NfcError.inBootloader) { //如果在bootloader中，则直接发送镜像数据
					return Promise.resolve({
						inBootloader: true,
						frameDataSize
					});
				}
				//如果是ackError(校验文件失败)或者发送失败，则认为其是升级校验失败，用于显示错误信息
				if(error === NfcError.ackError || this.commander.checkIsTransceiveFail(error as any)) {
					return Promise.reject(NfcError.upgradeCheckFailed);
				}

				return Promise.reject(error);
			}
		};

		if(!listenTag) {
			const checkUpgradeDataAction = ActionManager.getAction('NfcCheckUpgrade', this.actionApi);
			const canExecuteAction = await ActionManager.checkActionCanExecute(checkUpgradeDataAction);

			if(canExecuteAction) {
				this.logger.debug("action can be executed, run action CheckUpgrade");
				return checkUpgradeDataAction?.execute({data, isSubModule: isSubModule || false});
			}

			return handler();
		}

		return this.setTagDiscoveryListener({
			listener: handler,
			action: this.getAction('NfcCheckUpgrade', {data, isSubModule: isSubModule || false}),
			commandName: NfcCommandName.checkUpgrade,
			commandType: NfcCommandType.upgrade
		});
	}

	/**
	 * 发送升级镜像数据
	 * @param data - 升级镜像数据
	 * @param frameSize - 发送一帧的数据大小
	 * @param inBootloader - 是否在bootloader中
	 * @param listenTag - 是否监听标签
	 */	
	async sendUpgradeData(params: {
		data: number[];
		frameDataSize: number;
		inBootloader: boolean;
		listenTag: boolean;
		reboot?: boolean;
		isSubModule?: boolean;
		successMessage?: string;
		moduleId?: number;
		hasSubModule?: boolean;
	}) {
		this.logger.debug("send upgrade data ready", _.omit(params, 'data'));
		const { data, listenTag, inBootloader, reboot, successMessage, isSubModule, moduleId, hasSubModule } = params;
		const commandName = NfcCommandName.sendUpgradeData;
		const commandType = NfcCommandType.upgrade;
		const deviceInfo = getDeviceInfo(store.getState() as any);
		const modelSeries = getModelSeries(deviceInfo.model) as MODEL_SERIES;
		const password = this.getDevicePassword();
		//EM400NB系列的设备升级处理时间较长，需要设置较长的超时时间
		const checkTimeout = [ ...EM400NB_SERIES, MODELS['VS370'] ].includes(deviceInfo.model as MODELS) ? 25000 : 5000;
		const { upgradeDataStartPosition, checkData, checkUpgradeDataSendCount } = UpgradeHelper.getUpgradeCheckData(data, modelSeries);
		const handler = async () => {
			try {
				//如果之前不在bootloader中，则先校验镜像数据
				if(!inBootloader) {
					try {
						this.logger.debug("check upgrade data");
						await this.commander.checkUpgradeData({ password, checkData, checkSendCount: checkUpgradeDataSendCount, reboot, moduleId });
					} catch (error) {
						if(error !== NfcError.inBootloader) { //如果在bootloader中就继续，不在bootloader中则返回失败
							return Promise.reject(error);
						}
					}
				}
				this.logger.debug("start send upgrade data");

				//这里每2k更新一次进度条，因为循环里去掉了checkWriteable，所以这里的sendCount不需要 * 2
				const sendCount = Math.floor((data.length - upgradeDataStartPosition!) / 2048 / 2);
				this.tracker.beforeStart(NfcCommandName.sendUpgradeData, NfcCommandType.upgrade);
				this.tracker.onStart(); //重新开始进度
				this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.sendUpgradeData);
				await this.commander.sendUpgradeData({
					password,
					data,
					upgradeDataStartPosition: upgradeDataStartPosition!,
					checkTimeout,
					reboot,
					moduleId
				});

				return Promise.resolve(true);
			} catch (error) {
				return Promise.reject(error);
			}
		};
		const actionParams = {
			...params,
			//目前只支持一个文件的升级，所以这里直接传入data
			data: [data]
		};

		if(!listenTag) {
			const sendUpgradeDataAction = ActionManager.getAction('NfcSendUpgradeData', this.actionApi);
			const canExecuteAction = await ActionManager.checkActionCanExecute(sendUpgradeDataAction);

			if(canExecuteAction) {
				this.logger.debug("action can be executed, run action SendUpgradeData");
				return sendUpgradeDataAction?.execute({...actionParams, isSubModule: isSubModule || false, reboot: reboot || false, hasSubModule: hasSubModule || false});
			} else if (!reboot) {
				const result = await handler();
				this.tracker.onSuccess(successMessage);

				return result;
			}

			return handler();
		}

		return this.setTagDiscoveryListener({
			listener: handler,
			action: this.getAction('NfcSendUpgradeData', {...actionParams, isSubModule: isSubModule || false, reboot: reboot || false, hasSubModule: hasSubModule || false}),
			commandName,
			commandType,
			reListen: reboot,
			stopDetection: reboot,
			successMessage
		});
	}

	/**
	 * 重置电量统计
	 */
	async resetPowerMeter() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					await this.commander.sendCommand(NfcCommandName.resetPowerMeter, {password});
					
					return Promise.resolve(0);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.resetPowerMeter,
			commandType: NfcCommandType.operate
		});	
	}

	/**
	 * 写入图片数据
	 * @param data 压缩好后的图片数据
	 */
	async writeImgData(data: number[]) {
		return this.setTagDiscoveryListener({
			listener: async () => {
				try {
					const password = this.getDevicePassword();
					const sendCount = this.commander.getSendCount(data.length); 
					this.logger.debug('sendCount: ', sendCount);

					this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.writeImgData);
					this.logger.debug(data.length);
					await this.commander.sendCommand(NfcCommandName.writeImgData, { password, dataSize: data.length });
					this.logger.debug('send command success');
					await this.commander.sendImgData(data);
				
					return Promise.resolve(true);
				} catch (error) {
					this.logger.debug('error: ', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.writeImgData,
			commandType: NfcCommandType.write 
		});
	}

	/**
	 * 读取设备历史数据
	 * @param expectedSingleHistoryDataSize 预估的每条读取的历史数据大小
	 */
	async readHistoryData(
		{
			startTime,
			endTime,
			model,
			reportInterval,
			type = 0,
			hardwareVersion,
			firmwareVersion,
			expectedSingleHistoryDataSize
		}:
			{
				startTime: number;
				endTime: number;
				model: string;
				reportInterval: number;
				type: number;
				hardwareVersion: string;
				firmwareVersion: string;
				expectedSingleHistoryDataSize: number
			}) {
		return this.setTagDiscoveryListener({
			listener: async () => {
				try {
					const password = this.getDevicePassword();
					const currentTime = moment().unix();
				
					//选择的时间内有效的历史数据条数
					const timeDiffHistoryDataLength = Math.ceil((endTime - startTime) / reportInterval);
					this.logger.debug('timeDiffHistoryDataLength: ', timeDiffHistoryDataLength);
					//选择的时间内有效的历史数据大小
					const availableDataSize = timeDiffHistoryDataLength * expectedSingleHistoryDataSize;
					const sendCount = Math.ceil(this.commander.getSendCount(availableDataSize));
					let readHistoryData: Array<Record<string, any>> = [];
					//TS201获取设备历史数据条数的时间可能要较长的时间，所以设置较长的超时时间
					const checkReadableTimeout = model === MODELS['TS201'] ? 10000 : 5000;

					this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.readHistoryData);

					//如果有多个分区(type)，则需要循环读取历史数据
					for (let index = 0; index < type + 1; index++) {
						const ackDataLength = await this.commander.sendCommand(NfcCommandName.readHistoryData,
							{ startTime, endTime, password, currentTime, type: index },
							false,
							{ checkReadableTimeout }
						);
						const dataLengthResponse = await this.commander.receiveFlashData(ackDataLength);
						//设备当前所有历史数据条数
						const allHistoryDataLength = Buffer.from(dataLengthResponse.slice(1, 5)).readUInt16LE(0);
						this.logger.debug('allHistoryDataLength: ', allHistoryDataLength);

						//如果预估的数据条数比实际多，则以实际条数为准设置进度
						if(timeDiffHistoryDataLength > allHistoryDataLength) {
							const allHistoryDataSize = allHistoryDataLength * expectedSingleHistoryDataSize;
							const allSendCount = 14 +  Math.ceil(this.commander.getSendCount(allHistoryDataSize)) * 2;

							this.tracker.setTotalProgress(allSendCount);
						}

						const { receiveHistoryData } = await this.commander.receiveHistoryData(allHistoryDataLength, model, firmwareVersion, hardwareVersion);
						readHistoryData = readHistoryData.concat(receiveHistoryData);
					}

					// 统一返回格式，传统模式deviceSn为空，UI层会回退使用Redux缓存
					return Promise.resolve({
						historyData: readHistoryData,
						deviceSn: ''
					});
				} catch (error) {
					LOGE('read history data error: ', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.readHistoryData,
			commandType: NfcCommandType.read,
			action: this.getAction('NfcReadHistoryData', {startTime, endTime})
		});
	}

	/**
	 * 读取设备日志数据
	 */
	async readDeviceLog(): Promise<number[]> {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					this.logger.debug('start read device log');
					const dataLength = await this.commander.sendCommand(NfcCommandName.readLog);
					const sendCount = this.commander.getSendCount(dataLength);
					
					this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.readLog);
	
					const readlogData = await this.commander.receiveFlashData(dataLength);		
		
					return Promise.resolve(readlogData);
				} catch (error) {
					Log.e('NFC', 'read device log failed', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.readLog,
			commandType: NfcCommandType.read
		});
	}


	/**
	 * 清空数据
	 * @param type 0：清空雨量，1：清空历史记录，2：清空累计进入人数，3：清空累计离开人数
	 * @returns 
	 */
	async writeClear(type: 0 | 1 | 2 | 3) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					await this.commander.sendCommand(NfcCommandName.writeClear, {password, type});
					
					return Promise.resolve(0);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.writeClear,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcWriteClear', {type})
		});	
	}

	/**
	 * 读取模板
	 * @param 
	 */
	async getDSTemplateData(templateId: number) {
		const result = await this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const res = await this.commander.sendCommand(NfcCommandName.readDSTemplate, {password: password, templateId: templateId}, true);
					this.logger.debug(res);
					const getDataLength = (data: number[], start: number, end: number) => {
						const buffer = Buffer.from(data.slice(start, end));
						if (end - start === 2) {
							return buffer.readUInt16LE(0);
						} else {
							return buffer.readUInt32LE(0);
						}						
					};
					const len = getDataLength(res, 26, 28);
					const logoSize = getDataLength(res, 28, 30);
					const baseSize = getDataLength(res, 30, 32);
					this.tracker.setTotalProgressFromSendCount(getDataLength(res, 10, 12) / 64, NfcCommandName.readDSTemplate);
					let tempData:number[] = [], logoData: number[] = [], baseData: number[] = [];

					if (len) {
						await NfcUtils.sleepWithMS(10);
						tempData = await this.commander.receiveFlashData(len);
					}
					if (logoSize) {
						await NfcUtils.sleepWithMS(100);
						logoData = await this.commander.receiveFlashData(logoSize);
					}
					if (baseSize) {
						await NfcUtils.sleepWithMS(100);
						baseData = await this.commander.receiveFlashData(baseSize);
					}
					
					const crc = res.slice(22, 26);
					const footer = res.slice(26, 32);
					const header = crc.concat(res.slice(10, 12)).concat(footer).concat([ 0,0,0,0 ]);
					tempData = header.concat(tempData);
					const slicedTemplateData = _.slice(tempData, 0, len + 16);
					const flasInfo = await DeviceUtils.getDs3604Template(slicedTemplateData);
					const parseFlashInfo = JSON.parse(flasInfo);
					
					store.dispatch(setDSTemplateInfo(_.get(store.getState(), 'device.DSTemplateData').set(templateId, tempData)));
					LOGI('read DS templateData', parseFlashInfo);
					return Promise.resolve({tempData: parseFlashInfo, logoData: logoData, baseData: baseData});
				} catch (error) {
					return Promise.reject(error);	
				}
			},
			commandName: NfcCommandName.readDSTemplate,
			commandType: NfcCommandType.read
		}); 
		if (![ 'DETECTION_CANCELLED', 'DUPLICATE_REQUEST' ].includes(result)) {
			let logoData = result.logoData, baseData = result.baseData; 
			if (logoData.length) {
				logoData = await DeviceUtils.getDS3604Picture(logoData);
				const width = Number('0x' + NfcConverter.decodeCommand(logoData.slice(7,9).reverse()));
				const height = Number('0x' + NfcConverter.decodeCommand(logoData.slice(9,11).reverse()));
				result.tempData['image'].forEach((img:any)=>{
					if (img.common.layer !== 0) {
						Object.assign(img.common, {endx: img.common.startx + width, endy: img.common.starty + height});
					}
				});
				logoData = logoData.slice(13);
				result.logoData = logoData;
			}
			if (baseData.length) {
				baseData = await DeviceUtils.getDS3604Picture(baseData);
				baseData = baseData.slice(13);
				result.baseData = baseData;
			}
		}
		return result;
	}

	/**
	 * 写入模板
	 * @param 
	 */
	async setDSTemplateData(
		template: { 
			templateId: number, 
			totalData: { 
				json: string, 
				imageData: {
					[key: string]: {
						width: number, 
						height: number, 
						data: number[]
					}
				}
			} 
		}) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseWrite('total');
					let isSetTotalProgress = false;
					const password = this.getDevicePassword();
					const DSTemplateData = _.get(store.getState(), 'device.DSTemplateData');
					let rawData = new Array(2048).fill(0);
					if(DSTemplateData.has(template.templateId)) {
						rawData = DSTemplateData.get(template.templateId);
					}
					
					const DSTempInfo = await DeviceUtils.setDs3604Template(rawData, template.totalData.json);
					const dataSize = JSON.parse(DSTempInfo.result).datasize;
					const resRawdata = DSTempInfo.rawData.slice(0, dataSize + 16);
					const header = resRawdata.slice(0, 16);
					const { afterSendDataDelay } = this.nfcProxy.config;
					const logo = template.totalData.imageData['image-target'];
					let logoData:number[] = [];
					const base = template.totalData.imageData['background-target'];
					let baseData:number[] = [];
					
					if (logo) {
						logoData = await this.commander.setDS3604Picture({width: logo.width, height: logo.height, data: logo.data});
					}
					if (base) {
						baseData = await this.commander.setDS3604Picture({width: 400, height: 300, data: base.data});
					}
					//写入模板数据
					await this.commander.sendCommand(NfcCommandName.writeDSTemplate, { dataSize, password, logoSize: logoData.length, baseSize: baseData.length || 64, header, templateId: template.templateId });
					if(!isSetTotalProgress) {
						const sendDataCount = this.commander.getSendCount(dataSize + logoData.length + baseData.length);
						this.tracker.setTotalProgressFromSendCount(sendDataCount, NfcCommandName.writeDSTemplate);
						isSetTotalProgress = true;
					}
					
					await this.commander.sendFlashData({data: resRawdata.slice(16, resRawdata.length), dataSize});					
					if (logo) {
						await NfcUtils.sleepWithMS(100);
						await this.commander.sendTempImgData(logoData);
					}
					if (base) {
						await NfcUtils.sleepWithMS(100);
						await this.commander.sendTempImgData(baseData);
					} else {
						await NfcUtils.sleepWithMS(100);
						await this.commander.sendTempImgData(new Array(16).fill(0));
					}
					
					this.logger.debug('sendTempImgData end');
					await NfcUtils.sleepWithMS(afterSendDataDelay);
					await this.commander.checkReadable();
					await this.commander.checkWriteSuccess();

					store.dispatch(setDSTemplateInfo(_.get(store.getState(), 'device.DSTemplateData').set(template.templateId, resRawdata)));

					LOGI('write DS templateData', {
						totalData: _.omit(JSON.parse(template.totalData.json), 'image'),
						logoDataLength: logoData.length,
						baseDataLength: baseData.length
					});

					Counter.increaseWrite('success');
					return Promise.resolve();
				} catch (error) {
					Counter.increaseWrite('failed');
					Log.e('NFC', 'write DS templateData error', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.writeDSTemplate,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 获取SDI12设置
	 */
	async getSDI12Setting() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseRead('total'); 
					this.logger.debug('start read');	
					const dataLength = await this.commander.sendCommand(NfcCommandName.getSDI12Setting);
					const sendCount = this.commander.getSendCount(dataLength);
				
					this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.getSDI12Setting);

					const readFlashData = await this.commander.receiveFlashData(dataLength);
					//每次都要用实际的数据长度（设备给的数据长度）去解析
					//而不是实际接收到的数据长度（可能会因为64不能整除，而多接受64个字节）
					const slicedFlashData = _.slice(readFlashData, 0, dataLength);
					const sdiBaseInfo = await DeviceUtils.getSdiInfo(slicedFlashData);
					const parseSdiBaseInfo = JSON.parse(sdiBaseInfo);
					
					store.dispatch(setSDIData(_.slice(readFlashData, 128)));

					LOGI('read sdi setting', parseSdiBaseInfo);					
					Counter.increaseWrite('success');
					return Promise.resolve(parseSdiBaseInfo);
				} catch (error) {
					Counter.increaseWrite('failed');
					Log.e('NFC', 'get SDI12 setting error', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.getSDI12Setting,
			commandType: NfcCommandType.read
		});
	}

	/**
	 * SDI12设置
	 */
	async setSDI12Setting(SDIJson: Record<'sdi12', SDI12Setting>) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					Counter.increaseWrite('total');
					let isSetTotalProgress = false;
					const password = this.getDevicePassword();
					const SDIData = _.get(store.getState(), 'device.SDIData') || Array(3776).fill(0);
					const cloneData = _.cloneDeep(SDIJson);
					const sdiJSONStringify = JSON.stringify(cloneData);
					const SDIInfo = await DeviceUtils.setSdiInfo(SDIData, sdiJSONStringify);
					const dataSize = JSON.parse(SDIInfo.result).datasize;
					const { afterSendDataDelay } = this.nfcProxy.config;
					//写入flash数据
					await this.commander.sendCommand(NfcCommandName.setSDI12Setting, { dataSize, password });

					if(!isSetTotalProgress) {
						const sendDataCount = this.commander.getSendCount(dataSize);
						this.tracker.setTotalProgressFromSendCount(sendDataCount, NfcCommandName.setSDI12Setting);
						isSetTotalProgress = true;
					}
					
					await this.commander.sendFlashData({data: SDIInfo.rawData, dataSize});
					await NfcUtils.sleepWithMS(afterSendDataDelay);
					await this.commander.checkReadable();
					await this.commander.checkWriteSuccess();

					LOGI('write sdi setting', JSON.parse(sdiJSONStringify));
					Counter.increaseWrite('success');
					return Promise.resolve();
				} catch (error) {
					Counter.increaseWrite('failed');
					Log.e('NFC', 'set SDI12 setting error', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.setSDI12Setting,
			commandType: NfcCommandType.write
		});
	}

	/**
	 *  NB SDI12读取地址/读取采集数据
	 */
	async getSDIChannelOrFetch(id: number, type: 'channel' | 'fetch'): Promise<{
		channelId: number;
		isAllChannel: boolean;
		value: string;
		seconds: number;
		allChannelValue: {
			channelId: number;
			value: string;
		}[];
	}> {
		return this.setTagDiscoveryListener({
			listener: async () => {
				try {
					const password = this.getDevicePassword();
					const dataLength = await this.commander.sendCommand(NfcCommandName.getSDIChannelOrFetch, { password, id, type });
					this.tracker.setTotalProgressFromSendCount(this.commander.getSendCount(dataLength), NfcCommandName.getSDIChannelOrFetch);
					const finalData = await this.commander.receiveFlashData(dataLength);
					const reader = new Reader(finalData);
					this.logger.debug('finalData: ', reader.toString());

					const parseChannelData = () => {
						const channelId = reader.uint8();
						const dataBytes = reader.bytes(36); // 36字节为通道里的数据
						const value = String.fromCharCode(...dataBytes);
						return { channelId, value };
					};

					const parseAllChannelsData = () => {
						const data = [];
						while (reader.bytesAvailable() >= 37) {
							const channelData = parseChannelData();
							data.push(channelData);
						}
						return data.filter(item => item.value !== '');
					};

					const channelId = reader.uint8();
					const isAllChannel = channelId === 0;
					let value = '';
					let seconds = 0;
					let allChannelValue: { channelId: number; value: string; }[] = [];

					if (isAllChannel) {
						const sta = reader.uint8();
						const isData = sta === 0;
						if (isData) {
							// 接下来每37个字节一组，第一个字节是通道ID，剩下36字节则是通道里的数据
							allChannelValue = parseAllChannelsData();
						} else {
							seconds = reader.uint16LE();
						}
					} else {
						//@ts-ignore
						// eslint-disable-next-line @typescript-eslint/no-unused-vars
						const ctrl = reader.uint8();
						const sta = reader.uint8();
						const isData = sta === 0;
						if (isData) {
							const dataLength = finalData.length - 4; // 去除地址ID、控制字节和状态字节
							const dataArray = reader.bytes(dataLength);
							// eslint-disable-next-line no-control-regex
							value = String.fromCharCode(...dataArray).replace(/\u0000/g, ''); // 使用正则表达式替换所有 NULL 字符
						} else {
							seconds = reader.uint16LE();
						}
					}

					const result = {
						channelId,
						isAllChannel,
						value,
						seconds,
						allChannelValue
					};

					this.logger.debug('输出完整的结果对象', result); // 输出完整的结果对象

					return Promise.resolve(result);
				} catch (error) {
					Log.e('NFC', 'getSDIChannelOrFetch', error);
					return Promise.reject(NfcError.readRegisterError);
				}
			},
			commandName: NfcCommandName.getSDIChannelOrFetch,
			commandType: NfcCommandType.read
		});
	}


	/**
	 * 获取通道地址
	 */
	async getChannelAddress(id: number) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();	
					const dataLength = await this.commander.sendCommand(NfcCommandName.getChannelAddress, {password, id});
					this.tracker.setTotalProgressFromSendCount(this.commander.getSendCount(dataLength), NfcCommandName.getChannelAddress);
					const finalData = await this.commander.receiveFlashData(dataLength);
					const channelAddress = Buffer.from(finalData.slice(1,2)).toString();
					
					return Promise.resolve({ channelAddress });
				} catch (error) {
					Log.e('NFC', 'get SDI12 setting error', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.getChannelAddress,
			commandType: NfcCommandType.read
		});
	}

	/**
	 * 更改通道地址
	 */
	async setChannelAddress(newAddress: {
		id: number,
		preAddress: string,
		address: string
	}) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					this.logger.debug('start setChannelAddress');
					const result = await this.commander.sendCommand(NfcCommandName.setChannelAddress, {password, ...newAddress});
		
					return result ? Promise.reject(result) : Promise.resolve(result);
				} catch (error) {
					Counter.increaseWrite('failed');
					Log.e('NFC', 'set SDI12 setting error', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.setChannelAddress,
			commandType: NfcCommandType.write
		});
	}

	/**
	 * 距离校准
	 */
	async distanceCalibration() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
						
					await this.commander.sendCommand(NfcCommandName.distanceCalibration, { password });
						
					return Promise.resolve(0);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.distanceCalibration,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 距离盲区校准
	 */
	async distanceBlindZoneCalibration() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
							
					await this.commander.sendCommand(NfcCommandName.distanceBlindZoneCalibration, { password });
							
					return Promise.resolve(0);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.distanceBlindZoneCalibration,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 电机行程校准
	 */
	async strokeCalibration() {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					await this.commander.sendCommand(NfcCommandName.strokeCalibration, { password });
					
					return Promise.resolve(0);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.strokeCalibration,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 控制设备
	 * payload: 0 - 中止蜂鸣器响
	 */
	async controlDevice(payload: number) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					
					await this.commander.sendCommand(NfcCommandName.controlDevice, { password, payload });
					
					return Promise.resolve(0);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.controlDevice,
			commandType: NfcCommandType.operate
		});	
	}

	/**
	 * 准备差分升级(v1)
	 * 如果设备在application模式，则发送命令让设备进入bootloader模式
	 */
	@ActionManager.withAction('NfcReadyPatchUpgrade')
	async readyPatchUpgrade() {
		try {
			const password = this.getDevicePassword();
			const result = await this.commander.readyPatchUpgrade(password);
			this.logger.debug("ready patch upgrade result:", result);

			//用户取消了
			if (this.isCancel(result)) { 
				return Promise.reject(NfcError.detectionCancelled);
			}

			//如果设备在bootloader模式，则返回
			if(result.inBootloader) {
				return Promise.resolve({
					inBootloader: true,
					frameDataSize: 0
				});
			}

			return Promise.resolve({
				inBootloader: false,
				//仅在IPSO的动作中需要使用，这里仅做占位
				frameDataSize: 0
			});
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送差分升级数据(v1 只支持发送一个patch升级数据)
	 * @param data patch 升级数据
	 * @param crc CRC
	 * @param listenTag 是否监听标签
	 * @param inBootloader 是否在bootloader中
	 * @param frameDataSize 发送一帧的数据大小
	 */
	async sendPatchUpgradeData(params: {
			data: number[];
			crc: string;
			listenTag: boolean;
			inBootloader: boolean;
			frameDataSize: number;
		}) {
		const { data, crc, listenTag } = params;
		const handler = async() => {
			try {
				const password = this.getDevicePassword();
				const sendCount = this.commander.getSendCount(data.length);
				const reboot = true; //v1 差分升级数据发送完后，需要重启设备
				
				this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.sendPatchUpgrade);
				await this.commander.sendPatchUpgradeData(data, password, crc, reboot);
				
				return Promise.resolve(1);
			} catch (error) {
				return Promise.reject(error);
			}
		};

		const actionParams = {
			...params,
			data: [data],
			hasSubModule: false
		};

		if(!listenTag) {
			const sendPatchUpgradeDataAction = ActionManager.getAction('NfcSendPatchUpgradeData', this.actionApi);
			const canExecuteAction = await ActionManager.checkActionCanExecute(sendPatchUpgradeDataAction);
	
			if(canExecuteAction) {
				this.logger.debug("action can be executed, run action SendPatchUpgradeData");
				return sendPatchUpgradeDataAction?.execute(actionParams);
			}

			this.tracker.setCurrentCommand(NfcCommandName.sendPatchUpgrade);
			return handler();
		}

		return this.setTagDiscoveryListener({
			listener: handler,
			action: this.getAction('NfcSendPatchUpgradeData', actionParams),
			commandName: NfcCommandName.sendPatchUpgrade,
			commandType: NfcCommandType.upgrade
		});
	}
	
	/**
	 * 发送差分升级数据(v2 支持发送多个patch升级数据)
	 * @param data patch 升级数据
	 * @param crc CRC
	 * @param listenTag 是否监听标签
	 * @param inBootloader 是否在bootloader中
	 * @param frameDataSize 发送一帧的数据大小
	 * @param hasSubModule 是否有子模块
	 * 
	 * WT2X1 v2特殊处理，后续会移除以下参数
	 * @param iosDelayTime 延迟时间
	 * @param showToast 显示toast
	 * @param hideAllToast 隐藏所有toast
	 */
	async sendPatchUpgradeDatav2(params: {
		data: number[][];
		crc: string;
		listenTag: boolean;
		inBootloader: boolean;
		frameDataSize: number;
		hasSubModule: boolean;
		iosDelayTime: number;
		showToast: (options: any) => void;
		hideAllToast: () => void;
	}) {
		const { data, crc, listenTag, hasSubModule, iosDelayTime = 5000 } = params;
		const handler = async () => {
			try {
				const password = this.getDevicePassword();
				const dataLength = data.reduce((prev, current) => prev + current.length, 0);
				const sendCount = this.commander.getSendCount(dataLength);
				const totalUpgradeProgress = data.length;
				this.logger.debug("sendPatchUpgradeDatav2 all data length:", dataLength, sendCount);
				
				if(Platform.OS === 'android') {
					this.tracker.setTotalProgressFromSendCount(sendCount, NfcCommandName.sendPatchUpgrade);
				}

				if(Platform.OS === 'ios') {
					params.showToast({ title: translate('tips.upgrading'), showMask: false, status: 'loading', duration: 999999 });
				}

				for (let index = 0; index < data.length; index++) {
					const dataChunk = data[index];
					const currentUpgradeProgress = index + 1;
					const reboot = index === data.length - 1 ? true : false;
					this.logger.debug("sendPatchUpgradeDatav2 upgrade progress:", currentUpgradeProgress, dataChunk!.length, reboot);
	
					if(Platform.OS === 'ios') {
						//如果是第一次，就不需要重新开启会话
						if(index === 0) {
							const newSendCount = this.commander.getSendCount(dataChunk!.length);
							this.tracker.setTotalProgressFromSendCount(newSendCount, NfcCommandName.sendPatchUpgrade);

							await this.commander.sendPatchUpgradeData(dataChunk!, password, crc, reboot);
							this.tracker.onSuccess();
							this.logger.debug("sendPatchUpgradeDatav2 | dataChunk success:", index);
						} else { //如果是第二次及以后，每次发送数据前都需要重新开启会话
							await this.stopDetection(true);
							this.logger.debug("sendPatchUpgradeDatav2 | wait 5s for device ready");
							await NfcUtils.delay(iosDelayTime);
							await this.setTagDiscoveryListener({
								listener: async () => {
									try {
										this.logger.debug("sendPatchUpgradeDatav2 | check device is ready upgrade");
										//setTagDiscoveryListener会重置totalProgress，所以这里需要重新设置总进度
										const newSendCount = this.commander.getSendCount(dataChunk!.length) + 7 * 2; //7（检查设备是否准备好：发命令(5)+ 收数据(2)） * 2(可能需要发两次)
										this.tracker.setTotalProgressFromSendCount(newSendCount, NfcCommandName.sendPatchUpgrade);
										await this.commander.checkIsReadyUpgrade();
										await this.commander.sendPatchUpgradeData(dataChunk!, password, crc, reboot);
										this.logger.debug("sendPatchUpgradeDatav2 | dataChunk success:", index);
										return Promise.resolve(1);
									} catch (error) {
										return Promise.reject(error);
									}
								},
								commandName: NfcCommandName.sendPatchUpgrade,
								commandType: NfcCommandType.upgrade,
								reListen: false,
								alertMessage: `${translate('tips.upgrading')}(${currentUpgradeProgress})/(${totalUpgradeProgress})`
							});
						}
					} else {
						await this.commander.sendPatchUpgradeData(dataChunk!, password, crc, reboot);
						this.logger.debug("sendPatchUpgradeDatav2 | dataChunk success:", index);

						//如果是多次发送，且不是最后一个升级包，则等待3s，等设备处理完成后再继续
						if(data.length > 1 && index < data.length - 1) {
							this.logger.debug("sendPatchUpgradeDatav2 | wait 3s for device ready");
							await NfcUtils.delay(3000);
							this.logger.debug("sendPatchUpgradeDatav2 | check device is ready upgrade");
							await this.commander.checkIsReadyUpgrade();
						}
					}
				}

				return Promise.resolve(1);
			} catch (error) {
				return Promise.reject(error);
			} finally {
				if(Platform.OS === 'ios') {
					params.hideAllToast();
				}
			}
		};

		if(!listenTag) {
			const sendPatchUpgradeDataAction = ActionManager.getAction('NfcSendPatchUpgradeData', this.actionApi);
			const canExecuteAction = await ActionManager.checkActionCanExecute(sendPatchUpgradeDataAction);
	
			if(canExecuteAction) {
				this.logger.debug("action can be executed, run action SendPatchUpgradeData");
				return sendPatchUpgradeDataAction?.execute(params);
			}

			this.tracker.setCurrentCommand(NfcCommandName.sendPatchUpgrade);
			return handler();
		}

		console.log('send patch upgrade without stop Detection');

		const successMessage = hasSubModule
			? translate("tips.upgradeNextModule", {step: 1 , nextStep: 2})
			: undefined;

		return this.setTagDiscoveryListener({
			listener: handler,
			action: this.getAction('NfcSendPatchUpgradeData', params),
			commandName: NfcCommandName.sendPatchUpgrade,
			commandType: NfcCommandType.upgrade,
			reListen: false,
			stopDetection: !hasSubModule,
			successMessage: successMessage
		});
	}

	/**
	 * 获取设备产品信息
	 */
	@ActionManager.withAction('NfcGetProductInfo')
	async getProductInfo(): Promise<DeviceProductInfo | null> {
		try {			
			this.logger.debug("get product info");
			const dataLength = await this.commander.sendCommand(NfcCommandName.getProductInfo);
			const data = await this.commander.receiveFlashData(dataLength);
			//实际接收的数据大小通常是 dataLength 个字节，为了兼容旧设备，这里填充 2048 个字节
			const fillData = _.fill(new Array(2048), 0);

			for (let index = 0; index < data.length; index++) {
				const element = data[index];
				fillData[index] = element!;
			}

			const resultJSON = await DeviceUtils.getProductInfo(fillData);
			const result = JSON.parse(resultJSON);

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 获取 D2D Recv Match 值
	 * @returns 
	 */
	async getD2dRecvMatch(): Promise<{model: string, deviceEUI: string; oem: string}>  {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const dataLength = await this.commander.sendCommand(NfcCommandName.readD2dRecvMatch);
					const data = await this.commander.receiveFlashData(dataLength);
					const resultJSON = await DeviceUtils.getD2DPairInfo(data);
					const result = JSON.parse(resultJSON);
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.readD2dRecvMatch,
			commandType: NfcCommandType.operate,
			action: this.getAction('NfcGetD2dRecvMatchInfo')
		});
	}

	/**
	 * 采集SNR值
	 * @returns 
	 */
	async collectSNRValue(): Promise<{snrValue: number}> {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					this.logger.debug('start collectSNRValue');
					const dataLength = await this.commander.sendCommand(NfcCommandName.collectSNRValue);
					const result = await this.commander.receiveFlashData(dataLength);
					const buffer = Buffer.from(result.slice(0, dataLength));
					const floatValue = buffer.readFloatLE(0);
					return Promise.resolve({
						snrValue: floatValue.toFixed(2)
					});
				} catch (error) {
					this.logger.error('collectSNRValue error: ', error);
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.collectSNRValue,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * TVOC自清洁
	 */
	async clearTVOC() {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcClearTVOC'),
			commandName: NfcCommandName.clearTVOC,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 功耗测试模式
	 */
	async powerConsumptionTest() {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcPowerConsumptionTest'),
			commandName: NfcCommandName.powerConsumptionTest,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 读取NFC卡信息
	 */
	async readTag(): Promise<{
		id: string;
		tech?: NfcTech;
		techTypes?: NfcTech[];
	}> {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcReadTag'),
			commandName: NfcCommandName.common,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 获取蓝牙配对信息
	 */
	async getBluePair(): Promise<{'fetchBluePairInfo':DeviceInfo['fetchBluePairInfo']}> {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcGetBluePair'),
			commandName: NfcCommandName.common,
			commandType: NfcCommandType.operate
		});
	}	

	/**
	 * 采集AI命令
	 * @param {string} aiIndex ai1/ai2
	 */
	async collectAi(aiIndex: 'ai1' | 'ai2') {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcCollectAi', aiIndex),
			commandName: NfcCommandName.collect,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 读取AI值命令
	 * @param {string} aiIndex ai1/ai2
	 */
	async fetchAi(aiIndex: 'ai1' | 'ai2') {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcFetchAi', aiIndex),
			commandName: NfcCommandName.fetch,
			commandType: NfcCommandType.fetch
		});
	}

	/**
	 * 采集通道命令
	 * all: 表示采集所有通道, 0~34: 表示采集指定通道ID
	 * @param {number | 'all'} channelIndex 通道索引
	 */
	async collectChannel(channelIndex: number | 'all') {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcCollectChannel', channelIndex),
			commandName: NfcCommandName.collect,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 读取通道命令
	 * @param {number | 'all'} channelIndex 通道索引
	 * @param {FetchChannelDataType} dataType 数据类型
	 * @return {string | Array<{id: number; value: string}>} 返回值
	 */
	async fetchChannel(channelIndex: number | 'all', dataType: FetchChannelDataType): Promise<string | Array<{id: number; value: string}>> {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcFetchChannel', channelIndex, dataType),
			commandName: NfcCommandName.fetch,
			commandType: NfcCommandType.fetch
		});
	}

	/**
	 * 读取GPIO值
	 * @param {Metric.COLLECT_METRIC} type 通道类型
	 * @param {number} index 通道索引
	 */
	async fetchGPIO(type: 'di' | 'do' | 'counter', index: 1 | 2) {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcFetchGPIO', type, index),
			commandName: NfcCommandName.fetch,
			commandType: NfcCommandType.fetch
		});
	}

	/**
	 * GPIO调试
	 * @param index - GPIO索引
	 * @param type - 调试类型 开始计数、停止计数、配置计数、切换状态
	 * @param value - 调试参数 配置计数时，需要传入config_count
	 * @returns 1: 成功
	 */
	async gpioDebug(index: 1 | 2, type: 'start_count' | 'stop_count' | 'config_count' | 'switch_state', value?: {
		config_count: number;
	}) {
		return this.setTagDiscoveryListener({
			action: this.getAction('NfcGpioDebug', index, type, value),
			commandName: NfcCommandName.common,
			commandType: NfcCommandType.operate
		});
	}

	/**
	 * 添加NFC状态监听
	 * @param {String} eventName - 事件名称
	 * @param {Function} callback - 事件回调
	 */
	addEventListener<E extends NfcTrackerEvents>(eventName: E, callback: NfcTrackerCallback[E]) {

		this.tracker.addEventListener(eventName, callback);

		return {
			remove: () => this.tracker.removeEventListener(eventName, callback)
		};
	}

	/**
	 * 移除事件监听
	 * @param {String} eventName - 事件名称
	 * @param {Function} callback - 事件回调
	 */
	removeEventListener<E extends NfcTrackerEvents>(eventName: E, callback: NfcTrackerCallback[E]) {
		this.tracker.removeEventListener(eventName, callback);
	}

	/**
	 * 重新监听发现标签事件
	 * @param {function} listener - 回调函数 
	 */
	reListenDiscoveryEvent(listener?: () => Promise<any>, action?: IAction) {
		if(this.tracker.state === NfcState.notDetect || this.nfcProxy.tag == null) {
			this.logger.debug('not detect cancel trigger reListenDiscoveryEvent');
			return;
		}

		this.logger.debug('trigger reListenDiscoveryEvent');
		this.tagDiscovertyListener = _.isFunction(listener) ? listener : this.tagDiscovertyListener;
		this.tagDiscoveryAction = action ?? this.tagDiscoveryAction;
		this.reListened = true; 
	}

	/**
	 * 获取设备密码
	 * 如果有缓存密码，则返回缓存密码，否则返回默认密码
	 */
	private getDevicePassword() {
		const passwordId = this.getPasswordId();
		const {password} = DevicePasswordManager.getPasswordById(passwordId);

		return password;
	}

	/**
	 * 获取密码对应的ID
	 */
	public getPasswordId() {
		return this.nfcProxy.tag?.id ?? '';
	}

	/**
	 * 处理重新监听事件
	 */
	private async handleReListenDiscoveryEvent(
		{
			tech,
			errorMessage,
			commandName,
			commandType,
			reListenCount
		}:
			{
				tech: NfcTech,
				errorMessage: string,
				commandName: NfcCommandName,
				commandType: NfcCommandType,
				reListenCount: number
			}
	) {
		try {
			const { listener, action } = await this.getReListenDiscoveryListener(reListenCount);
			this.logger.debug('send failed, setTagDiscoveryListener again');
			return this.setTagDiscoveryListener({ tech, listener, action, commandName, commandType });
		} catch (error) {
			return Promise.reject(errorMessage);
		}
	}

	/**
	 * 获取重新监听的处理事件
	 */
	private getReListenDiscoveryListener(maxCount: number): Promise<{
		listener: any;
		action?: any;
	}> {
		return new Promise((resolve, reject) => {
			let count = 0;

			this.sleepTimer && clearInterval(this.sleepTimer);

			this.sleepTimer = setInterval(() => {
				//在重试倒计时中点击取消，应立即返回错误
				if(this.tracker.state === NfcState.notDetect || this.nfcProxy.tag == null) {
					this.sleepTimer && clearInterval(this.sleepTimer);
					this.logger.debug('not detect cancel getReListenDiscoveryListener');
					return reject('not detect cancel getReListenDiscoveryListener');
				}

				//点击重试后，立即返回监听函数
				if(this.reListened) {
					this.sleepTimer && clearInterval(this.sleepTimer);
					this.reListened = false;
					count = 0;

					this.logger.debug('getReListenDiscoveryListener');

					resolve({
						listener: this.tagDiscovertyListener,
						action: this.tagDiscoveryAction
					});
				}

				this.logger.debug(`getReListenDiscoveryListener count: ${count}`);

				count += 1;

				if(count >= maxCount) {
					this.sleepTimer && clearInterval(this.sleepTimer);
					reject('getReListenDiscoveryListener failed');
				}

			}, isiOS ? 500 : 1000);
		});
	}
	
	/**
	 * 电磁阀门调试 UC521-lora
	 * @param {string} command 指令内容
	*/
	async writeValveDebuggingCommand(command: string) {
		return this.setTagDiscoveryListener({
			listener: async() => {
				try {
					const password = this.getDevicePassword();
					const dataArr = NfcConverter.strToDecimalArr(command, 'utf-8');
					const dataSize = dataArr.length;
					await this.commander.sendCommand(NfcCommandName.valveDebugger, { password, dataSize });
					await this.commander.sendFlashData({
						data: dataArr, 
						dataSize
					});
					await this.commander.checkReadable(90000);
					const dataLength: any = await this.commander.getAckDataLength();		
					const finalData = await this.commander.receiveFlashData(dataLength);
					const finalDataStr = String.fromCharCode(...finalData);
					return Promise.resolve(finalDataStr);
				} catch (error) {
					return Promise.reject(error);
				}
			},
			commandName: NfcCommandName.valveDebugger,
			commandType: NfcCommandType.write
		});
	}
}

export default new NfcController();