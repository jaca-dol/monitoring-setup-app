import { Platform } from 'react-native';

import { Buffer } from 'buffer';
import _ from 'lodash';

import { MODEL_SERIES, MODELS, SUPPORTED_FREQUENCY_OPTIONS } from '../../model/constants';
import { DeviceProductInfo, GeneralDeviceInfo, UpgradeFileData, UpgradePlan, UpgradePlanData } from '../../model/deviceInfo';
import DeviceUtils from '../../model/DeviceUtils';
import translate from '../../utils/translate';
import { deviceContainer } from '../DeviceManager/device_container';
import { BasicDeviceProviderId, BasicDeviceProviderTypes } from '../DeviceManager/device_container/DeviceProvider';
import File from '../file';

export interface UpgradeFile {
	name: string;
	path: string;
}

enum UpgradeFileExtension {
	ZIP = 'zip',
	PATCH = 'patch',
	BIN = 'bin'
}

/**
 * 升级Helper配置
 */
interface UpgradeHelperConfig {
	/**
	 * 是否校验设备型号
	 */
	validateModel: boolean;
	
	/**
	 * 是否校验OEM id
	 */
	validateOEMId: boolean;

	/**
	 * 是否校验升级参数
	 */
	validateFirmwareParams: boolean;

	/**
	 * 是否是调试模式
	 */
	isDebugMode: boolean;
}

/**
 * 设备升级时所需的设备信息
 */
interface DeviceInfo {
	model: DeviceProductInfo['model'];
	oem: DeviceProductInfo['oem'];
	statusModel: GeneralDeviceInfo['statusModel'];
	hardwareVersion: DeviceProductInfo['hardwareVersion'];
	firmwareVersion: DeviceProductInfo['firmwareVersion'];
	supportFreq: GeneralDeviceInfo['supportFreq'];
	deviceInformation?: DeviceProductInfo['deviceInformation'];
}

/**
 * 升级Helper
 */
class BaseUpgradeHelper {
	/**
	 * 升级文件缓存
	 */
	upgradeFilesCache: Map<string, UpgradeFileData>;

	/**
	 * 支持的升级文件格式
	 */
	supportFileExtensions: string[];

	/**
	 * 日志服务
	 */
	logger: BasicDeviceProviderTypes['ExtendLogger'];

	/**
	 * 升级Helper配置
	 */
	config: UpgradeHelperConfig;

	constructor() {
		const extendLogger = deviceContainer.get<BasicDeviceProviderTypes['ExtendLoggerFactory']>(BasicDeviceProviderId.ExtendLoggerFactory);

		this.logger = extendLogger('UpgradeHelper');
		this.upgradeFilesCache = new Map<string, UpgradeFileData>();
		this.supportFileExtensions = [ UpgradeFileExtension.BIN, UpgradeFileExtension.ZIP, UpgradeFileExtension.PATCH ];
		this.config = {
			validateModel: true,
			validateOEMId: true,
			validateFirmwareParams: true,
			isDebugMode: false
		};
	}

	/**
	 * 获取文件后缀
	 */
	getFileExtension(filename: string): string | undefined {
		if (typeof filename === 'string' && filename) {
			const parts = filename.split('.');

			if (parts.length > 1) {
				return parts.pop();
			}
		}

		return;
	}
	/**
	 * 获取设备差分升级是否需要延迟等待
	 * @param {string} model - 设备型号
	 */
	getPatchSleepTime = _.memoize(model => {
		
		if(!_.isString(model)) {
			return 0;
		}

		if([ MODELS['VS370'], MODEL_SERIES['EM410-RDL'], MODEL_SERIES['EM411-RDL'], MODEL_SERIES['EM410-RDL-L0CEU'] ].some(m=>model.startsWith(m))) {
			return 20000;
		}
		
		return 0;
	});

	/**
	 * 判断是否支持升级
	 * @param options
	 */
	getIsSupportUpgrade(options: {
		mode: 'nfc' | 'ble';
		isCardMode: boolean;
		isSupportPatchUpgrade: boolean;
	}) {
		const { mode, isCardMode, isSupportPatchUpgrade } = options;

		//当前模式是NFC，如果是卡模式，则不支持升级
		if (mode === 'nfc' && isCardMode) {
			return false;
		}

		//iOS NFC因为会话20s超时的系统限制，所以iOS的NFC模式只支持差分升级，不支持全量升级，在蓝牙模式下支持全量升级
		if (Platform.OS === 'ios' && mode === 'nfc') {
			return isSupportPatchUpgrade;
		}

		return true;
	}

	/**
	 * 检查设备型号是否匹配
	 */
	getIsModelMatch(deviceModel: string, upgradeModel: string, deviceStatusModel: string) {
		try {
			const modelWildcard = 'X';
			//如果升级型号是通配型号比如（upgradeModel: WS51X，deviceModel: WS515）
			//只要设备型号以升级型号开头即可
			if(upgradeModel.includes(modelWildcard)) {
				const upgradeModelPrefix = _.get(upgradeModel.split(modelWildcard), [0], upgradeModel);

				return deviceModel.startsWith(upgradeModelPrefix);
			}

			//如果升级的型号是具体的型号，包含频段和pn，（upgradeModel: WT201-470M，deviceModel: WT201）
			//只要设备型号和升级型号互相包含即可
			if(upgradeModel.includes(deviceModel) || deviceModel.includes(upgradeModel)) {
				return true;
			}

			//如果升级型号是通配型号，不包含频段和pn，upgradeModel: WT201，deviceModel: WT201），则直接比较是否相等
			//如果升级型号与设备显示的型号相等即可
			return deviceModel === upgradeModel || deviceStatusModel === upgradeModel;
		} catch (error) {
			this.logger.error("getIsModelMatch error:", error, deviceModel, upgradeModel);
			return false;
		}
	}

	/**
	 * 检查版本是否匹配
	 * @param deviceVersion - 设备版本
	 * @param upgradeTargetVersion - 升级目标版本
	 * @returns 
	 */
	getIsVersionMatch(deviceVersion: { hardwareVersion: string, firmwareVersion: string }, upgradeTargetVersion: { hardwareVersion: string, firmwareVersion: string }) {
		try {
			//硬件只需要匹配大版本即可
			//固件匹配完整版本号
			const deviceHardwareVersion = deviceVersion.hardwareVersion.split('.')[0]?.toLowerCase();
			const deviceFirmwareVersion = deviceVersion.firmwareVersion.toLowerCase();
			//debug模式下不进行全匹配
			// if(this.config.isDebugMode) {
			// 	deviceFirmwareVersion = deviceVersion.firmwareVersion.split('-')[0].toLowerCase();
			// }            
			
			const UpgradeHardwareVersion = upgradeTargetVersion.hardwareVersion.split('.')[0]?.toLowerCase();
			const UpgradeFirmwareVersion = upgradeTargetVersion.firmwareVersion.split('-')[0]?.toLowerCase();			
			// if(this.config.isDebugMode) {
			// 	UpgradeFirmwareVersion = upgradeTargetVersion.firmwareVersion.toLowerCase();
			// }

			this.logger.debug(`getIsVersionMatch deviceHardwareVersion: ${deviceHardwareVersion}, UpgradeHardwareVersion: ${UpgradeHardwareVersion}, deviceFirmwareVersion: ${deviceFirmwareVersion}, UpgradeFirmwareVersion: ${UpgradeFirmwareVersion}`);

			return deviceHardwareVersion === UpgradeHardwareVersion && deviceFirmwareVersion === UpgradeFirmwareVersion;
		} catch (error) {
			this.logger.error('getIsVersionMatch', error);
			return false;
		}
	}

	/**
	 * 检查硬件版本是否匹配
	 * @param deviceVersion - 设备版本
	 * @param upgradeTargetVersion - 升级目标版本
	 * @returns 
	 */
	getIsHardwareVersionMatch(deviceHardwareVersion: string, upgradeTargetHardwareVersion: string) {
		try {
			//硬件只需要匹配大版本即可
			//固件去掉版本号中的-后面的内部版本号，只比较前面的正式版本号
			const _deviceHardwareVersion = deviceHardwareVersion.split('.')[0]?.toLowerCase();			
			const _upgradeTargetHardwareVersion = upgradeTargetHardwareVersion.split('.')[0]?.toLowerCase();			

			this.logger.debug(`getIsHardwareVersionMatch deviceHardwareVersion: ${_deviceHardwareVersion}, UpgradeHardwareVersion: ${_upgradeTargetHardwareVersion}`);

			return _deviceHardwareVersion === _upgradeTargetHardwareVersion;
		} catch (error) {
			this.logger.error('getIsHardwareVersionMatch', error);
			return false;
		}
	}

	/**
	 * 检查设备与固件的升级检测参数是否匹配
	 * @param firmwareParams
	 * @param deviceInfo
	 */
	getIsFirmwareParamsMatch(firmwareParams: UpgradePlanData['checkFirmwareParams'], deviceInfo: Pick<DeviceInfo, 'deviceInformation'>) {
		if(firmwareParams == null || !_.isObject(firmwareParams)) {
			return true;
		}

		const paramsKey = Object.keys(firmwareParams);

		//检查参数的每个key都要匹配，才算通过
		if(paramsKey.every(key => {
			const paramValue = _.get(firmwareParams, key);
			const deviceValue = _.get(deviceInfo, [ 'deviceInformation', key ]);

			//只要对应设备信息的值有一个在参数检查的值里面即可算匹配
			return !_.isArray(paramValue)
				? deviceValue === paramValue
				: paramValue.some(item => deviceValue === item);
		})) {
			this.logger.info("firmware params match", firmwareParams);
			return true;
		}

		return false;
	}

	/**
	 * 检查设备与固件的OEM id是否匹配
	 * @param deviceOEMId - 当前设备的OEM id
	 * @param upgradeOEMId - 升级固件的OEM id
	 */
	getIsOEMIdMatch(deviceOEMId: string, upgradeOEMId: string) {
		if(deviceOEMId == null || upgradeOEMId == null) {
			return true;
		}

		//如果升级固件的OEM id是0000（标准），则匹配设备的标准版本和中性版本
		if(upgradeOEMId === '0000') {
			return [ '0000', '0086', '0010', '1086' ].includes(deviceOEMId);
		}

		//如果升级固件为非标准，则直接匹配
		return deviceOEMId === upgradeOEMId;
	}

	/**
	 * 获取缓存的升级文件
	 * @param cacheKey - 缓存key
	 * @returns 
	 */
	private async getCachedUpgradeFile(cacheKey: string): Promise<UpgradeFileData | undefined> {
		try {
			const cached = this.upgradeFilesCache.get(cacheKey);

			if(!cached) {
				return;
			}

			const fullUpgradeFilePath = cached.fullUpgradeFile.map(file => file.path);
			const patchUpgradeFiles = cached.patchUpgradeFiles?.[0]?.path;
			let fullUpgradeFileIsExists = false;
			let patchUpgradeFileIsExists = false;

			if (fullUpgradeFilePath.length > 0) {
				for (const file of fullUpgradeFilePath) {
					fullUpgradeFileIsExists = await File.isExists(file);
					if (!fullUpgradeFileIsExists) {
						this.upgradeFilesCache.delete(cacheKey);
						return;
					}
				}
			}

			if(patchUpgradeFiles != null) {
				patchUpgradeFileIsExists = await File.isExists(patchUpgradeFiles);

				if(!patchUpgradeFileIsExists) {
					this.upgradeFilesCache.delete(cacheKey);
					return;
				}
			}

			return cached;
		} catch (error) {
			return;
		}
	}

	/**
	 * 检查升级文件是否符合要求
	 */
	checkUpgradeFile(options: {
		name: string;
		size: number | null;
		uri: string | null;
		isSupportPatchUpgrade: boolean;
	}): {isValid: boolean; error: string} {
		const { name, size, uri, isSupportPatchUpgrade } = options;
		const fileExtension = this.getFileExtension(name);
		this.logger.debug('checkUpgradeFile fileExtension:', fileExtension);

		if (name == null) return { isValid: false, error: translate('upgrade.wrongUpgradeFileName') };
		if (size == null) return { isValid: false, error: translate('upgrade.wrongUpgradeFileSizeEmpty') };
		if (uri == null) return { isValid: false, error: translate('upgrade.wrongUpgradeFileUriEmpty') };
		if (fileExtension == null || fileExtension === '') return { isValid: false, error: translate('upgrade.wrongUpgradeFileExtensionEmpty') };

		//大于2M的升级文件，则认为其格式不正确(VS321 WE模块包大小可达4M)
		if (size === 0 || size > 5097152) {
			return {
				isValid: false,
				error: translate('upgrade.wrongUpgradeFileSize')
			};
		}

		//如果不是支持的升级文件格式，则提示错误
		if (!this.supportFileExtensions.includes(fileExtension)) {
			const supportFileExtensions = this.supportFileExtensions.join('/');

			return {
				isValid: false,				
				error: translate('tips.wrongFileFormat', {format: supportFileExtensions})
			};
		}

		//如果是差分升级文件，但是设备不支持差分升级，则提示错误
		if (fileExtension === 'patch' && !isSupportPatchUpgrade) {
			return {
				isValid: false,				
				error: translate('tips.wrongFileFormat', {format: UpgradeFileExtension.BIN})
			};
		}

		return {isValid: true, error: ''};
	}

	/**
	 * 处理缓存文件
	 * @param cachedFile - 缓存文件
	 * @param deviceInfo - 设备信息
	 */
	private async handleCachedFile(cachedFile: UpgradeFileData, deviceInfo: DeviceInfo, isValidModelMatch: boolean): Promise<UpgradeFileData> {
		//如果缓存与当前设备型号不匹配，则提示错误
		if(cachedFile.model != null && isValidModelMatch && !this.getIsModelMatch(deviceInfo.model, cachedFile.model, deviceInfo.statusModel)) {
			this.logger.debug('handleCachedFile | model not match device model', deviceInfo.model, cachedFile.model);
			return Promise.reject(translate('tips.patchModelError'));
		}

		//如果缓存与当前设备的升级参数不匹配，则提示错误
		if(this.config.validateFirmwareParams && cachedFile.checkFirmwareParams != null && deviceInfo.deviceInformation != null && !this.getIsFirmwareParamsMatch(cachedFile.checkFirmwareParams, deviceInfo)) {
			this.logger.debug('handleCachedFile | firmware params not match', cachedFile.checkFirmwareParams);
			return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
		}

		//如果缓存与当前设备的OEM id不匹配，则提示错误
		if(this.config.validateOEMId && cachedFile.odm != null && !this.getIsOEMIdMatch(deviceInfo.oem, cachedFile.odm)) {
			this.logger.debug('handleCachedFile | oem id not match', deviceInfo.oem, cachedFile.odm);
			return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
		}

		this.logger.info("cachedFile:", cachedFile);
		return cachedFile;
	}

	/**
	 * 处理 zip 升级文件
	 * @param file - 升级文件
	 * @param deviceInfo - 设备信息
	 * @param upgradeFileData - 升级文件数据
	 */
	private async handleZipFile(file: UpgradeFile, deviceInfo: DeviceInfo, upgradeFileData: UpgradeFileData): Promise<UpgradeFileData> {
		try {
			//解压缩，根据设备频段获取设备对应的.bin文件信息
			this.logger.debug("start unzip zip file");
			const filename = file.name;
			const filePath = file.path;
			const fileList = await File.unzip({
				fileName: filename,
				filePath,
				tempDirName: 'upgrade_temp'
			});

			if(fileList == null) {
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			const supportedFrequencyOptions = SUPPORTED_FREQUENCY_OPTIONS;
			const options = supportedFrequencyOptions[deviceInfo.supportFreq as keyof typeof SUPPORTED_FREQUENCY_OPTIONS];
			let findFilePath = '';
			try {
				fileList.forEach(file => {
					options.forEach(option => {
						const num = option.label.match(/\d+/g);
						if (file.name.indexOf('-' + num?.[0]) > -1) {
							findFilePath = file.path;
						}
					});
				});
			}catch (error) {
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			if(findFilePath === '') {
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			upgradeFileData.fullUpgradeFile = [{
				name: filename,
				path: findFilePath,
				version: 1,
				dataMap: new Map()
			}];

			return upgradeFileData;
		} catch (error) {
			this.logger.error("handleZipFile error:", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 处理 patch 升级文件
	 * @param file 
	 * @param upgradeFileData 
	 */
	private async handlePatchFile(file: UpgradeFile, upgradeFileData: UpgradeFileData): Promise<UpgradeFileData> {
		//如果是v1的差分升级文件，则将其放入差分升级文件列表中
		this.logger.debug("start handle patch file");
		upgradeFileData.patchUpgradeFiles = [{
			name: file.name,
			path: file.path,
			version: 1
		}];

		return upgradeFileData;
	}

	/**
	 * 处理解压 bin 升级文件
	 * @param file - 升级文件
	 */
	private async handleUnzipBinFile(file: { name: string; path: string; }, tempNumber: number): Promise<{
		isZip: boolean;
		upgradeFileList?: UpgradeFile[];
		error?: string;
	}> {
		try {
			const filename = file.name;
			const filePath = file.path;
			this.logger.debug("unzip bin with password", filename, filePath);
			const upgradeFileList = await File.unzip({
				fileName: filename,
				filePath,
				password: 'Ljm&Milesight@2024',
				tempDirName: `upgrade_temp${tempNumber}`
			});

			return {
				isZip: true,
				upgradeFileList
			};
		} catch (error: any) {
			this.logger.warn("unzip bin error:", error);
			const isZip = error && error.isZip === true;

			return Promise.resolve({
				isZip,
				error: translate('tips.unableParse')                
			});
		}
	}

	/**
	 * 处理读取升级计划文件
	 */
	private async handleReadUpgradePlanFile(upgradeFileList: UpgradeFile[]) {		
		try {
			const upgradePlanFile = upgradeFileList.find(file => file.name === 'upgrade_plan.json');

			//如果没有upgrade_plan.json文件，则提示错误
			if (!upgradePlanFile) {
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			this.logger.debug("start read upgrade_plan.json");
			const upgradePlanJSON = await File.readFile(upgradePlanFile.path, 'utf8');
			const upgradePlanData: UpgradePlanData = JSON.parse(upgradePlanJSON);
			this.logger.debug("get upgrade plan data:", upgradePlanData);
			
			return upgradePlanData;
		} catch (error) {
			this.logger.error("get upgrade plan data error:", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 处理 bin 升级文件
	 * @param file - 升级文件
	 * @param deviceInfo - 设备信息
	 * @param upgradeFileData - 升级文件数据
	 * @param isValidModelMatch - 是否校验设备型号
	 * @returns 
	 */
	private async handleBinFile(file: UpgradeFile, deviceInfo: DeviceInfo, upgradeFileData: UpgradeFileData, tempNumber: number = 1, isValidModelMatch: boolean): Promise<UpgradeFileData> {
		try {
			const { isZip, upgradeFileList, error } = await this.handleUnzipBinFile(file, tempNumber);

			//如果不是压缩文件，则认为其是全量升级文件
			if(!isZip) {
				this.logger.debug("not zip file handle as full upgrade file");

				upgradeFileData.fullUpgradeFile = [{
					name: file.name,
					path: file.path,
					version: 1,
					dataMap: new Map()
				}];
				return upgradeFileData;
			}

			//如果解压成功，但是没有对应的文件列表，则提示错误
			if(upgradeFileList == null) {
				this.logger.info("upgrade file list not exist:");
				return Promise.reject(error ?? translate('tips.upgradeFailedWithNotMatchFile'));
			}

			this.logger.debug("unzip bin success", upgradeFileList.length);
			const upgradePlanData = await this.handleReadUpgradePlanFile(upgradeFileList);

			//如果当前设备型号与升级计划里面的型号不匹配，则提示错误
			if(isValidModelMatch && upgradePlanData.model && !this.getIsModelMatch(deviceInfo.model, upgradePlanData.model, deviceInfo.statusModel)) {
				this.logger.info("device model not match plan model", deviceInfo.model, upgradePlanData.model);
				return Promise.reject(translate('tips.patchModelError'));
			}

			//如果存在固件升级检查参数，则进行固件升级检查
			if(this.config.validateFirmwareParams && upgradePlanData.checkFirmwareParams != null && deviceInfo.deviceInformation != null && !this.getIsFirmwareParamsMatch(upgradePlanData.checkFirmwareParams, deviceInfo)) {
				this.logger.info("firmware params not match", upgradePlanData.checkFirmwareParams);
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));	
			}

			//如果存在OEM id，则进行OEM id检查
			if(this.config.validateOEMId && upgradePlanData.odm != null && !this.getIsOEMIdMatch(deviceInfo.oem, upgradePlanData.odm)) {
				this.logger.info("oem id not match", deviceInfo.oem, upgradePlanData.odm);
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			//获取所有的升级计划文件信息
			this.logger.debug("upgradePlanData.upgradePlan:", upgradePlanData.upgradePlan);
			if(upgradePlanData?.upgradePlan) {
				//如果不存在升级计划。则说明当前目录层级不存在差分升级的文件
				upgradeFileData.patchUpgradePlan = upgradePlanData?.upgradePlan?.map(item => ({
					hardwareVersion: item.hardwareVersion,
					firmwareVersion: item.firmwareVersion,
					files: item.files.map(file => ({
						name: file,
						path: upgradeFileList.find(f => f.name === file)?.path ?? ''
					}))
				}));
				//获取所有的差分升级文件信息
				upgradeFileData.patchUpgradeFiles = _.flatten(upgradeFileData?.patchUpgradePlan?.map(plan => {
					if(plan.files) {
						return plan.files.map(file => ({
							name: file.name,
							path: file.path,
							version: 2
						}));
					}
			
					return [];
				}));
			}
			//获取当前目录bin文件
			const findFullUpgradeFile = upgradeFileList.filter(f => File.getFileExtension(f.name) === 'bin');
			//如果有全量升级文件，则将其放入全量文件中
			if (findFullUpgradeFile) {				
				const { upgradeFiles } = upgradePlanData;
				if (upgradeFiles) {	
					for(const i in upgradeFiles) { 
						//遍历升级文件数组，找出匹配当前目录bin文件列表中的bin文件，这些bin文件都是不支持再次解压的
						const findFile =  findFullUpgradeFile.find(f => upgradeFiles[i] === f.name);
						
						if(findFile) {
							upgradeFileData.fullUpgradeFile.push({
								name: findFile.name,
								path: findFile.path,
								version: 1,
								dataMap: new Map()
							});							
						}
					}
					for(const i in findFullUpgradeFile) {
						//遍历当前目录的bin文件，过滤掉在升级计划中的文件，即为可解压缩bin文件，进行处理
						if( !upgradeFiles.includes(findFullUpgradeFile[i]?.name ?? '')) {
							await	this.handleBinFile(findFullUpgradeFile[i]!, deviceInfo, upgradeFileData, tempNumber + 1, isValidModelMatch);
						}
					}
				} else {
					//不存在升级文件时，对每一个bin进行解压缩处理
					for(const i in findFullUpgradeFile) {
						await this.handleBinFile(findFullUpgradeFile[i]!, deviceInfo, upgradeFileData, tempNumber + 1, isValidModelMatch);
					}
				}
			}
			
			//获取升级文件的基本信息
			upgradeFileData.model = upgradePlanData.model;
			upgradeFileData.name = upgradePlanData.name;
			upgradeFileData.targetFirmwareVersion = upgradePlanData.firmwareVersion;
			upgradeFileData.targetHardwareVersion = upgradePlanData.hardwareVersion;
			upgradeFileData.pn = upgradePlanData.pn;
			upgradeFileData.odm = upgradePlanData.odm;
			upgradeFileData.maxSize = upgradePlanData.maxSize;
			upgradeFileData.checkFirmwareParams = upgradePlanData.checkFirmwareParams;
			if (upgradePlanData.submoduleUpgradeFiles) {
				upgradeFileData.submoduleUpgradeFiles = upgradePlanData.submoduleUpgradeFiles;
			}
			// 目前cth01有用到这个字段，其它设备以后扩展
			if (upgradePlanData.upgradeMethod === 1) {
				upgradeFileData.upgradeMethod = upgradePlanData.upgradeMethod;
			}
			if (upgradePlanData.upgradeMethod && upgradePlanData.upgradeMethod === 1) {
				upgradeFileData.rawData = upgradePlanData;
			}
			return upgradeFileData;
		} catch (error) {
			this.logger.error("handleBinFile error:", error);
			return Promise.reject(error);
		}
	}

	/**
	 * 解密全量升级文件
	 * @param upgradeFileData - 升级文件数据
	 */
	private async decryptFullUpgradeFile(upgradeFileData: UpgradeFileData): Promise<UpgradeFileData> {
		try {
			for (const file of upgradeFileData.fullUpgradeFile) {
				this.logger.debug("start decrypUpgradeData", file.path);
				const isExists = await File.isExists(file.path);

				if (!isExists) {
					this.logger.info("file not exist:", file.path);
					return Promise.reject(translate('tips.fileNotExist'));
				}

				const fullFileContent = await File.readFile(file.path, 'base64');
				const fullUpgradeDataStr = await DeviceUtils.decrypUpgradeData(fullFileContent);
				const fullUpgradeBuffer = Buffer.from(fullUpgradeDataStr, 'base64');
				const int8Array = new Int8Array(fullUpgradeBuffer);
				const fullUpgradeData = Array.from(int8Array); //解密后的数据需要是int8的类型

				file.dataMap.set('data', fullUpgradeData);
				this.logger.debug("decrypUpgradeData done:", fullUpgradeData.length);
			}

			return upgradeFileData;
		} catch (error) {
			this.logger.error("decryptFullUpgradeFile error", error);

			return Promise.reject(error);
		}
	}

	/**
	 * 预处理升级文件
	 */
	async preprocessUpgradeFile(file: UpgradeFile, deviceInfo: DeviceInfo, { isValidModelMatch }: { isValidModelMatch: boolean }): Promise<UpgradeFileData> {
		try {
			const filename = file.name;
			const { model } = deviceInfo;
			const fileExtension = this.getFileExtension(filename);
			const startTime = Date.now();
			const cacheKey = `${filename}-${model}`;
			const cachedFile = await this.getCachedUpgradeFile(cacheKey);
			const endTime = Date.now();
			this.logger.debug("preprocessUpgradeFile: ", file.name, fileExtension);			
			cachedFile != null && this.logger.debug("UpgradeHelper", "get cached file:", endTime - startTime);

			//如果是缓存文件，优先返回缓存文件
			if(cachedFile != null) {
				return this.handleCachedFile(cachedFile, deviceInfo, isValidModelMatch);
			}

			let upgradeFileData: UpgradeFileData = {
				model,
				fullUpgradeFile: [],
				maxSize: 16384, //默认差分文件最大大小16KB
				patchUpgradeFiles: undefined,
				patchUpgradePlan: undefined
			};

			switch (fileExtension) {
				case UpgradeFileExtension.ZIP:
					upgradeFileData = await this.handleZipFile(file, deviceInfo, upgradeFileData);
					break;
				case UpgradeFileExtension.PATCH:
					upgradeFileData = await this.handlePatchFile(file, upgradeFileData);
					break;
				case UpgradeFileExtension.BIN:
					upgradeFileData = await this.handleBinFile(file, deviceInfo, upgradeFileData, 1, isValidModelMatch);
					break;
				default:
					throw new Error(translate('tips.wrongFileFormat', { format: this.supportFileExtensions.join('/') }));
			}

			//如果有全量升级文件信息，则先将其解密
			if(upgradeFileData.fullUpgradeFile.length > 0) {
				upgradeFileData = await this.decryptFullUpgradeFile(upgradeFileData);
			}

			//将升级文件数据放入缓存中
			this.upgradeFilesCache.set(cacheKey, upgradeFileData);
			const endTime2 = Date.now();
			this.logger.debug("preprocessUpgradeFile duration:", endTime2 - startTime);

			return upgradeFileData;
		} catch (error) {
			this.logger.error("preprocessUpgradeFile error:", error);

			return Promise.reject(error);
		}
	}

	/**
	 * 获取升级计划
	 * @param upgradeFileData - 升级文件数据
	 * @param deviceInfo - 当前设备信息
	 * @param productInfo - 要升级的设备产品信息
	 */
	async getUpgradePlan(
		upgradeFileData: UpgradeFileData,
		deviceInfo: DeviceInfo,
		productInfo: DeviceProductInfo | null,
		options?: { isValidModelMatch?: boolean }
	): Promise<UpgradePlan> {
		try {
			const { isValidModelMatch = this.config.validateModel } = options || {};
			this.logger.debug("get upgrade plan");

			//如果没有获取到设备信息
			if(!productInfo) {
				this.logger.debug("not product info");
				//如果存在差分升级文件，比如新的bin文件或者旧的差分升级文件
				if (this.hasPatchUpgradeFiles(upgradeFileData)) {
					//如果是旧的差分升级文件，则使用旧的差分升级
					return this.getIsOldPatchUpgradeFile(upgradeFileData.patchUpgradeFiles)
						? this.getOldPatchUpgradePlan(upgradeFileData.patchUpgradeFiles, 'not product info and has old patch files')
						: this.getFullUpgradePlan(upgradeFileData, 'not product info and not old patch files', productInfo);
				}

				//如果不存在差分升级文件，则使用全量升级
				return this.getFullUpgradePlan(upgradeFileData, 'not product info and not patch files', productInfo);
			}

			//如果当前设备型号与要升级的设备型号不匹配，则提示错误
			if(isValidModelMatch && productInfo.model && !this.getIsModelMatch(deviceInfo.model, productInfo.model, deviceInfo.statusModel)) {
				this.logger.debug("current device model not match upgrade device model", deviceInfo.model, productInfo.model);
				return Promise.reject(translate('tips.patchModelError'));
			}

			//如果当前设备与要升级的设备固件参数不匹配，则提示错误
			if(this.config.validateFirmwareParams && upgradeFileData.checkFirmwareParams != null && productInfo.deviceInformation != null && !this.getIsFirmwareParamsMatch(upgradeFileData.checkFirmwareParams, productInfo)) {
				this.logger.info("firmware params not match", upgradeFileData.checkFirmwareParams);
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			//如果当前设备与要升级的固件的OEM id不匹配，则提示错误
			if(this.config.validateOEMId && upgradeFileData.odm != null && !this.getIsOEMIdMatch(deviceInfo.oem, upgradeFileData.odm)) {
				this.logger.info("oem id not match", deviceInfo.oem, upgradeFileData.odm);
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			//如果当前设备与要升级的固件的硬件大版本不匹配，则提示错误
			if(upgradeFileData.targetHardwareVersion != null && !this.getIsHardwareVersionMatch(deviceInfo.hardwareVersion, upgradeFileData.targetHardwareVersion)) {
				this.logger.info("hardware version not match", deviceInfo.hardwareVersion, upgradeFileData.targetHardwareVersion);
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			//如果设备不支持差分升级
			if(productInfo.canPatchUpgrade === false) {
				this.logger.debug("device not support patch upgrade");

				//如果使用的是旧的差分升级文件，但设备不支持差分升级，则提示错误
				if(this.hasPatchUpgradeFiles(upgradeFileData) && this.getIsOldPatchUpgradeFile(upgradeFileData.patchUpgradeFiles)) {
					return Promise.reject(Platform.OS === 'ios'
						? translate('tips.upgradeFailedWithNotMatchFileOrUseAndroid')
						: translate('tips.wrongFileFormat', { format: UpgradeFileExtension.BIN }));
				}

				//如果使用的是bin文件，则使用全量升级
				return this.getFullUpgradePlan(upgradeFileData, 'device not support patch upgrade', productInfo);
			}

			//有设备信息但没有差分升级计划，比如旧bin文件或者旧的差分升级文件
			if(upgradeFileData.patchUpgradePlan == null) {
				this.logger.debug("not patch upgrade plan");

				//如果存在差分升级文件，且是旧的差分升级文件，则使用旧的差分升级
				if(this.hasPatchUpgradeFiles(upgradeFileData) && this.getIsOldPatchUpgradeFile(upgradeFileData.patchUpgradeFiles)) {
					return this.getOldPatchUpgradePlan(upgradeFileData.patchUpgradeFiles, 'not patch upgrade plan and has old patch files');
				}

				//如果不存在差分升级文件，则认为是全量升级
				return this.getFullUpgradePlan(upgradeFileData, 'not patch upgrade plan and not patch upgrade files', productInfo);
			}

			//找到要升级设备的对应升级计划
			const findUpgradePlan = upgradeFileData.patchUpgradePlan.find(plan => {
				return this.getIsVersionMatch(productInfo, plan) && plan.files.length > 0;
			});

			this.logger.debug("productInfo subVersion patchEnable:", productInfo?.subVersion?.[0]?.patchEnable);

			//如果存在差分升级计划，则使用新差分升级，并读取差分升级文件内容
			if(findUpgradePlan && (productInfo?.subVersion?.[0]?.patchEnable ?? true)) {
				this.logger.debug("find patch upgrade plan:", findUpgradePlan);
				return this.getPatchUpgradePlan(upgradeFileData, findUpgradePlan, productInfo, 'find patch upgrade plan');
			}

			return this.getFullUpgradePlan(upgradeFileData, 'not find patch upgrade plan', productInfo);
		} catch (error: any) {
			this.logger.error("getUpgradePlan error:", error);
			return Promise.reject(error.message ?? error);
		}
	}

	/**
	 * 获取全量升级计划
	 * @param upgradeFileData - 升级文件数据
	 * @param reason - 使用升级计划的原因
	 */
	private getFullUpgradePlan(upgradeFileData: UpgradeFileData, reason: string, productInfo: DeviceProductInfo | null): UpgradePlan {
		const plan: UpgradePlan = {
			type: 'full',
			files: new Map(),
			reason
		};

		this.dealWithFullUpgradePlan(plan, upgradeFileData, productInfo);
		this.logger.debug("upgradeV2 getFullUpgradePlan plan:", plan);
		return plan;
	}

	private dealWithFullUpgradePlan(plan: UpgradePlan, upgradeFileData: UpgradeFileData, productInfo: DeviceProductInfo | null, hasPatchUpgradeFiles: boolean = false) {        
		const submoduleInfo = productInfo?.submoduleInfo ?? [];

		upgradeFileData.fullUpgradeFile.forEach(file => {
			// 检查 file.name 是否在 submoduleInfo 中

			if (upgradeFileData.submoduleUpgradeFiles?.find(item => item === file.name)) {
				if(!productInfo?.subVersion) {
					plan.files.set(file.name, file.dataMap.get('data') ?? []);
					this.logger.debug("upgradeV2 put upgrade file to plan list:", file.name);
				} else if (upgradeFileData.upgradeMethod === 1) {
					const index = upgradeFileData.submoduleUpgradeFiles?.findIndex(item => item === file.name);
					if (index != undefined && index !== -1) {
						const subVersion = productInfo?.subVersion?.[index]?.version ?? '';
						if (this.upgradeOrDowngradeSubmoduleByPlanRawData(subVersion, file.name)) {
							plan.hasSubmodule = true;
							plan.files.set(file.name, file.dataMap.get('data') ?? []);
							this.logger.debug("upgradeV2 put upgrade file to plan list:", file.name);
						}
					}
				} else if (this.needSubmoduleUpgrade(productInfo?.subVersion?.[0]?.version ?? '', file.name)) {
					plan.hasSubmodule = true;
					plan.files.set(file.name, file.dataMap.get('data') ?? []);
					this.logger.debug("upgradeV2 put upgrade file to plan list:", file.name);
				}
			} else if (!submoduleInfo.includes(file.name) && !hasPatchUpgradeFiles) {
				plan.files.set(file.name, file.dataMap.get('data') ?? []);
				this.logger.debug("upgradeV2 put upgrade file to plan list:", file.name);
			}
		});
	}

	//submoduleName: WT401.0000.0100.0101-a2.bin
	public needSubmoduleUpgrade(subVersion: string, submoduleName: string): boolean {
		this.logger.debug('subVersion:', subVersion, 'submoduleName:', submoduleName);
		if (!subVersion || subVersion.length == 0) {
			return false;
		}

		let submoduleVersion = submoduleName.split('-')[0];
		submoduleVersion = submoduleVersion?.replace('.bin', '') ?? '';		
		const submoduleVersionArray = submoduleVersion.split('.');
		if (submoduleVersionArray.length > 1) {
			return !this.isV1LargerThanV2(subVersion, submoduleVersionArray[submoduleVersionArray.length - 1]!);
		}

		return false;
	}

	public upgradeOrDowngradeSubmoduleByPlanRawData(subVersion: string, submoduleName: string): boolean {
		this.logger.debug('upgradeOrDowngradeSubmoduleByPlanRawData subVersion:', subVersion, 'submoduleName:', submoduleName);
		if (!subVersion || subVersion.length == 0) {
			return false;
		}

		const [ versionPart, suffixPart = '' ] = submoduleName.split('-');
		const submoduleVersion = versionPart?.replace('.bin', '');
		const submoduleSuffix = suffixPart.replace('.bin', '');

		const submoduleVersionArray = submoduleVersion?.split('.') ?? [];
		if (submoduleVersionArray.length > 1) {
			const lastVersion = submoduleVersionArray[submoduleVersionArray.length - 1];
			const versionName = submoduleSuffix ? `${lastVersion}-${submoduleSuffix}` : lastVersion;
			return subVersion !== versionName;
		}

		return false;
	}

	//v1: v1.1, v2: 0101
	private isV1LargerThanV2(v1: string, v2: string): boolean {
		const [ v1Major, v1Minor ] = v1.slice(1).split('.').map(Number);
		const v2Major = parseInt(v2.slice(0, 2), 10);
		const v2Minor = parseInt(v2.slice(2, 4), 10);
	
		if (v1Major !== v2Major) {
			//@ts-expect-error
			return v1Major > v2Major;
		}
	
		//@ts-expect-error
		return v1Minor >= v2Minor;
	}
	
	/**
	 * 获取旧的差分升级计划
	 * @param upgradeFileData - 差分升级文件数据
	 * @param reason - 使用升级计划的原因
	 */
	private async getOldPatchUpgradePlan(patchUpgradeFiles:  NonNullable<UpgradeFileData['patchUpgradeFiles']>, reason: string): Promise<UpgradePlan> {
		const plan: UpgradePlan = {
			type: 'oldPatch',
			files: new Map(),
			reason
		};

		for (let index = 0; index < patchUpgradeFiles.length; index++) {
			const file = patchUpgradeFiles[index];
			const content = await File.readFile(file?.path ?? '', 'base64');
			const data = Buffer.from(content, 'base64').toJSON().data;

			plan.files.set(file?.name ?? '', data);
		}

		return plan;
	}

	/**
	 * 获取差分升级计划
	 * @param findUpgradePlan - 升级计划
	 * @param reason - 使用升级计划的原因
	 */
	private async getPatchUpgradePlan(upgradeFileData: UpgradeFileData, findUpgradePlan: NonNullable<UpgradeFileData['patchUpgradePlan']>[number], productInfo: DeviceProductInfo | null, reason: string): Promise<UpgradePlan> {
		const plan: UpgradePlan = {
			type: 'patch',
			files: new Map(),
			reason
		};

		for (let index = 0; index < findUpgradePlan.files.length; index++) {
			const file = findUpgradePlan?.files[index];
			const content = await File.readFile(file?.path ?? '', 'base64');
			const data = Buffer.from(content, 'base64').toJSON().data;

			if(data.length > upgradeFileData.maxSize) {
				this.logger.debug("patch file size too large:", data.length, upgradeFileData.maxSize);
				return Promise.reject(translate('tips.upgradeFailedWithNotMatchFile'));
			}

			plan.files.set(file?.name ?? '', data);
		}

		if (upgradeFileData.upgradeMethod !== 1) {
			this.dealWithFullUpgradePlan(plan, upgradeFileData, productInfo, true);
		} else {
			plan.type = 'patchSubmodule';
		}

		if(plan.hasSubmodule) {
			plan.type = 'patchSubmodule';
		}

		this.logger.debug("upgradeV2 getPatchUpgradePlan plan:", plan);

		return plan;
	}

	/**
	 * 是否存在差分升级文件
	 * @param upgradeFileData - 升级文件数据
	 */
	private hasPatchUpgradeFiles(upgradeFileData: UpgradeFileData): upgradeFileData is UpgradeFileData & { patchUpgradeFiles: NonNullable<UpgradeFileData['patchUpgradeFiles']> } {
		return upgradeFileData.patchUpgradeFiles != null && upgradeFileData.patchUpgradeFiles.length > 0;
	}

	/**
	 * 是否为旧的差分升级文件
	 * @param patchUpgradeFiles - 差分升级文件
	 */
	private getIsOldPatchUpgradeFile(patchUpgradeFiles: NonNullable<UpgradeFileData['patchUpgradeFiles']>): boolean {
		return patchUpgradeFiles.length === 1 && patchUpgradeFiles.every(file => file.version === 1);
	}

	/**
	 * 从升级计划中获取升级数据
	 */
	getUpgradeDataFromUpgradePlan(upgradePlan: UpgradePlan) {
		const data: number[][] = [];

		upgradePlan.files.forEach(file => {
			data.push(file);
		});

		return data;
	}

	/**
	 * 获取升级校验数据
	 * @param data - 升级数据
	 * @param modelSeries - 设备系列
	 */
	getUpgradeCheckData(data: number[], modelSeries: MODEL_SERIES) {
		const firstHeadData = _.slice(data, 0, 8);
		const headCheck = [ 34, 67, 101, -121, 120, 86, 52, 34 ]; //22 34 56 78 87 65 43 21
		const isSpecialModel = [ MODEL_SERIES['WS130'], MODEL_SERIES['WS150'], MODEL_SERIES['WS500'], MODEL_SERIES['WS550'], MODEL_SERIES['AT'] ].includes(modelSeries);
		//指定发送升级校验数据次数
		const checkUpgradeDataSendCount = isSpecialModel ? 1 : null;
		let checkData;
		let upgradeDataStartPosition;

		if (modelSeries === MODEL_SERIES['SCT01']) {
			checkData = data.slice(0, 1200);
			upgradeDataStartPosition = 0;
		} else {
			checkData = _.slice(data, 0, 64); //旧版镜像默认头部内容是0-64
			upgradeDataStartPosition = 32; //默认镜像内容是从33个字节开始

			//因为data是int8的类型，在JSC引擎下===比较返回 false，在Hermes引擎下返回 true
			//为了兼容通用，改用 == 比较
			if(firstHeadData.every((v, i) => v == headCheck[i])) {
				//如果是新版的镜像，则需要取对应区域的头部去校验
				const size = data[8]; //头部大小是在第九位

				if(size != null && size < 12) {
					throw new Error(`${size}异常`);
				}

				//从CRC开始到头部结束的数据
				checkData = _.slice(data, 12, checkUpgradeDataSendCount === 1 ? 76 : size);

				upgradeDataStartPosition = size;
			}
		}

		return {
			checkData,
			upgradeDataStartPosition,
			checkUpgradeDataSendCount
		};
	}

	/**
	 * 设置升级Helper配置
	 * @param config - 升级Helper配置
	 */
	setConfig(config: UpgradeHelperConfig) {
		this.config = config;
	}
}

export const UpgradeHelper = new BaseUpgradeHelper();