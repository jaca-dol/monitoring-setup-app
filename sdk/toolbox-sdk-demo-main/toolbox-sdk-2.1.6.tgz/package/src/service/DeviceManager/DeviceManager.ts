/* eslint-disable @typescript-eslint/no-unused-vars */
import { inject, injectable } from 'inversify';
import { get, slice } from 'lodash';

import { Constructor } from '../../model';
import { MODEL_SERIES } from '../../model/constants';
import { DeviceInfo, DeviceSettingInfo } from '../../model/deviceInfo/DeviceInfo';
import DeviceUtils from '../../model/DeviceUtils';
import { UpgradeHelper } from '../../service/upgrade/UpgradeHelper';
import { IExtendLoggerFactory, ILogger, LoggerType } from '../../utils/logger';
import { IEventEmitter } from '../../utils/util/EventEmitter';
import { IBleActionApi } from '../action';
import { ActionManager } from '../action/ActionManager/ActionManager';
import { ActionName, ActionTypes } from '../action/types/IActionTypes';
import { default as NfcConverter } from '../nfc/NfcConverter';
import { Commander } from './Commander';
import { BleManager, NfcManager } from './container';
import { DeviceManagerError } from './DeviceManagerError';
import { BleProtocol, IProtocol, NfcProtocol } from './protocol';
import { container, ExportType, IDeviceManager, IDeviceManagerConfig, IDeviceManagerContext, IManager, Mode, Providers } from './types';

export interface ManagerTypeMap {
  'nfc': typeof NfcManager;
  'ble': typeof BleManager;
}

export type ManagerType<T extends Mode> = ManagerTypeMap[T];

/**
 * 设备管理器
 * 负责设备的管理，包括初始化、连接、断开、操作、发送命令等
 */
@injectable()
export class BaseDeviceManager implements IDeviceManager {
	private manager: IManager;
	private commander: InstanceType<typeof Commander>;
	private protocol: IProtocol;
	private managerInstance = new Map<Mode, IManager>();
	private protocolInstance = new Map<Mode, IProtocol>();
	private context: IDeviceManagerContext;
	private logger: LoggerType;
	private eventEmitter: IEventEmitter;
	private actionApi: IBleActionApi;

	constructor(
		@inject(Providers.DeviceManagerContext) context: IDeviceManagerContext,
		@inject(Providers.ExtendLoggerFactory) extendLoggerFactory: IExtendLoggerFactory,
		@inject(Providers.EventEmitter) EventEmitter: Constructor<IEventEmitter>,
		@inject(Providers.Logger) logger: ILogger,
        @inject(Providers.BleActionApi) actionApi: IBleActionApi
	) {
		this.context = context;
		this.manager = this.getManager(this.config.mode);
		this.protocol = this.getProtocol(this.config.mode);
		this.commander = new Commander(this.manager, this.protocol, extendLoggerFactory);
		this.logger = logger.extend('DeviceManager');
		this.eventEmitter = new EventEmitter();
		this.eventEmitter.setMaxListeners(50);
		this.actionApi = actionApi;
	}

	/**
	 * 初始化
	 */
	public init() {
		this.logger.debug('init');
		
		return this.manager.init();
	}

	/**
	 * 获取配置
	 */
	public get config() {
		return this.context.getConfig();
	}

	/**
	 * 设置配置
	 */
	public setConfig = (config: Partial<IDeviceManagerConfig>) => {
		this.context.setConfig(config);
		this.eventEmitter.emit('ConfigChange', config);
	}
	
	/**
	 * 获取当前模式
	 */
	public getMode() {
		return this.config.mode;
	}

	/**
	 * 获取动作
	 * @param name - 动作名称
	 * @param params - 动作参数
	 */
	getAction<N extends ActionName>(name: N, ...params: ActionTypes[N]['params']) {
		return ActionManager.getActionWithParams<N>(name, this.actionApi, ...params);
	}

	/**
	 * 订阅config变化
	 */
	public subscribeConfig = (listener: (config: IDeviceManagerConfig) => void) =>  {
		const eventName = 'ConfigChange';

		if (this.eventEmitter.eventNames().includes(eventName)) {
			return () => {}; // 返回一个空的取消订阅函数
		}

		this.eventEmitter.on('ConfigChange', listener);

		return () => {
			this.eventEmitter.off('ConfigChange', listener);
		};
	}

	/**
	 * 获取config快照
	 */
	public getConfigSnapshot = () =>  {
		return this.config;
	}

	/**
	 * 模式切换
	 * @param mode - 模式
	 * @returns 
	 */
	public use(mode: Mode) {
		this.checkMode(mode);

		if(this.config.mode === mode) {
			return;
		}

		this.logger.info('change mode', mode);
		this.manager = this.getManager(mode);
		this.protocol = this.getProtocol(mode);

		this.setConfig({mode});
		this.commander.setManager(this.manager);
		this.commander.setProtocol(this.protocol);
	}

	/**
	 * 开机
	 */
	public async powerOn() {
		try {
			return await this.commander.powerOn();
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 关机
	 */
	@ActionManager.withAction('BlePowerOff')
	public async powerOff() {
		try {
			return await this.commander.powerOff();
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 测试命令(仅蓝牙)
	 */
	public async test(data: number[]) {
		try {
			return await this.commander.test({data});
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 同步时间
	 */
	@ActionManager.withAction('BleSyncTime')
	public async syncTime(timestamp: number, timeZone: number) {
		try {
			return await this.commander.syncTime(timestamp, timeZone);
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 获取设备信息
	 */
	@ActionManager.withAction('BleReadIPSOData')
	public async read(): Promise<{
		deviceInfo: DeviceInfo;
		rawData: number[];
		tslInfo?: Record<string, any>;
		readTime?: number;
	}> {
		try {
			this.logger.debug('read');
			const response = await this.commander.read();
			const flashInfo = await DeviceUtils.getFlashInfo(response);
			const deviceInfo = JSON.parse(flashInfo) as DeviceInfo;
			const isCrcError = get(deviceInfo, 'code') === DeviceManagerError.getError({
				type: 'CRC_ERROR'
			});
			const isDataError = get(deviceInfo, 'status.length') === 0;

			//如果状态页没有状态内容就认为是数据错误/不支持的设备，提醒版本过低
			if(isDataError) {
				this.logger.error('is not support device info', deviceInfo);
				return Promise.reject(DeviceManagerError.getError({type: 'DATA_ERROR'}));
			}

			//如果crc校验错误，则报错
			if(isCrcError) {
				return Promise.reject(DeviceManagerError.getError({type: 'CRC_ERROR'}));
			}

			return {
				deviceInfo,
				//前128字节是状态直接去掉，后面是数据
				rawData: response.slice(128)
			};	
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 写入设备信息
	 */
	@ActionManager.withAction('BleWriteIPSOData')
	public async write(data: number[], settingJSON: string, _deviceSettingInfo: DeviceSettingInfo) {
		try {
			this.logger.debug('write');
			const flashInfo = await DeviceUtils.setFlashInfo(data, settingJSON);
			
			if(flashInfo.code != 1) {
				const deviceManagerError = DeviceManagerError.getError({
					code: flashInfo.code
				});

				throw DeviceManagerError.create(deviceManagerError.name as any) ?? flashInfo.code;
			}

			const rawData: number[] = flashInfo.rawData;
			const dataSize = JSON.parse(flashInfo.result).datasize;
			
			await this.commander.write(rawData, dataSize);
			this.logger.info('write device info', settingJSON);

			return Promise.resolve(rawData);
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 密码校验
	 * 输入当前连接设备对应的密码
	 */
	@ActionManager.withAction('BleAuth')
	public async auth(password: string, phoneModel: string) {
		try {
			this.logger.debug('start auth');
			const result = await this.commander.auth({password, phoneModel});
			this.logger.debug('auth success');
			BleManager.setCurrentPeripheralAuthenticated(true);
			return result;
		} catch (error) {
			BleManager.setCurrentPeripheralAuthenticated(false);
			return this.handleError(error);
		}
	}

	/**
	 * 重置设备
	 */
	@ActionManager.withAction('BleReset')
	public async reset() {
		try {
			const result = await this.commander.reset();
			
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 写入AT指令
	 */
	public async writeATCommand(command: string) {
		try {
			const dataArr = NfcConverter.strToDecimalArr(command, 'utf-8');
			const dataSize = dataArr.length;
			const result = await this.commander.writeATCommand(dataSize, dataArr);
			
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 写入证书
	 */
	public async writeCertificate(type: 1 | 2 | 3, mode: number, data: string, checkData: number) {
		try {
			const dataArr = NfcConverter.strToDecimalArr(data, 'utf-8');
			const dataSize = dataArr.length;
			await this.commander.writeCertificate(type, mode,  dataArr, checkData, dataSize );
				
			return Promise.resolve('success');
		} catch (error) {
			this.handleError(error);
			return Promise.reject(error);
		}
	}

	/**
	 * 传感器校准
	 */
	public async distanceCalibration() {
		try {
			const result = await this.commander.distanceCalibration();
				
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 传感器盲区校准
	 */
	public async distanceBlindZoneCalibration() {
		try {
			const result = await this.commander.distanceBlindZoneCalibration();
					
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 清除电能
	 */
	@ActionManager.withAction('BleResetEnergy')
	public async resetEnergy(_channel: number) {
		this.logger.debug('ipso v1 device not support reset energy');
	}

	/**
	 * 传感器采集
	 */
	public async collect() {
		try {
			const result = await this.commander.collect();
						
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 重启
	 */
	@ActionManager.withAction('BleReboot')
	public async restart() {
		try {
			const result = await this.commander.restart();

			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}
	

	/**
	 * 传感器手动校准
	 */
	public async distanceManualDiagnose(params: { sensitivity: number, signalQuality: number, peakOrder: number }) {
		try {
			const result = await this.commander.distanceManualDiagnose(params);
						
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 读取设备日志
	 */
	public async readLog() {
		try {
			const result = await this.commander.readLog();
								
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 距离雷达曲线数据
	 */
	public async readDistanceRadarData() {
		try {
			const result = await this.commander.readDistanceRadar();
							
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 检查升级镜像数据
	 * @param data - 检查镜像数据
	 * @param modelSeries - 设备型号系列
	 * @param reboot - 是否重启
	 * @param moduleId - 模块ID
	 */
	@ActionManager.withAction('BleCheckUpgrade')
	public async checkUpgrade({ data, modelSeries, reboot, moduleId }: { data: number[], modelSeries: string, reboot?: boolean, moduleId?: number, isSubModule?: boolean }) {
		try {
			const { checkData, upgradeDataStartPosition } = UpgradeHelper.getUpgradeCheckData(data, modelSeries as MODEL_SERIES);
			const result = await this.commander.checkUpgradeData({data: checkData, reboot, moduleId});

			return Promise.resolve({
				inBootloader: result === 1,
				//仅在IPSO的动作中使用，这里仅做占位
				frameDataSize: data.length - upgradeDataStartPosition!
			});
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 获取设备信息
	 */
	@ActionManager.withAction('BleGetProductInfo')
	public async getProductInfo() {
		try {
			const result = await this.commander.getProductInfo();
				
			return Promise.resolve(result);
		} catch (error) {
			return this.handleError(error);
		}
	}
	/**
	 * 检查差分升级升级镜像数据
	 * @param data - 检查镜像数据
	 * @param modelSeries - 设备型号系列
	 * @param reboot - 是否重启
	 * @param moduleId - 模块ID
	 */
	@ActionManager.withAction('BleReadyPatchUpgrade')
	public async readyPatchUpgrade(_params: { data: number[], modelSeries: string}) {
		try {
			const result = await this.commander.readyPatchUpgrade();

			return Promise.resolve({
				inBootloader: result === 1,
				//仅在IPSO的动作中使用，这里仅做占位
				frameDataSize: 0
			});
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 全量升级镜像
	 * @param data - 镜像数据
	 * @param modelSeries - 设备型号系列
	 * @param reboot - 是否重启
	 * @param moduleId - 模块ID
	 * @returns 
	 */
	@ActionManager.withAction('BleSendUpgradeData')
	public async fullUpgrade({ data, modelSeries, reboot, moduleId, checkTimeout }: { data: number[], modelSeries: string, reboot?: boolean, moduleId?: number, frameDataSize: number, checkTimeout?: number, hasSubModule?: boolean, isSubModule?: boolean }) {
		try {
			const { upgradeDataStartPosition } = UpgradeHelper.getUpgradeCheckData(data, modelSeries as MODEL_SERIES);
			const upgradeData = slice(data, upgradeDataStartPosition);
			
			await this.commander.sendUpgradeData({ data: upgradeData, reboot, moduleId, checkTimeout });

			return Promise.resolve(true);
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 发送upgrade_plan.json数据
	 */
	@ActionManager.withAction('BleSendUpgradePlanJson')
	public async sendUpgradePlanJson(_rawData: Record<string, any>) {
		this.logger.debug('ipso v1 device not support send upgrade plan json');
	}

	/**
	 * 读取模板数据
	 */
	public async readTemplateData(name: string) {
		try {
			const rawData = await this.commander.readTemplateData(name);
			const stringifyFlashInfo = await DeviceUtils.getFlashInfo([ ...new Array(128).fill(0), ...rawData ]);
			const flashInfo = JSON.parse(stringifyFlashInfo);
			
			const isCrcError = get(flashInfo, 'code') === DeviceManagerError.getError({ type: 'CRC_ERROR' }).code;

			//如果crc校验错误，则报错
			if (isCrcError) {
				return Promise.reject(DeviceManagerError.getError({ type: 'CRC_ERROR' }));
			}

			return {
				deviceInfo: flashInfo as DeviceInfo,
				rawData
			};
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 发送传感器密码
	 */
	public async sendSensorPassword(password: string) {
		try {
			const result = await this.commander.sendSensorPassword(password);
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 删除模板数据
	 */
	public async deleteTemplateData(name: string) {
		try {
			const result = await this.commander.deleteTemplateData(name);
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 发送模板数据
	 */
	public async sendTemplateData(data: (number | string)[], name: string) {
		try {
			const result = await this.commander.sendTemplateData(data, name);
					
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 发送固件数据
	 */
	public async sendFirmwareData(data: number[], name: string) {
		try {
			const result = await this.commander.sendFirmwareData(data, name);
				
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 差分升级镜像
	 * @param data - 镜像数据
	 * @param reboot - 是否重启
	 * @returns 
	 */
	@ActionManager.withAction('BleSendPatchUpgradeData')
	public async patchUpgrade({ data, reboot }: { data: number[], reboot?: boolean, inBootloader: boolean, frameDataSize: number, hasSubModule?: boolean }) {
		try {
			await this.commander.sendPatchUpgradeData({ data, reboot});
	
			return Promise.resolve(true);
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 读取历史数据
	 */
	@ActionManager.withAction('BleReadHistoryData')
	public async readHistory({ startTime, endTime, model, type = 0, hardwareVersion, firmwareVersion }: {
		startTime: number;
		endTime: number;
		model: string;
		type: 0 | 1 | 2;
		hardwareVersion: string;
		firmwareVersion: string;
		exportType?: ExportType;
		cancelAbortController?: AbortController;
		/**
		 * 历史数据接收完成的回调
		 * @param params 包含数据条数、总时间和进度
		 */
		onHistoryDataReceived?: (params: { quantity: number; totalTime: number; progress: number }) => void;
	}): Promise<{ receiveHistoryData: Array<number>, receiveHistoryDataSize: number, status?: 'success' | 'partial', retryCount?: number }> {
		try {
			const data = await this.commander.readHistory({
				startTime,
				endTime,
				type,
				parser: (data: number[]) => {
					const result = DeviceUtils.getHistoryData(data, model, firmwareVersion, hardwareVersion);
					return result;
				}
			});
			this.logger.debug('read history data', data.receiveHistoryDataSize);
			
			return data;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 停止读取历史数据
	 * 发送停止命令给硬件，硬件收到后停止发送数据，正常接收流程会自动停止
	 */
	@ActionManager.withAction('BleStopReadHistory')
	public async stopReadHistory() {
		this.logger.debug('ipso v1 device not support stop read history');
	}

	/**
	 * 设置相对初始面
	 * @param type 
	 * @returns 
	 */
	public async relativeInitialSurface(type: 'setting' | 'clear' | 'zero-setting' | 'zero-clear') {
		try {
			const result = await this.commander.relativeInitialSurface(type);
			
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 清空数据
	 */
	public async clear(type: 'rainfall' | 'history') {
		try {
			const result = await this.commander.clear(type);
			
			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	/**
	 * 清空CTH01历史数据
	 */
	@ActionManager.withAction('BleClearCTH01History')
	public async clearCTH01History(_clearType: 0 | 1 | 2 | 3) {
		this.logger.debug('ipso v1 device not support clear cth01 history');
	}

	/**
	 * 获取通讯管理器
	 */
	public getManager<T extends Mode>(mode?: Mode): ManagerType<T> {
		const managerMode = mode ?? this.config.mode;

		if (this.managerInstance.has(managerMode)) {
			return this.managerInstance.get(managerMode) as ManagerType<T>;
		}

		let manager: IManager;

		switch (managerMode) {
			case 'ble':
				manager = BleManager;
				break;
			case 'nfc':
				manager = NfcManager;
				break;
			default:
				throw new Error(`Invalid mode: ${managerMode}`);
		}

		this.managerInstance.set(managerMode, manager);

		return manager as ManagerType<T>;
	}

	/**
	 * 根据模式获取通讯协议
	 */
	public getProtocol(mode?: Mode): IProtocol {
		const protocolMode = mode ?? this.config.mode;

		if (this.protocolInstance.has(protocolMode)) {
			return this.protocolInstance.get(protocolMode) as IProtocol;
		}

		let protocol: IProtocol;

		switch (protocolMode) {
			case 'nfc':
				protocol = new NfcProtocol();
				break;
			case 'ble':
				protocol = new BleProtocol();
				break;
			default:
				throw new Error(`Invalid mode: ${protocolMode}`);
		}

		this.protocolInstance.set(protocolMode, protocol);

		return protocol;
	}


	/**
	 * VS321获取检测图片
	 */
	public async getVerificationImage(type: 0 | 1 | 2 | 3) {
		return await this.commander.getVerificationImage(type);
	}

	/**
	 * PIR状态
	 */
	public async pirStatus(type: 0 | 1) {
		return await this.commander.pirStatus(type);
	}

	/**
	 * 图像曝光度
	 */
	public async setExposure(value: number) {
		return await this.commander.setExposure(value);
	}

	/**
	 * 光敏值
	 */
	public async fetchLightSensorValue() {
		return await this.commander.fetchLightSensorValue();
	}

	/**
	 * WE2版本
	 */
	public async fetchWE2Version() {
		return await this.commander.fetchWE2Version();
	}

	/**
	 * 检查模式是否合法
	 */
	private checkMode(mode: any): mode is Mode {
		if(mode !== 'ble' && mode !== 'nfc') {
			throw new Error(`Invalid mode: ${mode}`);
		}

		return true;
	}

	/**
	 * 错误处理
	 * @returns 
	 */
	private handleError(error: any) {
		if(error instanceof DeviceManagerError) {
			return Promise.reject(error);
		}

		//对错误进行包装再抛出
		if(error && error.status === 'password_error' || error === 'password_error') {
			return Promise.reject(DeviceManagerError.create('PASSWORD_ERROR'));
		}

		if(error && error.status === 'password_error_many_times') {
			return Promise.reject(DeviceManagerError.create('PASSWORD_ERROR_MANY_TIMES', error));
		}

		if(error instanceof Error) {
			return Promise.reject(error);
		}

		if(typeof error === 'string') {
			return Promise.reject(new Error(error));
		}

		return Promise.reject(error);
	}
}

//绑定DeviceManager，全局单例
container.bind(BaseDeviceManager).toSelf().inSingletonScope();

export const DeviceManager = container.get(BaseDeviceManager);