
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';
import { isLocationEnabled, promptForEnableLocationIfNeeded } from 'react-native-android-location-enabler';
import { Linking, AppState, AppStateStatus, Platform } from 'react-native';
import WifiManager, { WifiEntry } from 'react-native-wifi-reborn';
import { NetworkInfo } from 'react-native-network-info';
import { Notification } from '../../utils/notification';
import translate from '../../utils/translate';
import { BasicDeviceProviderTypes, deviceContainer, BasicDeviceProviderId } from './device_container';
import { Toast } from '../../utils/toast';
import { sleep } from '../../utils';
import EventEmitter from '../../utils/util/EventEmitter';

export const NETWORK_INFO_CHANGED_EVENT = 'NETWORK_INFO_CHANGED_EVENT';

export interface WifiInfo extends WifiEntry {
	signal: number;
	isSecure: boolean;
}

export interface WifiInfoChangedEvent {
	currentBSSID: string;
	currentSSID: string;
	gatewayIP: string;
}

export class WifiManagerService {
	private currentState: AppStateStatus = AppState.currentState;
	private beginConnect = false;
	public currentBSSID: string = '';
	public currentSSID: string = '';
	public gatewayIP: string = '';
	private logger: BasicDeviceProviderTypes['ExtendLogger'];
	private systemConnectedOnSuccess?: (event: WifiInfoChangedEvent) => void;
	// private subscription: any = null;

	constructor() {
		AppState.addEventListener('change', nextAppState => {
			if (
				this.beginConnect && this.currentState.match(/inactive|background/) && nextAppState === 'active'
			) {
				this.refreshCurrentWifiInfo().then(() => {
					this.systemConnectedOnSuccess?.({
						currentBSSID: this.currentBSSID,
						currentSSID: this.currentSSID,
						gatewayIP: this.gatewayIP
					});
				}).catch(error => {
					this.logger.error(`systemStartConnect error: ${error}`);
				}).finally(() => {
					this.systemConnectedOnSuccess = undefined;
					this.beginConnect = false;
				});
			}
			this.currentState = nextAppState;
		});
		const extendLogger = deviceContainer.get<BasicDeviceProviderTypes['ExtendLoggerFactory']>(BasicDeviceProviderId.ExtendLoggerFactory);

		this.logger = extendLogger('WifiManager');
	}

	private mapSignalLevelTo4Levels(dBm: number) {
		if (dBm >= -50) {
			return 4; // Excellent signal
		} else if (dBm >= -60) {
			return 3; // Good signal
		} else if (dBm >= -70) {
			return 2; // Fair signal
		} else if (dBm >= -80) {
			return 1; // Weak signal
		} else {
			return 1; // Very weak or no signal
		}
	}

	private isNetworkSecure(capabilities: string) {
		// Check for common security keywords
		return (
			capabilities.includes("WPA") ||
			capabilities.includes("WPA2") ||
			capabilities.includes("WPA3") ||
			capabilities.includes("WEP")
		);
	}


	isConnected(entry: WifiInfo): boolean {
		if (this.currentBSSID === '') {
			return false;
		}

		return entry.BSSID.toLowerCase() === this.currentBSSID.toLowerCase();
	}

	async connectTo(entry: WifiInfo, password: string | null): Promise<void> {
		try {
			await WifiManager.connectToProtectedWifiSSID({
				ssid: entry.SSID,
				password: password,
				timeout: 15
			});
			await this.refreshCurrentWifiInfo();
		} catch (error) {
			this.logger.error(`connectTo ${entry.SSID} error: ${error}`);
			return Promise.reject(error);
		}
	}

	async getWifiList(): Promise<WifiInfo[]> {
		try {
			const enable = await WifiManager.isEnabled();
			if (!enable) {
				Toast.show(translate('tips.pleaseOpenWifi'));
				await sleep(1000);
				WifiManager.setEnabled(true);
				return Promise.reject(new Error('Wifi is not enabled'));
			}

			await this.refreshCurrentWifiInfo();

			// Starting Android 9, it's only allowed to scan 4 times per 2 minuts in a foreground app.
			let wifiList = await WifiManager.reScanAndLoadWifiList();
			this.logger.debug("re scan Wifi List:", wifiList);
			if (!Array.isArray(wifiList)) {
				this.logger.debug("re scan failed");
				wifiList = await WifiManager.loadWifiList();
				// this.logger.debug("Wifi List:", wifiList.map(item => item.SSID));
			}

			if (wifiList && Array.isArray(wifiList)) {

				const list = wifiList.filter(entry => entry.BSSID !== null && this.isGatewayBSSID(entry.BSSID));
				return list.map(entry => ({
					...entry,
					signal: this.mapSignalLevelTo4Levels(entry.level),
					isSecure: this.isNetworkSecure(entry.capabilities)
				}));
			}

			return [];

		} catch (error) {
			this.logger.error(`getWifiList error: ${error}`);
			return [];
		}
	}

	isGatewayBSSID(bssid: string): boolean {
		return bssid.toLowerCase().startsWith('c0:ba:1f') || bssid.toLowerCase().startsWith('24:e1:24');
	}

	async refreshCurrentWifiInfo(): Promise<void> {
		try {
			const pastBSSID = this.currentBSSID;
			const currentBSSID = await NetworkInfo.getBSSID() ?? '';
			this.logger.debug(`raw BSSID: ${currentBSSID}`);
			if (!this.isGatewayBSSID(currentBSSID)) {
				this.currentBSSID = '';
				this.currentSSID = '';
				this.gatewayIP = '';
			} else {
				this.currentBSSID = currentBSSID;
				this.currentSSID = await WifiManager.getCurrentWifiSSID();
				this.gatewayIP = await NetworkInfo.getGatewayIPAddress() ?? '';
			}

			this.logger.debug(`refreshCurrentWifiInfo: ${this.currentSSID}, ${this.gatewayIP}, ${this.currentBSSID}`);

			if(pastBSSID !== this.currentBSSID) {
				EventEmitter.emit(NETWORK_INFO_CHANGED_EVENT, {
					currentBSSID: this.currentBSSID,
					currentSSID: this.currentSSID,
					gatewayIP: this.gatewayIP
				});
			}
			// this.logger.debug(`refreshCurrentWifiInfo: ${this.currentSSID}, ${this.gatewayIP}, ${this.currentBSSID}`);
		} catch (error) {
			this.logger.error(`refreshCurrentWifiInfo error: ${error}`);
		}
	}


	async systemStartConnect(onSuccess?: (event: WifiInfoChangedEvent) => void): Promise<void> {
		try {
			this.systemConnectedOnSuccess = onSuccess;
			this.beginConnect = true;
			if(Platform.OS === 'ios') {
				await Linking.openURL('App-Prefs:root=WIFI');
			} else {
				await Linking.sendIntent('android.settings.WIFI_SETTINGS');
			}

		} catch (error) {
			this.beginConnect = false;
			this.logger.error(`systemStartConnect error: ${error}`);
			return Promise.reject(error);
		}
	}

	async checkIOSPermission(): Promise<void> {
		try {
			const result = await check(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
			if (result !== RESULTS.GRANTED && result !== RESULTS.UNAVAILABLE) {
				// 显示权限说明通知
				await Notification.show({
					title: translate('permission.wifi.title'),
					content: translate('permission.wifi.content'),
				});

				const permissionResult = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
				Notification.hide(1500);
				if (permissionResult !== RESULTS.GRANTED && permissionResult !== RESULTS.UNAVAILABLE) {
					return Promise.reject(new Error('Permission not granted'));
				}
			}
		} catch (error) {
			this.logger.error(`checkIOSPermission error: ${error}`);
			return Promise.reject(error);
		}
	}

	async checkAndroidPermission(): Promise<void> {
		try {
			const result = await check(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
			if (result !== RESULTS.GRANTED && result !== RESULTS.UNAVAILABLE) {
				// 显示权限说明通知
				await Notification.show({
					title: translate('permission.wifi.title'),
					content: translate('permission.wifi.content'),
				});

				const permissionResult = await request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
				Notification.hide(1500);
				if (permissionResult !== RESULTS.GRANTED && permissionResult !== RESULTS.UNAVAILABLE) {
					return Promise.reject(new Error('Permission not granted'));
				}
			}


			const checkLocationEnabled = await isLocationEnabled();
			if (!checkLocationEnabled) {

				// 显示位置服务说明通知
				await Notification.show({
					title: translate('permission.location.title'),
					content: translate('permission.wifi.location.content'),
				});

				const enableLocationResult = await promptForEnableLocationIfNeeded();

				Notification.hide(1500);
				if (!enableLocationResult) {
					return Promise.reject(new Error('Location not enabled'));
				}
			}

			return Promise.resolve();
		} catch (error) {
			this.logger.error(`checkAndroidPermission error: ${error}`);
			return Promise.reject(error);
		}
	}
}

const _wifiManager = new WifiManagerService();
export default async () => {
	if (Platform.OS === 'android') {
		await _wifiManager.checkAndroidPermission();
	} else {
		await _wifiManager.checkIOSPermission();
	}

	return _wifiManager;
};