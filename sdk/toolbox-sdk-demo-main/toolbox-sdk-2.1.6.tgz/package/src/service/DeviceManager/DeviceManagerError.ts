import { DEVICE_MANAGER_ERROR, DeviceManagerErrorType } from './types';

export class DeviceManagerError extends Error {

	name: DeviceManagerErrorType;

	/**
	 * 错误码
	 */
	code: number;

	/**
	 * 导致错误的原始错误（原因）
	 */
	cause?: any;

	constructor(error: { name: DeviceManagerErrorType; code: number; message: string, cause?: any }) {
		super(error.message);
		this.name = error.name;
		this.code = error.code;
		this.cause = error.cause;
	}

	static throw(errorType: DeviceManagerErrorType) {
		throw new DeviceManagerError(DEVICE_MANAGER_ERROR[errorType] as any ?? DEVICE_MANAGER_ERROR.UNKNOWN_ERROR);
	}
	
	static create(errorType: DeviceManagerErrorType, cause?: any) {
		//@ts-ignore
		return new DeviceManagerError({
			...DEVICE_MANAGER_ERROR[errorType] as any,
			cause,
		} ?? DEVICE_MANAGER_ERROR.UNKNOWN_ERROR);
	}

	static getError({
		type,
		code
	}: {
		type?: DeviceManagerErrorType;
		code?: number;
	}) {
		if(code != null) {
			const findError = Object.values(DEVICE_MANAGER_ERROR).find(e => e.code === code);

			return findError ?? DEVICE_MANAGER_ERROR.UNKNOWN_ERROR;
		}

		if(type != null) {
			return DEVICE_MANAGER_ERROR[type] ?? DEVICE_MANAGER_ERROR.UNKNOWN_ERROR;
		}

		return DEVICE_MANAGER_ERROR.UNKNOWN_ERROR;
	}
}
