import { Platform } from 'react-native';
import NfcAdapter, { NfcTech, NfcEvents } from 'react-native-nfc-manager';
import { injectable, inject} from "inversify";
import _ from 'lodash';

import type { IEventEmitter } from '../../../utils/util/EventEmitter';
import type { IExtendLoggerFactory, LoggerType } from '../../../utils/logger';
import translate from '../../../utils/translate';

import { IManager, Providers, type IDeviceManagerContext, CommandData } from "../types";

import { NfcError } from './NfcError';
import { NfcEvent, NfcEventCallback } from './types';

import { Constructor } from '../../../model';

//代码预留，暂不在实际业务中使用
@injectable()
export class NfcManager implements IManager {
	type: 'nfc';
	
	tech: NfcTech;
	
	tag: any;

	/**
	 * 日志
	 */
	private logger: LoggerType;

	/**
	 * 上下文
	 */
	private context: IDeviceManagerContext;

	/**
	 * 事件发射器
	 */
	private eventEmitter: IEventEmitter;

	constructor(
		@inject(Providers.EventEmitter) EventEmitter: Constructor<IEventEmitter>,
		@inject(Providers.ExtendLoggerFactory) extendLoggerFactory: IExtendLoggerFactory,
		@inject(Providers.DeviceManagerContext) context: IDeviceManagerContext
	) {
		this.type = 'nfc';
		this.tech = Platform.OS === 'ios' ? NfcTech.MifareIOS : NfcTech.NfcA;
		this.logger = extendLoggerFactory('NfcManager');
		this.eventEmitter = new EventEmitter();
		this.context = context;
		NfcAdapter.start();
	}

	init() {
		return Promise.resolve();
	}

	async scan() {
		try {
			await NfcAdapter.cancelTechnologyRequest();
			this.logger.debug('start scan');
			this.eventEmitter.emit(NfcEvent.scan);
			
			//@ts-ignore
			await NfcAdapter.requestTechnology(this.tech, {
				alertMessage: translate('tips.approachTip')
			});

			return Promise.resolve(this.tag);
		} catch (error: any) { 
			return this.handleError(error, 'scan');
		}
	}

	/**
	 * 停止检测芯片
	 * @param waitForSessionClose - 是否等待会话关闭
	 */
	async stopScan(waitForSessionClose: boolean) {
		try {
			await NfcAdapter.cancelTechnologyRequest();
			this.eventEmitter.emit(NfcEvent.stopScan);
			this.tag = null;
			if (Platform.OS === 'ios' && waitForSessionClose) {
				return new Promise(resolve => {
					NfcAdapter.setEventListener(NfcEvents.SessionClosed, () => {
						resolve(0);
						NfcAdapter.setEventListener(NfcEvents.SessionClosed, null);
						return;
					});
				});
			}
			console.debug('stop detection');
			return Promise.resolve();
		} catch (error: any) {
			return this.handleError(error, 'stopScan');
		}
	}

	async connect() {
		try {
			this.tag = await NfcAdapter.getTag();
			this.eventEmitter.emit(NfcEvent.connect, this.tag);
			return Promise.resolve(this.tag);
		} catch (error) {
			return this.handleError(error, 'connect');
		}
	}

	public on<T extends NfcEvent>(event: T, listener: NfcEventCallback[T]) {
		this.eventEmitter.on(event, listener);

		return {
			off: () => this.eventEmitter.off(event, listener)
		};
	}

	get mode() {
		return 'p2p' as const;
	}

	destroy() {
		return Promise.resolve();
	}

	async checkNfcState() {
		const isSupport = await NfcAdapter.isSupported();

		if(!isSupport) {
			return Promise.reject(NfcError.getError('NFC_NOT_SUPPORT'));
		}

		try {
			const isEnabled = await NfcAdapter.isEnabled();

			if (!isEnabled) {
				this.logger.debug('NFC not enabled');
				if(Platform.OS === 'ios') {
					return Promise.reject(NfcError.getError('NFC_NOT_ENABLED'));
				}

				// eslint-disable-next-line no-async-promise-executor
				return new Promise(async (resolve, reject) => {
					try {
						await NfcAdapter.goToNfcSetting();
						this.logger.debug('navigate to NFC Setting success');
						setTimeout(async() => {
							const isEnabled = await NfcAdapter.isEnabled();
							this.logger.debug('Set timer check NFC is enabled', isEnabled);
							if(isEnabled) {
								resolve(0);
							} else {
								reject(NfcError.getError('NFC_NOT_ENABLED'));
							}
						}, 3000);
					} catch (error) {
						reject(error);
					}
				});
			}

			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	async beforeSend(): Promise<void> {
		try {
			this.eventEmitter.emit(NfcEvent.beforeSend);
			await this.checkNfcState();
			await this.scan();
			await this.connect();
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}
	
	async send(commandData: CommandData) {
		return Platform.OS === 'ios' ? NfcAdapter.sendMifareCommandIOS(commandData) : NfcAdapter.transceive(commandData);
	}

	async sendWithoutResponse(commandData: CommandData) {
		this.send(commandData);
		return Promise.resolve();
	}

	async afterSend(waitForSessionClose: boolean) {
		try {
			this.eventEmitter.emit(NfcEvent.afterSend);
			await this.stopScan(waitForSessionClose);
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	receive(_params?: Parameters<IManager['receive']>[0]) {
		return Promise.resolve([]);
	}

	get config() {
		return this.context.getConfig().nfc;
	}

	private handleError(error: any, tag?: string): Promise<any> {
		//错误代码对照链接：https://developer.apple.com/documentation/corenfc/nfcreadererror/code
		if (_.isString(error) && error.indexOf('NFCError') != -1) {
			if(error === 'NFCError:201') {
				error = NfcError.getError('DETECTION_TIMEOUT');
			} else if (error === 'NFCError:200') {
				error = NfcError.getError('DETECTION_TIMEOUT');
			} else if (error === 'NFCError:100') {
				error = NfcError.getError('TAG_CONNECTION_LOST');
			}
		} else if (error === 'cancelled') {
			error = NfcError.getError('DETECTION_CANCELLED');
		} else if (error === 'duplicate tech request, please call cancelTechnologyRequest to cancel previous one') {
			error = NfcError.getError('DUPLICATE_REQUEST');
		}

		if(__DEV__) {
			const logTag = tag ?  `${tag} error ->` : '';
			const logName = error.name ? `${error.name}` : '';
			const logContent = [ logTag, logName ].filter(s => s != '' && s != null).join(' ');
			const logData = {
				message: error.message,
				cause: error.cause
			};
	
			this.logger.error(logContent, logData);
		}

		return Promise.reject(error);
	}
}