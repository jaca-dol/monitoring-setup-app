import { NFC_ERRORS, NfcErrorType } from './types';

export class NfcError extends Error {
	code: number;
	cause?: any;

	constructor(error: { name: string; code: number; message: string, cause?: any }) {
		super(error.message);
		this.name = error.name;
		this.code = error.code;
		this.cause = error.cause;
	}

	static throw(errorType: NfcErrorType, cause?: any) {
		//@ts-ignore
		throw new NfcError({
			...NFC_ERRORS[errorType],
			cause,
		} ?? NFC_ERRORS.UNKNOWN_ERROR);
	}
	
	static create(errorType: NfcErrorType, cause?: any) {
		//@ts-ignore
		return new NfcError({
			...NFC_ERRORS[errorType],
			cause,
		} ?? NFC_ERRORS.UNKNOWN_ERROR);
	}

	static getError(errorType: NfcErrorType) {
		return NFC_ERRORS[errorType] ?? NFC_ERRORS.UNKNOWN_ERROR;
	}
}
