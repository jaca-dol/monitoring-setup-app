import * as NFC_TYPES from '../../nfc/types';

/**
 * NFC可能会抛出的错误集合
 */
export const NFC_ERRORS = {
	/**
	 * 数据错误
	 */
	DATA_ERROR: {
		name: 'DATA_ERROR',
		code: -1,
		message: 'Data error'
	},
	/**
	 * 超时
	 */
	TIMEOUT: {
		name: 'TIMEOUT',
		code: 2,
		message: 'Timeout'
	},
	/**
	 * 密码错误
	 */
	WRONG_PASSWORD: {
		name: 'WRONG_PASSWORD',
		code: 3,
		message: 'Wrong password'
	},
	/**
	 * 写入失败
	 */
	WRITE_FAILED: {
		name: 'WRITE_FAILED',
		code: 4,
		message: 'Write failed'
	},
	/**
	 * 型号不匹配
	 */
	UNMATCHED_DEVICE_MODEL: {
		name: 'UNMATCHED_DEVICE_MODEL',
		code: 5,
		message: 'Unmatched device model'
	},
	/**
	 * crc校验错误
	 */
	CRC_ERROR: {
		name: 'CRC_ERROR',
		code: 6,
		message: 'Crc error'
	},
	/**
	 * 采集中
	 */
	COLLECTING: {
		name: 'COLLECTING',
		code: 8,
		message: 'Collecting'
	},
	/**
	 * 处于bootloader中
	 */
	IN_BOOTLOADER: {
		name: 'IN_BOOTLOADER',
		code: 9,
		message: 'In bootloader'
	},
	/**
	 * 内存不足
	 */
	PATCH_OUT_OF_MEMORY: {
		name: 'PATCH_OUT_OF_MEMORY',
		code: 10,
		message: 'Patch out of memory'
	},
	/**
	 * 补丁头部错误
	 */
	PATCH_HEADER_ERROR: {
		name: 'PATCH_HEADER_ERROR',
		code: 11,
		message: 'Patch header error'
	},
	/**
	 * 补丁crc错误
	 */
	PATCH_CRC_ERROR: {
		name: 'PATCH_CRC_ERROR',
		code: 12,
		message: 'Patch crc error'
	},
	/**
	 * 补丁型号错误
	 */
	PATCH_MODEL_ERROR: {
		name: 'PATCH_MODEL_ERROR',
		code: 13,
		message: 'Patch model error'
	},
	/**
	 * 未知错误
	 */
	UNKNOWN_ERROR: {
		name: 'UNKNOWN_ERROR',
		code: 100,
		message: 'Unknown error'
	},
	/**
	 * 不支持NFC
	 */
	NFC_NOT_SUPPORT: {
		name: 'NFC_NOT_SUPPORT',
		code: 101,
		message: 'NFC not support'
	},
	/**
	 * NFC未启用
	 */
	NFC_NOT_ENABLED: {
		name: 'NFC_NOT_ENABLED',
		code: 102,
		message: 'NFC not enabled'
	},
	/**
	 * 取消监测NFC
	 */
	DETECTION_CANCELLED: {
		name: 'DETECTION_CANCELLED',
		code: 103,
		message: 'Detection cancelled'
	},

	/**
	 * 重复请求
	 */
	DUPLICATE_REQUEST: {
		name: 'DUPLICATE_REQUEST',
		code: 104,
		message: 'Duplicate request'
	},

	/**
	 * NFC检测超时
	 */
	DETECTION_TIMEOUT: {
		name: 'DETECTION_TIMEOUT',
		code: 105,
		message: 'Detection timeout'
	},
	/**
	 * NFC tag未找到
	 */
	TAG_NOT_FOUND: {
		name: 'TAG_NOT_FOUND',
		code: 106,
		message: 'Tag not found'
	},

	/**
	 * NFC tag连接丢失
	 */
	TAG_CONNECTION_LOST: {
		name: 'TAG_CONNECTION_LOST',
		code: 107,
		message: 'Tag connection lost'
	}
};

export type NfcErrorType = keyof typeof NFC_ERRORS;

export interface INfcError extends Error {
	code: number;
	name: keyof typeof NFC_ERRORS;
	message: string;
}

export enum NfcEvent {
	/**
	 * 扫描事件
	 */
	scan = 'scan',

	/**
	 * 停止扫描事件
	 */
	stopScan = 'stopScan',

	/**
	 * 连接事件
	 */
	connect = 'connect',

	/**
	 * 状态改变事件
	 */
	stateChange = 'stateChange',

	/**
	 * 发送数据前事件
	 */
	beforeSend = 'beforeSend',

	/**
	 * 发送数据事件
	 */
	send = 'send',
	/**
	 * 发送后事件
	 */
	afterSend = 'afterSend',
}

export interface NfcEventCallback {
	[NfcEvent.scan]: () => void;
	[NfcEvent.stopScan]: () => void;
	[NfcEvent.connect]: (tag: NFC_TYPES.NfcTag) => void;
	[NfcEvent.stateChange]: (state: any) => void;
	[NfcEvent.beforeSend]: () => void;
	[NfcEvent.send]: () => void;
	[NfcEvent.afterSend]: () => void;
}