import { Container } from 'inversify';

import { IStorage, Storage } from '../../utils/util';
import { BleEvent, BleEventCallback } from './ble';
import { IProtocol as IBaseProtocol } from './protocol';

export type CommandData = number[];

export type CommandResponse = number[];

export const NFC_MODE = 'nfc';
export const BLE_MODE = 'ble';

export type Mode = typeof NFC_MODE | typeof BLE_MODE;

export const container = new Container();

export enum DeviceManagerEvent {
	start = 'start',

	progress = 'progress',

	success = 'success',

	error = 'error',

	discover = 'discover'
}

export interface DeviceManagerEventCallback {
	[DeviceManagerEvent.start]: () => void;
	[DeviceManagerEvent.progress]: (progress: number) => void;
	[DeviceManagerEvent.success]: (data: any) => void;
	[DeviceManagerEvent.error]: (error: any) => void;
	[DeviceManagerEvent.discover]: (data: any) => void;
}

export interface IManager {
	/**
	 * 管理器类型
	 */
	type: 'ble' | 'nfc';

	/**
	 * 与设备交互的模式
	 */
	mode: 'p2p' | 'card';
	
	init: () => Promise<any>;

	destroy: () => void;

	config: IDeviceManagerConfig['ble'] | IDeviceManagerConfig['nfc'];

	scan(serviceUUIDs?: string[], seconds?: number, allowDuplicates?: boolean): Promise<void>;
	scan(params: any): Promise<void>;

	stopScan: (params?: any) => Promise<void>;

	connect(peripheralID: string): Promise<void>;
	connect(params: any): Promise<void>;

	beforeSend: () => Promise<void>;

	/**
	 * 发送数据，等待响应
	 */
	send: (commandData: CommandData) => Promise<number[]>;

	/**
	 * 发送数据，没有响应
	 */
	sendWithoutResponse: (commandData: CommandData) => Promise<void>;

	/**
	 * 接收数据
	 */
	receive: (
		params?: {
			/**
			 * 接收数据的大小
			 */
			size?: number;

			/**
			 * 检查数据是否接收完毕
			 */
			checkDone?: (data: number[], allData: number[]) => boolean;

			/**
			 * 转换数据
			 */
			transform?: (data: number[]) => number[];
		},
		options?: { timeout?: number; }
	) => Promise<number[]>;

	afterSend: (params?: any) => Promise<void>;

	on<T extends BleEvent>(event: T, listener: BleEventCallback[T]): {
		off: () => void
	};
	on<T>(event: T, listener: any): void;
}

export const DEVICE_MANAGER_ERROR = {
	UNKNOWN_ERROR: {
		name: 'UNKNOWN_ERROR',
		code: 0,
		message: 'Unknown error'
	},
	DATA_ERROR: {
		name: 'DATA_ERROR',
		code: -1,
		message: 'Data error'
	},
	ACK_ERROR: {
		name: 'ACK_ERROR',
		code: -2,
		message: 'Ack error'
	},
	TIMEOUT: {
		name: 'TIMEOUT',
		code: 2,
		message: 'Timeout'
	},
	//NFC校验密码错误
	WRONG_PASSWORD: {
		name: 'WRONG_PASSWORD',
		code: 3,
		message: 'Wrong password'
	},
	WRITE_FAILED: {
		name: 'WRITE_FAILED',
		code: 4,
		message: 'Write failed'
	},
	UNMATCH_DEVICE: {
		name: 'UNMATCH_DEVICE',
		code: 5,
		message: 'Unmatch device'
	},
	CRC_ERROR: {
		name: 'CRC_ERROR',
		code: 6,
		message: 'Crc error'
	},
	IN_BOOT_LOADER: {
		name: 'IN_BOOT_LOADER',
		code: 9,
		message: 'In boot loader'
	},
	INVALID_MODE: {
		name: 'INVALID_MODE',
		code: 10,
		message: 'Invalid mode'
	},
	//蓝牙校验密码错误
	PASSWORD_ERROR: {
		name: 'PASSWORD_ERROR',
		code: 11,
		message: 'Password error'
	},
	//蓝牙校验密码错误多次
	PASSWORD_ERROR_MANY_TIMES: {
		name: 'PASSWORD_ERROR_MANY_TIMES',
		code: 12,
		message: 'Password error many times'
	}
};

export interface IDeviceManagerConfig {
	//模式
	mode: Mode;

	/**
	 * nfc配置
	 */
	nfc: {
		/**
		 * 最大字节大小
		 */
		maxByteSize: number;
	};

	/**
	 * 蓝牙配置
	 */
	ble: {
		/**
		 * 扫描时长（秒）
		 */
		scanSeconds: number;

		/**
		 * 默认服务ID
		 */
		serviceUUID: string;
				
		/**
		 * 默认写入特征ID
		 */
		writeCharacteristicUUID: string;

		/**
		 * 默认订阅特征ID
		 */
		notifyCharacteristicUUID: string;

		/**
		 * 默认pin码
		 */
		pinCode: string;

		/**
		 * 最大字节大小
		 */
		maxByteSize: number;
	};

	//默认密码
	password: string;
}

export interface IDeviceManagerContext {
	setConfig: (config: Partial<IDeviceManagerConfig>) => void;

	getConfig: () => IDeviceManagerConfig;
}

export type DeviceManagerErrorType = keyof typeof DEVICE_MANAGER_ERROR;

export const Providers = {
	BleAdapter: Symbol.for('BleAdapter'),
	EventEmitter: Symbol.for('EventEmitter'),
	Logger: Symbol.for('Logger'),
	ExtendLoggerFactory: Symbol.for('ExtendLoggerFactory'),
	DeviceManager: Symbol.for('DeviceManager'),
	DeviceManagerContext: Symbol.for('DeviceManagerContext'),
	Storage: Symbol.for('Storage'),
	BleActionApi: Symbol.for('BleActionApi'),
} as const;

export interface ProviderTypes {
	Storage: {
		constructor: new (options?: ConstructorParameters<typeof Storage>[0]) => IStorage;
		instance: IStorage;
	};
	DeviceManagerContext: {
		instance: IDeviceManagerContext;
	}
}

export type IProtocol = IBaseProtocol;

/**
 * 设备管理器接口
 */

export interface IDeviceManager {
	/**
	 * 初始化
	 */
	init: () => Promise<any>;

	/**
	 * 获取配置
	 */
	config: IDeviceManagerConfig;

	/**
	 * 设置配置
	 */
	setConfig: (config: Partial<IDeviceManagerConfig>) => void;

	/**
	 * 获取模式
	 */
	getMode: () => Mode;

	/**
	 * 切换模式
	 */
	use: (mode: Mode) => void;

	/**
	 * 获取管理器
	 */
	getManager: (mode?: Mode) => IManager;

	/**
	 * 获取协议
	 */
	getProtocol: () => IProtocol;

	/**
	 * 订阅config变化
	 */
	subscribeConfig: (listener: (config: IDeviceManagerConfig) => void) => void;

	/**
	 * 获取config快照
	 */
	getConfigSnapshot: () => IDeviceManagerConfig;
}

export enum ExportType {
	ALARM = 0,
	PERIODIC = 1,
	MONTHLY_ENERGY = 2,
	MONTHLY_EXTREME = 3,
}

export const MONTHLY_EXPORT_TYPES = [ ExportType.MONTHLY_ENERGY, ExportType.MONTHLY_EXTREME ];
