import { Container, interfaces } from 'inversify';

import Logger from '../../../utils/logger';

import { BasicDeviceProviderId, BasicDeviceProviderTypes } from './DeviceProvider';

/**
 * 设备模块的依赖注入容器
 * @link api - https://github.com/inversify/InversifyJS/blob/master/wiki/container_api.md
 * @link scope - https://github.com/inversify/InversifyJS/blob/master/wiki/scope.md
 */
const deviceContainer = new Container({
	// 跳过基类检查，避免因为抽象类的构造函数而报错
	skipBaseClassChecks: true
});

//绑定自有logger的实例
deviceContainer.bind<BasicDeviceProviderTypes['Logger']>(BasicDeviceProviderId.Logger).toConstantValue(Logger);

//绑定自有logger的extend方法
deviceContainer.bind<interfaces.Factory<BasicDeviceProviderTypes['ExtendLogger']>>(BasicDeviceProviderId.ExtendLoggerFactory).toFactory<BasicDeviceProviderTypes['ExtendLogger'], string[]>((context: interfaces.Context) => {
	const logger = context.container.get<BasicDeviceProviderTypes['Logger']>(BasicDeviceProviderId.Logger);
	
	return logger.extend;
});

export { deviceContainer };