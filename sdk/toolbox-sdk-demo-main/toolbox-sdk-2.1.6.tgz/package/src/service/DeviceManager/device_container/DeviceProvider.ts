import { IExtendLoggerFactory, LoggerType, ILogger } from '../../../utils/logger';


export const BasicDeviceProviderId = {
	Logger: Symbol.for('Logger'),
	ExtendLogger: Symbol.for('ExtendLogger'),
	ExtendLoggerFactory: Symbol.for('ExtendLoggerFactory')	
};

export interface BasicDeviceProviderTypes {
	Logger: ILogger;
	ExtendLogger: LoggerType;
	ExtendLoggerFactory: IExtendLoggerFactory;
}