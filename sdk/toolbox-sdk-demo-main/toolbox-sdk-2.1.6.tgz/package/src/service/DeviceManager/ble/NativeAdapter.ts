import { NativeEventEmitter, NativeModules, Platform } from 'react-native';

import { Notification } from '../../../utils/notification';
import { inject, injectable } from 'inversify';
import { isLocationEnabled, promptForEnableLocationIfNeeded } from 'react-native-android-location-enabler';
import BleManager from 'react-native-ble-manager';
import { check, PERMISSIONS, PermissionStatus, requestMultiple, RESULTS } from 'react-native-permissions';
import translate from '../../../utils/translate';

import { runWithTimeout, sleep } from '../../../utils/util';

import { ILogger, LoggerType } from '../../../utils/logger';
import { Providers } from '../types';
import { BleError } from './BleError';
import { AdapterBleState, AdapterPeripheralInfo, BleAdapterEvent, IBleAdapter } from './types';

@injectable()
export class NativeAdapter implements IBleAdapter {
	bleManagerEmitter: NativeEventEmitter;
	
	rssiStrengths: number[];

	logger: LoggerType;

	constructor(
		@inject(Providers.Logger) Logger: ILogger,
	) {
		const BleManagerModule = NativeModules.BleManager;
		this.bleManagerEmitter = new NativeEventEmitter(BleManagerModule);
		this.rssiStrengths = [];
		this.logger = Logger.extend('BleAdapter');
	}

	async init(): Promise<void> {
		try {
			if(Platform.OS === 'android') {
				await this.checkAndroidPermission();
			}

			await BleManager.start({
				showAlert: true
			});

			//ios的会在start之后主动触发状态更新（取决于系统版本，ios16会主动触发，ios15不会），
			//android需要手动触发
			const firstState = await this.checkState();
			
			if(Platform.OS === 'ios') {
				//iOS的初始化需要申请权限，这里要等待权限申请完成
				if(firstState === 'unknown') {
					await sleep(10);
					const nextState = await this.checkState(s => s !== 'unknown');
					
					//如果申请权限失败，直接抛出异常
					if(nextState === 'unauthorized') {
						throw BleError.create('PERMISSION_NOT_GRANTED');
					}
				}
			}
		} catch (error) {
			return Promise.reject(error);
		}
	}

	async checkState(condition?: (state: AdapterBleState) => boolean): Promise<AdapterBleState> {
		return new Promise(resolve => {
			BleManager.checkState();

			const listener = this.bleManagerEmitter.addListener(BleAdapterEvent.DidUpdateState, ({ state }: { state: AdapterBleState }) => {
				if(typeof condition === 'function' && !condition(state)) {
					return;
				}

				listener.remove();
				resolve(state);
			});
		});
	}

	async checkAndroidPermission(): Promise<void> {
		try {
			const permissions = [ 
				PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
				PERMISSIONS.ANDROID.BLUETOOTH_SCAN, 
				PERMISSIONS.ANDROID.BLUETOOTH_CONNECT 
			];

			// 先检查是否已经获取所有权限
			const currentPermissions = await Promise.all(
				permissions.map(permission => check(permission))
			);

			//UNAVAILABLE表示不需要判断
			const hasAllPermissions = currentPermissions.every(
				(result: PermissionStatus) => result === RESULTS.GRANTED || result === RESULTS.UNAVAILABLE
			);

			if (!hasAllPermissions) {
				// 显示权限说明通知
				await Notification.show({
					title: translate('permission.bluetooth.title'),
					content: translate('permission.bluetooth.content'),
				});

				const permissionResults = await requestMultiple(permissions);
				
				Notification.hide(1500);

				const isAllPermissionsGranted = Object.values(permissionResults).every(
					result => result === RESULTS.GRANTED || result === RESULTS.UNAVAILABLE
				);
				
				if (!isAllPermissionsGranted) {
					BleError.throw('PERMISSION_NOT_GRANTED');
				}
			}

			// 检查定位服务功能是否开启
			const checkLocationEnabled = await isLocationEnabled();
			if (!checkLocationEnabled) {
				// 显示位置服务说明通知
				await Notification.show({
					title: translate('permission.location.title'),
					content: translate('permission.location.content'),
				});

				try {
					const enableLocationResult = await promptForEnableLocationIfNeeded();
					
					Notification.hide(1500);

					if (!enableLocationResult) {
						BleError.throw('PERMISSION_NOT_GRANTED');
					}
				} catch (error) {
					Notification.hide(1500);
					console.log('error: ', error);
					BleError.throw('PERMISSION_NOT_GRANTED');
				}
			}

			return Promise.resolve();
		} catch (error) {
			Notification.hide(1500);
			return Promise.reject(error);
		}
	}

	scan(...args: Parameters<IBleAdapter['scan']>): Promise<void> {
		return BleManager.scan(...args);
	}

	stopScan(): Promise<void> {
		return BleManager.stopScan();
	}

	async connect(peripheralId: string, signal?: AbortSignal): Promise<void> {
		try {
			await runWithTimeout(BleManager.connect(peripheralId), 15000, 'connect timeout', signal);
			this.logger.debug('connect success');
			if(Platform.OS === 'android') {
				/** 
				 * 0：平衡模式（默认，约 30ms-50ms）
				 * 1：低延迟（连接间隔约 7.5ms-15ms）
				 * 2：低功耗（约 100ms-125ms）
				 * 蓝牙连接间隔如果低于25ms，设备读写会有蓝牙锁，导致读写超时
				*/
				await BleManager.requestConnectionPriority(peripheralId, 0);
				this.logger.debug('request connection priority success');
				//此接口导致部分机型重复配对，从而导致断连
				// const phy = await BleManager.requestPHY(peripheralId, 2, 2, 0);
				// this.logger.debug('request phy success', phy);
			}
		} catch (error) {
			return Promise.reject(error);
		}
	}

	disconnect(peripheralID: string, force = true): Promise<void> {
		return BleManager.disconnect(peripheralID, force);
	}

	async readRSSI(peripheralId: string): Promise<number> {
		try {
			const threshold = 20; // 信号强度值的阈值
			const bufferSize = 10; // 信号强度值的缓冲区大小
			let rssi = await BleManager.readRSSI(peripheralId);

			//部分iOS的机型（iPhone X/11）信号强度值不稳定会突变，需要做平滑处理
			if(Platform.OS === 'ios') {
				// 如果当前信号强度值与最新的值差距过大，则重新读取2次，并取3个值的平均值
				if (this.rssiStrengths.length > 0 && Math.abs(rssi - this.rssiStrengths[this.rssiStrengths.length - 1]!) > threshold) {
					await sleep(5);
					const secondRssi = await BleManager.readRSSI(peripheralId);
					await sleep(5);
					const thirdRssi = await BleManager.readRSSI(peripheralId);
					rssi = Math.round((rssi + secondRssi + thirdRssi) / 3); // 取三个值的平均值，并作为新的信号强度值
				}

				// 将最新的信号强度值添加到数组中
				this.rssiStrengths.push(rssi);

				if (this.rssiStrengths.length > bufferSize) {
					this.rssiStrengths.shift(); // 移除数组第一个元素（最旧的元素）
				}
			}

			return rssi;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	createBond(peripheralId: string, peripheralPin?: string): Promise<void> {
		if(Platform.OS === 'ios') {
			return Promise.resolve();
		}
		return BleManager.createBond(peripheralId, peripheralPin);
	}

	removeBond(peripheralId: string): Promise<void> {
		if(Platform.OS === 'ios') {
			return Promise.resolve();
		}
		return BleManager.removeBond(peripheralId);
	}

	async getServices(peripheralId: string, serviceUUIDs?: string[], mtu?: number): Promise<AdapterPeripheralInfo> {
		try {
			// 华为mate70 & 鸿蒙6.0.0，容易超时失败
			const services = await runWithTimeout(BleManager.retrieveServices(peripheralId, serviceUUIDs), 12000, 'get services timeout');

			if(Platform.OS === 'android' && mtu != null) {
				this.logger.debug('request MTU', peripheralId, mtu);
				await BleManager.requestMTU(peripheralId, mtu);
			}
			return services;
		} catch (error: any) {
			if(error.message === 'get services timeout') {
				this.logger.debug('disconnect in error getServices');
				await this.disconnect(peripheralId);
			}

			return Promise.reject(error);
		}
	}

	async startNotification(peripheralID: string, serviceUUID: string, characteristicUUID: string): Promise<void> {
		try {
			await BleManager.startNotification(peripheralID, serviceUUID, characteristicUUID);
			return Promise.resolve();
		} catch (error) {
			if(typeof error === 'string' && error.includes('Error writing descriptor status')) {
				await this.refreshCache(peripheralID);
				this.logger.debug('refresh cache in error startNotification');
				await this.disconnect(peripheralID);
				this.logger.debug('disconnect in error startNotification');
			}

			return Promise.reject(error);
		}
	}

	stopNotification(peripheralID: string, serviceUUID: string, characteristicUUID: string): Promise<void> {
		return BleManager.stopNotification(peripheralID, serviceUUID, characteristicUUID);
	}

	read(peripheralID: string, serviceUUID: string, characteristicUUID: string): Promise<any> {
		return BleManager.read(peripheralID, serviceUUID, characteristicUUID);
	}

	write(peripheralID: string, serviceUUID: string, characteristicUUID: string, data: any, maxByteSize?: number | undefined): Promise<void> {
		return BleManager.write(peripheralID, serviceUUID, characteristicUUID, data, maxByteSize);
	}

	writeWithoutResponse(peripheralID: string, serviceUUID: string, characteristicUUID: string, data: any, maxByteSize?: number | undefined, queueSleepTime?: number): Promise<void> {
		return BleManager.writeWithoutResponse(peripheralID, serviceUUID, characteristicUUID, data, maxByteSize, queueSleepTime);
	}

	getConnectedPeripherals(...args: Parameters<IBleAdapter['getConnectedPeripherals']>): Promise<AdapterPeripheralInfo[]> {
		return BleManager.getConnectedPeripherals(...args);
	}
	
	refreshCache(peripheralId: string): Promise<boolean> {
		if(Platform.OS === 'ios') {
			return Promise.resolve(true);
		}

		return BleManager.refreshCache(peripheralId);
	}

	isPeripheralConnected(peripheralId: string): Promise<boolean> {
		return BleManager.isPeripheralConnected(peripheralId,[]);
	}

	getBondedPeripherals(): Promise<AdapterPeripheralInfo[]> {
		if (Platform.OS === 'ios') {
			return Promise.resolve([]);
		}
		return BleManager.getBondedPeripherals();
	}

	enableBluetooth(): Promise<void> {
		if (Platform.OS === 'ios') {
			return Promise.resolve();
		}

		return BleManager.enableBluetooth();
	}

	addEventListener<E extends BleAdapterEvent>(eventName: E, callback: any) {
		const subscription = this.bleManagerEmitter.addListener(eventName, callback);

		return {
			remove: () => {
				subscription.remove();
			}
		};
	}

	removeAllListeners(eventName: string) {
		this.bleManagerEmitter.removeAllListeners(eventName);
	}
}
