/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Peripheral as BasePeripheral, PeripheralInfo as BasePeripheralInfo, ScanOptions } from 'react-native-ble-manager';

export type AdapterPeripheral = BasePeripheral;

export type AdapterPeripheralInfo = BasePeripheralInfo;

export type AdapterBleState = 'unknown' | 'resetting' | 'unsupported' | 'unauthorized' | 'on' | 'off' | 'turning_on' | 'turning_off';

export type BleState = 'uninitialized' | 'connected' | 'disconnect' | AdapterBleState;

/**
 * Adapter蓝牙事件
 */
export enum BleAdapterEvent {
	/**
	 * 扫描结束事件
	 */
	StopScan = 'BleManagerStopScan',

	/**
	 * 蓝牙状态变化事件
	 */
	DidUpdateState = 'BleManagerDidUpdateState',

	/**
	 * 连接外围设备事件
	 */
	ConnectPeripheral = 'BleManagerConnectPeripheral',

	/**
	 * 断开外围设备事件
	 */
	DisconnectPeripheral = 'BleManagerDisconnectPeripheral',

	/**
	 * 发现外围设备事件
	 */
	DiscoverPeripheral = 'BleManagerDiscoverPeripheral',

	/**
	 * 特征值变化事件
	 */
	DidUpdateValueForCharacteristic = 'BleManagerDidUpdateValueForCharacteristic',
}

/**
 * Adapter蓝牙事件回调
 */
export interface IBleAdapterEventCallback {
	[BleAdapterEvent.StopScan]: (status: number) => void;
	[BleAdapterEvent.DidUpdateState]: ({ state }: { state: AdapterBleState }) => void;
	[BleAdapterEvent.ConnectPeripheral]: ({peripheral}: {peripheral: string}) => void;
	[BleAdapterEvent.DisconnectPeripheral]: ({peripheral, status, code, domain}: {peripheral: string, status: number, code: number, domain: string }) => void;
	[BleAdapterEvent.DiscoverPeripheral]: (peripheral: Peripheral) => void;
	[BleAdapterEvent.DidUpdateValueForCharacteristic]: ({ value, peripheral, characteristic, service }: {
		value: any[];
		peripheral: string;
		characteristic: string;
		service: string;
	}) => void;
}

/**
 * 蓝牙适配器
 */
export interface IBleAdapter {

	/**
	 * 初始化
	 */
	init(): Promise<any>;

	/**
	 * 扫描外围设备
	 */
	scan(
		serviceUUIDs: string[],
		seconds: number,
		allowDuplicates?: boolean,
		options?: ScanOptions
	): Promise<void>;

	/**
	 * 停止扫描
	 */
	stopScan(): Promise<void>;

	/**
	 * 连接外围设备
	 */
	connect(peripheralId: string, signal?: AbortSignal): Promise<void>;

	/**
	 * 断开连接
	 */
	disconnect(
		peripheralID: string,
		force?: boolean
	): Promise<void>;

	/**
	 * 获取蓝牙信号
	 */
	readRSSI(peripheralID: string): Promise<number>;

	/**
	 * 绑定外围设备 
	 */
	createBond(peripheralID: string, peripheralPin?: string | undefined): Promise<void>;

	/**
	 * 移除绑定外围设备 
	 */
	removeBond(peripheralID: string): Promise<void>;

	/**
	 * 获取设备的所有服务和特征值
	 * @param peripheralId
	 * @param serviceUUIDs 如果传入，则只获取指定服务的服务和特征值 [iOS only]
	 * @param mtu 如果有传mtu，在请求服务成功后，会去请求MTU [Android only]
	 */
	getServices(peripheralId: string, serviceUUIDs?: string[], mtu?: number): Promise<AdapterPeripheralInfo>;

	/**
	 * 判断外围设备是否已连接
	 * @param peripheralId
	 */
	isPeripheralConnected(peripheralId: string): Promise<boolean>;

	/**
	 * 获取已绑定的外围设备
	 */
	getBondedPeripherals(): Promise<AdapterPeripheral[]>

	/**
	 * 启用设备特征值变化时的 notify 功能，订阅特征
	 */
	startNotification(
		peripheralID: string,
		serviceUUID: string,
		characteristicUUID: string
	): Promise<void>;

	/**
	 * 禁用设备特征值变化时的 notify 功能
	 */
	stopNotification(
		peripheralID: string,
		serviceUUID: string,
		characteristicUUID: string
	): Promise<void>;

	/**
	 * 读取特征值
	 */
	read(
		peripheralID: string,
		serviceUUID: string,
		characteristicUUID: string
	): Promise<any>;

	/**
	 * 写入特征值
	 */
	write(
		peripheralID: string,
		serviceUUID: string,
		characteristicUUID: string,
		data: any,
		maxByteSize?: number
	): Promise<void>;

	/**
	 * 写入特征值
	 */
	writeWithoutResponse(
		peripheralID: string,
		serviceUUID: string,
		characteristicUUID: string,
		data: any,
		maxByteSize?: number,
		queueSleepTime?: number
	): Promise<void>;

	/**
	 * 刷新BLE缓存
	 */
	refreshCache(peripheralID: string): Promise<boolean>;

	/**
	 * 获取已连接的外围设备
	 * @param serviceUUIDs
	 */
	getConnectedPeripherals(serviceUUIDs: string[]): Promise<AdapterPeripheral[]>;

	/**
	 * 添加事件监听
	 */
	addEventListener<E extends BleAdapterEvent>(eventName: E, callback: IBleAdapterEventCallback[E]): {
		remove: () => void;
	};

	/**
	 * 移除所有事件监听
	 */
	removeAllListeners?<E extends BleAdapterEvent>(evetName: E): void;

	/**
	 * 检查蓝牙状态
	 */
	checkState(): Promise<AdapterBleState>;

	/**
	 * 开启蓝牙
	 */
	enableBluetooth(): Promise<void>;
}

export type BleAdapterConstructor = new (name: string) => IBleAdapter;

export interface Peripheral extends AdapterPeripheral {
	/**
	 * 设备名称
	 */
	name: string;

	/**
	 * 是否已认证
	 */
	authenticated?: boolean;

	/**
	 * 是否已连接
	 */
	connected: boolean;

	/**
	 * 连接时间
	 */
	connectedTime: number | null;

	/**
	 * 根据rssi计算的信号强度
	 * 1 - 4 信号依次增强
	 */
	signal: number;

	/**
	 * 绑定状态
	 */
	bondState: 'unbond' | 'bonded';

	/**
	 * 已连接数量
	 */
	connectCount: number;

	/**
	 * mac地址
	 */
	mac: string;

	/**
	 * 是否已开启监听
	 */
	startNotification: boolean;

	/**
	 * 是否已获取服务
	 */
	getServiced: boolean;


	/**
	 * 扫描时间（debug模式下）
	 */
	scanDuration?: number;

	/**
	 * 断连原因
	 */
	disconnectReason: {
		/**
		 * 断连类型
		 */
		type: 'unknown' | 'force-disconnect';

		/**
		 * 断连文本
		 */
		text?: string;

		/**
		 * 断连负载
		 */
		payload?: {
			/**
			 * 连接的设备型号
			 */
			model: string;

			/**
			 * 设备时间
			 */
			time: string;
		}
	} | null;
}

export interface PeripheralInfo extends Peripheral, AdapterPeripheralInfo {
	/**
	 * 设备名称
	 */
	name: string;
}

export enum BleEvent {
	/**
	 * 扫描事件
	 */
	scan = 'scan',

	/**
	 * 停止扫描事件
	 */
	stopScan = 'stopScan',

	/**
	 * 连接事件
	 */
	connect = 'connect',

	/**
	 * 断开连接事件
	 */
	disconnect = 'disconnect',

	/**
	 * 发现设备事件
	 */
	discover = 'discover',

	/**
	 * 蓝牙状态改变事件
	 */
	stateChange = 'stateChange',

	/**
	 * 更新特征值事件
	 */
	updateCharacteristic = 'updateCharacteristic',

	/**
	 * 发送数据前事件
	 */
	beforeSend = 'beforeSend',

	/**
	 * 发送数据事件
	 */
	send = 'send',

	/**
	 * 接收到数据事件
	 */
	receiveData = 'sendReceiveData',

	/**
	 * 发送后事件
	 */
	afterSend = 'afterSend',
}

export interface BleEventCallback {
	[BleEvent.scan]: () => void;
	[BleEvent.stopScan]: () => void;
	[BleEvent.connect]: (peripheral: Peripheral) => void;
	[BleEvent.disconnect]: (peripheral: Peripheral) => void;
	[BleEvent.discover]: (peripheral: Peripheral) => void;
	[BleEvent.stateChange]: (state: AdapterBleState) => void;
	[BleEvent.updateCharacteristic]: ({ value, peripheral, characteristic, service }: {
		value: any[];
		peripheral: string;
		characteristic: string;
		service: string;
	}) => void;
	[BleEvent.beforeSend]: () => void;
	[BleEvent.send]: () => void;
	[BleEvent.afterSend]: () => void;
	[BleEvent.receiveData]: (data: any) => void;
}

/**
 * Ble可能会抛出的错误集合
 */
export const BLE_ERRORS = {
	UNKNOWN_ERROR: {
		name: 'UNKNOWN_ERROR',
		code: 100,
		message: 'Unknown error'
	},
	BLE_NOT_ENABLED: {
		name: 'BLE_NOT_ENABLED',
		code: 101,
		message: 'Bluetooth not enabled'
	},
	PERMISSION_NOT_GRANTED: {
		name: 'PERMISSION_NOT_GRANTED',
		code: 102,
		message: 'Permission not granted'
	},
	BLE_NOT_INIT: {
		name: 'BLE_NOT_INIT',
		code: 103,
		message: 'Ble not init'
	},
	CONNECT_FAILED: {
		name: 'CONNECT_FAILED',
		code: 104,
		message: 'Connect failed'
	},
	TIMEOUT: {
		name: 'TIMEOUT',
		code: 105,
		message: 'Timeout'
	},
	PERIPHERAL_NOT_FOUND: {
		name: 'PERIPHERAL_NOT_FOUND',
		code: 106,
		message: 'Peripheral not found'
	},
	PERIPHERAL_BONDED: {
		name: 'PERIPHERAL_BONDED',
		code: 107,
		message: 'Peripheral bonded'
	},
	NOT_CONNECTED_PERIPHERAL: {
		name: 'NOT_CONNECTED_PERIPHERAL',
		code: 108,
		message: 'Not connected peripheral'
	},
	SERVICE_NOT_FOUND: {
		name: 'SERVICE_NOT_FOUND',
		code: 109,
		message: 'Service not found'
	},
	USER_CANCELLED_BLE_CONNECTION: {
		name: 'USER_CANCELLED_BLE_CONNECTION',
		code: 110,
		message: 'User cancelled BLE connection'
	}
};

export type BleErrorType = keyof typeof BLE_ERRORS;

export interface IBleError extends Error {
	code: number;
	name: keyof typeof BLE_ERRORS;
	message: string;
}

