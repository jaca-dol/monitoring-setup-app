export const isVA05DeviceName = (deviceName?: string): boolean => {
	return deviceName?.toUpperCase().includes('VA05') ?? false;
};
