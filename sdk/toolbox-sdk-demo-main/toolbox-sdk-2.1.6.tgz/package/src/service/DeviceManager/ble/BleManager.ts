import { Platform } from 'react-native';

import { Buffer } from 'buffer';
import { inject, injectable } from 'inversify';
import { isString, ListIteratee, Many, orderBy } from 'lodash';

import { ILogger, LoggerType } from '../../../utils/logger';
import { retry, RetryOptions, runWithTimeout } from '../../../utils/util';
import { BleProtocol } from '../protocol';
import { IDeviceManagerContext, IManager, Providers } from '../types';
import { BleError } from './BleError';
import { BleAdapterEvent, BleEvent } from './types';
import { isVA05DeviceName } from './utils';

import type { IEventEmitter } from '../../../utils/util/EventEmitter';

import type { Peripheral, PeripheralInfo, IBleAdapter, BleEventCallback, AdapterPeripheral, AdapterBleState, BleState } from './types';
interface Listener {
	remove: () => void;
}

type IDeviceManagerContextType = IDeviceManagerContext;

type EmitInterceptor = (bleEvent: BleEvent, ...args: any[]) => boolean;

/**
 * 蓝牙管理器，负责蓝牙的管理
 * 包括初始化、扫描、连接、断开、发送数据
 */
@injectable()
export class BleManager implements IManager {

	/**
	 * 蓝牙适配器
	 */
	private bleAdapter: IBleAdapter;

	/**
	 * 日志
	 */
	private logger: LoggerType;

	/**
	 * 上下文
	 */
	private context: IDeviceManagerContext;

	/**
	 * 缓存的设备
	 */
	private peripherals: Map<string, Peripheral>;

	/**
	 * 扫描到的设备
	 */
	private scannedPeripherals: Map<string, Peripheral>;

	/**
	 * 当前连接的设备
	 */
	private currentConnectedPeripheral: Peripheral | undefined;

	/**
	 * 适配器事件监听器
	 */
	private adapterEventListeners: Map<BleAdapterEvent, Listener>;

	/**
	 * 事件发射器
	 */
	private eventEmitter: IEventEmitter;

	/**
	 * 发送事件拦截器
	 */
	private emitInterceptors: EmitInterceptor[];

	/**
	 * 协议
	 */
	private protocol: InstanceType<typeof BleProtocol>;

	/**
	 * 是否正在扫描
	 */
	public isScanning: boolean;

	/**
	 * 蓝牙状态
	 */
	public bleState: BleState;

	/**
	 * 类型
	 */
	public type = 'ble' as IManager['type'];

	/**
	 * 模式
	 */
	public mode: IManager['mode'] = 'p2p';

	public abortController: Map<string, AbortController>;

	constructor(
		@inject(Providers.BleAdapter) adapter: IBleAdapter,
		@inject(Providers.EventEmitter) EventEmitter: { new(): IEventEmitter },
		@inject(Providers.DeviceManagerContext) context: IDeviceManagerContextType,
		@inject(Providers.Logger) logger: ILogger,
	) {
		this.peripherals = new Map();
		this.adapterEventListeners = new Map();
		this.bleAdapter = adapter;

		this.logger = logger.extend('BleManager');
		this.eventEmitter = new EventEmitter();
		this.eventEmitter.setMaxListeners(50);
		this.context = context;
		this.isScanning = false;
		this.bleState = 'uninitialized';
		this.protocol = new BleProtocol();
		this.currentConnectedPeripheral = undefined;
		this.emitInterceptors = [];
		this.scannedPeripherals = new Map();
		this.abortController = new Map();
	}

	public get config() {
		return this.context.getConfig().ble;
	}

	public async init(): Promise<BleState> {
		try {
			this.logger.debug('init');

			if(this.bleState === 'uninitialized') {
				this.addAdapterEventListeners();
				await this.bleAdapter.init();
			}

			await this.checkBleState();
			this.logger.debug('init done', this.bleState);

			return this.bleState;
		} catch (error) {
			return this.handleError(error, 'init');
		}
	}

	public async beforeSend() {
		try {
			this.logger.debug('beforeSend');
			this.emit(BleEvent.beforeSend);
			this.logger.debug('beforeSend checkBleState');
			await this.checkBleState();

			if(this.currentConnectedPeripheral == null) {
				BleError.throw('NOT_CONNECTED_PERIPHERAL');
				return;
			}
			const id = this.currentConnectedPeripheral.id;
			const { fn, maxRetries, retryInterval, tag } =  {
				fn: async () => { 
					this.logger.debug('beforeSend checkConnect');
					await this.checkConnect(id);
					this.logger.debug('beforeSend checkServices');
					await this.checkServices(id);
					this.logger.debug('beforeSend checkNotification');
					await this.checkNotification(id, false);
					return Promise.resolve();
				},
				maxRetries: 3,
				retryInterval: 1000,
				tag: 'beforeSend'
			};
			//华为手机，首次连接配对后，进行断连，二次连接读取时，getServices 必定会失败，需要多次重试
			await retry({fn, maxRetries, retryInterval, tag});
			return;
		} catch (error) {
			return this.handleError(error, 'beforeSend');
		}
	}

	private async _send(data: number[], options?: {
		peripheralId: string;
		serviceUUID: string;
		characteristicUUID: string;
		timeout?: number
	}) {
		try {
			const { peripheralId, serviceUUID, characteristicUUID, timeout = 15000 } = options ?? {
				peripheralId: this.currentConnectedPeripheral?.id as string,
				serviceUUID: this.config.serviceUUID,
				characteristicUUID: this.config.writeCharacteristicUUID,
				timeout: 15000
			};
			await runWithTimeout(this.writeWithoutResponse({
				peripheralId,
				serviceUUID,
				characteristicUUID,
				data: data,
				checkServices: false
			}), timeout as number, 'send timeout');

			return Promise.resolve();
		} catch (error) {
			return this.handleError(error, '_send');
		}
	}

	/**
	 * 发送数据并接收响应
	 * @param data 
	 * @param options 
	 * @returns 
	 */
	public async send(data: number[], options?: {
		peripheralId: string;
		serviceUUID: string;
		characteristicUUID: string;
	}) {
		try {
			const { peripheralId, serviceUUID, characteristicUUID } = options ?? {
				peripheralId: this.currentConnectedPeripheral?.id as string,
				serviceUUID: this.config.serviceUUID,
				characteristicUUID: this.config.writeCharacteristicUUID,
			};
			this.emit(BleEvent.send);
			await this._send(data, {
				peripheralId,
				serviceUUID,
				characteristicUUID
			});
			const response = await this.receive();

			return Promise.resolve(response);
		} catch (error) {
			return this.handleError(error, 'send');
		}
	}

	/**
	 * 发送数据，不接受响应
	 * @param data 
	 * @param options 
	 * @returns 
	 */
	public async sendWithoutResponse(data: number[], options?: {
		peripheralId: string;
		serviceUUID: string;
		characteristicUUID: string;
	}) {
		try {
			const { peripheralId, serviceUUID, characteristicUUID } = options ?? {
				peripheralId: this.currentConnectedPeripheral?.id as string,
				serviceUUID: this.config.serviceUUID,
				characteristicUUID: this.config.writeCharacteristicUUID,
			};
			this.emit(BleEvent.send);
			// this.logger.debug('send without response');
			await this._send(data, {
				peripheralId,
				serviceUUID,
				characteristicUUID
			});
			// this.logger.debug('send done');
			return Promise.resolve();
		} catch (error) {
			return this.handleError(error, 'sendWithoutResponse');
		}
	}

	public afterSend() {
		this.logger.debug('after send');
		this.emit(BleEvent.afterSend);
		return Promise.resolve();
	}

	public setCurrentPeripheralAuthenticated(authenticated: boolean): void {
		const peripheral = this.getCurrentConnectedPeripheral();
		if (peripheral) {
			peripheral.authenticated = authenticated;
			this.setPeripheral(peripheral);
		}
	}

	/**
	 * 接收数据，直到满足条件再返回数据
	 */
	public async receive(params?: Parameters<IManager['receive']>[0], options?: {
		peripheralId?: string;
		serviceUUID?: string;
		characteristicUUID?: string;
		timeout?: number;
	}) {
		try {
			this.logger.debug('receive data');
			const { size, checkDone, transform } = params ?? {};

			const defaultOptions = {
				peripheralId: this.currentConnectedPeripheral?.id as string,
				serviceUUID: this.config.serviceUUID,
				characteristicUUID: this.config.notifyCharacteristicUUID,
				timeout: 10000
			};
		
			const { 
				peripheralId = defaultOptions.peripheralId, 
				serviceUUID = defaultOptions.serviceUUID, 
				characteristicUUID = defaultOptions.characteristicUUID, 
				timeout = defaultOptions.timeout 
			} = options ?? {};
		
			if(checkDone != null) {
				const result = await this.listenNotificationUntil({
					peripheralId,
					serviceUUID,
					characteristicUUID,
					checkDone,
					transform,
					timeout
				});
				this.logger.debug('receive done', result.length);

				return Promise.resolve(result);
			}
			
			if(size != null) {
				const result = await this.listenNotificationUntil({
					peripheralId,
					serviceUUID,
					characteristicUUID,
					checkDone: (_data, allData) => {
						return allData.length >= size;
					},
					transform,
					timeout
				});

				this.logger.debug('receive done', result.length);
				return Promise.resolve(result);
			}

			const result = await runWithTimeout(this.listenNotificationOnce(peripheralId, serviceUUID), timeout as number, 'receive timeout');
			this.logger.debug('receive done', result.length ?? result);

			return Promise.resolve(result);
		} catch (error) {
			return this.handleError(error, 'receive');
		}
	}
	
	public destroy() {
		this.logger.debug('destroy');
		this.removeAdapterEventListeners();
		this.currentConnectedPeripheral = undefined;
	}

	/**
	 * 扫描设备
	 * 开始扫描请确保之前的扫描已经停止，否则重复扫描会立即停止
	 */
	public async scan(
		serviceUUIDs: string[] = [],
		seconds = this.config.scanSeconds,
		allowDuplicates = false
	): Promise<void> {
		try {
			this.logger.debug(`start scan ${seconds} seconds`);
			await this.checkBleState();
			this.resetScannedPeripherals();
			await this.bleAdapter.scan(serviceUUIDs, seconds, allowDuplicates, {
				scanMode: 2,
				phy: 255,
				advertisingNameContains: ['VA05'],
				manufacturerData: {
					manufacturerId: [ 0x8300, 0x8301 ]
				}
			});
			this.emit(BleEvent.scan);
			this.isScanning = true;
		} catch (error) {
			this.isScanning = false;

			return this.handleError(error, 'scan');
		}
	}

	public async stopScan(): Promise<void> {
		try {
			await this.checkBleState();
			
			if(!this.isScanning) {
				this.logger.debug('not scanning cancel stop scan');
				return Promise.resolve();
			}
			
			this.logger.debug('stop scan');
			await this.bleAdapter.stopScan();
			this.isScanning = false;
		} catch (error) {
			return this.handleError(error, 'stopScan');
		}
	}

	/**
	 * 连接外围设备
	 * @param {string} peripheralID - 要连接的外围设备的 ID。
	 * @param {boolean} [retryOnFailed] - 如果连接失败，是否要重试连接。
	 * @param {RetryOptions} [retryOptions] - 重试选项
	 */
	public async connect(peripheralID: string, retryOnFailed: boolean = true, retryOptions?: RetryOptions): Promise<void> {
		try {
			this.logger.debug('start connect: ', peripheralID);

			const abortController = new AbortController();
			this.abortController.set('connect', abortController); 

			if(retryOnFailed) {
				const { fn, maxRetries, retryInterval, tag } = retryOptions ?? {
					fn: () => this.bleAdapter.connect(peripheralID, abortController.signal),
					maxRetries: 3,
					retryInterval: 500,
					tag: 'connect'
				};
				await retry({fn, maxRetries, retryInterval, tag, signal: abortController.signal});
			} else {
				await this.bleAdapter.connect(peripheralID);
			}
			
			this.logger.debug('connect done: ', peripheralID);

			//在连续连接两台设备的情况下ConnectPeripheral事件未被触发，这里需要做兼容处理
			if(this.currentConnectedPeripheral?.id !== peripheralID) {
				this.logger.debug('not trigger connectPeripheral event, update peripheral to connected');
				this.updatePeripheralToConnected(peripheralID);
			}

		} catch (error) {
			return this.handleError(error, 'connect');
		}
	}

	/**
	 * 断开外围设备
	 * @param {string} peripheralID - 要断开的外围设备的 ID
	 * @param {boolean} [force] - 是否强制断开
	 */
	public async disconnect(peripheralID: string, silent?: boolean, force?: boolean): Promise<void> {
		const disconnectEventInterceptor = (event: string) => {
			if(event === 'disconnect') {
				return false;
			}

			return true;
		};

		try {
			if(!peripheralID) {
				return Promise.reject('invalid peripheral id');
			}

			if(silent) {
				this.addEmitInterceptorOnce(disconnectEventInterceptor); //添加拦截器，防止在主动断开连接后，提示断开连接
			}
			
			this.logger.debug('disconnect: ', peripheralID);
			await this.bleAdapter.disconnect(peripheralID, force);
			return Promise.resolve();
		} catch (error) {
			this.removeEmitInterceptor(disconnectEventInterceptor);
			return this.handleError(error);
		}
	}

	public async stopConnect(): Promise<void> {
		this.abortController.get('connect')?.abort();
	}

	public async bondPeripheral(peripheralID: string, pinCode = this.config.pinCode): Promise<void> {
		try {
			const peripheral = this.getPeripheral(peripheralID);
			const bondedPeripheralIds = (await this.bleAdapter.getBondedPeripherals()).map(p => p.id);
			const isBonded = Platform.OS === 'ios' ? true : bondedPeripheralIds.includes(peripheralID);
			this.logger.debug('bondedPeripheralIds', bondedPeripheralIds, isBonded);

			//FIXME: 已经绑定过设备，杀掉app后，bondState的状态会被重置，导致下一次进来会重复配对，引发断连问题
			if (peripheral?.bondState === 'bonded' && isBonded) {
				this.logger.debug('already bonded');
				return Promise.resolve();
			}

			this.logger.debug('create bond', peripheralID, pinCode);
			try {
				await this.bleAdapter.createBond(peripheralID, pinCode);
			} catch (error) {
				if (typeof error === "string" && error.includes('allow one bond')) {
					this.logger.debug('already bonded with try catch');			
				} else {
					this.logger.debug('create bond error', error);
					throw error;
				}				
			}
			this.logger.debug('bonded', peripheralID);

			if(peripheral) {
				peripheral.bondState = 'bonded';
				this.setPeripheral(peripheral);
			}

			return Promise.resolve();
		} catch (error) {
			return this.handleError(error);
		}
	}

	public async unbondPeripheral(peripheralID: string): Promise<void> {
		try {
			const peripheral = this.getPeripheral(peripheralID);

			if(peripheral && peripheral.bondState === 'unbond') {
				this.logger.debug('already unbonded');
				return Promise.resolve();
			}

			await this.bleAdapter.removeBond(peripheralID);
			this.logger.debug('unbonded');

			if(peripheral) {
				peripheral.bondState = 'unbond';
				this.setPeripheral(peripheral);
			}
			
			return Promise.resolve();
		} catch (error) {
			return this.handleError(error);
		}
	}

	public async getConnectedPeripherals(serviceUUIDs: string[] = []): Promise<Peripheral[]> {
		try {
			this.logger.debug('getConnectedPeripherals');
			const connectedAdapterPeripherals = await this.bleAdapter.getConnectedPeripherals(serviceUUIDs);
			const peripherals = connectedAdapterPeripherals.map(adapterPeripheral => {
				const peripheral = this.getPeripheral(adapterPeripheral.id) ?? this.transformPeripheral(adapterPeripheral); // 从缓存中获取，如果没有则做转换
				this.logger.debug('all connected peripherals: ', {
					peripheralId: peripheral.id,
					name: peripheral?.name,
					connectedTime: peripheral?.connectedTime,
					connected: peripheral?.connected,	
					service: peripheral.getServiced			
				});				
				
				return peripheral;
			}).filter(p => this.isValidPeripheral(p) && p.getServiced) // 过滤掉无效的设备和未获取服务的设备
				.sort((ap, bp) => (ap?.connectedTime as number) - (bp?.connectedTime as number) > 0 ? 1 : -1); //按连接时间排序
			for (const peripheral of peripherals) {
				this.logger.debug('valid connected peripherals: ', {
					peripheralId: peripheral.id,
					name: peripheral?.name,
					connected: peripheral?.connected,							
				});
				this.setPeripheral(peripheral);
			}

			return peripherals;
		} catch (error) {
			return this.handleError(error, 'getConnectedPeripherals');
		}
	}

	public async getServices(peripheralId: string): Promise<PeripheralInfo> {
		try {
			this.logger.debug('getServices');
			const adapterPeripheralInfo = await this.bleAdapter.getServices(peripheralId, [this.config.serviceUUID], this.config.maxByteSize);
			const peripheral = this.getPeripheral(peripheralId) ?? this.transformPeripheral(adapterPeripheralInfo);

			peripheral.getServiced = true;
			peripheral.rssi = adapterPeripheralInfo.rssi;
			peripheral.signal = this.transformRSSItoSignal(adapterPeripheralInfo.rssi);
			peripheral.advertising = adapterPeripheralInfo.advertising;
			const services = {
				...peripheral,
				services: adapterPeripheralInfo.services,
				serviceUUIDs: adapterPeripheralInfo.serviceUUIDs,
				characteristics: adapterPeripheralInfo.characteristics
			};
			
			this.setPeripheral(peripheral);

			return services;
		} catch (error) {
			return this.handleError(error, 'getServices');
		}
	}

	public async read({
		peripheralId,
		serviceUUID,
		characteristicUUID,
		checkServices = true
	}: {
		peripheralId: string;
		serviceUUID: string;
		characteristicUUID: string;
		checkServices?: boolean;
	}) {
		try {
			this.logger.debug('read');
			if(checkServices) {
				await this.checkServices(peripheralId);
			}
			const response = await this.bleAdapter.read(peripheralId, serviceUUID, characteristicUUID);
			const result = {
				raw: response,
				hex: Buffer.from(response).toString('hex')
			};

			return result;
		} catch (error) {
			return this.handleError(error);
		}
	}

	public async write({
		peripheralId,
		serviceUUID,
		characteristicUUID,
		data,
		maxByteSize = this.config.maxByteSize,
		checkServices = true
	}: {
		peripheralId: string;
		serviceUUID: string;
		characteristicUUID: string;
		data: number[];
		maxByteSize?: number;
		checkServices?: boolean;
	}) {
		try {
			this.logger.debug('write');
			if(checkServices) {
				await this.checkServices(peripheralId);
			}
			await this.bleAdapter.write(peripheralId, serviceUUID, characteristicUUID, data, maxByteSize);            
			return Promise.resolve();
		} catch (error) {
			return this.handleError(error);
		}
	}

	public async writeWithoutResponse({
		peripheralId,
		serviceUUID,
		characteristicUUID,
		data,
		maxByteSize = this.config.maxByteSize,
		checkServices = true
	}: {
		peripheralId: string;
		serviceUUID: string;
		characteristicUUID: string;
		data: number[];
		maxByteSize?: number;
		checkServices?: boolean;
	}) {
		try {
			// this.logger.debug('write without response');

			if(checkServices) {
				await this.checkServices(peripheralId);
			}

			return this.bleAdapter.writeWithoutResponse(peripheralId, serviceUUID, characteristicUUID, data, maxByteSize);
		} catch (error) {
			return this.handleError(error);
		}
	}

	public async refreshCache(peripheralId: string): Promise<void> {
		try {
			this.logger.debug('refresh cache');
			await runWithTimeout(this.bleAdapter.refreshCache(peripheralId), 2000);
			this.logger.debug('refresh cache success');
			return;
		} catch (error) {
			return this.handleError(error, 'refreshCache');
		}
	}

	public async startNotification(
		{
			peripheralID,
			serviceUUID = this.config.serviceUUID,
			characteristicUUID = this.config.notifyCharacteristicUUID,
			checkServices = true
		}:
		{
			peripheralID: string;
			serviceUUID?: string;
			characteristicUUID?: string;
			checkServices?: boolean
		}
	): Promise<void> {
		try {
			this.logger.debug('start notification');
			if(checkServices) {
				await this.checkServices(peripheralID);
			}

			await this.bleAdapter.startNotification(peripheralID, serviceUUID, characteristicUUID);
			const peripheral = this.getPeripheral(peripheralID);

			if(peripheral && !peripheral.startNotification) {
				peripheral.startNotification = true;
				this.setPeripheral(peripheral);
			}

			return;
		} catch (error: any) {
			return this.handleError(error, 'startNotification');
		}
	}

	public async stopNotification(
		peripheralId: string,
		serviceUUID = this.config.serviceUUID,
		characteristicUUID = this.config.notifyCharacteristicUUID
	): Promise<void> {
		try {
			this.logger.debug('stop notification');
			await this.bleAdapter.stopNotification(peripheralId, serviceUUID, characteristicUUID);

			const peripheral = this.getPeripheral(peripheralId);

			if(peripheral && peripheral.startNotification) {
				peripheral.startNotification = false;
				this.setPeripheral(peripheral);
			}

			return;
		} catch (error) {
			return this.handleError(error, 'stopNotification');
		}
	}

	public listenNotificationOnce(
		peripheralId: string,
		serviceUUID = this.config.serviceUUID,
		characteristicUUID = this.config.notifyCharacteristicUUID
	): Promise<number[]> {
		return new Promise((resolve, reject) => {			
			this.eventEmitter.once(BleEvent.updateCharacteristic, ({ value, peripheral, characteristic, service }) => {
				const isSameCharacteristic = peripheralId.toUpperCase() === peripheral && service === serviceUUID && characteristic === characteristicUUID;
				
				if(!isSameCharacteristic) {
					this.logger.debug('listenNotificationOnce receive data not same characteristic ', peripheral, service, characteristic);
					return reject();
				}
				
				this.emit(BleEvent.receiveData, value);
				return resolve(value);
			});
		});
	}

	/**
	 * 监听通知，直到checkDone返回true或者超时
	 */
	public listenNotificationUntil(
		{
			checkDone,
			peripheralId,
			serviceUUID = this.config.serviceUUID,
			characteristicUUID = this.config.notifyCharacteristicUUID,
			timeout = 10000,
			transform = (d: number[]) => d,
			onReceive
		}: {
			checkDone: (data: number[], allData: number[]) => boolean,
			peripheralId: string,
			serviceUUID?: string,
			characteristicUUID?: string,
			timeout?: number,
			transform?: (data: number[]) => number[],
			onReceive?: (data: number[]) => void;
		}
	): Promise<number[]> {
		return new Promise((resolve, reject) => {
			const allData: number[] = [];
			let timeoutId: any;

			const clearTimer = () => {
				if (timeoutId !== undefined) {
					clearTimeout(timeoutId);
					timeoutId = undefined;
				}
			};

			const startTimer = () => {
				timeoutId = setTimeout(() => {
					this.eventEmitter.removeListener(BleEvent.updateCharacteristic, listener);
					reject(BleError.create('TIMEOUT'));
				}, timeout);
			};

			const listener = ({ value, peripheral, characteristic, service }: { value: any[], peripheral: string, characteristic: string, service: string }) => {
				const isSameCharacteristic = peripheral === peripheralId.toUpperCase() && service === serviceUUID && characteristic === characteristicUUID;
				
				if(!isSameCharacteristic) {
					this.logger.debug('listenNotificationUntil receive data not same characteristic ', peripheral, service, characteristic);
					return;	
				}

				this.emit(BleEvent.receiveData, value);
				onReceive?.(value);
				allData.push(...transform(value));

				const isDone = checkDone(value, allData);
				clearTimer();
				startTimer();
				
				if(isDone) {
					clearTimer();
					this.eventEmitter.removeListener(BleEvent.updateCharacteristic, listener);
					return resolve(allData);
				}
			};

			this.eventEmitter.on(BleEvent.updateCharacteristic, listener);
			startTimer();
		});
	}

	public getPeripheral(id: string): Peripheral | undefined {
		return this.peripherals.get(id);
	}

	public setPeripheral(peripheral: Peripheral) {
		this.peripherals.set(peripheral.id, peripheral);
	}

	/**
	 * 获取所有已缓存的设备
	 */
	public getAllPeripherals(order?: {
		iteratees?: Many<ListIteratee<Peripheral>>,
		orders?: Many<boolean|"asc"|"desc">
	}): Peripheral[] {
		const orderByParams = order ?? {
			iteratees: [ 'connected', p => p.advertising.serviceUUIDs?.length, 'signal', 'name' ],
			orders: [ 'desc', 'desc', 'desc', 'desc', 'desc' ]
		};

		return orderBy(Array.from(this.peripherals.values()), orderByParams.iteratees, orderByParams.orders);
	}

	/**
	 * 获取所有已经扫描到的设备
	 */
	public getAllScannedPeripherals(order?: {
		iteratees?: Many<ListIteratee<Peripheral>>,
		orders?: Many<boolean|"asc"|"desc">
	}): Peripheral[] {
		const orderByParams = order ?? {
			iteratees: [ 'connected', p => p.advertising.serviceUUIDs?.length, 'signal', 'name' ],
			orders: [ 'desc', 'desc', 'desc', 'desc', 'desc' ]
		};

		return orderBy(Array.from(this.scannedPeripherals.values()), orderByParams.iteratees, orderByParams.orders);
	}

	public getCurrentConnectedPeripheral() {
		return this.currentConnectedPeripheral;
	}

	public setCurrentConnectedPeripheral(peripheral: Peripheral) {
		this.currentConnectedPeripheral = peripheral;
	}

	public on<T extends BleEvent>(event: T, listener: BleEventCallback[T]) {
		this.eventEmitter.on(event, listener);

		return {
			off: () => this.eventEmitter.off(event, listener)
		};
	}

	public off<T extends BleEvent>(event: T, listener: BleEventCallback[T]) {
		this.eventEmitter.off(event, listener);
	}

	/**
   * 添加事件触发拦截器。
   * 在触发事件之前执行拦截器，如果拦截器返回 false，事件将不会被触发。
   * 注意：同一个拦截器不会被添加多次。
   *
   * @param interceptor 拦截器函数，接收事件名和事件参数，返回布尔值。
   */
	public addEmitInterceptor(interceptor: EmitInterceptor) {
		if (this.emitInterceptors.indexOf(interceptor) === -1) { // 检查拦截器是否已经存在于数组中
			this.logger.debug('addEmitInterceptor');
			this.emitInterceptors.push(interceptor); // 仅在拦截器不存在时添加
		}
	}

	/**
	 * 仅添加一次拦截器，触发后就自动移除
	 */
	public addEmitInterceptorOnce(interceptor: EmitInterceptor) {
		const onceInterceptor: EmitInterceptor = (event, ...args) => {
			const shouldEmit = interceptor(event, ...args);
			
			if (shouldEmit === false) {
				this.removeEmitInterceptor(onceInterceptor);
			}

			return shouldEmit;
		};

		this.addEmitInterceptor(onceInterceptor);
	}

	/**
   * 移除事件触发拦截器。
   * 如果拦截器存在于拦截器数组中，则将其移除。
   *
   * @param interceptor 要移除的拦截器函数。
   */
	public removeEmitInterceptor(interceptor: EmitInterceptor) {
		const index = this.emitInterceptors.indexOf(interceptor);
		if (index !== -1) {
			this.logger.debug('removeEmitInterceptor');
			this.emitInterceptors.splice(index, 1);
		}
	}

	/**
	 * @description get signal from peripheral
	 */
	public async getSignal(peripheralID: string): Promise<number> {
		try {
			this.logger.debug('get signal');
			const rssi = await this.readRSSI(peripheralID);
			const signal = this.transformRSSItoSignal(rssi);
			const peripheral = this.getPeripheral(peripheralID);

			if(peripheral) {
				peripheral.signal = signal;
				peripheral.rssi = rssi;
				this.setPeripheral(peripheral);
			}

			return signal;
		} catch (error) {
			return this.handleError(error);
		}
	}

	public async readRSSI(peripheralID: string): Promise<number> {
		return runWithTimeout(this.bleAdapter.readRSSI(peripheralID), 5000, 'readRSSI timeout');
	}

	public async checkConnect(peripheralID: string) {
		try {
			const isConnected = this.getPeripheral(peripheralID)?.connected;
			
			//如果当前已经连接了其他设备，先断开
			if(peripheralID != this.currentConnectedPeripheral?.id && this.currentConnectedPeripheral?.connected) {
				this.logger.debug(`disconnect current connected peripheral ${this.currentConnectedPeripheral.id} before connect next peripheral ${peripheralID}`);
				await this.disconnect(this.currentConnectedPeripheral.id, true);
			}

			this.logger.debug(`check connect: ${isConnected}`);

			if(!isConnected) {
				this.logger.debug('not connected, connecting...');
				await this.connect(peripheralID);
			}

			return Promise.resolve();
		} catch (error) {
			return this.handleError(error, 'checkConnect');
		}
	}

	public async checkServices(peripheralID: string) {
		try {
			this.logger.debug('check services');
			const peripheral = await this.checkPeripheral(peripheralID);

			if(!peripheral?.getServiced) {
				await this.getServices(peripheralID);
			}

			return true;
		} catch (error) {
			return this.handleError(error, 'checkServices');
		}
	}

	/**
	 * 启用蓝牙
	 * 仅在Android上可用
	 */
	public async enableBluetooth() {
		try {
			this.logger.debug('enable bluetooth');
			return await this.bleAdapter.enableBluetooth();
		} catch (error) {
			return this.handleError(error, 'enableBluetooth');
		}
	}

	private emit(event: BleEvent, ...args: any[]) {
		//TODO: 后续可以使用tapable使用类似功能
		for (const interceptor of this.emitInterceptors) {
			const shouldEmit = interceptor(event, ...args);

			if (shouldEmit === false) {
				return;
			}
		}

		this.eventEmitter.emit(event, ...args);
	}

	public resendDisconnectEvent(mperipheral: Peripheral) {
		this.emit(BleEvent.disconnect, mperipheral);
	}

	private async checkBleState(): Promise<boolean> {
		if(this.bleState === 'uninitialized') {
			await this.init();
		}

		if(this.bleState === 'unauthorized') {
			BleError.throw('PERMISSION_NOT_GRANTED');
		}

		if(this.bleState === 'off') {
			BleError.throw('BLE_NOT_ENABLED');
		}

		return true;
	}

	private async checkPeripheral(peripheralID: string) {
		try {
			const peripheral = this.getPeripheral(peripheralID);

			return peripheral;
		} catch (error) {
			return this.handleError(error, 'checkPeripheral');
		}
	}

	/**
	 * 检查是否已经开启通知
	 */
	private async checkNotification(peripheralID: string, checkServices = true) {
		try {
			const peripheral = await this.checkPeripheral(peripheralID);
			
			if(!peripheral?.startNotification) {
				await this.startNotification({
					peripheralID,
					checkServices
				});
			}

			return true;
		} catch (error) {
			return this.handleError(error, 'checkNotification');
		}
	}

	/**
	 * rssi转为信号强度
	 */
	private transformRSSItoSignal(rssi: number): number {
		if(rssi <= -80) {
			return 1;
		}

		if(rssi > -80 && rssi <= -70) {
			return 2;
		}

		if(rssi > -70 && rssi <= -60) {
			return 3;
		}

		if(rssi > -60) {
			return 4;
		}

		return 1;
	}

	/**
	 * 解析广播包
	 * @TODO: 优化为由蓝牙协议来解析
	 */
	private decodeManufacturerData(peripheral: AdapterPeripheral): {
		mac: string;
		connectCount: number;
	} {
		try {
			const bytes = peripheral?.advertising.manufacturerRawData?.bytes ?? [];
			const data = {
				mac: 'unknown',
				connectCount: 0
			};

			if(bytes.length < 8) {
				return data;
			}

			//bytes的组成： size(广播包的大小 1B) type(广播包的类型 0xff表示用户自定义数据 1B) con_num(连接次数 1B) server(服务器类型 1B)  mac(mac地址 6B) 其他(NB)
			//iOS的广播包没有前缀，从con_num开始，8个字节，所以需要补充字节
			//Android则从size开始
			const shouldAddPrefix = Platform.OS === 'ios' || bytes.length === 8;
			const bytesBuffer = shouldAddPrefix ? Buffer.from([ 0, 0xff, ...bytes ]) : Buffer.from(bytes);

			// const startBit = Platform.OS === 'ios' ? 0 : 2;
			data.connectCount = bytesBuffer.readUIntLE(Platform.OS === 'ios' ? 2 : 3, 1);
			data.mac = bytesBuffer.readUIntLE(4, 6).toString(16).toUpperCase();

			return data;
		} catch (error) {
			this.logger.debug('decodeManufacturerData error: ', error);

			return {
				mac: 'unknown',
				connectCount: 0
			};
		}
	}

	/**
	 * 检测是否是 VA05 设备
	 * 通过设备名称（name 或 localName）包含 "VA05" 来识别
	 */
	private isVA05Device(peripheral: AdapterPeripheral): boolean {
		return isVA05DeviceName(peripheral.name) || isVA05DeviceName(peripheral.advertising?.localName);
	}

	/**
	 * 判断是否是有效的外围设备（符合我们协议的设备）
	 */
	private isValidPeripheral = (peripheral: AdapterPeripheral) => {
		try {
			// VA05T 设备的特殊处理：即使 MAC 不包含 24E124，也应该允许通过
			if(this.isVA05Device(peripheral)) {
				return true;
			}

			//Android的设备id是mac地址可以直接判断，iOS的设备id是UUID
			if(peripheral.id.includes('24:E1:24')) {
				return true;
			}
			
			const result = this.decodeManufacturerData(peripheral);
			
			if(result.mac.includes('24E124')) {
				return true;
			}
	
			return false;
		} catch (error) {
			return false;	
		}
	}

	/**
	 * 判断是不是断开连接的消息
	 */
	private isDisconnectMessage = (data: number[]) => {		
		if(!this.protocol.isData(data)) {
			return false;
		}

		const result = this.protocol.decodeData(data);		

		//断开的消息包大小要大于0且小于等于64才是有效
		return result.type === 'disconnect' && result.size && result.size > 0 && result.size <= 64;
	}

	/**
	 * 转换外围设备数据
	 */
	private transformPeripheral(peripheral: AdapterPeripheral): Peripheral {
		const name = peripheral.advertising.localName ?? peripheral.name ?? 'N/A';
		const manufacturerData = this.decodeManufacturerData(peripheral);

		// 某些型号（VA05-T）的 connectCount 字段不表示真实的连接数,需要忽略并设为 0
		const shouldIgnoreConnectCount = isVA05DeviceName(name);

		return {
			...peripheral,
			name,
			connected: false,
			connectedTime: 0,
			signal: this.transformRSSItoSignal(peripheral.rssi),
			bondState: 'unbond',
			startNotification: false,
			getServiced: false,
			disconnectReason: null,
			authenticated: false,
			...manufacturerData,
			connectCount: shouldIgnoreConnectCount ? 0 : manufacturerData.connectCount		
		};
	}

	/**
	 * 清空扫描到的外围设备
	 */
	private resetScannedPeripherals() {
		this.scannedPeripherals = new Map();
	}

	/**
	 * 添加扫描到的外围设备
	 */
	private addScannedPeripheral(peripheral: AdapterPeripheral) {
		const id = peripheral.id;
		const savedPeripheral = this.getPeripheral(id);
		//已存储的连接等状态要做处理，避免被初始化的状态覆盖
		const nextPeripheral = savedPeripheral 
			? Object.assign(this.transformPeripheral(peripheral), {
				connected: savedPeripheral.connected,
				connectedTime: savedPeripheral.connectedTime,
				bondState: savedPeripheral.bondState,
				startNotification: savedPeripheral.startNotification,
				getServiced: savedPeripheral.getServiced,
				disconnectReason: savedPeripheral.disconnectReason,
				authenticated: savedPeripheral.authenticated ?? false
			})
			: this.transformPeripheral(peripheral);

		this.scannedPeripherals.set(id, nextPeripheral);
		this.setPeripheral(nextPeripheral);

		return nextPeripheral;
	}

	/**
	 * 删除缓存中没有被扫描到的设备
	 */
	private deleteNotScannedPeripherals() {
		//过滤出缓存里那些不在已扫描设备的id
		const idsToDelete = Array.from(this.peripherals.keys()).filter(id => !this.scannedPeripherals.has(id) && this.currentConnectedPeripheral?.id != id);

		//从缓存中删除那些设备
		idsToDelete.forEach(id => this.peripherals.delete(id));
	}

	/**
	 * 更新设备的连接状态
	 */
	private updatePeripheralToConnected(peripheralId: string) {
		const mperipheral = this.getPeripheral(peripheralId);

		if(mperipheral) {
			mperipheral.connected = true;
			mperipheral.connectedTime = Date.now();

			if(mperipheral.disconnectReason != null) {
				mperipheral.disconnectReason = null;
			}

			this.setPeripheral(mperipheral);
			this.currentConnectedPeripheral = mperipheral;
		} else {
			this.logger.debug('connected peripheral not save');
			this.getConnectedPeripherals([]).then(peripherals => {
				//如果在已连接的设备中找到了，就更新一下
				//如果没找到，就创建一个新的外围设备
				const newPeripheral = peripherals.find(p => p.id === peripheralId) ?? this.transformPeripheral({ id: peripheralId, name: 'N/A', rssi: 0, advertising: { localName: 'N/A' } });

				this.logger.debug('find peripheral and save', newPeripheral);

				newPeripheral.connected = true;
				newPeripheral.connectedTime = Date.now();

				this.setPeripheral(newPeripheral);
				this.currentConnectedPeripheral = newPeripheral;
			});
		}
	}

	/**
	 * 添加适配器事件监听器
	 */
	private addAdapterEventListeners() {
		this.logger.debug('add Adapter EventListeners');
		this.removeAdapterAllEventListeners(); //可能会有未正常移除的事件监听器，所以在添加之前，先清空之前所有的事件监听器
		this.adapterEventListeners.set(BleAdapterEvent.DiscoverPeripheral, this.bleAdapter.addEventListener(BleAdapterEvent.DiscoverPeripheral, this.handleDiscoverPeripheral));
		this.adapterEventListeners.set(BleAdapterEvent.ConnectPeripheral, this.bleAdapter.addEventListener(BleAdapterEvent.ConnectPeripheral, this.handleConnectPeripheral));
		this.adapterEventListeners.set(BleAdapterEvent.DisconnectPeripheral, this.bleAdapter.addEventListener(BleAdapterEvent.DisconnectPeripheral, this.handleDisconnectPeripheral));
		this.adapterEventListeners.set(BleAdapterEvent.StopScan, this.bleAdapter.addEventListener(BleAdapterEvent.StopScan, this.handleStopScan ));
		this.adapterEventListeners.set(BleAdapterEvent.DidUpdateState, this.bleAdapter.addEventListener(BleAdapterEvent.DidUpdateState, this.handleUpdateState));
		this.adapterEventListeners.set(BleAdapterEvent.DidUpdateValueForCharacteristic, this.bleAdapter.addEventListener(BleAdapterEvent.DidUpdateValueForCharacteristic, this.handleUpdateCharacteristic));
	}

	private removeAdapterEventListeners() {
		this.logger.debug('remove Adapter EventListeners');
		Array.from(this.adapterEventListeners.values()).forEach(listener => listener.remove());
	}

	private removeAdapterAllEventListeners() {
		if(this.bleAdapter?.removeAllListeners != null) {
			Object.values(BleAdapterEvent).forEach(event => {
				this.bleAdapter.removeAllListeners?.(event);
			});
		}
	}

	private handleDiscoverPeripheral = (peripheral: AdapterPeripheral) => {
		if(!this.isValidPeripheral(peripheral)) {
			return;
		}

		const nextPeripheral = this.addScannedPeripheral(peripheral);
		this.deleteNotScannedPeripherals();
		this.emit(BleEvent.discover, nextPeripheral);
	}

	private handleStopScan = (map: any) => {
		const { status } = map;
		//status为0，代表主动停止扫描；10代表完整的一次扫描结束，因此需要发送停止扫描事件
		//参考链接：https://developer.android.com/reference/android/bluetooth/le/ScanCallback#SCAN_FAILED_ALREADY_STARTED
		if(status != 0 && status != 10) {
			this.logger.debug('stop scan status is error:', status);
			return;
		}
		this.logger.debug('stop scan, scan peripherals:', this.getAllScannedPeripherals());
		this.isScanning = false;
		this.deleteNotScannedPeripherals();
		this.emit(BleEvent.stopScan);
	}

	private handleConnectPeripheral = ({ peripheral }: { peripheral: string }) => {
		this.logger.debug('handleConnectPeripheral connect peripheral: ', peripheral);
		const nextPeripheral = this.updatePeripheralToConnected(peripheral);
		this.bleState = 'connected';
		this.emit(BleEvent.connect, nextPeripheral);
	}

	private handleDisconnectPeripheral = ({ peripheral, status, code, domain }: { peripheral: string, status: number, code: number, domain: string }) => {
		this.logger.debug('handleDisconnectPeripheral disconnect peripheral: ', peripheral, status ?? '', code ?? '', domain ?? '');
		const mperipheral = this.getPeripheral(peripheral);

		if(mperipheral) {
			mperipheral.connected = false;
			mperipheral.connectCount = 0;
			mperipheral.connectedTime = null;
			mperipheral.startNotification = false;
			mperipheral.getServiced = false;
			mperipheral.authenticated = false;

			this.setPeripheral(mperipheral);
		}

		//下面的逻辑暂且注释，因为在已连接设备的情况下，切换另一条设备连接，会手动断联，这时候也没有code和domain等字段，容易导致误判
		// 如果断连的原因是直接从系统中删除配对信息，则需要删除密码重新配对
		// const isDeletedPaired = Platform.OS === 'ios' && !domain && !code;
		// if (isDeletedPaired && DevicePasswordManager.getPasswordById(peripheral)) {
		// 	DevicePasswordManager.removePasswordById(peripheral);
		// }

		if(!this.currentConnectedPeripheral) {
			this.logger.debug('current connected peripheral is null stop emit disconnect event');
			return;
		}
		//偶现蓝牙名称显示N/A，打印记录
		// Log.info('mperipheral: ', {
		// 	peripheral: mperipheral,
		// 	name: mperipheral?.name
		// });
		mperipheral && this.emit(BleEvent.disconnect, mperipheral);
		this.currentConnectedPeripheral = undefined;
		this.logger.debug('reset current connected peripheral');

		this.getConnectedPeripherals().then(peripherals => {
			if(peripherals.length > 0) {
				this.logger.debug('set current connected peripheral to first peripheral', peripherals[0]);
				this.currentConnectedPeripheral = peripherals[0];
			}
		});

		if (this.bleState !== 'off') {
			this.bleState = 'disconnect';
		}
	}

	/**
	 * 处理被断连的消息
	 */
	private handleDisconnectMessage = (id: string, value: any[]) => {		
		const message = this.protocol.decodeData<'disconnect'>(value);
		if(message) {
			const { payload } = message;
			const disconnectModel = payload?.model ?? 'Unknown';
			const time = payload?.time ?? '-';
			const mperipheral = this.getPeripheral(id);

			if(mperipheral) {
				mperipheral.disconnectReason = {
					type: 'force-disconnect',
					payload: {
						model: disconnectModel,
						time
					}
				};
				this.setPeripheral(mperipheral);
			}
			this.logger.debug(`handleDisconnectMessage: disconnect from ${disconnectModel} in ${time}`);
		}
	}

	private handleUpdateCharacteristic = ({ value, peripheral, characteristic, service }: { value: any[], peripheral: string, characteristic: string, service: string }) => {		

		if(this.isDisconnectMessage(value)) {
			this.handleDisconnectMessage(peripheral, value);
		}

		this.emit(BleEvent.updateCharacteristic, { 
			value, 
			peripheral: peripheral.toUpperCase(), 
			characteristic: characteristic.toUpperCase(), 
			service: service.toUpperCase()
		});
	}

	private handleUpdateState = ({state}: { state: AdapterBleState }) => {
		this.logger.debug('ble state: ', state);

		this.bleState = state;
		this.emit(BleEvent.stateChange, state);

		//如果蓝牙关闭了，就把当前已外围设备都设置为未连接
		if ((state === 'off' || state === 'turning_off') && this.currentConnectedPeripheral != null) {
			this.getAllPeripherals().filter(p => p.connected).forEach(p => {
				p.connected = false;
				p.connectedTime = null;
				p.startNotification = false;
				p.getServiced = false;
				this.setPeripheral(p);
			});
		}
	}

	private handleError(error: any, tag?: string) {
		let errorMessage = error?.message ?? error;

		if(error instanceof BleError) {
			errorMessage = error.message;
		}

		//对原生错误进行包装，再将其重新抛出
		if(error === 'No bluetooth enabled') {
			error = BleError.create('BLE_NOT_ENABLED', error);
			errorMessage = error.message;
		}

		if(error === 'Connection error' || error === 'start notification error writing descriptor') {
			error = BleError.create('CONNECT_FAILED', error);
			errorMessage = error.message;
		}

		if(isString(error) && error.includes('Device disconnected') && tag === 'getServices') {
			error = BleError.create('TIMEOUT', error);
			errorMessage = error.message;
		}
		if(errorMessage.includes('Could not find service with UUID')) {
			error = BleError.create('SERVICE_NOT_FOUND', error);
		}

		if(__DEV__) {
			const logTag = tag ?  `${tag} error ->` : '';
			const logName = error.name ? `${error.name}` : '';
			const logContent = [ logTag, logName ].filter(s => s != '' && s != null).join(' ');
			const logData = {
				message: error.message,
				cause: error.cause
			};
	
			this.logger.error(logContent, logData);
		}

		return Promise.reject(error);
	}
}
