import { Buffer } from 'buffer';

import { TimeCounter } from '../../../utils/counter';
import { ILogger, LoggerType } from '../../../utils/logger';
import { delay } from '../../../utils/util';
import NfcUtils from '../../nfc/NfcUtils';
import { BleProtocolV2 } from '../protocol/BleProtocolV2';
import { IManager } from '../types';
import { BleError } from './BleError';

/**
 * BLE数据接收结果
 */
export type BleReceiveResult =
	| { status: 'success'; data: number[] }
	| { status: 'partial'; data: number[]; reason: 'protocolVersionError' | 'cancelByUser' | 'maxZeroProgressReached' };

interface SendOptions {
    /**
     * 钩子
     */
    hooks?: {
            /**
             * 发送完数据时的钩子
             */
            onSendData?: (data: number[]) => void;

            /**
             * 接收数据大小时的钩子
             * @param {number} receiveDataSize - 要接收的数据大小
             * @param {number} alreadyReceiveDataSize - 已经接收的数据大小
             * @param {boolean} isLastFrame - 是否为最后一帧，如果为true，则表示数据接收完毕
             */
            onReceiveDataSize?: (receiveDataSize: number, alreadyReceiveDataSize: number, isLastFrame: boolean) => Promise<void> | void;

						/**
						 * 接收数据时的钩子
						 * @param {number[]} data - 接收到的数据
						 */
						onReceiveData?: (data: number[]) => Promise<void> | void;
    };

    /**
     * 检查超时时间
     */
    checkTimeout?: number;

    /**
     * 是否更新进度
     */
    updateProgress?: boolean;

		/**
		 * 帧头丢失是否返回已接收的部分数据
		 */
		returnPartialDataOnFrameHeaderLost?: boolean;
}

/**
 * BLE命令收发器V2版本
 */
export class BleCommanderV2 {
		manager: IManager;
		
		protocol: BleProtocolV2;
		
		logger: LoggerType;

		/**
		 * 检查超时时间
		 */
		checkTimeout = 8000;

		constructor(manager: IManager, protocol: BleProtocolV2, logger: ILogger) {
			this.manager = manager;
			this.protocol = protocol;
			this.logger = logger.extend('BleCommanderV2');
		}

		async sendWithRetryIfTimeOut(data: number[], options?: SendOptions & { times?: number }): Promise<BleReceiveResult> {
			let { times = 2 } = options ?? {};
			let response: BleReceiveResult = { status: 'success', data: [] };

			while (times > 0) {
				try {
					this.logger.debug('upgradeV2 sendWithRetryIfTimeOut | send...', times);
					response = await this.send(data, options);
					return Promise.resolve(response);
				} catch (error) {
					if (error instanceof BleError && (error.name === 'TIMEOUT' || error.code === 105)) {
						this.logger.debug('upgradeV2 sendWithRetryIfTimeOut | timeout, retry...', times);
						times--;
						continue;
					}
					return Promise.reject(error);
				}
			}
			return Promise.resolve(response);
		}

		/**
		 * 发送数据并接收响应(一帧数据)
		 * @param {number[]} data - 要发送的数据
		 * @param {object} options - 发送选项
		 * @returns {Promise<BleReceiveResult>} 数据接收结果
		 */
		async send(data: number[], options?: SendOptions): Promise<BleReceiveResult> {
			try {
				const { hooks, checkTimeout, returnPartialDataOnFrameHeaderLost } = Object.assign({
					hooks: {},
					checkTimeout: this.checkTimeout,
					returnPartialDataOnFrameHeaderLost: false,
				}, options);
				const receiveAllData: number[] = [];
				let alreadyReceiveDataSize = 0;
				TimeCounter.time('BleCommanderV2 | send');
				await this.sendDataWithoutResponse(data);
				hooks.onSendData && hooks.onSendData(data);
				let receiveDone = false;
				try {
					do {
						const { receiveDataSize, frameData, isLastFrame, crc32 } = await this.receiveFrameHeader({ checkTimeout });
						hooks.onReceiveDataSize && (await hooks.onReceiveDataSize(receiveDataSize, alreadyReceiveDataSize + frameData.length, isLastFrame));
						const response = await this.receiveData(receiveDataSize, frameData, { checkTimeout });
						const calculatedCrc32 = NfcUtils.getCrc32(response);
						if(calculatedCrc32 !== crc32) {
							this.logger.debug(`crc32 error, calculated: ${calculatedCrc32} received: ${crc32}`);
							if (returnPartialDataOnFrameHeaderLost) {
								return {
									status: 'partial',
									data: receiveAllData,
									reason: 'protocolVersionError'
								};
							}
						}
						hooks.onReceiveData && (await hooks.onReceiveData(response));
						receiveAllData.push(...response);
						alreadyReceiveDataSize += receiveDataSize;
						receiveDone = isLastFrame;
					} while (!receiveDone);
				} catch (error: any) {
					// 特殊处理协议版本错误 - 返回已接收的部分数据
					// 一般情况下是丢帧导致的，所以返回已接收的部分数据
					// 数据丢失有两种情况
					// 1. 帧头直接丢了
					// 2. 帧头收到了，数据丢了
					// 但是帧头丢了的原因也可能是上一帧中的数据丢了，导致找不到下一帧的帧头
					if (returnPartialDataOnFrameHeaderLost && (error === 'protocolVersionError' || error?.name === 'TIMEOUT')) {
						this.logger.debug('Protocol version error, returning partial data');
						return {
							status: 'partial',
							// 返回已接收的部分数据，因为已经接收到的数据是完整的，所以可以返回已接收的部分数据
							data: receiveAllData,
							reason: 'protocolVersionError'
						};
					}
					throw error;
				}

				// 打印发送的数据，只打印前100个字节
				this.logger.debug("send success", Buffer.from(data).toString('hex').slice(0, 100) + (data.length > 100 ? '...' : ''));
				return { status: 'success', data: receiveAllData };
			} catch (error) {
				this.logger.debug("send error:", error);
				return Promise.reject(error);
			} finally {
				TimeCounter.timeEnd('BleCommanderV2 | send');
			}
		}
		
		/**
		 * 发送数据(不等待响应)
		 */
		async sendDataWithoutResponse(data: number[]) {
			try {
				const dataSize = data.length;
				const { chunkCount, chunks } = await this.protocol.encodeDataChunk(data);

				TimeCounter.time('BleCommanderV2 | sendDataWithoutResponse');
				await this.manager.beforeSend();

				for (let index = 0; index < chunkCount; index++) {
					const chunk = chunks[index]!;	
					delay(50);
					// this.logger.debug(`send ${index},  ${chunk.slice(0, 8).map(item => item.toString(16).padStart(2, '0')).join(' ')}`);
					await this.manager.sendWithoutResponse(chunk);
				}

				this.logger.debug(`sendDataWithoutResponse success | dataSize ${dataSize}, count ${chunkCount}`);

				return Promise.resolve();
			} catch (error) {
				this.logger.debug('sendDataWithoutResponse error: ', error);
				return Promise.reject(error);
			} finally {
				TimeCounter.timeEnd('BleCommanderV2 | sendDataWithoutResponse');
			}
		}

		/**
		 * 发送数据(等待响应)
		 * @deprecated 目前没有使用，使用 send 方法代替，后续可以考虑删除
		 */
		async sendDataWithResponse(data: number[]): Promise<number[]> {
			try {
				const dataSize = data.length;
				const { chunkCount, chunks } = await this.protocol.encodeDataChunk(data);
				const result: number[] = [];
				
				TimeCounter.time('BleCommanderV2 | sendDataWithResponse');
				await this.manager.beforeSend();

				for (let index = 0; index < chunkCount; index++) {
					const chunk = chunks[index]!;
					const response = await this.manager.send(chunk);

					result.push(...response);
				}

				this.logger.debug(`sendDataWithResponse success | dataSize ${dataSize}, count ${chunkCount}`);
				
				return Promise.resolve(result);
			} catch (error) {
				this.logger.debug('sendDataWithResponse error: ', error);
				return Promise.reject(error);
			} finally {
				TimeCounter.timeEnd('BleCommanderV2 | sendDataWithResponse');
			}
		}

		/**
		 * 接收帧头部数据
		 */
		async receiveFrameHeader(options?: {
				checkTimeout?: number;
		}) {
			try {
				const { checkTimeout } = Object.assign({ checkTimeout: this.checkTimeout }, options);
				const currentProtocolVersion = this.protocol.version;

				const headerData = await this.manager.receive({
					checkDone: (_data, allData) => allData.length >= 8,
				}, { timeout: checkTimeout });
						
				if (!headerData || headerData.length < 8) {
					this.logger.debug("receiveFrameHeader | headerData:", Buffer.from(headerData).toString('hex'), headerData);
					return Promise.reject('invalidFrameHeaderData');
				}

				// 只取前8字节作为帧头进行协议检查
				const frameHeader = headerData.slice(0, 8);

				if(this.protocol.isProtocolV1Response(frameHeader)) {
					return Promise.reject('oldProtocolResponse');
				}

				// decodeFrame 会从传入的 frame 中提取数据部分，所以传入完整的 headerData
				const { preamble, protocolVersion, dataSize, data: frameData, crc32 } = this.protocol.decodeFrame(headerData);
				const receiveProtocolVersion = protocolVersion;
				const receiveDataSize = dataSize;

				if (!receiveProtocolVersion || currentProtocolVersion < receiveProtocolVersion) {
					this.logger.debug('receiveFrameHeader | protocolVersion error', currentProtocolVersion, receiveProtocolVersion, Buffer.from(frameHeader).toString('hex'));
					return Promise.reject('protocolVersionError');
				}

				this.logger.debug('receiveFrameHeader', Buffer.from(frameHeader).toString('hex'));

				return Promise.resolve({ 
					receiveDataSize, 
					frameData,
					isLastFrame: preamble === 0x00,
					crc32
				});
			} catch (error) {
				this.logger.debug("receiveFrameHeader | error:", error);
				return Promise.reject(error);    
			}
		}

		/**
		 * 接收数据
		 * @param {number} receiveDataSize - 要接收的数据大小
		 * @param {number[]} frameData - 帧数据(已经在头部接收的帧数据)
		 */
		async receiveData(receiveDataSize: number, frameData: number[], options?: {
				checkTimeout?: number;
		}) {
			const { checkTimeout } = Object.assign({ checkTimeout: this.checkTimeout }, options);
			let receiveAllData: number[] = frameData;

			try {
				TimeCounter.time('BleCommanderV2 | receiveData');

				// 前面接收头部数据的时候已经接收到了一部分数据，所以需要减去已经接收到的数据长度
				const remainingDataSize = receiveDataSize - frameData.length;

				// 如果第一次接收头部数据就已经接收完毕，则直接返回
				if (receiveAllData.length >= receiveDataSize) {
					this.logger.debug('receiveData | data already received');
					return Promise.resolve(receiveAllData.slice(0, receiveDataSize));
				}

				if (remainingDataSize > 0) {
					const remainingData = await this.manager.receive({
						size: remainingDataSize,
					}, { timeout: checkTimeout });
					receiveAllData.push(...remainingData);
				}

				receiveAllData = receiveAllData.slice(0, receiveDataSize);

				this.logger.debug('receiveData success', receiveAllData.length);
				return Promise.resolve(receiveAllData);
			} catch (error) {
				this.logger.debug("receiveData | error:", error);
		
				// 超时但已接收足够数据
				if (error === 'timeout' && receiveDataSize > 0 && receiveAllData.length >= receiveDataSize) {
					this.logger.debug('receiveData timeout done');
					return Promise.resolve(receiveAllData.slice(0, receiveDataSize));
				}

				return Promise.reject(error);
			} finally {
				TimeCounter.timeEnd('BleCommanderV2 | receiveData');
			}
		}
} 