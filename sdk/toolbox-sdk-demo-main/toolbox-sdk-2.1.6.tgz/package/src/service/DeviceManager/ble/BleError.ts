import { BLE_ERRORS } from './types';

export class BleError extends Error {
	code: number;
	cause?: any;

	constructor(error: { name: string; code: number; message: string, cause?: any }) {
		super(error.message);
		this.name = error.name;
		this.code = error.code;
		this.cause = error.cause;
	}

	static throw(errorType: keyof typeof BLE_ERRORS, cause?: any) {
		const errorInfo = BLE_ERRORS[errorType] ?? BLE_ERRORS.UNKNOWN_ERROR;
		throw new BleError({ ...errorInfo, cause });
	}
	
	static create(errorType: keyof typeof BLE_ERRORS, cause?: any) {
		const errorInfo = BLE_ERRORS[errorType] ?? BLE_ERRORS.UNKNOWN_ERROR;
		return new BleError({ ...errorInfo, cause });
	}

	static getError(errorType: keyof typeof BLE_ERRORS) {
		return BLE_ERRORS[errorType] ?? BLE_ERRORS.UNKNOWN_ERROR;
	}
}
