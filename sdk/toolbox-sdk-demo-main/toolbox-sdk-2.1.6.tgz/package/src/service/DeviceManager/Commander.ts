import { Buffer } from 'buffer';
import { get } from 'lodash';
import moment from 'moment';

import DeviceUtils from '../../model/DeviceUtils';
import { IExtendLoggerFactory, LoggerType } from '../../utils/logger';
import { crc32 } from '../../utils/util/crc32';
import { delay, sleep } from '../../utils/util';

import { RequestMessageJSON, RequestType } from './protocol';
import { Reader } from './protocol/Reader';
import { IManager, IProtocol } from './types';

/**
 * 命令收发器
 * 负责发送命令、数据、接收响应
 */
export class Commander {
	manager: IManager;
	protocol: IProtocol;
	private logger: LoggerType;

	constructor(manager: IManager, protocol: IProtocol, extendLoggerFactory: IExtendLoggerFactory) {
		this.manager = manager;
		this.protocol = protocol;
		this.logger = extendLoggerFactory('BleCommander');
	}

	public setManager(manager: IManager) {
		this.manager = manager;
	}

	public setProtocol(protocol: IProtocol) {
		this.protocol = protocol;
	}

	/**
	 * 检查响应
	 */
	private checkResponse(response: number[]) {
		const result = this.protocol.decodeResponse(response);

		if(result.status === 'success') {
			return Promise.resolve(result);
		}

		if(result.status === 'password_error') {
			return Promise.reject(result);
		}

		return Promise.reject(result.status ?? 'invalid response');
	}

	/**
	 * 发送命令
	 */
	public async sendCommand<T extends RequestType>({
		type,
		data,
		payload,
		checkResponse = true
	}: {
		type: T;
		data?: number[];
		payload?: RequestMessageJSON<T>['payload'];
		checkResponse?: boolean;
	}) {
		try {
			const commandRequest = this.protocol.encodeRequest<T>({
				type,
				data,
				payload
			});
			this.logger.debug('sendCommand: ', type, Buffer.from(commandRequest).toString('hex'));
			await this.manager.beforeSend();
			const response = await this.manager.send(commandRequest);
			const result = checkResponse
				? await this.checkResponse(response)
				: this.protocol.decodeResponse(response);
			await this.manager.afterSend();
			this.logger.debug('send command done', result);

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送数据
	 * 将数据分成多个包，在每个包加入协议的前缀，然后组合后再发送
	 */
	public async sendData(data: number[], dataSize: number) {
		try {
			const protocol = this.protocol;
			// 每个包的字节数，减去协议的前缀6个字节
			const chunkSize = 240 - 8; //发送的数据包大小需要是8的倍数
			const chunkCount = Math.ceil(data.length / chunkSize);
			this.logger.debug('send count: ', chunkCount);
			for (let index = 0; index < chunkCount; index++) {
				const start = index * chunkSize;
				const end = (index + 1) * chunkSize;
				const chunk = data.slice(start, end);
				const encodeChunk = protocol.encodeData({
					type: 'data',
					size: dataSize ?? data.length,
					data: chunk
				});
				await this.manager.sendWithoutResponse(encodeChunk);
				delay(30);
			}
			this.logger.debug('send data done');
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送证书数据
	 * 将数据分成多个包，在每个包加入协议的前缀，然后组合后再发送
	 */
	public async sendCertificateData(data: number[]) {
		try {
			const protocol = this.protocol;
			// 每个包的字节数，减去协议的前缀6个字节
			const chunkSize = 240 - 8; //发送的数据包大小需要是8的倍数
			const chunkCount = Math.ceil(data.length / chunkSize);
			this.logger.debug('send count: ', chunkCount);

			for (let index = 0; index < chunkCount; index++) {
				const start = index * chunkSize;
				const end = (index + 1) * chunkSize;
				const chunk = data.slice(start, end);
				const encodeChunk = protocol.encodeData({
					type: 'data',
					size: chunk.length + 6,
					data: chunk
				});
				await this.manager.sendWithoutResponse(encodeChunk);
				await sleep(10);
			}

			this.logger.debug('send data done');
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	}
	/**
	 * 开机
	 */
	public async powerOn() {
		try {
			const result = await this.sendCommand({
				type: 'powerOn'
			});

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 同步时间
	 */
	public async syncTime(timestamp: number, timezone: number) {
		try {
			const result = await this.sendCommand({
				type: 'syncTime',
				payload: {
					timestamp,
					timezone
				}
			});

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 关机
	 */
	public async powerOff() {
		try {
			const result = await this.sendCommand({type: 'powerOff'});

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 读取设备信息（flash）
	 */
	public async read() {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'readFlash'
			});
			let size: number | undefined;

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if (!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if (!size) {
						return false;
					}

					return allData.length === size;
				}
			}, {
				timeout: 20000
			});
			await this.manager.afterSend();

			return receiveData;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 写入设备信息（flash）
	 */
	public async write(data: number[], dataSize: number) {
		try {
			const protocol = this.protocol;
			const writeRequest = protocol.encodeRequest({
				type: 'writeFlash'
			});

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(writeRequest);
			await this.sendData(data, dataSize);
			const response = await this.manager.receive();
			await this.checkResponse(response);
			await this.manager.afterSend();

			return true;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 测试命令(Ble)
	 */
	public async test({data}: {data: number[]}) {
		try {
			const result = await this.sendCommand({
				type: 'test',
				checkResponse: false,
				data,
			});
			const response = result.response ?? [];

			if(response.length === 0) {
				return response;
			}

			//第7个字节开始开始才是真正返回的数据
			if(response.length > 6) {
				return response.slice(6);
			}

			return response;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 验证密码
	 */
	public async auth({password, phoneModel}: {password: string, phoneModel: string}) {
		try {
			const authResult = await this.sendCommand({
				type: 'password',
				payload: {
					password,
					phoneModel
				}
			});

			return authResult;
		} catch (error: any) {
			const hasTimeData = error.response && error.response.length >= 14;

			if(error.status === 'password_error' && hasTimeData) {
				const milliseconds = Buffer.from(error.response.slice(10, 14)).readUInt32LE();

				return Promise.reject({
					status: 'password_error_many_times',
					milliseconds
				});
			}

			return Promise.reject(error.status ?? error);
		}
	}

	/**
	 * 重置
	 */
	public async reset() {
		try {
			const result = await this.sendCommand({type: 'reset'});

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	
	/**
	 * 写入AT指令
	 */
	public async writeATCommand(dataSize: number, data: number[]) {
		try {
			const atRequest = this.protocol.encodeRequest({
				type: 'atDebugger',
				payload: {
					size: dataSize
				}
			});

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(atRequest);
			await this.sendData(data, dataSize);
			const response = await this.manager.receive(undefined, { timeout: 30000 });
			await this.checkResponse(response);
			await this.manager.afterSend();
			const relevantPart = response.slice(10);
			const finalDataStr = String.fromCharCode(...relevantPart);
			this.logger.debug('finalDataStr',finalDataStr);
			return finalDataStr;

		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 写入证书
	 */
	public async writeCertificate(type: 1 | 2 | 3, mode: number, data: number[], checkData: number, dataSize: number ) {
		try {

			const certificateRequest = this.protocol.encodeRequest({
				type: 'writeCertificate',
				payload: {
					size: dataSize,
					mode,
					type,
					checkData
				}
			});

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(certificateRequest);
			await this.sendCertificateData(data);
			const response = await this.manager.receive();
			await this.checkResponse(response);
			await this.manager.afterSend();

			return true;

		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 传感器校准
	 */
	public async distanceCalibration() {
		try {
			const result = await this.sendCommand({type: 'distanceCalibration'});

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 传感器盲区校准
	 */
	public async distanceBlindZoneCalibration() {
		try {
			const result = await this.sendCommand({type: 'distanceBlindZoneCalibration'});
	
			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 传感器采集
	 */
	public async collect() {
		try {

			const request = this.protocol.encodeRequest({
				type: 'collect'
			});
			
			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(request);
			const result = await this.manager.receive(undefined, { timeout: 15000 });
			await this.manager.afterSend();

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 重启
	 */
	public async restart() {
		try {
			const result = await this.sendCommand({type: 'restart'});
			
			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 传感器手动校准
	 */
	public async distanceManualDiagnose(params: { sensitivity: number, signalQuality: number, peakOrder: number }) {
		try {
			const result = await this.sendCommand({ type: 'distanceManualDiagnose', payload: params });
			this.logger.debug('result: ', result);

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 读取日志
	 */
	public async readLog() {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'readLog'
			});
			let size: number | undefined;

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if(!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if(!size) {
						return false;
					}

					return allData.length === size;
				},
			});
			await this.manager.afterSend();
			return receiveData;
		} catch (error) {
			return Promise.reject(error);
		}
	}
	/**
	 * 距离雷达曲线数据
	 */
	public async readDistanceRadar() {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'readDistanceRadar'
			});
			let size: number | undefined;

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if (!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if (!size) {
						return false;
					}

					return allData.length === size;
				},
			});
			await this.manager.afterSend();

			const reader = new Reader(receiveData);
			reader.skip(1); // 版本
			const count = reader.uint16LE(); // 偏移 1-2
			const maxIntensityDistance = reader.uint16LE(); // 偏移 3-4
			const nearestDistance = reader.uint16LE(); // 偏移 5-6
			const signalQuality = reader.int16LE(); // 偏移 7-8
			const sensitivity = reader.uint16LE(); // 偏移 9-10
			const peakOrder = reader.uint16LE(); // 偏移 11-12
			reader.skip(1); // 曲线段数

			// 读取固定的4段的点数
			const segmentPoints = [];
			for (let i = 0; i < 4; i++) {
				segmentPoints.push(reader.uint16LE()); // 每个段的点数，偏移 14+2*i
			}

			reader.skip(2); // 跳过预留部分 22-23
			
			const echoData: { x: number, y: number }[] = [];
			for (let i = 0; i < count; i++) {
				if (reader.bytesAvailable() < 4) {
					this.logger.debug('Not enough data available to read distance and value');
					break;
				}

				const x = reader.uint16LE(); // 每个距离，偏移 reservedOffset + 2*i
				const y = reader.uint16LE(); // 每个强度，偏移 reservedOffset + 2*i + 2
				echoData.push({ x: x / 1000, y });
			}

			return {
				maxIntensityDistance,
				nearestDistance,
				signalQuality,
				sensitivity: sensitivity / 10,
				peakOrder,
				echoData,
				segmentPoints
			};
		} catch (error) {
			this.logger.debug('error: ', error);
			return Promise.reject(error);
		}
	}


	/**
	 * 检查升级镜像数据
	 * @param data - 升级镜像数据
	 * @returns 
	 */
	public async checkUpgradeData({data, reboot = false , moduleId = 0}: {data: number[], reboot?: boolean, moduleId?: number}) {
		try {
			this.logger.debug('upgrade request data: ', data, data.length);
			const upgradeRequest = this.protocol.encodeRequest({
				type: 'upgrade',
				payload: {
					size: data.length,
					reboot,
					moduleId
				}
			});
			this.logger.debug('start send upgrade request', upgradeRequest);
			await this.manager.sendWithoutResponse(upgradeRequest);
			this.logger.debug('start send upgrade data');
			await this.sendData(data, data.length);
			const response = await this.manager.receive();
			this.logger.debug('checkUpgradeData response: ', response);
			const result = this.protocol.decodeResponse(response);

			if(result.status === 'success') {
				return 0;
			} else if (result.status === 'bootloader') {
				return 1;
			}

			return Promise.reject(result);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 准备差分升级
	 * @param
	 * @returns 
	 */
	public async getProductInfo() {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'getProductInfo'
			});
			let size: number | undefined;

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if(!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if(!size) {
						return false;
					}

					return allData.length === size;
				},
			});
			await this.manager.afterSend();
			const resultJSON = await DeviceUtils.getProductInfo(receiveData);
			const result = JSON.parse(resultJSON);
			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}	
	/**
	 * 准备差分升级
	 * @param
	 * @returns 
	 */
	public async readyPatchUpgrade() {
		try {
			const upgradeRequest = this.protocol.encodeRequest({
				type: 'readyPatch',
			});
			this.logger.debug('start send upgradeRequest',upgradeRequest);
			await this.manager.sendWithoutResponse(upgradeRequest);
			const response = await this.manager.receive();
			this.logger.debug('upgradeRequest response: ', response);
			const result = this.protocol.decodeResponse(response);

			if(result.status === 'success') {
				return 0;
			} else if (result.status === 'bootloader') {
				return 1;
			}

			return Promise.reject(result);
		} catch (error) {
			return Promise.reject(error);
		}
	}	
	/**
	 * 发送全量升级镜像数据
	 * @param data - 升级数据
	 */
	public async sendUpgradeData(
		{data, reboot = false , moduleId = 0, checkTimeout}: 
		{data: number[], reboot?: boolean, moduleId?: number, checkTimeout?: number}
	) {
		try {
			this.logger.debug('upgrade data: ', data.length);
			const result = await this.sendCommand({
				type: 'upgrade',
				payload: {
					size: data.length,
					reboot,
					moduleId
				}
			});
			const responseType = get(result.response, '[62]');
			await sleep(10);
			const startTime = Date.now();
			this.logger.debug('start send data', data.length);
			const protocol = this.protocol;

			// 每个包的字节数，减去协议的前缀6个字节
			const chunkSize = 240 - 8; //发送的数据包大小需要是8的倍数
			const chunkCount = Math.ceil(data.length / chunkSize);
			this.logger.debug('send count: ', chunkCount);

			for (let index = 0; index < chunkCount; index++) {
				const time = index % 10 === 9 ? 120 : 45;
				const start = index * chunkSize;
				const end = (index + 1) * chunkSize;
				const chunk = data.slice(start, end);
				const encodeChunk = protocol.encodeData({
					type: 'data',
					size: data.length,
					data: chunk
				});

				switch (responseType) {
					case 255: {
						//每包数据都需要有回包，支持设备：VS370
						const response = await this.manager.send(encodeChunk);
						await this.checkResponse(response);
						break;
					}
					case 254: {
						//每10包数据需要有回包，每包不需要有延时，支持设备：VS321
						if(index % 10 === 9) {
							const response = await this.manager.send(encodeChunk);
							await this.checkResponse(response);
						} else {
							await this.manager.sendWithoutResponse(encodeChunk);
						}
						break;
					}
					default: {
						await this.manager.sendWithoutResponse(encodeChunk);
						delay(time);
						break;
					}
				}
			}

			this.logger.debug('send data done');

			const duration = Date.now() - startTime;
			this.logger.debug('send data done', duration, data.length);
			const response = await this.manager.receive(undefined, {timeout: checkTimeout});
			this.logger.debug('send upgradeData response: ', response);
			await this.checkResponse(response);

			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送差分升级镜像数据
	 * @param data - 升级数据
	 */
	public async sendPatchUpgradeData({data, reboot = false}: {data: number[], reboot?: boolean}) {
		try {
			this.logger.debug('upgrade patch data: ', data.length);
			const result = await this.sendCommand({
				type: 'sendPatch',
				payload: {
					size: data.length,
					reboot,
				}
			});
			const sendDataWithResponse = get(result.response, '[62]') === 0xff;
			await sleep(10);
			const startTime = Date.now();
			this.logger.debug('start send data', data.length);
			const protocol = this.protocol;

			// 每个包的字节数，减去协议的前缀6个字节
			const chunkSize = 240 - 8; //发送的数据包大小需要是8的倍数
			const chunkCount = Math.ceil(data.length / chunkSize);
			this.logger.debug('send count: ', chunkCount);

			for (let index = 0; index < chunkCount; index++) {
				const time = index % 10 === 9 ? 120 : 45;
				const start = index * chunkSize;
				const end = (index + 1) * chunkSize;
				const chunk = data.slice(start, end);
				const encodeChunk = protocol.encodeData({
					type: 'data',
					size: data.length,
					data: chunk
				});

				if(sendDataWithResponse) {
					const response = await this.manager.send(encodeChunk);
					await this.checkResponse(response);
				} else {
					await this.manager.sendWithoutResponse(encodeChunk);
					delay(time);
				}
			}

			this.logger.debug('send data done');

			const duration = Date.now() - startTime;
			this.logger.debug('send data done', duration, data.length);
			const response = await this.manager.receive();
			this.logger.debug('send upgradeData response: ', response);
			await this.checkResponse(response);

			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 读取模板数据
	 */
	public async readTemplateData(name: string) {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'readTemplate',
				payload: {
					name
				}
			});
			let size: number | undefined;

			await this.manager.beforeSend();
			await this.manager.send(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if(!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if(!size) {
						return false;
					}

					return allData.length === size;
				},
			});
			await this.manager.afterSend();

			return receiveData;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送传感器密码
	 */
	public async sendSensorPassword(password: string) {
		try {
			const { response } = await this.sendCommand({
				type: 'writeSensorPassword',
				payload: {
					password
				}
			});
			this.logger.debug('send sensor password response: ', response);
			await this.checkResponse(response);
		
			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 删除模板数据
	 */
	public async deleteTemplateData(name: string) {
		try {
			const { response } = await this.sendCommand({
				type: 'deleteTemplate',
				payload: {
					name
				}
			});
			this.logger.debug('send delete template response: ', response);
			await this.checkResponse(response);
	
			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送模板数据
	 */
	public async sendTemplateData(data: (number | string)[], name: string) {
		try {
			this.logger.debug('sendTemplateData: ', data.length);
			const size = data.length;
			const crc = crc32(data);
			await this.sendCommand({
				type: 'writeTemplate',
				payload: {
					size,
					crc,
					name
				}
			});
			await sleep(10);
			const startTime = Date.now();
			this.logger.debug('start send data', data.length);
			// @ts-expect-error
			await this.sendData(data, data.length);
			const duration = Date.now() - startTime;
			this.logger.debug('send data done', duration, data.length);
			const response = await this.manager.receive();
			this.logger.debug('send template response: ', response);
			await this.checkResponse(response);
	
			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 发送固件数据
	 */
	public async sendFirmwareData(data: number[], name: string) {
		try {
			this.logger.debug('sendFirmware data: ', data.length);
			const size = data.length;
			const crc = crc32(data);
			await this.sendCommand({
				type: 'writeFirmware',
				payload: {
					size,
					crc,
					name
				}
			});
			await sleep(10);
			const startTime = Date.now();
			this.logger.debug('start send data', data.length);
			await this.sendData(data, data.length);
			const duration = Date.now() - startTime;
			this.logger.debug('send data done', duration, data.length);
			const response = await this.manager.receive();
			this.logger.debug('send firmware response: ', response);
			await this.checkResponse(response);

			return Promise.resolve(true);
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 读取设备历史记录
	 */
	public async readHistory({ 
		startTime, 
		endTime, 
		parser,
		type 
	}: 
		{ 
			startTime: number;
			endTime: number; 
			type: 0 | 1 | 2;
			parser: (data: number[]) => Promise<any>;
		}) {
		try {
			const protocol = this.protocol;
			const currentTime = moment().unix();
			await this.sendCommand({
				type: 'readHistory',
				payload: {
					startTime,
					endTime,
					currentTime,
					type
				}
			});
			let receiveHistoryData: number[] = [];
			let receiveHistoryDataSize = 0;
			let isLastFrame = false;

			while(!isLastFrame) {
				let currentReceiveSize: number | undefined = 0;
				//action: 2表示开始读取历史数据
				const readActionRequest = protocol.encodeData({
					type: 'data',
					size: 2,
					data: [2]
				});
				
				await this.manager.sendWithoutResponse(readActionRequest);
				await sleep(5);
				
				//当前已经接收到的数据大小
				const receiveData = await this.manager.receive({
					transform: d => {
						if(!currentReceiveSize) {
							const decodeResult = protocol.decodeData(d);
							currentReceiveSize = decodeResult.size;
						}

						return protocol.decodeData(d).data ?? d;
					},
					checkDone(_data, allData) {
						if(!currentReceiveSize) {
							return false;
						}

						if(currentReceiveSize === 1) {
							return true;
						}

						return allData.length === currentReceiveSize;
					},
				});

				// 可能出现dataLength（设备内有数据，但不在时间范围）, 1表示时间范围内没有数据
				if(currentReceiveSize === 1) {
					return Promise.resolve({
						receiveHistoryData,
						receiveHistoryDataSize
					});
				}

				const slicedData = receiveData.slice(0, currentReceiveSize);
				let historyDataJson = '{}';
				try {
					historyDataJson = await parser(slicedData);
				} catch (error) {
					historyDataJson = '{}';
				}
				const parsedData = JSON.parse(historyDataJson);
				const { historyData = [], lastFrame = false } = parsedData || {};
				const availableData = historyData.filter((d: any) => d.timestamp !== '0');
				
				receiveHistoryData = receiveHistoryData.concat(availableData);
				isLastFrame = lastFrame === true;
				receiveHistoryDataSize += slicedData.length;
			}

			//action: 3表示停止读取历史数据
			const stopReadActionRequest = protocol.encodeData({
				type: 'data',
				size: 1,
				data: [3]
			});
			await this.manager.sendWithoutResponse(stopReadActionRequest);

			return {
				receiveHistoryData,
				receiveHistoryDataSize
			};
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 设置相对初始面
	 */
	public async relativeInitialSurface(type: 'setting' | 'clear' | 'zero-setting' | 'zero-clear') {
		try {
			const result = await this.sendCommand({type: 'relativeInitialSurface', payload: {type}});

			return result;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * 清空数据
	 */
	public async clear(type: 'rainfall' | 'history') {
		return this.sendCommand({
			type: 'clear',
			payload: {
				type
			}
		});
	}

	/**
	 * VS321获取检测图片
	 *
	 * @param {number} type
	 * @example
	 * 0: 图片刷新
	 * 1: 开启debug模式，获取不带人像坐标的图片数据
	 * 2: 开启debug模式，获取带人像坐标的图片数据
	 * 3: 关闭设备debug模式
	 * @return {*} 
	 * @memberof Commander
	 */
	public async getVerificationImage(type: 0 | 1 | 2 | 3): Promise<number[]> {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'readVerificationImage',
				payload: {
					type
				}
			});
			let size: number | undefined;
			let receiveData: number[] = [];

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			if(type !== 3) {// 关闭debug模式，不接收数据
				receiveData = await this.manager.receive({
					transform: d => {
						if (!size) {
							const decodeResult = protocol.decodeData(d);
							size = decodeResult.size;
						}

						return protocol.decodeData(d).data ?? d;
					},
					checkDone(_data, allData) {
						if (!size) {
							return false;
						}

						return allData.length === size;
					}
				}, {
					timeout: 5000
				});
			}
			await this.manager.afterSend();

			return receiveData;
		} catch (error) {
			return Promise.reject(error);
		}
	}

	/**
	 * PIR状态
	 */
	public async pirStatus(type: 0 | 1) {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'pirStatus',
				payload: {
					type
				}
			});

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			await this.manager.afterSend();
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		} 
	}

	/**
	 * 图像曝光度
	 */
	public async setExposure(value: number) {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'exposure',
				payload: {
					value
				}
			});

			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			await this.manager.afterSend();

			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		} 
	}

	/**
	 * 光敏值获取
	 */
	public async fetchLightSensorValue() {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'lightSensorValue'
			});
			let size: number | undefined;
			
			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if (!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if (!size) {
						return false;
					}

					return allData.length === size;
				}
			}, {
				timeout: 5000
			});
			await this.manager.afterSend();
			const reader = new Reader(receiveData);
			const value = reader.uint16LE();

			return Promise.resolve(value);
		} catch (error) {
			return Promise.reject(error);
		} 
	}

	/**
	 * WE2版本获取
	 */
	public async fetchWE2Version() {
		try {
			const protocol = this.protocol;
			const readRequest = protocol.encodeRequest({
				type: 'WE2Version'
			});
			let size: number | undefined;
			
			await this.manager.beforeSend();
			await this.manager.sendWithoutResponse(readRequest);
			const receiveData = await this.manager.receive({
				transform: d => {
					if (!size) {
						const decodeResult = protocol.decodeData(d);
						size = decodeResult.size;
					}

					return protocol.decodeData(d).data ?? d;
				},
				checkDone(_data, allData) {
					if (!size) {
						return false;
					}

					return allData.length === size;
				}
			}, {
				timeout: 5000
			});
			await this.manager.afterSend();
			const version = Buffer.from(receiveData).toString();

			return Promise.resolve(version);
		} catch (error) {
			return Promise.reject(error);
		} 
	}
}
