import { DeviceManagerErrorType } from './types';
import { BleErrorType } from './ble/types';

/**
 * 通用的设备错误
 * 整合了蓝牙错误和设备管理错误
 */
export class CommonDeviceError extends Error {
	/**
	 * 错误码
	 */
	code: number;

	/**
	 * 错误名称
	 */
	name: BleErrorType | DeviceManagerErrorType;
	
	/**
	 * 错误信息
	 */
	message: string;

	/**
	 * 导致错误的原始错误（原因）
	 */
	cause?: any;

	/**
	 * 是否已经处理过
	 */
	handled?: boolean;

	constructor({ code, name, message, cause }: {
		code: number;
		name: BleErrorType | DeviceManagerErrorType; 
		message: string;
		cause?: any;
	}) {
		super(message);
		this.code = code;
		this.name = name;
		this.message = message;
		this.cause = cause;
	}
}