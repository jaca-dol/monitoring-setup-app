/* eslint-disable @typescript-eslint/no-unused-vars */
import { injectable, inject } from "inversify";

import { IDeviceManagerContext, IDeviceManagerConfig, Providers, ProviderTypes } from './types';

export const defaultDeviceManagerConfig: IDeviceManagerConfig = {
	mode: 'nfc',
	nfc: {
		maxByteSize: 64
	},
	ble: {
		serviceUUID: '0000FE40-CC7A-482A-984A-7F2ED5B3E58F',
		writeCharacteristicUUID: '0000FE41-8e22-4541-9d4c-21edae82ed19',
		notifyCharacteristicUUID: '0000FE42-8E22-4541-9D4C-21EDAE82ED19',
		scanSeconds: 60,
		pinCode: '521125',
		maxByteSize: 250,
	},
	password: '123456'
};

@injectable()
export class DeviceManagerContext implements IDeviceManagerContext {
	protected config: IDeviceManagerConfig;
	protected storage: ProviderTypes['Storage']['instance'];

	constructor(
		@inject(Providers.Storage) Storage: ProviderTypes['Storage']['constructor'],
	) {
		this.config = defaultDeviceManagerConfig;
		this.storage = new Storage({
			id: 'device-manager-context'
		});
		this.init();
	}

	private init() {
		try {
			const config = this.storage.getObject('config') as IDeviceManagerConfig | null;
			if (config != null && typeof config === 'object' && config.mode != null) {
				this.config = config;
			} else {
				this.storage.set('config', this.config);
			}
		} catch (error) {
			console.log('error: ', error);
		}
	}

	public setConfig(config: Partial<IDeviceManagerConfig>): void {
		this.config = {
			...this.config,
			...config
		};
		this.storage.set('config', this.config);
	}

	public getConfig(): IDeviceManagerConfig {
		return this.config;
	}
}