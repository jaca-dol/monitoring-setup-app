import { interfaces } from "inversify";
import { partial } from 'lodash';
import "reflect-metadata"; //⚠️这个全局只需要导入一次就好了

import { IEventEmitter, EventEmitter } from '../../utils/util/EventEmitter';
import Logger, { LoggerType, ILogger, Log } from '../../utils/logger';
import { IStorage, Storage } from '../../utils/util';
import { BleActionApi, IBleActionApi } from "../action";
import { BleProtocolV2 } from "./protocol/BleProtocolV2";
import { BleCommanderV2 } from "./ble/BleCommanderV2";
import { IPSOProtocol } from "../ipso";
import { DataModelManager } from "../../model/DataModel";
import { DataCodecManager } from "../../model/codec";
import { DevicePasswordManager } from "../../service/password";
import { IBleAdapter } from './ble/types';
import { BleManager as BaseBleManager } from './ble/BleManager';
import { NfcManager as BaseNfcManager } from './nfc/NfcManager';
import { NativeAdapter } from "./ble/NativeAdapter";
import { DeviceManagerContext } from "./DeviceManagerContext";
import { IDeviceManagerContext, Providers, container } from "./types";

/**
 * 依赖注入容器
 * @link api - https://inversify.io/docs/6.x/api/binding-syntax/
 */


//绑定EventEmitter
container.bind<interfaces.Newable<IEventEmitter>>(Providers.EventEmitter).toConstructor<IEventEmitter>(EventEmitter);

//绑定自有logger的实例
container.bind<ILogger>(Providers.Logger).toConstantValue(Logger);

//绑定自有logger的extend方法
container.bind<interfaces.Factory<LoggerType>>(Providers.ExtendLoggerFactory).toFactory<LoggerType, string[]>((context: interfaces.Context) => {
	const logger = context.container.get<ILogger>(Providers.Logger);
	return logger.extend;
});

//绑定Storage
container.bind<interfaces.Newable<IStorage>>(Providers.Storage).toConstructor(Storage);

//绑定DeviceManagerContext，全局单例
container.bind<IDeviceManagerContext>(Providers.DeviceManagerContext).to(DeviceManagerContext).inSingletonScope();

//绑定BleAdapter，全局单例
container.bind<IBleAdapter>(Providers.BleAdapter).to(NativeAdapter).inSingletonScope();

//绑定BleManager，全局单例
container.bind(BaseBleManager).toSelf().inSingletonScope();

//绑定DeviceManager，全局单例
// container.bind(BaseDeviceManager).toSelf().inSingletonScope();

//绑定NfcManager，全局单例
container.bind(BaseNfcManager).toSelf().inSingletonScope();

//绑定BleProtocolV2，全局单例
container.bind(BleProtocolV2).toSelf().inSingletonScope();

//绑定BleActionApi，全局单例
container.bind<IBleActionApi>(Providers.BleActionApi).toDynamicValue(context => {
	const bleManager = context.container.get(BaseBleManager);
	const bleProtocolV2 = context.container.get(BleProtocolV2);
	const logger = context.container.get<ILogger>(Providers.Logger);
	const passwordGetter = {
		getPassword: () => DevicePasswordManager.getPasswordById(bleManager.getCurrentConnectedPeripheral()?.id ?? '').password,
		getPasswordId: () => bleManager.getCurrentConnectedPeripheral()?.id ?? ''
	};
	const log = {
		error: partial(Log.e, 'DeviceManager'),
		info: partial(Log.i, 'DeviceManager')
	};
	const ipsoProtocol = new IPSOProtocol(passwordGetter, 'forceNew');
	const bleCommander = new BleCommanderV2(bleManager, bleProtocolV2, logger);

	return new BleActionApi({
		dataModelManager: DataModelManager,
		dataCodecManager: DataCodecManager,
		ipsoProtocol: ipsoProtocol,
		logger: logger,
		log: log,
		manager: bleManager,
		commander: bleCommander,
		protocol: bleProtocolV2
	});
}).inSingletonScope();

export const NfcManager = container.get(BaseNfcManager);

export const BleManager = container.get(BaseBleManager);

// export const DeviceManager = container.get(BaseDeviceManager);

