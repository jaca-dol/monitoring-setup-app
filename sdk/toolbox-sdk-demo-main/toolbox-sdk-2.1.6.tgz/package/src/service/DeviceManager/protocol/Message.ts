import { Reader } from './Reader';
import { Writer } from './Writer';

type Properties<T> = { [P in keyof T]?: T[P] };

export abstract class Message<T extends Record<string, any>> {

	version = 0x01;

	magic = [ 0x4d, 0x3c, 0x2b, 0x1a, 0x78, 0x56, 0x34, 0x12 ];

	static Reader = Reader;

	static Writer = Writer;

	constructor(properties?: Properties<T>) {
		if (properties) {
			for (const [ key, value ] of Object.entries(properties)) {
				(this as any)[key] = value;
			}
		}
	}

	/**
	 * Encodes a message of this type.
	 * @param message Message to encode
	 * @returns Writer
	 */
	public abstract encode(message: (T | { [k: string]: any })): number[];

	/**
	 * Decodes a message of this type.
	 * @param reader Reader or buffer to decode
	 * @returns Decoded message
	 */
	public abstract decode(bytes: number[]): T;

	/**
	 * Verifies a message of this type.
	 * @param message Message to verify
	 * @returns
	 */
	public abstract verify(message: any): boolean;
}