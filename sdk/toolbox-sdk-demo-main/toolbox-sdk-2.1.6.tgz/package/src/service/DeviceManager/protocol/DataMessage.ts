import { isObject, get, has, isArray } from 'lodash';
import moment from 'moment';

import { Message } from './Message';
import { Reader } from './Reader';
import { DataMessageJSON,IDataMessageTypeKey, DataMessageTypeKey, DataMessageType, DataMessageDataType } from './types';

/**
 * 数据消息携带的数据解析器
 */
const DataDecoder: {
	[key in IDataMessageTypeKey]: (params: {
		data: number[];
		size: number;
	}) => DataMessageDataType[key];
} = {
	disconnect: ({data, size}) => {
		const model = new Reader(data).string(size);

		return {
			data,
			time: moment().format('YYYY-MM-DD HH:mm:ss'),
			model
		};
	},
	data: ({data}) => {
		return {
			data
		};
	}
};

/**
 * 数据消息
 */
export class DataMessage extends Message<DataMessageJSON> {
	public encode(message: DataMessageJSON | { [k: string]: any; }): number[] {
		const valid = this.verify(message);	

		if(!valid) {
			throw new Error('Invalid message');
		}

		const { version = this.version, type = 'data', size, data = [] } = message as DataMessageJSON;
		const dataSize = size ?? data.length ?? 0;
		const bufferLength = 6 + (data.length);
		const writer = new Message.Writer(bufferLength);

		writer.uint8(version);
		writer.uint8(DataMessageType[type]);
		writer.uint32LE(dataSize);

		if(data.length > 0) {
			writer.bytes(data);
		}

		return writer.toData();
	}

	/**
	 * 解析数据包
	 */
	public decode(bytes: number[]): DataMessageJSON {
		try {
			const reader = new Message.Reader(bytes);
			const version = reader.uint8();
			const type = reader.uint8();
			const size = reader.uint32LE();
			const data = reader.bytes(bytes.length - 6);
			const typeKey = DataMessageTypeKey.find(key => DataMessageType[key as IDataMessageTypeKey] === type) as IDataMessageTypeKey;

			return {
				version,
				type: typeKey,
				size,
				data,
				payload: DataDecoder[typeKey]({
					data,
					size
				}),
				status: 'success',
				response: bytes
			};
		} catch (error) {
			return {
				status: 'invalid',
				response: bytes
			};
		}
	}

	public verify(message: number[] | Record<string, any>): boolean {
		try {
			if(!isObject(message) && !isArray(message)) {
				return false;
			}

			if(Array.isArray(message) && (message as number[]).length > 6) {
				const buffer = new Reader(message);
				const version = buffer.uint8();
				const type = buffer.uint8();
				const size = buffer.uint32LE();
				const isValidVersion = version === 0x01;
				const isValidType = Object.values(DataMessageType).includes(type);
				const isValidSize = size != null;

				if(isValidVersion && isValidType && isValidSize) {
					return true;
				}
			}
			
			if(isObject(message)) {
				const type = get(message, 'type', null);
				const data = get(message, 'data', null);
				const isValidType = has(DataMessageType, type);
				const isValidData = isArray(data) && data.length != 0;
	
				return isValidType && isValidData;
			}
	
			return false;
		} catch (error) {
			return false;
		}
	}
}
