import { Buffer } from 'buffer';
import { injectable } from 'inversify';

import NfcUtils from '../../nfc/NfcUtils';
import { DataMessage } from './DataMessage';
import { RequestMessage } from './RequestMessage';
import { ResponseMessage } from './ResponseMessage';
import { DataMessageJSON, IDataMessageTypeKey, IProtocol, RequestMessageJSON, RequestType, ResponseJSON } from './types';

/**
 * BLE协议V2版本
 * 支持IPSOv2协议
 */
@injectable()
export class BleProtocolV2 implements IProtocol {
		/**
		 * 前导码
		 */
		private preamble = 0x00;

		/**
		 * 协议版本
		 */
		version: number;

		/**
		 * 魔数
		 */
		magic: number;

		/**
		 * 一帧大小，由帧头（8） + 若干个数据块组成(x * 240 = 4096)
		 */
		frameSize = 8 + 4096;

		/**
		 * 发送数据块大小
		 * 232存疑
		 */
		private chunkSize = 240;

		constructor() {
			this.version = 0x01;
			this.magic = 0x123456781a2b3c4d;
		}

		/**
		 * 编码帧数据
		 * @param data - 帧数据
		 */
		encodeFrame(data: number[]): number[] {
			const headerBuffer = Buffer.alloc(8);
			const dataBuffer = Buffer.from(data);
			const crc32 = NfcUtils.getCrc32(data);
			headerBuffer.writeUInt8(this.preamble, 0);
			headerBuffer.writeUInt8(this.version, 1);
			headerBuffer.writeUInt16LE(data.length, 2);
			headerBuffer.writeUInt32LE(crc32, 4);
			return [
				...headerBuffer,
				...dataBuffer
			];
		}

		/**
		 * 解码帧数据
		 * @param data - 帧数据
		 */
		decodeFrame(frame: number[]): {
				preamble: number;
				protocolVersion: number;
				dataSize: number;
				crc32: number;
				data: number[];
		} {
			const headerBuffer = Buffer.from(frame.slice(0, 8));
			const preamble = headerBuffer.readUInt8(0);
			const protocolVersion = headerBuffer.readUInt8(1);
			const dataSize = headerBuffer.readUInt16LE(2);
			const crc32 = headerBuffer.readUInt32LE(4);
			const frameData = frame.slice(8, 8 + dataSize);

			return {
				preamble,
				protocolVersion,
				dataSize,
				crc32,
				data: frameData
			};
		}

		/**
		 * 将数据编码为数据块
		 * @param data - 数据
		 * @param chunkSize - 数据块大小
		 */
		async encodeDataChunk(data: number[], chunkSize = this.chunkSize): Promise<{
				chunkCount: number;
				chunks: number[][];
		}> {
			const chunks: number[][] = [];
			const chunkCount = this.getSendCount(data.length);

			for (let i = 0; i < chunkCount; i++) {
				const start = i * chunkSize;
				const end = Math.min((i + 1) * chunkSize, data.length);
				const chunk = data.slice(start, end);
				chunks.push(chunk);
			}

			return {
				chunkCount,
				chunks
			};
		}

		/**
		 * 根据数据大小获取要发送chunk的次数
		 */
		getSendCount(dataSize: number): number {
			return Math.ceil(dataSize / this.chunkSize);
		}

		/**
		 * 根据数据大小获取要发送的帧次数
		 */
		getFrameCount(dataSize: number): number {
			return Math.ceil(dataSize / this.frameSize);
		}

		/**
		 * 判断响应是否为旧协议的响应
		 */
		isProtocolV1Response(response: number[]): boolean {
			if (Array.isArray(response)) {
				//旧协议以4d3c2b1a78563412开头
				const isProtocolV1 = [ 77, 60, 43, 26, 120, 86, 52, 18 ].every((value, index) => {
					return response[index] === value;
				});

				return isProtocolV1;
			}

			return false;
		}

		// 以下是原BleProtocol的方法，保留以保持兼容性
		encodeRequest<T extends RequestType>(json: RequestMessageJSON<T>) {
			const request = new RequestMessage();
			return request.encode<T>(json);
		}

		isRequest(bytes: number[]) {
			const request = new RequestMessage();
			return request.verify(bytes);
		}

		decodeRequest<T extends RequestType>(bytes: number[]) {
			const request = new RequestMessage();
			return request.decode<T>(bytes);
		}

		encodeResponse(json: ResponseJSON) {
			const response = new ResponseMessage();
			return response.encode(json);
		}

		decodeResponse(bytes: number[]) {
			const response = new ResponseMessage();
			return response.decode(bytes);
		}

		isResponse(bytes: number[]) {
			const response = new ResponseMessage();
			return response.verify(bytes);
		}

		encodeData(json: Pick<DataMessageJSON, 'data' | 'type' | 'size'>) {
			const message = new DataMessage();
			return message.encode(json);
		}

		decodeData<T extends IDataMessageTypeKey>(bytes: number[]): DataMessageJSON<T> {
			const message = new DataMessage();
			return message.decode(bytes);
		}

		isData(bytes: number[]) {
			const message = new DataMessage();
			return message.verify(bytes);
		}
} 