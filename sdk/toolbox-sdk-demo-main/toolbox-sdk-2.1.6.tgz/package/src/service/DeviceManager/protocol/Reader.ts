import { Buffer } from 'buffer';

export class Reader {
	buffer: Buffer;
	offset: number;

	constructor(bytes: Buffer | number[]) {
		bytes = Array.isArray(bytes) ? Buffer.from(bytes) : bytes; 

		this.buffer = bytes;
		this.offset = 0;
	}

	uint8(): number {
		const value = this.buffer.readUInt8(this.offset);
		this.offset += 1;
		return value;
	}

	uint16(): number {
		const value = this.buffer.readUInt16BE(this.offset);
		this.offset += 2;
		return value;
	}

	uint16LE(): number {
		const value = this.buffer.readUInt16LE(this.offset);
		this.offset += 2;
		return value;
	}

	uint32(): number {
		const value = this.buffer.readUInt32BE(this.offset);
		this.offset += 4;
		return value;
	}

	uint32LE(): number {
		const value = this.buffer.readUInt32LE(this.offset);
		this.offset += 4;
		return value;
	}

	int16LE(): number {
		const value = this.buffer.readInt16LE(this.offset);
		this.offset += 2;
		return value;
	}

	bool(): boolean {
		return this.uint8() === 1;
	}

	bytesAvailable() {
		return this.buffer.length - this.offset;
	}

	bytes(length: number): number[] {
		const value = this.toData().slice(this.offset, this.offset + length);
		this.offset += length;

		return value;
	}

	string(length: number): string {
		const value = this.buffer.toString('utf8', this.offset, this.offset + length);
		this.offset += length;
		return value;
	}

	skip(length: number): void {
		this.offset += length;
	}

	toString(): string {
		return this.buffer.toString('hex');
	}

	toData(): number[] {
		return this.buffer.toJSON().data;
	}
}