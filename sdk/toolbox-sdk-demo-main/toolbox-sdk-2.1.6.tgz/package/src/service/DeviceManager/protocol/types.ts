export const RequestAction = {
	read: 0x01,
	write: 0x02,
};

/**
 * 读取类型
 */
export const ReadType = {
	/**
	 * 读取flash
	 */
	readFlash: 0x05,
	/**
	 * 采集
	 */
	collect: 0x06,

	/**
	 * 读取日志
	 */
	readLog: 0x10,

	/**
	 * 读取历史记录
	 */
	readHistory: 0x09,

	/**
	 * 读取模板
	 */
	readTemplate: 0xa0,

	/**
	 * 读取雷达曲线数据
	 */
	readDistanceRadar: 0x17,

	/**
	 * 读取设备数据
	 */
	getProductInfo: 0x34,

	/**
	 * 读取检测图片
	 */
	readVerificationImage: 0x37,

	/**
	 * PIR状态
	 */
	pirStatus: 0x39,

	/**
	 * WE2版本
	 */
	WE2Version: 0x3A,

	/**
	 * 光敏值
	 */
	lightSensorValue: 0x3B
};

/**
 * 写入类型
 */
export const WriteType = {
	writeFlash: 0x01,
	powerOn: 0x02,
	powerOff: 0x03,
	upgrade: 0x04,
	reset: 0x07,
	password: 0x08,
	reload: 0x0a,
	restart: 0x0b,
	distanceCalibration: 0x17,
	distanceBlindZoneCalibration: 0x17,
	distanceManualDiagnose: 0x17,
	syncTime: 0x0c,
	relativeInitialSurface: 0x10,
	clear: 0x20,
	test: 0x21,
	writeTemplate: 0xa0,
	writeFirmware: 0xa1,
	writeSensorPassword: 0xa2,
	deleteTemplate: 0xa3,
	readyPatch: 0x35,
	sendPatch: 0x36,
	atDebugger: 0x26,
	writeCertificate: 0x27,
	exposure: 0x40
};

export type ReadTypeKey = keyof typeof ReadType;

export type WriteTypeKey = keyof typeof WriteType;

/**
 * 请求消息携带的数据类型
 */
export interface RequestMessageDataType {
	readFlash: null;
	readDistanceRadar: null;
	readLog: null;
	readHistory: {
		/**
		 * 开始时间
		 */
		startTime: number;

		/**
		 * 结束时间
		 */
		endTime: number;

		/**
		 * 当前时间
		 */
		currentTime: number;

		/**
		 * 历史数据类型，0 | 1 | 2 表示不同的存储分区
		 */
		type: 0 | 1 | 2;
	};
	writeFlash: null;
	powerOn: null;
	powerOff: null;
	upgrade: {
		/**
		 * 升级数据大小
		 */
		size: number;
		reboot: boolean;
		moduleId: number;
	};
	writeFirmware: {
		size: number;
		name: string;
		crc: number;
	};
	readTemplate: {
		name: string;
	}
	writeTemplate: {
		size: number;
		name: string;
		crc: number;
	};
	deleteTemplate: {
		name: string;
	}
	writeSensorPassword: {
		password: string;
	}
	reset: null;
	password: {
		password: string;
		phoneModel: string;
	};
	reload: null;
	restart: null;
	collect: null;
	test: number[];
	syncTime: {
		timestamp: number;
		timezone: number;
	};
	relativeInitialSurface: {
		type: 'setting' | 'clear' | 'zero-setting' | 'zero-clear'
	},
	clear: {
		type: 'rainfall' | 'history'
	}
	distanceCalibration: null;
	distanceManualDiagnose: {
		sensitivity: number,
		signalQuality: number,
		peakOrder: number
	};
	readyPatch: null;
	sendPatch: {
		/**
		 * 升级数据大小
		 */
		size: number;
		reboot: boolean;
	},
	getProductInfo: null;
	distanceBlindZoneCalibration: null;
	atDebugger: {
		size: number;
	};
	writeCertificate: {
		size: number;
		mode: number;
		type: 1 | 2 | 3;
		checkData: number;
	};
	readVerificationImage: {
		type: 0 | 1 | 2 | 3;
	};
	pirStatus: {
		type: 0 | 1;
	};
	exposure: {
		value: number
	};
	WE2Version: null;
	lightSensorValue: null
}

export type RequestType = ReadTypeKey | WriteTypeKey;

export interface RequestMessageJSON<T extends RequestType> {

	/**
	 * 协议版本
	 */
	version?: number;

	/**
	 * 魔数
	 */
	magic?: number[];

	/**
	 * 动作
	 */
	action?: 'read' | 'write';

	/**
	 * 类型
	 */
	type: ReadTypeKey | WriteTypeKey;

	/**
	 * 携带数据（number数组）
	 */
	data?: number[];

	/**
	 * 携带数据（对象）
	 * 优先级：data > payload
	 */
	payload?: RequestMessageDataType[T];
}

/**
 * 响应状态
 */
export const ResponseStatus = {
	success: 0x00,
	failed: 0x01,
	timeout: 0x02,
	password_error: 0x03,
	crc_error: 0x04,
	bootloader: 0x09,
	patchOutOfMemory: 0x0A,//内存超出
	patchHeaderError: 0x0B,//patch头部错误
	patchCrcError: 0x0C,//固件crc校验错误
	patchModelError: 0x0D,//类型错误
	invalid: 0xff
};

/**
 * 数据消息类型
 */
export const DataMessageType = {
	data: 0x00,
	disconnect: 0x01,
};

/**
 * 数据消息携带的数据类型
 */
export interface DataMessageDataType {
	data: {
		/**
		 * 原始数据
		 */
		data: number[];
	};
	disconnect: {
		time: string;
		model: string;
		data: number[];
	};
}

export type IResponseStatusKey = keyof typeof ResponseStatus;

export type IDataMessageTypeKey = keyof typeof DataMessageType;

export const ResponseStatusKey = Object.keys(ResponseStatus);

export const DataMessageTypeKey = Object.keys(DataMessageType);

export interface ResponseJSON {
	version?: number;
	magic?: number[];
	status: IResponseStatusKey;
	response: number[];
}

export interface DataMessageJSON<T extends IDataMessageTypeKey = any> {
	/**
	 * 版本
	 */
	version?: number;

	/**
	 * 状态
	 */
	status: IResponseStatusKey;

	/**
	 * 数据
	 */
	data?: number[];

	/**
	 * 解码后的数据
	 */
	payload?: DataMessageDataType[T];

	/**
	 * 数据长度
	 */
	size?: number;

	/**
	 * 数据类型
	 */
	type?: IDataMessageTypeKey;

	/**
	 * 原始数据
	 */
	response: number[];
}

export interface IProtocol {
	encodeRequest: <T extends RequestType>(json: RequestMessageJSON<T>) => number[];

	decodeRequest: <T extends RequestType>(bytes: number[]) => RequestMessageJSON<T>;

	encodeResponse: (json: ResponseJSON) => number[];

	decodeResponse: (bytes: number[]) => ResponseJSON;

	encodeData: (json: Pick<DataMessageJSON, 'data' | 'type' | 'size'>) => number[];

	decodeData: <T extends IDataMessageTypeKey>(bytes: number[]) => DataMessageJSON<T>;
}