import { RequestMessage } from './RequestMessage';
import { ResponseMessage } from './ResponseMessage';
import { RequestMessageJSON, ResponseJSON, IProtocol, RequestType } from './types';

export class NfcProtocol implements IProtocol {
	version: number;
	magic: number;

	constructor() {
		this.version = 0x01;
		this.magic = 0x123456781a2b3c4d;
	}

	encodeRequest<T extends RequestType>(json: RequestMessageJSON<T>) {
		const request = new RequestMessage();

		return request.encode(json);
	}

	decodeRequest<T extends RequestType>(bytes: number[]) {
		const request = new RequestMessage();
		return request.decode<T>(bytes);
	}

	encodeResponse(json: ResponseJSON) {
		const response = new ResponseMessage();

		return response.encode(json);
	}

	decodeResponse(bytes: number[]) {
		const response = new ResponseMessage();

		return response.decode(bytes);
	}

	encodeData() {
		return [];
	}

	decodeData() {
		return {} as any;
	}
}