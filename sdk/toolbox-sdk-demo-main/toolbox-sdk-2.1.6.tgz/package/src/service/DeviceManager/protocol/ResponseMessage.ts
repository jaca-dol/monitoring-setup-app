import { Message } from './Message';
import { ResponseStatus, ResponseStatusKey, IResponseStatusKey, ResponseJSON } from './types';

export class ResponseMessage extends Message<ResponseJSON> {
	public encode(message: ResponseJSON | { [k: string]: any; }): number[] {
		const valid = this.verify(message);	

		if(!valid) {
			throw new Error('Invalid message');
		}

		const writer = new Message.Writer(16);
		const { version = this.version, magic = this.magic, status } = message;

		writer.bytes(magic);
		writer.uint8(version);
		writer.uint8(ResponseStatus[status]);

		return writer.toData();
	}

	public decode(bytes: number[]): ResponseJSON {
		try {
			const reader = new Message.Reader(bytes);
			const magic = reader.bytes(8);
			const version = reader.uint8();
			const status = reader.uint8();

			return {
				version,
				magic,
				status: ResponseStatusKey.find(key => ResponseStatus[key as IResponseStatusKey] === status) as IResponseStatusKey,
				response: bytes
			};
		} catch (error) {
			return {
				status: 'invalid',
				response: bytes
			};
		}
	}

	public verify(message: any): message is ResponseJSON {
		if(!(message.status)) {
			return false;
		}

		return true;
	}
}
