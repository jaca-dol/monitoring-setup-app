import { DataMessage } from './DataMessage';
import { RequestMessage } from './RequestMessage';
import { ResponseMessage } from './ResponseMessage';
import { RequestMessageJSON, ResponseJSON, IProtocol, DataMessageJSON, IDataMessageTypeKey, RequestType } from './types';

export class BleProtocol implements IProtocol {
	version: number;
	magic: number;

	constructor() {
		this.version = 0x01;
		this.magic = 0x123456781a2b3c4d;
	}

	encodeRequest<T extends RequestType>(json: RequestMessageJSON<T>) {
		const request = new RequestMessage();

		return request.encode<T>(json);
	}

	isRequest(bytes: number[]) {
		const request = new RequestMessage();

		return request.verify(bytes);
	}

	decodeRequest<T extends RequestType>(bytes: number[]) {
		const request = new RequestMessage();
		return request.decode<T>(bytes);
	}

	encodeResponse(json: ResponseJSON) {
		const response = new ResponseMessage();

		return response.encode(json);
	}

	decodeResponse(bytes: number[]) {
		const response = new ResponseMessage();

		return response.decode(bytes);
	}

	isResponse(bytes: number[]) {
		const response = new ResponseMessage();

		return response.verify(bytes);
	}

	encodeData(json: Pick<DataMessageJSON, 'data' | 'type' | 'size'>) {
		const message = new DataMessage();

		return message.encode(json);
	}

	decodeData<T extends IDataMessageTypeKey>(bytes: number[]): DataMessageJSON<T> {
		const message = new DataMessage();

		return message.decode(bytes);
	}

	isData(bytes: number[]) {
		const message = new DataMessage();

		return message.verify(bytes);
	}
}