import { Buffer } from 'buffer';

import { Message } from './Message';
import {
	ReadType, ReadTypeKey, RequestAction, RequestMessageDataType, RequestMessageJSON, RequestType, WriteType, WriteTypeKey,
} from './types';

const RequestDataEncoder: {
	[key in RequestType]: (params: RequestMessageDataType[key]) => number[];
} = {
	readFlash: () => {
		return [];
	},
	readHistory: ({ startTime, endTime, currentTime, type }) => {
		const writer = new Message.Writer(15);

		writer.uint8(1); //action 1
		writer.uint8(1); //填充位
		writer.uint32LE(endTime);
		writer.uint32LE(startTime);
		writer.uint32LE(currentTime);
		writer.uint8(type);

		return writer.toData();
	},
	readDistanceRadar: () => {
		return [];
	},
	readLog: () => {
		return [];
	},
	writeFlash: function () {
		return [];
	},
	powerOn: function () {
		return [];
	},
	powerOff: function () {
		return [];
	},
	upgrade: function ({size, reboot, moduleId}) {
		const writer = new Message.Writer(22);

		writer.uint32LE(size);
		writer.uint32LE(0);
		writer.uint32LE(0);
		writer.uint32LE(0);
		writer.uint16LE(0);
		writer.uint16LE(reboot ? 0 : 0x5a5a);
		writer.uint16LE(moduleId);

		return writer.toData();
	},
	readTemplate: function ({ name }) {
		const nameBuffer = Buffer.alloc(80, 0);
		const encodedName = Buffer.from(name, 'utf8');
		encodedName.copy(nameBuffer as Uint8Array, 0, 0, Math.min(encodedName.length, 80));

		const writer = new Message.Writer(80);
		writer.buffer.write(nameBuffer.toString('utf8'), writer.offset, 80, 'utf8');
		writer.offset += 80;

		return writer.toData();
	},
	writeSensorPassword: function ({ password }) {
		const writer = new Message.Writer(6);
		writer.string(password);
		return writer.toData();
	},
	deleteTemplate: function ({ name }) {
		const nameBuffer = Buffer.alloc(80, 0);
		const encodedName = Buffer.from(name, 'utf8');
		encodedName.copy(nameBuffer as Uint8Array, 0, 0, Math.min(encodedName.length, 80));

		const writer = new Message.Writer(80);
		writer.buffer.write(nameBuffer.toString('utf8'), writer.offset, 80, 'utf8');
		writer.offset += 80;

		return writer.toData();
	},
	writeTemplate: function ({ size, name, crc }) {
		const nameBuffer = Buffer.alloc(80, 0);
		const encodedName = Buffer.from(name, 'utf8');
		encodedName.copy(nameBuffer as Uint8Array, 0, 0, Math.min(encodedName.length, 80));

		const writer = new Message.Writer(4 + 4 + 80);
		writer.int32LE(crc);
		writer.uint32LE(size);
		writer.buffer.write(nameBuffer.toString('utf8'), writer.offset, 80, 'utf8');
		writer.offset += 80;

		return writer.toData();
	},
	writeFirmware: function ({ size, name, crc }) {
		const nameBuffer = Buffer.alloc(48, 0);
		Buffer.from(name, 'ascii').copy(nameBuffer as Uint8Array, 0, 0, Math.min(name.length, 48));

		const writer = new Message.Writer(4 + 4 + 48);
		writer.int32LE(crc);
		writer.uint32LE(size);
		writer.buffer.write(nameBuffer.toString('ascii'), writer.offset, 48, 'ascii');
		writer.offset += 48;

		return writer.toData();
	},

	//准备升级
	readyPatch: function () {
		return [];
	},
	//发升级包数据
	sendPatch: function ({size, reboot}) {
		const writer = new Message.Writer(4);
		//是否需要重启设备（一般只在最后一次差分升级完成后才需要重启）

		writer.uint16LE(size);
		writer.uint16LE(reboot ? 0 : 0x5a5a);

		return writer.toData();
	},
	//写入AT指令
	atDebugger: function ({size}) {
		const writer = new Message.Writer(2);
		writer.uint16LE(size);
		return writer.toData();
	},
	//写入证书
	writeCertificate: function ({size, mode, type, checkData}) {
		const writer = new Message.Writer(11);
		writer.uint32LE(size);
		writer.uint8(mode);
		writer.uint8(type);
		writer.uint8(0);
		writer.int32LE(checkData);
		return writer.toData();
	},
	//获取产品信息
	getProductInfo:  function () {
		return [];
	},
	reset: function (): number[] {
		return [];
	},
	password: function ({ password, phoneModel}) {
		const passwordBuffer = Buffer.from(password, 'utf-8');
		const passwordData = passwordBuffer.toJSON().data;
		const phoneModelBuffer = Buffer.from(phoneModel, 'utf-8');
		const brandData = [phoneModelBuffer.byteLength].concat(phoneModelBuffer.toJSON().data);
		const data = passwordData.concat(brandData).concat([passwordBuffer.byteLength]);

		return data;
	},
	reload: function () {
		return [];
	},
	collect: function () {
		return [];
	},
	restart: function () {
		return [];
	},
	test: function (params: number[]) {
		return params;
	},
	syncTime: function ({ timestamp, timezone }) {
		const writer = new Message.Writer(6);

		writer.uint32LE(timestamp);
		writer.int16LE(timezone);

		return writer.toData();
	},
	relativeInitialSurface: function ({ type }) {
		const writer = new Message.Writer(2);
		const typeData = {
			setting: 0xff,
			clear: 0xfe,
			'zero-setting': 0xfd,
			'zero-clear': 0xfc
		}[type];

		writer.uint8(typeData);

		return writer.toData();
	},
	clear: ({type}) => {
		const writer = new Message.Writer(2);
		const typeData = {
			rainfall: 0x00,
			history: 0x01
		}[type];

		writer.uint8(typeData);

		return writer.toData();
	},
	distanceCalibration: () => {
		const writer = new Message.Writer(1);
		writer.uint8(0x01);

		return writer.toData();
	},

	distanceBlindZoneCalibration: () => {
		const writer = new Message.Writer(1);
		writer.uint8(0x02);

		return writer.toData();
	},

	distanceManualDiagnose: ({ sensitivity, signalQuality, peakOrder }) => {
		const writer = new Message.Writer(7);
		const sensitivityToInt = sensitivity * 10;
		writer.uint8(0x03);
		writer.int16LE(signalQuality);
		writer.int16LE(sensitivityToInt);
		writer.int16LE(peakOrder);

		return writer.toData();
	},
	readVerificationImage: ({ type }) => {
		const writer = new Message.Writer(1);
		writer.uint8(type);

		return writer.toData();
	},
	pirStatus: ({ type }) => {
		const writer = new Message.Writer(1);
		writer.uint8(type);

		return writer.toData();
	},
	exposure: ({value}) => {
		const writer = new Message.Writer(1);
		writer.uint8(value);

		return writer.toData();
	},
	lightSensorValue: function () {
		return [];
	},
	WE2Version: function () {
		return [];
	}
};

export class RequestMessage extends Message<RequestMessageJSON<any>> {
	public encode<T extends RequestType>(message: RequestMessageJSON<T>): number[] {
		const valid = this.verify(message);

		if(!valid) {
			throw new Error('Invalid message');
		}

		const { version = this.version, magic = this.magic, action, type, data = [], payload } = message as RequestMessageJSON<T>;
		const messageData = data.length > 0
			? data
			: payload !== null
				? RequestDataEncoder[type as RequestType](payload as never) ?? []
				: [];

		const requestAction = action ?? type in ReadType ? 'read' : 'write';
		const bufferLength = 11 + (messageData.length ?? 0);
		const writer = new Message.Writer(bufferLength);

		writer.bytes(magic);
		writer.uint8(version);
		writer.uint8(RequestAction[requestAction]);
		writer.uint8(requestAction === 'read' ? ReadType[type as ReadTypeKey] : WriteType[type as WriteTypeKey]);

		if(messageData.length > 0) {
			writer.bytes(messageData);
		}
		
		return writer.toData();
	}

	public decode<T extends RequestType>(bytes: number[]): RequestMessageJSON<T> {
		const reader = new Message.Reader(bytes);
		const magic = reader.bytes(8);
		const version = reader.uint8();
		const action = reader.uint8();
		const type = reader.uint8();

		return {
			version,
			magic,
			action: action === RequestAction.read ? 'read' : 'write',
			type: action === RequestAction.read
				? (Object.keys(ReadType).find(key => ReadType[key as ReadTypeKey] === type)) as ReadTypeKey
				: (Object.keys(WriteType).find(key => WriteType[key as WriteTypeKey] === type)) as WriteTypeKey
		};
	}

	public verify(message: any) {
		if(!(message.type in ReadType) && !(message.type in WriteType)) {
			return false;
		}

		return true;
	}
}
