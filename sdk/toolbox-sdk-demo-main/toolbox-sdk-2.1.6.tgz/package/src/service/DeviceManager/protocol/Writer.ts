import { Buffer } from 'buffer';

export class Writer {
	buffer: Buffer;
	offset: number;

	constructor(size: number) {
		this.buffer = Buffer.alloc(size);
		this.offset = 0;
	}

	uint8(value: number): void {
		this.buffer.writeUInt8(value, this.offset);
		this.offset += 1;
	}

	int8(value: number): void {
		this.buffer.writeInt8(value, this.offset);
		this.offset += 1;
	}

	uint16(value: number): void {
		this.buffer.writeUInt16BE(value, this.offset);
		this.offset += 2;
	}

	int16(value: number): void {
		this.buffer.writeInt16BE(value, this.offset);
		this.offset += 2;
	}

	int16LE(value: number): void {
		this.buffer.writeInt16LE(value, this.offset);
		this.offset += 2;
	}

	uint16LE(value: number): void {
		this.buffer.writeUInt16LE(value, this.offset);
		this.offset += 2;
	}

	uint32(value: number): void {
		this.buffer.writeUInt32BE(value, this.offset);
		this.offset += 4;
	}

	int32(value: number): void {
		this.buffer.writeInt32BE(value, this.offset);
		this.offset += 4;
	}

	int32LE(value: number): void {
		this.buffer.writeInt32LE(value, this.offset);
		this.offset += 4;
	}

	uint32LE(value: number): void {
		this.buffer.writeUInt32LE(value, this.offset);
		this.offset += 4;
	}

	string(value: string): void {
		this.buffer.write(value, this.offset, value.length, 'utf8');
		this.offset += value.length;
	}

	bool(value: boolean): void {
		this.uint8(value ? 1 : 0);
	}

	bytes(bytes: number[], le = true): void {
		const types = [
			{
				type: 'uint8',
				min: 0,
				max: 255,
				method: this.uint8.bind(this)
			},
			{
				type: 'int8',
				min: -128,
				max: 127,
				method: this.int8.bind(this)
			},
			{
				type: 'uint16',
				min: 0,
				max: 65535,
				method: le ? this.uint16LE.bind(this) : this.uint16.bind(this)
			},
			{
				type: 'int16',
				min: -32768,
				max: 32767,
				method: le ? this.int16LE.bind(this) : this.int16.bind(this)
			},
			{
				type: 'uint32',
				min: 0,
				max: 4294967295,
				method: le ? this.uint32LE.bind(this) : this.uint32.bind(this)
			},
			{
				type: 'int32',
				min: -2147483648,
				max: 2147483647,
				method: le ? this.int32LE.bind(this) : this.int32.bind(this)
			}
		];

		for (const byte of bytes) {
			// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
			const findType = types.find(
				type => byte >= type.min && byte <= type.max
			);

			if(!findType) {
				throw new Error(`${byte} is out of range`);
			}

			findType.method(byte);
		}
	}

	toBuffer(): Buffer {
		return this.buffer.slice(0, this.offset);
	}

	/**
	 * 转成uint8数组
	 */
	toData(): number[] {
		return this.toBuffer().toJSON().data;
	}

	toString(): string {
		return this.toBuffer().toString('hex');
	}
}