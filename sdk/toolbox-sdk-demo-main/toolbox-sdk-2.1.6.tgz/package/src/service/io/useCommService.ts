import store from "../../utils/store/store";
import { setDeviceRawData, setSettingMode, loadDeviceInfo, loadPreDeviceInfo, setAllSolenoidWork, getPreDeviceInfo, getRawData, getDeviceInfo, setDeviceInfo, setPreDeviceInfo } from "../../utils/store/actions";
import { difference, getDeviceSettingInfo, getSettingJSON, getOriginPreDeviceInfo } from "../../model/utils";
import NfcController from "../nfc/controller/NfcController";
import { DeviceHooks } from "../hook/useDeviceEvent";
import { DeviceInfo, DeviceSettingInfo } from "../../model/deviceInfo";
import { processPayload } from "../../model/utils";
import _ from "lodash";
import { DeviceManager, BleManager, BleError } from "../DeviceManager";
import { DevicePasswordManager } from "../password/DevicePasswordManager";
import { sleep } from "../../utils/util";
import { Platform } from "react-native";
import { getModel, getDeviceName, getBrand } from "react-native-device-info";

const useCommService = () => {

	const bleConnect = async (id: string) => {
		try {
			DeviceManager.use('ble');
			await BleManager.checkConnect(id);
			await BleManager.bondPeripheral(id);
			await sleep(10);
			return Promise.resolve();
		} catch (error) {
			return Promise.reject(error);
		}
	};

	const bleAuth = async (id: string, password: string, isRemember = true) => {
		DeviceManager.use('ble');
		const authDisconnectEventInterceptor = (event: string) => {
			if(event === 'disconnect') {
				return false;
			}

			return true;
		};
		const getPhoneModel = async () => {
			try {
				if(Platform.OS === 'ios') {
					return getModel();
				}

				//安卓获取顺序：设备名称 > 设备型号 > 品牌
				return await getDeviceName() ?? getModel() ?? getBrand();
			} catch (error) {
				return getModel() ?? 'unknown';
			}
		};

		try {
			const phoneModel = await getPhoneModel();
			BleManager.addEmitInterceptor(authDisconnectEventInterceptor); //添加拦截器，防止在输入密码过程中，提示断开连接
			const result = await DeviceManager.auth(password, phoneModel);
			if(isRemember) {
				DevicePasswordManager.setPasswordById(id, password);
			}
			DevicePasswordManager.setPasswordById(id, password, true);
			BleManager.removeEmitInterceptor(authDisconnectEventInterceptor);
			return result;
		} catch (error: any) {
			const hasPassword = DevicePasswordManager.getPasswordById(id, false).password != null;
			if(error.name === 'PASSWORD_ERROR' && hasPassword) {
				console.log('password error, remove password', password);
				DevicePasswordManager.removePasswordById(id);
			}

			setTimeout(() => {
				BleManager.removeEmitInterceptor(authDisconnectEventInterceptor);
			}, 1500);

			return Promise.reject(error);
		}
	};


	const read = async (mode: 'nfc' | 'ble') => {
		try {
			if (mode === 'nfc') {
				return await nfcRead();
			} else {
				return await bleRead();
			}			
		} catch (error) {
			return Promise.reject(error);
		}
	};

	/**
     * 读取设备便利函数(对外暴露的接口，内部不使用)
     */
	const nfcRead = async () => {
		{
			try {
				DeviceManager.use('nfc');
				const { deviceInfo, rawData } = await NfcController.readFlash();
    
				if (!deviceInfo || !rawData) {
					return;
				}
    
				store.dispatch(setDeviceRawData(rawData));
				store.dispatch(setSettingMode('device'));
				store.dispatch(loadDeviceInfo(deviceInfo));
				store.dispatch(loadPreDeviceInfo(deviceInfo));
    
				if (_.has(deviceInfo, 'solenoidWork')) {
					store.dispatch(setAllSolenoidWork(deviceInfo.solenoidWork));
				}
    
				//触发读取设备信息完成事件
				DeviceHooks.read.call(deviceInfo as DeviceInfo);

				const { payload, status } = processPayload(store.getState().device.deviceInfo, deviceInfo);    
				return {...payload, status} as Partial<DeviceInfo>;
			} catch (error) {
				return Promise.reject(error);
			}
		}
	};




	/**
	 * 写入设备数据(对外暴露的接口，内部不使用)
	 * @param deviceInfo 设备信息
	 * @returns 
	 */
	const nfcWrite = async (finalJSON: string, newDeviceSettingInfo: DeviceSettingInfo) => {
		try {
			DeviceManager.use('nfc');
			const result = await NfcController.write(finalJSON, newDeviceSettingInfo as DeviceInfo);
			return Promise.resolve(result);
		} catch (error: any) {
			return Promise.reject(error);
		}
	};

	const bleRead = async () => {
		try {
			DeviceManager.use('ble');
			const result = await DeviceManager.read();
			store.dispatch(setDeviceRawData(result.rawData));
			store.dispatch(setSettingMode('device'));
			store.dispatch(loadDeviceInfo(result.deviceInfo));
			store.dispatch(loadPreDeviceInfo(result.deviceInfo));

			const currentConnectedPeripheral = BleManager.getCurrentConnectedPeripheral();

			//关联设备sn和BLE的Id
			if(result.deviceInfo.sn && currentConnectedPeripheral) {
				DevicePasswordManager.associateSnWithBLEId(result.deviceInfo.sn, currentConnectedPeripheral.id);
			}

			//触发读取设备信息完成事件
			DeviceHooks.read.call(result.deviceInfo as DeviceInfo);
			const { payload, status } = processPayload(store.getState().device.deviceInfo, result.deviceInfo);    
			return {...payload, status} as Partial<DeviceInfo>;
		} catch (error) {
			return Promise.reject(error);
		}
	};
	/**
	 * 蓝牙写入
	 */
	const bleWrite = async (finalJSON: string, newDeviceSettingInfo: DeviceSettingInfo) => {
		try {
			DeviceManager.use('ble');
			const isChangePassword = _.get(
				newDeviceSettingInfo,
				'changePassword',
				false
			);

			const settingPassword = _.get(
				newDeviceSettingInfo,
				'password',
				null
			);
			const rememberPassword = _.get(
				newDeviceSettingInfo,
				'rememberPassword',
				true
			);

			let rawData = getRawData(store.getState());

			const currentConnectedPeripheral = BleManager.getCurrentConnectedPeripheral();
            
			if (!currentConnectedPeripheral?.connected) {
				BleError.throw('NOT_CONNECTED_PERIPHERAL');
			}

			//模版模式下，如果没有rawData，就读取一次
			if (rawData.length === 0) {
				const readResult = await DeviceManager.read();
				rawData = readResult.rawData;
			}

			const nextRawData = await DeviceManager.write(rawData, JSON.stringify(_.omit(JSON.parse(finalJSON), 'rememberPassword')), newDeviceSettingInfo);

			const deviceInfo = getDeviceInfo(store.getState());

			//当非修改密码时，password以存储密码为值，修改密码时以新密码为值
			if (_.get(newDeviceSettingInfo, 'password', '') != deviceInfo.password) {
				if (!isChangePassword) {					
					_.set(newDeviceSettingInfo, 'password', deviceInfo.password);
				}
			}

			//只要有设置密码，就更新相关密码
			if(deviceInfo.sn && settingPassword) {
				if(rememberPassword) {
					DevicePasswordManager.setPasswordBySn(deviceInfo.sn, settingPassword);
				}
				//更新临时密码
				DevicePasswordManager.setPasswordBySn(deviceInfo.sn, settingPassword, true);
			}

			if(!rememberPassword) {
				DevicePasswordManager.removePasswordBySn(deviceInfo.sn);
			}

			setDeviceRawData(nextRawData);
			setDeviceInfo(deviceInfo);
			setPreDeviceInfo(deviceInfo);
		
			return Promise.resolve(nextRawData);
		} catch (error) {
			return Promise.reject(error);
		}
	};

	const write = async (deviceInfo: Partial<DeviceInfo>, mode: 'nfc' | 'ble') => {
		const deviceSettingInfo = _.cloneDeep(deviceInfo) as DeviceInfo;		
		const prevDeviceInfo = getPreDeviceInfo(store.getState());
		const defaultPreDeviceInfo = getOriginPreDeviceInfo(prevDeviceInfo);
		const diffSetting = difference(deviceSettingInfo, defaultPreDeviceInfo, [
			'reportMode',
			'dismissReport',
		]) as Partial<DeviceInfo>;

		const preDeviceSettingInfo = getDeviceSettingInfo(
			prevDeviceInfo
		);

		const newDeviceSettingInfo = _.merge({}, preDeviceSettingInfo, diffSetting) as DeviceSettingInfo;

		const finalJSON = getSettingJSON(
			diffSetting,
			newDeviceSettingInfo,
			prevDeviceInfo,
			false
		);
		try {
			let result = null;
			if (mode === 'nfc') {
				result = await nfcWrite(finalJSON, newDeviceSettingInfo);
			} else {
				result = await bleWrite(finalJSON, newDeviceSettingInfo);
			}
            
			//触发写入设备信息完成事件
			DeviceHooks.writeFinish.call(newDeviceSettingInfo as DeviceInfo);

			return Promise.resolve(result);
		} catch (error) {
			return Promise.reject(error);
		}
	};

	return {
		read,
		write,
		bleConnect,
		bleAuth
	};
};

export default useCommService;