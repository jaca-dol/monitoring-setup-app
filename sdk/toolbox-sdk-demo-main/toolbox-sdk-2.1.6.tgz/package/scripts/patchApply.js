#!/usr/bin/env node

/**
 * Apply patches using git apply.
 * Works regardless of where the user installed your library.
 */

const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

// ----- 1) Detect real library root -----
const libRoot = path.resolve(__dirname, ".."); // your library root
const patchesDir = path.join(libRoot, "patches");

if (!fs.existsSync(patchesDir)) {
	console.log("No patches directory, skipping.");
	process.exit(0);
}

// ----- 2) Walk upward to find user's project root -----
// Root is the first dir containing package.json but NOT inside node_modules/
function findUserProjectRoot(start) {
	let current = start;

	// eslint-disable-next-line no-constant-condition
	while (true) {
		const pkg = path.join(current, "package.json");
		const isNodeModules = current.split(path.sep).includes("node_modules");

		if (fs.existsSync(pkg) && !isNodeModules) {
			return current;
		}

		const parent = path.dirname(current);
		if (parent === current) break;
		current = parent;
	}

	return null;
}

const userProjectRoot = findUserProjectRoot(libRoot);

if (!userProjectRoot || userProjectRoot.includes('packages/toolbox-sdk')) {
	console.error("Could not detect user project root. Skipping patches.");
	process.exit(0);
}

console.log(`Detected user root at: ${userProjectRoot}`);

// ----- 3) apply all .patch files -----
const patchFiles = fs
	.readdirSync(patchesDir)
	.filter(f => f.endsWith(".patch") || f.endsWith(".diff"));

if (patchFiles.length === 0) {
	console.log("No patch files found.");
	process.exit(0);
}

for (const file of patchFiles) {
	const patchPath = path.join(patchesDir, file);

	console.log(`Applying patch: ${file}`);

	try {
		// git apply must run from user project root
		child_process.execSync(`git apply "${patchPath}"`, {
			cwd: userProjectRoot,
			stdio: 'ignore',
		});
		console.log(`✓ Applied ${file}`);
	} catch (e) {
		// console.error(`✗ Failed to apply ${file}`);
	}
}

console.log("All patches processed.");
