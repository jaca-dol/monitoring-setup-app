//
//  DeviceUtils.h
//  UrsalinkNFC
//
//  Created by 郑荣滨 on 2020/5/26.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import <React/RCTBridgeModule.h>

@interface DeviceUtils : NSObject <RCTBridgeModule>
    
@end
  
