//
//  DeviceUtils.m
//  UrsalinkNFC
//
//  Created by 郑荣滨 on 2020/5/26.
//  Copyright © 2020 Facebook. All rights reserved.
//
#import "DeviceUtils.h"
#import "nfc_app.h"
#import <React/RCTLog.h>
#import <React/RCTConvert.h>
#import "node_lzss.h"
#import "bmp2hex.h"
#import "app_card.h"
#import "unxx_crc32.h"
#import "aes.h"
#import "main_version.h"


@implementation DeviceUtils

- (char *) getCharArr:(NSArray *)data withCount:(int)count {
  char charArray[count];
  int cArray[count];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }
  
  return charArray;
}

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(mainVersion:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
    NSString *version = [NSString stringWithUTF8String:mainVersion()];
    resolve(version);
}

RCT_EXPORT_METHOD(getFlashInfo:(NSArray *)data getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("getFlashInfo count %d\n", count);
  char charArray[count];
  int cArray[count];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }
//  char *charArray = [self getCharArr:data withCount:count];
//  RCTLog(@"data %@", data);
//  RCTLog(@"data %@", data);
  char *cjsonStr = get_flash_base_info(charArray, count);
  printf("cjsonStr %s", cjsonStr);
  NSString *jsonStr = [NSString stringWithUTF8String:cjsonStr];
//  RCTLog(@"jsonStr %@", jsonStr);
  if (data) {
    resolve(jsonStr);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"get_flash_base_info error"}];;
    reject(@"get flash base info", @"There were no json", error);
  }
}

RCT_EXPORT_METHOD(setFlashInfo:(NSArray *)data withJSON:(NSString *)jsonStr getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("setFlashInfo count %d\n", count);
  char charArray[count];
  int cArray[count];
  const char * cJsonStr =[jsonStr UTF8String];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }
//  char *charArray = [self getCharArr:data withCount:count];
//  RCTLog(@"data %@", data);
//  RCTLog(@"data %@", data);
  char *cResultjsonStr = set_flash_base_info(charArray, cJsonStr);
  NSString *resultJsonStr = [NSString stringWithUTF8String:cResultjsonStr];
  NSError *error = nil;
  id jsonObject = [NSJSONSerialization
                       JSONObjectWithData:[resultJsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:&error];
  NSDictionary *deserializedDict = (NSDictionary *)jsonObject;
  NSLog(@"setFlashInfo Deserialized JSON Dictionary = %@", deserializedDict);
  NSString *successCode = @"1";
  if([deserializedDict objectForKey:@"code"]) {
    NSMutableArray * rawData = [[NSMutableArray alloc] initWithCapacity: count];
    for (int j = 0; j < count; j++) {
      NSNumber * intWrapped = [NSNumber numberWithInt: (int)charArray[j]];
      [rawData addObject: intWrapped];
    }
    
    NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:
    [deserializedDict objectForKey:@"code"], @"code", rawData, @"rawData", resultJsonStr,@"result",nil];
    
    resolve(finalDictionary);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"set_flash_base_info error"}];;
    reject(@"set flash base info", @"There were no json", error);
  }
}

/**
 * 设置设备USB配置信息
 * @param flashData - flashData
 * @param unpData - unpData
 * @param settingJSON - settingJSON
 */
RCT_EXPORT_METHOD(setFlashInfoToUnp:(NSArray *)flashData withUnpData:(NSArray *)unpData withJSON:(NSString *)jsonStr getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int flashCount = (int)[flashData count];
  int unpCount = (int)[unpData count];

  // 创建 C 数组
  char *flashCharArray = (char *)malloc(flashCount * sizeof(char));
  char *unpCharArray = (char *)malloc(unpCount * sizeof(char));
  const char *cJsonStr = [jsonStr UTF8String];

  // 将 NSArray 转换为 C 数组
  for (int i = 0; i < flashCount; ++i) {
    flashCharArray[i] = (char)[[flashData objectAtIndex:i] intValue] & 0xFF;
  }

  for (int i = 0; i < unpCount; ++i) {
    unpCharArray[i] = (char)[[unpData objectAtIndex:i] intValue] & 0xFF;
  }

  // 调用本地方法
  uint16_t resultSize = set_flash_base_info_to_unp_sct(flashCharArray, (char *)cJsonStr, unpCharArray);

  // 检查结果大小
  if (resultSize == 0) {
    free(flashCharArray);
    free(unpCharArray);
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"set_flash_base_info_to_unp_sct error"}];
    reject(@"set flash base info to unp", @"Result size is zero", error);
    return;
  }

  // 处理结果
  NSMutableArray *flashRawData = [[NSMutableArray alloc] initWithCapacity:flashCount];
  for (int j = 0; j < flashCount; j++) {
    NSNumber *intWrapped = [NSNumber numberWithInt:(int)flashCharArray[j] & 0xFF];
    [flashRawData addObject:intWrapped];
  }

  NSMutableArray *unpRawData = [[NSMutableArray alloc] initWithCapacity:resultSize];
  for (int j = 0; j < resultSize; j++) { 
    NSNumber *intWrapped = [NSNumber numberWithInt:(int)unpCharArray[j] & 0xFF];
    [unpRawData addObject:intWrapped];
  }

  NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:
                                   @(resultSize), @"resultSize",
                                   flashRawData, @"flashData",
                                   unpRawData, @"unpData",
                                   nil];
  free(flashCharArray);
  free(unpCharArray);

  resolve(finalDictionary);
}


RCT_EXPORT_METHOD(decodeData:(NSArray *)data decodeWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("count %d", count);
  char charArray[4096];
  int cArray[4096];
  char resultArray[4096];
  int resultSize = 0;

  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  Decode(charArray, count, resultArray, &resultSize);
  printf("count %d", count);
  printf("resultSize %d", resultSize);
  
  NSMutableArray * rawData = [[NSMutableArray alloc] initWithCapacity: resultSize];
  for (int j = 0; j < resultSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithChar: resultArray[j]];
    [rawData addObject: intWrapped];
  }
  
  NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys: [NSNumber numberWithInt:resultSize], @"size", rawData, @"data", nil];

  resolve(finalDictionary);
}

RCT_EXPORT_METHOD(encodeData:(NSArray *)data encodeWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("count %d", count);
  char charArray[4096];
  int cArray[4096];
  char resultArray[4096];
  int resultSize = 0;

  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  Encode(charArray, count, resultArray, &resultSize);
  printf("count1 %d", count);
  printf("resultSize1 %d", resultSize);

  NSMutableArray * rawData = [[NSMutableArray alloc] initWithCapacity: resultSize];
  for (int j = 0; j < resultSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithChar: resultArray[j]];
    [rawData addObject: intWrapped];
  }
  
  NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys: [NSNumber numberWithInt:resultSize], @"size", rawData, @"data", nil];

  resolve(finalDictionary);
}

RCT_EXPORT_METHOD(bmp2Hex:(NSArray *)data encodeWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("count %d", count);
  char charArray[5120];
  int cArray[5120];
  char resultArray[5120];
  int resultSize = count;
  printf("count %d\n", count);
  printf("resultSize %d\n", resultSize);
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  bitmap_to_hex(charArray, count, resultArray, &resultSize);

  printf("count %d\n", count);
  printf("resultSize %d\n", resultSize);

  NSMutableArray * rawData = [[NSMutableArray alloc] init];

  for (int j = 0; j < resultSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithInt: resultArray[j]];
    [rawData addObject: intWrapped];
  }

//  NSMutableDictionary *finalDictionary = [NSMutableDictionary dictionary];
//  [finalDictionary setValue: [NSNumber numberWithInt:resultSize] forKey:@"size"];
//  [finalDictionary setValue: rawData forKey:@"data"];
  NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys: [NSNumber numberWithInt:resultSize], @"size", rawData, @"data", nil];

  resolve(finalDictionary);
}

RCT_EXPORT_METHOD(bmp2WT30XHex:(NSArray *)data encodeWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("count %d", count);
  char charArray[10240];
  int cArray[10240];
  char resultArray[10240];
  int resultSize = count;
  printf("count %d\n", count);
  printf("resultSize %d\n", resultSize);
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  bitmap_to_hex_wt30x(charArray, count, resultArray, &resultSize);

  printf("count %d\n", count);
  printf("resultSize %d\n", resultSize);

  NSMutableArray * rawData = [[NSMutableArray alloc] init];

  for (int j = 0; j < resultSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithInt: resultArray[j]];
    [rawData addObject: intWrapped];
  }

  NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys: [NSNumber numberWithInt:resultSize], @"size", rawData, @"data", nil];

  resolve(finalDictionary);
}

RCT_EXPORT_METHOD(getHistoryData:(NSArray *)data deviceModel: (NSString *)model deviceFirmware: (NSString *)firmware deviceHardware: (NSString *)hardware getHistoryDataWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[count];
  int cArray[count];
  const char * cModel = [model UTF8String];
  const char * cFirmware = [firmware UTF8String];
  const char * cHardware = [hardware UTF8String];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  char *cjsonStr = get_histroy_data_json(charArray, count, cModel, cFirmware, cHardware);
  
  if(cjsonStr == NULL) {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:-1 userInfo:@{NSLocalizedDescriptionKey:@"cjson error"}];
    reject(@"get history data", @"cjson is null", error);
    return;
  }
  
  NSString *jsonStr = [NSString stringWithUTF8String:cjsonStr];
  
  if (data) {
    resolve(jsonStr);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"getHistoryData error"}];
    reject(@"get history data", @"There were no json", error);
  }
}

/**
 * 获取卡模式数据
 */
RCT_EXPORT_METHOD(getCardInfo:(NSArray *)data getCardInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int cardDataCount = [data count];
  char cardData[cardDataCount];
  struct card_header_s cardHeader;
  uint8_t outputData[4096];
  int outputDataSize = 4096;
   
  for (int i = 0; i < cardDataCount; ++i) {
    cardData[i] = (char)[[data objectAtIndex:i] intValue] & 0xFF;
  }
  
  int dataSize = app_card_read(&cardHeader, cardData, cardDataCount, outputData, outputDataSize);
  char *cDeviceInfoJson = get_flash_base_info(outputData, dataSize);
  
  NSMutableArray * outputCardData = [[NSMutableArray alloc] initWithCapacity: dataSize];
  for (int j = 0; j < dataSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithInt: outputData[j]];
    [outputCardData addObject: intWrapped];
  }
  NSString *deviceInfoJson = [NSString stringWithUTF8String:cDeviceInfoJson];
  NSNumber *keyMode = [NSNumber numberWithInt:cardHeader.info.Fields.key_mode];
  NSNumber *cardVersion = [NSNumber numberWithInt:cardHeader.info.Fields.version];
  NSNumber *cardStatus = [NSNumber numberWithInt:cardHeader.info.Fields.ntag_status];
  NSDictionary *resultDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:
    keyMode, @"keyMode",
    cardVersion, @"cardVersion",
    cardStatus, @"cardStatus",
    deviceInfoJson, @"deviceInfo",
    outputCardData, @"cardData",
    nil
  ];
  
  resolve(resultDictionary);
}

/**
 * 设置卡模式数据
 */
RCT_EXPORT_METHOD(setCardInfo:
                  (NSArray *)data
                  withJSON:(NSString *)setting
                  withCardHeader: (NSDictionary *)settingCardHeader
                  setCardInfoWithResolver: (RCTPromiseResolveBlock)resolve
                  rejecter: (RCTPromiseRejectBlock)reject
) {
  int dataCount = [data count];
  char cardData[dataCount];
  const char *settingJson = [setting UTF8String];
  struct card_header_s cardHeader;
  int outputDataSize = 4096;
  uint8_t outputData[outputDataSize];

  NSNumber *keyMode = [RCTConvert NSNumber:settingCardHeader[@"keyMode"]];
  NSNumber *cardVersion = [RCTConvert NSNumber:settingCardHeader[@"cardVersion"]];
  NSNumber *cardStatus = [RCTConvert NSNumber:settingCardHeader[@"cardStatus"]];
  
  unsigned char charCardVersion = [cardVersion unsignedCharValue];
  unsigned char charKeyMode = [keyMode unsignedCharValue];
  unsigned char charCardStatus =[cardStatus unsignedCharValue];
  
  cardHeader.info.Fields.version = charCardVersion;
  cardHeader.info.Fields.key_mode = charKeyMode;
  cardHeader.info.Fields.ntag_status = charCardStatus;
   
  for (int i = 0; i < dataCount; ++i) {
    cardData[i] = (char)[[data objectAtIndex:i] intValue] & 0xFF;
  }
  
  char *setFlashInfoResult = set_flash_base_info(cardData, settingJson);
  NSString *resultJsonStr = [NSString stringWithUTF8String: setFlashInfoResult];
  NSError *error = nil;
  id setResultJsonObject = [NSJSONSerialization JSONObjectWithData: [resultJsonStr dataUsingEncoding:NSUTF8StringEncoding] options: NSJSONReadingAllowFragments
      error: &error
  ];
  NSDictionary *setResultDict = (NSDictionary *)setResultJsonObject;
  
  int setDataSize = [[setResultDict objectForKey:@"datasize"] intValue];
  int writeCardDataSize = app_card_write(&cardHeader, cardData, setDataSize, outputData, outputDataSize);
  
  NSMutableArray *encodeData = [[NSMutableArray alloc] initWithCapacity: writeCardDataSize];
  for (int j = 0; j < writeCardDataSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithInt: (int)outputData[j]];
    [encodeData addObject: intWrapped];
  }
    
  NSDictionary *resultDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:
      [setResultJsonObject objectForKey:@"code"], @"code",
      encodeData, @"encodeData",
      resultJsonStr, @"result",
      nil
  ];
    
  resolve(resultDictionary);
}

/**
 * 读取模板
 */
RCT_EXPORT_METHOD(getDs3604Template:(NSArray *)data getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[count];
  int cArray[count];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  char *cjsonStr = get_ds3604_template(charArray, count);
  NSString *jsonStr = [NSString stringWithUTF8String:cjsonStr];
  
  if (data) {
    resolve(jsonStr);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"getDs3604Template error"}];;
    reject(@"get ds3604 template", @"There were no json", error);
  }
}

/**
 * 写入模板
 */
RCT_EXPORT_METHOD(setDs3604Template:(NSArray *)data withJSON:(NSString *)jsonStr getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char *charArray = (char *)malloc(count * sizeof(char));
  int *cArray = (int *)malloc(count * sizeof(int));
  const char * cJsonStr =[jsonStr UTF8String];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  char *cResultjsonStr = set_ds3604_template(charArray, cJsonStr);
  NSString *resultJsonStr = [NSString stringWithUTF8String:cResultjsonStr];
  NSError *error = nil;
  id jsonObject = [NSJSONSerialization
                       JSONObjectWithData:[resultJsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:&error];
  NSDictionary *deserializedDict = (NSDictionary *)jsonObject;
  NSLog(@"setDs3604Template Deserialized JSON Dictionary = %@", deserializedDict);
  NSString *successCode = @"1";
  if([deserializedDict objectForKey:@"code"]) {
    NSMutableArray * rawData = [[NSMutableArray alloc] initWithCapacity: count];
    for (int j = 0; j < count; j++) {
      NSNumber * intWrapped = [NSNumber numberWithInt: (int)charArray[j]];
      [rawData addObject: intWrapped];
    }
    
    NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:
    [deserializedDict objectForKey:@"code"], @"code", rawData, @"rawData", resultJsonStr,@"result",nil];
    
    resolve(finalDictionary);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"set_ds3604_template error"}];;
    reject(@"set_ds3604_template", @"There were no json", error);
  }
}

RCT_EXPORT_METHOD(getDS3604Picture:(NSArray *)data resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[30720];
  int cArray[30720];
  char resultArray[30720];
  
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  uint16_t resultSize = get_ds3604_picture(charArray, resultArray);
  printf("resultSize %d\n", resultSize);

  NSMutableArray *rawData = [[NSMutableArray alloc] init];

  for (int j = 0; j < resultSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithUnsignedChar: resultArray[j]];
    [rawData addObject: intWrapped];
  }

  resolve(rawData);
}

RCT_EXPORT_METHOD(setDS3604Picture:(NSArray *)data resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[30720];
  int cArray[30720];
  char resultArray[30720];
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  uint16_t resultSize = set_ds3604_picture(charArray, resultArray);
  printf("resultSize %d\n", resultSize);

  NSMutableArray *rawData = [[NSMutableArray alloc] init];

  for (int j = 0; j < resultSize; j++) {
    NSNumber * intWrapped = [NSNumber numberWithUnsignedChar: resultArray[j]];
    [rawData addObject: intWrapped];
  }

  resolve(rawData);
}

/**
 * 读取SDI
 */
RCT_EXPORT_METHOD(getSdiInfo:(NSArray *)data getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[count];
  int cArray[count];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  char *cjsonStr = get_sdi_base_info(charArray, count);
  NSString *jsonStr = [NSString stringWithUTF8String:cjsonStr];
  printf("cjsonStr %s", cjsonStr);
  if (data) {
    resolve(jsonStr);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"getSdiBaseInfo error"}];;
    reject(@"get_sdi_base_info", @"There were no json", error);
  }
}

/**
 * 读取SDI
 */
RCT_EXPORT_METHOD(setSdiInfo:(NSArray *)data withJSON:(NSString *)jsonStr getFlashInfoWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("setSdiBaseInfo count %d\n", count);
  char charArray[count];
  int cArray[count];
  const char * cJsonStr =[jsonStr UTF8String];
  printf("cJsonStr %s", cJsonStr); 
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }
//  char *charArray = [self getCharArr:data withCount:count];
//  RCTLog(@"data %@", data);
//  RCTLog(@"data %@", data);
  char *cResultjsonStr = set_sdi_base_info(charArray, cJsonStr);
  NSString *resultJsonStr = [NSString stringWithUTF8String:cResultjsonStr];
  NSError *error = nil;
  id jsonObject = [NSJSONSerialization
                       JSONObjectWithData:[resultJsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:&error];
  NSDictionary *deserializedDict = (NSDictionary *)jsonObject;
  NSLog(@"setSdiBaseInfo Deserialized JSON Dictionary = %@", deserializedDict);
  NSString *successCode = @"1";
  if([deserializedDict objectForKey:@"code"]) {
    NSMutableArray * rawData = [[NSMutableArray alloc] initWithCapacity: count];
    for (int j = 0; j < count; j++) {
      NSNumber * intWrapped = [NSNumber numberWithInt: (int)charArray[j]];
      [rawData addObject: intWrapped];
    }
    
    NSDictionary *finalDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:
    [deserializedDict objectForKey:@"code"], @"code", rawData, @"rawData", resultJsonStr,@"result",nil];
    
    resolve(finalDictionary);
  } else {
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:666 userInfo:@{NSLocalizedDescriptionKey:@"set_sdi_base_info error"}];;
    reject(@"set sdi base info", @"There were no json", error);
  }
}


RCT_EXPORT_METHOD(getCrc32:(NSArray *)data resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  printf("crc32 DATA count %d\n", count);
  char charArray[count];
  int cArray[count];
   
  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  uint32_t crc32Value = my_ether_crc32(0, (uint8_t *)charArray, count);

  printf("CRC32 Result (signed): %d\n", (int32_t)crc32Value);

  // 创建一个有符号整数的 NSNumber 对象
  NSNumber *signedResult = [NSNumber numberWithInt:(int32_t)crc32Value];

  // 打印 NSNumber 对象
  NSLog(@"CRC32 Result (NSNumber, signed) = %@", signedResult);

  resolve(signedResult);
}

/**
 * 解密升级镜像文件
 */
RCT_EXPORT_METHOD(decrypUpgradeData:(NSString *)base64EncodedString
                  decrypUpgradeDataWithResolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
  // 1. 解码 Base64 字符串为二进制数据
  NSData *data = [[NSData alloc] initWithBase64EncodedString:base64EncodedString options:0];
  if (!data) {
    reject(@"error", @"Invalid Base64 string", nil);
    return;
  }

  // 2. 分配内存并复制二进制数据到一个新的 buffer 中
  int size = (int)[data length];
  char *buffer = malloc(size);
  if (buffer == NULL) {
    reject(@"error", @"Memory allocation failed", nil);
    return;
  }
  memcpy(buffer, [data bytes], size);

  // 3. 对数据进行解密
  char decryptionSuccess = aes_decryp(buffer, size);
  
  if (decryptionSuccess == "0") {
    free(buffer);
    reject(@"decryption_error", @"data size empty", nil);
    return;
  }

  // 4. 创建一个新的 NSData 对象来包含解密后的数据
  NSData *decryptedData = [NSData dataWithBytesNoCopy:buffer length:size freeWhenDone:YES];

  // 5. 将解密后的数据重新编码为 Base64 字符串
  NSString *base64DecryptedString = [decryptedData base64EncodedStringWithOptions:0];

  // 6. 返回 Base64 编码的解密数据
  resolve(base64DecryptedString);
}

/**
 * 获取设备产品信息
 */
RCT_EXPORT_METHOD(getProductInfo:(NSArray *)data resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[count];
  int cArray[count];
  printf("getProductInfo count %d\n", count);

  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  char *cjsonStr = get_flash_product_info(charArray, count);
  NSString *result = [NSString stringWithUTF8String:cjsonStr];
  
  NSLog(@"getProductInfo result = %@", result);
  
  resolve(result);
}

/**
 * 获取D2d Recv Match信息
 */
RCT_EXPORT_METHOD(getD2DPairInfo:(NSArray *)data resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  int count = [data count];
  char charArray[count];
  int cArray[count];
  printf("getD2DPairInfo count %d\n", count);

  for (int i = 0; i < count; ++i) {
    cArray[i] = [[data objectAtIndex:i] intValue];
    charArray[i] = (char)cArray[i] & 0xFF;
  }

  char *cjsonStr = get_d2d_pairinfo(charArray, count);
  NSString *result = [NSString stringWithUTF8String:cjsonStr];
  
  NSLog(@"getD2DPairInfo result = %@", result);
  
  resolve(result);
}

@end
