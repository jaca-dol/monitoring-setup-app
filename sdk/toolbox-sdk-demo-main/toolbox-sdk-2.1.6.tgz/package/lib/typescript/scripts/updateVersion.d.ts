export {};
//# sourceMappingURL=updateVersion.d.ts.map