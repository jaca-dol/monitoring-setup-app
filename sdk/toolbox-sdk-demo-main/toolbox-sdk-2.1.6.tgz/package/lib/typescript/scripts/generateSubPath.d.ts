export {};
//# sourceMappingURL=generateSubPath.d.ts.map