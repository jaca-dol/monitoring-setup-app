#!/usr/bin/env node
export {};
//# sourceMappingURL=checkSpecificConfigExports.d.ts.map