export function generateTestData({ sourceFilePath }: {
    sourceFilePath: any;
}): Promise<any>;
//# sourceMappingURL=generateTestData.d.ts.map