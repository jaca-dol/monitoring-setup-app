export function findSn(deviceName: any): {};
export function findPn(deviceName: any): {};
export function formatePath(path: any): any;
export function generateHex(length: any): string;
export function getDeviceNameFromEnv(): string | undefined;
/**
 * 错误处理
 */
export function handleError(error: any): void;
export namespace CliPrefix {
    const inquirerPrefix: string;
    const donePrefix: string;
    const spinner: string;
    const successPrefix: string;
    const failedPrefix: string;
    const exitPrefix: string;
}
//# sourceMappingURL=common.d.ts.map