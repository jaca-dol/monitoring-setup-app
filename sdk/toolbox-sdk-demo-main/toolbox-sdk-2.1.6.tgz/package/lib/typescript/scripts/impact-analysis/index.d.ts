#!/usr/bin/env node
export function parseArgs(argv: any): {
    base: string;
};
export function getRepoRoot(): any;
export function buildImpactReport({ base, repoRoot }?: {
    base?: string | undefined;
    repoRoot?: any;
}): {
    ok: boolean;
    exitCode: number;
    report: any;
};
export function printImpactReport(result: any, { stdout, stderr }?: {
    stdout?: (NodeJS.WriteStream & {
        fd: 1;
    }) | undefined;
    stderr?: (NodeJS.WriteStream & {
        fd: 2;
    }) | undefined;
}): void;
export function runImpactAnalysis({ base, repoRoot, stdout, stderr }?: {
    base?: string | undefined;
    repoRoot?: any;
    stdout?: (NodeJS.WriteStream & {
        fd: 1;
    }) | undefined;
    stderr?: (NodeJS.WriteStream & {
        fd: 2;
    }) | undefined;
}): {
    ok: boolean;
    exitCode: number;
    report: any;
};
//# sourceMappingURL=index.d.ts.map