#!/usr/bin/env node
/**
 * 将变更文件解析为影响报告
 * @param {Array<{ relativePath: string, absolutePath: string, status: string }>} changedSdkFiles
 * @param {string | { repoRoot: string, sdkRootDir: string }} contextOrSdkRootDir
 * @returns {{ overallRisk: string, modules: Array, devices: { mustTest: string[], shouldTest: string[] } }}
 */
export function resolveImpact(changedSdkFiles: Array<{
    relativePath: string;
    absolutePath: string;
    status: string;
}>, contextOrSdkRootDir: string | {
    repoRoot: string;
    sdkRootDir: string;
}): {
    overallRisk: string;
    modules: any[];
    devices: {
        mustTest: string[];
        shouldTest: string[];
    };
};
/**
 * 从 model/config/specific/ 扫描所有已注册设备型号
 * @param {string} specificDir - 设备配置目录的绝对路径
 * @returns {Array<{ model: string, file: string }>}
 */
export function scanRegisteredDevices(specificDir: string): Array<{
    model: string;
    file: string;
}>;
/**
 * 对单个文件匹配 zone 规则
 * @param {string} relativePath - 相对于 toolbox-sdk 根目录的路径
 * @returns {{ zone: object, risk: string, category: string } | null}
 */
export function matchZone(relativePath: string): {
    zone: object;
    risk: string;
    category: string;
} | null;
export namespace SUBSYSTEM {
    const SDK: string;
    const MOBILE_DEVICE_SETTING: string;
}
export function buildModelCatalog(sdkRootDir: any): {
    status: string;
    notes: string[];
    sources: {
        specificCount: number;
        modelEnumCount: number;
        totalCount: number;
    };
    allDeviceModels: any[];
    specificModels: any[];
    normalizedModelMap: Map<any, any>;
    modelKeyValueMap: Map<any, any>;
};
export function parseModelsEnum(constantsPath: any): {
    values: any[];
    keyValueMap: Map<any, any>;
};
export function parseNewDeviceSettingFallbackRules(newDeviceSettingPath: any, modelCatalog: any): {
    status: string;
    notes: string[];
    generalFallbackModels: any;
    thresholdFallbackModels: any;
    thresholdRuntimeUncertainModels: never[];
} | {
    generalFallbackModels: any[];
    thresholdFallbackModels: any[];
    thresholdRuntimeUncertainModels: any[];
    status: string;
    notes: never[];
};
export function parseNfcKnownModels(nfcConfigPath: any, allDeviceModels: any, normalizedModelMap: any): {
    status: string;
    notes: string[];
    knownModels: any;
    uncertainModels: never[];
    caseCount: number;
} | {
    status: string;
    notes: never[];
    knownModels: any[];
    uncertainModels: any[];
    caseCount: number;
};
export function parseBleKnownModels(repoRoot: any, allDeviceModels: any, normalizedModelMap: any, specificModels: any): {
    status: string;
    notes: string[];
    knownModels: any[];
    knownCount: any;
    explicitBleFileCount: number;
};
//# sourceMappingURL=resolveDevices.d.ts.map