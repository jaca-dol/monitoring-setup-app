export const ZONES: ({
    pattern: string;
    category: string;
    risk: string;
    label: string;
    subsystem?: undefined;
} | {
    pattern: string;
    category: string;
    risk: string;
    label: string;
    subsystem: string;
})[];
export namespace RISK_LEVELS {
    const CRITICAL: number;
    const HIGH: number;
    const MEDIUM: number;
    const LOW: number;
    const INFO: number;
    const NONE: number;
}
export function getRiskWeight(risk: any): any;
export function compareRisk(a: any, b: any): number;
export function getMaxRisk(risks: any): any;
//# sourceMappingURL=zoneConfig.d.ts.map