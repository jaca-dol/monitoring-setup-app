/**
 * 标准提测版本分支:
 * - 形如 release/X.Y.Z
 * - 中间段 Y 仅允许 1-2 位
 *   例如: release/2.1.2, release/2.1.10
 *   非标准版: release/2.2417.0
 */
export const STANDARD_RELEASE_BRANCH_REGEX: RegExp;
export function isStandardReleaseBranchName(branchName: any): boolean;
//# sourceMappingURL=releaseBranchRule.d.ts.map