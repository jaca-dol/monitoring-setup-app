#!/usr/bin/env node
export function format(result: any): string;
export namespace SCOPE_LABELS {
    const CRITICAL: string;
    const HIGH: string;
    const MEDIUM: string;
    const LOW: string;
    const INFO: string;
    const NONE: string;
}
export namespace SUBSYSTEM_LABELS {
    const SDK: string;
    const MOBILE_DEVICE_SETTING: string;
}
//# sourceMappingURL=formatOutput.d.ts.map