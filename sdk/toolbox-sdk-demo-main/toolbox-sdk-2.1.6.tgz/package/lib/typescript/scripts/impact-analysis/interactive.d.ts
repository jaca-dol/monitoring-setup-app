#!/usr/bin/env node
export const MANUAL_BRANCH_VALUE: "__manual_release_branch__";
export const OUTPUT_FILE_NAME: "impact-report.md";
export function normalizeRemoteReleaseBranch(refName: any): string;
export function parseRemoteReleaseBranches(output: any): string[];
export function compareStandardReleaseBranchesDesc(left: any, right: any): number;
export function getStandardReleaseBranches(branches: any): any;
export function buildBranchChoices(standardBranches: any): {
    name: string;
    value: string;
}[];
export function validateReleaseBranchInput(input: any): true | "请输入要比较的 release 分支" | "分支名必须以 release/ 开头";
export function getCommandErrorMessage(error: any): string;
export function readOriginReleaseBranches(repoRoot: any, execFileSyncImpl?: any): string[];
export function fetchOriginBranch(branchName: any, repoRoot: any, execFileSyncImpl?: any): void;
export function writeImpactReportFile(reportPath: any, report: any, writeFileSyncImpl?: any): void;
export function createFailureReport(message: any): string;
export function promptForReleaseBranch({ standardBranches, prompt }: {
    standardBranches: any;
    prompt?: any;
}): Promise<any>;
export function runInteractiveImpactAnalysis({ repoRoot, prompt, execFileSyncImpl, writeFileSyncImpl, buildImpactReportImpl, stdout, stderr, }?: {
    repoRoot?: any;
    prompt?: any;
    execFileSyncImpl?: any;
    writeFileSyncImpl?: any;
    buildImpactReportImpl?: any;
    stdout?: (NodeJS.WriteStream & {
        fd: 1;
    }) | undefined;
    stderr?: (NodeJS.WriteStream & {
        fd: 2;
    }) | undefined;
}): Promise<any>;
//# sourceMappingURL=interactive.d.ts.map