#!/usr/bin/env node
/**
 * 构建依赖图
 * @param {string} srcDir - 源码目录
 * @returns {{ dependencies: Map<string, Set<string>>, dependents: Map<string, Set<string>> }}
 */
export function buildImportGraph(srcDir: string): {
    dependencies: Map<string, Set<string>>;
    dependents: Map<string, Set<string>>;
};
/**
 * 获取变更文件的传递闭包（所有直接和间接受影响的文件）
 * @param {string[]} changedFiles - 变更文件的绝对路径
 * @param {Map<string, Set<string>>} dependents - 反向依赖图
 * @returns {Set<string>}
 */
export function getTransitiveAffected(changedFiles: string[], dependents: Map<string, Set<string>>): Set<string>;
export function getAllTsFiles(dir: any, files?: any[]): any[];
//# sourceMappingURL=buildImportGraph.d.ts.map