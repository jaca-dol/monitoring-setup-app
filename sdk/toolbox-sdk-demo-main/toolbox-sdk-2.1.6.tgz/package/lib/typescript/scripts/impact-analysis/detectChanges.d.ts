#!/usr/bin/env node
/**
 * 获取当前分支相对于 base 分支的变更文件列表
 * @param {string} base - 基准分支，如 'origin/master'
 * @param {string} repoRoot - 仓库根目录
 * @returns {{ ok: boolean, files: Array<{ path: string, status: string }>, error?: string }}
 */
export function getChangedFiles(base?: string, repoRoot?: string): {
    ok: boolean;
    files: Array<{
        path: string;
        status: string;
    }>;
    error?: string;
};
/**
 * 过滤出影响分析核心文件
 * - src 下 .ts/.tsx
 * - src/service/ipso/resources 下 .json
 * - codec 下 .c/.h
 * - apps/mobile 设备设置链路下 .ts/.tsx/.js/.jsx
 */
export function filterImpactFiles(changedFiles: any, repoRoot: any): any;
export function filterSdkFiles(changedFiles: any, repoRoot: any): any;
/**
 * 解析 git diff --name-status 输出
 * @param {string} output
 * @returns {Array<{ path: string, status: string }>}
 */
export function parseDiffOutput(output: string): Array<{
    path: string;
    status: string;
}>;
export function isSrcCoreFile(p: any): boolean;
export function isCodecCoreFile(p: any): boolean;
export function isMobileDeviceSettingFile(p: any): boolean;
export function isIgnoredCoreFile(p: any): boolean;
/**
 * 影响分析中需要忽略的噪音文件
 * main_version.c 会在发版脚本里按时间戳自动更新，不代表业务逻辑变更
 * 参考: apps/mobile/scripts/utils/version.js
 */
export const IGNORED_CORE_FILES: Set<string>;
/**
 * 影响分析中需要忽略的噪音路径
 * src/model/tsl 下 TypeScript 文件由 generateTLSType 脚本生成，主要用于类型定义
 * 参考: packages/toolbox-sdk/scripts/commands/GenerateTypesCommand.js
 */
export const IGNORED_CORE_PATTERNS: RegExp[];
export const MOBILE_SETTING_INCLUDE_PATTERNS: RegExp[];
export const MOBILE_SETTING_EXCLUDE_PATTERNS: RegExp[];
export function isUnknownRevisionError(error: any): boolean;
export function parseOriginBranchName(base: any): any;
declare const path: any;
export {};
//# sourceMappingURL=detectChanges.d.ts.map