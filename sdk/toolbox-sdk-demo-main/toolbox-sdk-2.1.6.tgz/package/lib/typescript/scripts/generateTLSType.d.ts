export {};
//# sourceMappingURL=generateTLSType.d.ts.map