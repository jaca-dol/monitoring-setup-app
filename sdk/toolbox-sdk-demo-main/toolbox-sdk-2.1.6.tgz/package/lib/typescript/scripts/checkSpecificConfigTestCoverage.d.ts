#!/usr/bin/env node
export function analyzeSpecificConfigContent(filePath: any, content: any): any[];
export function analyzeTestContent(filePath: any, content: any): {
    filePath: any;
    serviceClasses: any[];
    coverageByService: Map<any, any>;
};
export function checkSpecificConfigTestCoverage(options?: {}): {
    services: any[];
    coverageByService: Map<any, any>;
    unsupportedReturns: any[];
    missingCoverage: any[];
    ok: boolean;
};
export function collectConfigTestCoverage(testConfigDir: any): Map<any, any>;
export function collectSpecificConfigServices(specificDir: any): any[];
export function formatFailure(result: any): string;
//# sourceMappingURL=checkSpecificConfigTestCoverage.d.ts.map