export = Spinner;
declare class Spinner {
    constructor(options: any);
    ora: any;
    done: boolean;
    start(): void;
    stop(): void;
    text(message: any): void;
    succeed(message: any): void;
    succeedWithFormat(prefix: any, message: any): void;
    fail(message: any): void;
    failWithFormat(message: any): void;
}
//# sourceMappingURL=Spinner.d.ts.map