export function error(...params: any[]): void;
export function e(...params: any[]): void;
export function log(...params: any[]): void;
export function l(...params: any[]): void;
export function warn(...params: any[]): void;
export function w(...params: any[]): void;
//# sourceMappingURL=Logger.d.ts.map