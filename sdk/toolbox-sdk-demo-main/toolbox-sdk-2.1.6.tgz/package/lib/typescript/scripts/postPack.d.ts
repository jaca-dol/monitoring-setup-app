export {};
//# sourceMappingURL=postPack.d.ts.map