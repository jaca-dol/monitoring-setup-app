export = CommandExecutor;
declare class CommandExecutor {
    constructor(context: any);
    context: any;
    commands: any[];
    addCommand(command: any): void;
    execute(): Promise<void>;
}
//# sourceMappingURL=CommandExecutor.d.ts.map