export = BaseCommand;
declare class BaseCommand {
    next: any;
    setNext(command: any): any;
    execute(context: any): Promise<void>;
    beforeExecute(context: any): Promise<void>;
    doExecute(context: any): Promise<void>;
    afterExecute(context: any): Promise<void>;
}
//# sourceMappingURL=BaseCommand.d.ts.map