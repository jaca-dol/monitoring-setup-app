export = GenerateTestDataCommand;
declare const GenerateTestDataCommand_base: any;
declare class GenerateTestDataCommand extends GenerateTestDataCommand_base {
    [x: string]: any;
    constructor(inputFilePath: any);
    inputFilePath: any;
    unionNames: Set<any>;
    tslConfig: any;
    setupOutputPath(): void;
    fileName: any;
    deviceName: any;
    interfaceNames: {} | undefined;
    deviceNames: {} | undefined;
    outputFileNames: {} | undefined;
    outputFilePaths: {} | undefined;
    updateTslConfig(deviceName: any): void;
    beforeExecute(context: any): Promise<void>;
    doExecute(): Promise<any>;
    generateMockData(sourceCode: any): {};
    generateObjectFromInterface(nodes: any, superName?: string, index?: number): {};
    generateValueForType(node: any, superName?: string): any;
    isNumberLiteralType(typeNode: any): any;
    getJSDocComment(node: any, sourceFile: any): string;
    getDefaultValue(commentText: any): any;
    getRandomString(length: any): string;
    getRandomInt(min: any, max: any): any;
    getRandomFloat(min: any, max: any, decimals?: number): number;
    generateTestDataFile(mockData: any, sn: any): Promise<string>;
    afterExecute(context: any): Promise<void>;
}
//# sourceMappingURL=GenerateTestDataCommand.d.ts.map