export const presets: string[];
export const plugins: (string | (string | {
    legacy: boolean;
})[] | (string | {
    loose: boolean;
})[])[];
//# sourceMappingURL=babel.config.d.ts.map