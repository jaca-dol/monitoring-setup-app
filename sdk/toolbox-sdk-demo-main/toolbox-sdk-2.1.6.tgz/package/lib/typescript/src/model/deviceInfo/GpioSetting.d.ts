export interface GpioSetting {
    gpio1: {
        enable: boolean;
        /**
         * 0：di、1：do、2：counter
         */
        type: number;
        /**
         * 0：pull down，1：pull up，2：none
         */
        diType: number;
        value: number;
        keepCountValue?: boolean;
        /**
         * 数字滤波
         */
        filter: boolean;
        /**
         * 滤波速率
         */
        filterSpeed: number;
        /**
         * 滤波速率单位 0：us，1：ms
         */
        filterUnit: number;
        /**
         * 计数值状态 0：停止 1：开始
         */
        counterState: 0 | 1;
    };
    gpio2: {
        enable: boolean;
        /**
         * 0：di、1：do、2：counter
         */
        type: number;
        /**
         * 0：pull down，1：pull up，2：none
         */
        diType: number;
        value: number;
        keepCountValue?: boolean;
        /**
         * 数字滤波
         */
        filter: boolean;
        /**
        * 滤波速率
        */
        filterSpeed: number;
        /**
         * 滤波速率单位 0：us，1：ms
         */
        filterUnit: number;
        /**
         * 计数值状态 0：停止 1：开始
         */
        counterState: 0 | 1;
    };
}
//# sourceMappingURL=GpioSetting.d.ts.map