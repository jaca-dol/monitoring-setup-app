import { FormattedStatus } from './StatusDeviceInfo';
/**
 * 状态页面支持的动作类型
 */
export type StatusActionType = 'button' | 'switch' | 'icon' | 'picker';
export type StatusActionIconType = 'copy' | 'refresh';
/**
 * 状态页面支持的动作构造器
 */
export interface StatusActionConstructor<T extends StatusActionType, M extends string, P extends any[], F> {
    /**
     * 动作类型
     */
    type: T;
    /**
        * 动作文案 key
        */
    text?: string;
    /**
     * 是否可见
     */
    visible?: boolean;
    /**
     * 图标名称
     */
    iconName?: StatusActionIconType;
    /**
     * 动作名称
     */
    method?: M;
    /**
     * 动作参数\
     * method需要提前绑定的参数\
     * 参数会被绑定在method函数的最后面
     */
    params?: P;
    /**
     * 自定义点击回调\
     * 动作优先级：method > onPress\
     * 为了方便后续的扩展和单元测试，建议使用method
     * @deprecated
     */
    onPress?: (value?: any) => void;
    /**
     * 函数类型\
     * 仅用于TS类型推导
     */
    funcType?: F;
}
/**
 * 状态页面支持的动作集合\
 * method相关的实现在useDeviceStatus.ts中\
 * onPress相关的实现在getDeviceStatusAction.ts中
 */
export interface StatusActionMap {
    /**
     * 清除累计雨量
     */
    clearAccumulatedRainfall: StatusActionConstructor<'button', 'clearAccumulatedRainfall', [], (e: any, status: FormattedStatus) => Promise<void>>;
    /**
     * 重置电量
     */
    resetPowerMeter: StatusActionConstructor<'button', 'resetPowerMeter', [check: boolean], (e: any, status: FormattedStatus) => Promise<void>>;
    /**
     * 同步时间
     */
    syncTime: StatusActionConstructor<'icon', 'syncTime', [], (e: any, status: FormattedStatus) => Promise<void>>;
    /**
     * 采集
     */
    collect: StatusActionConstructor<'button', 'collect', [], (e: any, status: FormattedStatus) => Promise<void>>;
    /**
     * 复制文本
     */
    handleCopyPress: StatusActionConstructor<'icon', 'handleCopyPress', [], (e: any, status: FormattedStatus) => void>;
    /**
     * 开关机(旧名称)
     */
    handlePowerSwitch: StatusActionConstructor<'switch', 'handlePowerSwitch', [], (value: boolean) => Promise<void>>;
    /**
     * 开关机
     */
    toggleDeviceState: StatusActionConstructor<'switch', 'toggleDeviceState', [], (value: boolean) => Promise<void>>;
    /**
     * 开关电磁阀
     */
    toggleValve: StatusActionConstructor<'switch', 'toggleValve', [valveIndex: 1 | 2], (value: boolean, valveIndex: 1 | 2) => Promise<void>>;
    /**
     * 脉冲计数清零
     */
    clearPulseCount: StatusActionConstructor<'button', 'clearPulseCount', [pulseIndex: 1 | 2], (e: any, pulseIndex: 1 | 2) => Promise<void>>;
    /**
     * 脉冲计数开始、结束
     */
    setPlusCount: StatusActionConstructor<'button', 'setPlusCount', [pulseIndex: 0 | 1 | 2], (e: any, pulseIndex: 0 | 1 | 2) => Promise<void>>;
    /**
     * 事件：控制设备 0 - 中止蜂鸣器响
     */
    controlDevice: StatusActionConstructor<'button', 'controlDevice', [index: number], (e: any, index: number) => Promise<void>>;
    /**
     * 事件：清空人流量计数
     */
    resetPeopleCount: StatusActionConstructor<'button', 'resetPeopleCount', [type: 2 | 3], (e: any, type: 2 | 3) => Promise<void>>;
    /**
     * 修改阀门开度
     */
    changeValveState: StatusActionConstructor<'button', 'changeValveState', [valveIndex: 1 | 2, valveStateType?: 0 | 1], (e: any, valveIndex: 1 | 2, valveStateType?: 0 | 1) => Promise<void>>;
}
/**
 * 状态页面支持的动作
 */
export type StatusAction = {
    [K in keyof StatusActionMap]: Omit<StatusActionMap[K], 'funcType'> & {
        type: StatusActionMap[K]['type'];
        params?: StatusActionMap[K]['params'];
    };
}[keyof StatusActionMap];
/**
 * 容器动作方法名称
 */
export type ContainerActionMethod = 'viewCTH01Details';
/**
 * 只描述卡片层的交互press | longPress
 */
export interface ContainerAction {
    /**
     * type: press | longPress
     */
    type?: 'press' | 'longPress';
    /**
     * method
     */
    method: ContainerActionMethod;
    /**
     * params
     * 参数会被绑定在method函数的最后面
     */
    params?: any[];
    /**
     * 防抖
       * 默认120ms
     */
    debounceMs?: number;
}
//# sourceMappingURL=StatusAction.d.ts.map