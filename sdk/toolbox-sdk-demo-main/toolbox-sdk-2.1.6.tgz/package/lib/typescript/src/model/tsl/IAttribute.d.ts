import type { Status } from '../deviceInfo/StatusDeviceInfo';
import { AttributeDefinition } from './AttributeDefinition';
/**
 * 属性值
 */
type AttributeValue = any;
/**
 * 将属性值转换到状态值的结果
 */
export type NormalizeDataStatusResult = (Status & {
    order: number;
}) | undefined;
/**
 * 将属性值转换到历史数据的结果
 */
export type NormalizeDataHistoryResult = Record<string, any> | undefined;
/**
 * 模型属性类
 */
export interface IAttribute<Value = AttributeValue> {
    /**
     * 属性key
     */
    key: string;
    /**
     * 属性值
     */
    value: Value;
    /**
     * 对应数据的路径
     */
    path: string;
    /**
     * 定义
     */
    definition: AttributeDefinition<Value>;
    /**
     * 获取默认属性值
     */
    getDefaultValue(): Value;
    /**
     * 将数据值转换成属性值(data[path] -> value)
     * @param value - 数据值
     * @param data - 所有的data数据
     */
    normalizeValue(value: any, data: any, context: Record<string, any>): Value;
    /**
     * 将属性值转换为数据值（value -> data[path])
     * @param value - 属性值
     * @param data - 所有的data数据
     */
    normalizeDataValue(value: Value, data: any, context: Record<string, any>): any;
    /**
     * 将属性值转换到数据的状态值(value -> data.status[x])
     * @param value - 属性值
     * @param data - 所有data数据
     */
    normalizeDataStatus(value: Value, data: any): NormalizeDataStatusResult;
    /**
     * 将属性值转换到数据的历史值(value -> data.history[x])
     * @param value - 属性值
     * @param data - 所有data数据
     * @returns 返回的对象将会被合并到data.history中
     */
    normalizeDataHistory(value: Value, data: any): NormalizeDataHistoryResult;
}
/**
 * 属性构造器
 */
export type AttributeConstructor = new (definition: AttributeDefinition) => IAttribute;
export {};
//# sourceMappingURL=IAttribute.d.ts.map