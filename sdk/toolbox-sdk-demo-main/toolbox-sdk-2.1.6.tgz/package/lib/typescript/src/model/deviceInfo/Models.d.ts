import { MODELS, MODEL_SERIES } from '../constants';
/**
 * 设备型号或者设备系列
 */
export type Models = keyof typeof MODELS | keyof typeof MODEL_SERIES;
//# sourceMappingURL=Models.d.ts.map