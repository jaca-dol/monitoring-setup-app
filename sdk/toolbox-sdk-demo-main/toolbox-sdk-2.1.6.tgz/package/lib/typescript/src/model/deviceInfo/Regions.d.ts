export declare enum RegionType {
    DESK_OCCUPANCY = "DESK_OCCUPANCY",
    PEOPLE_COUNTING = "PEOPLE_COUNTING"
}
//# sourceMappingURL=Regions.d.ts.map