import _ from 'lodash';
/**
 * SN前缀 -> 型号前缀的映射
 */
export declare const SnModelMap: {
    [sn: string]: string | undefined;
};
/**
 * PN -> Model/MODEL_SERIES的映射
 */
export declare const PnModelMap: {
    [model: string]: {
        [pn: string]: string;
    };
};
/**
 * 型号前缀/具体型号 -> SN前缀的映射
 * @example
 * {
 *	"EM300": "6136",
 *	"EM500": "6126",
 *	'EM300-TH': '6136',
 *	'EM300-WL': '6136',
 *	'EM500-SWL-L003': '6126',
 * }
 */
export declare const ModelSnMap: {
    [key: string]: string;
};
/**
* 型号前缀 -> SN前缀的映射
* 用于处理相同model拥有不同的sn前缀和pn后缀的情况
* @example
* {
*	"EM300": "6136",
*	'EM400': '6329',
*	"EM500": "6126",
*	"WS52X": "6148"
* }
*/
export declare const ModelPrefixSnMap: {
    [key: string]: string;
};
/**
 * 具体型号 -> PN的映射
 * @example
 * {
 *	'EM300-TH': '100',
 *	'EM300-WL': '200',
 *	'WS525-10A-CN': '105',
 * }
 */
export declare const ModelPnMap: {
    [key: string]: string;
};
/**
 * 具体型号 -> 型号前缀的映射
 * @example
 * {
 *	'EM300-TH': 'EM300',
 *	'EM300-WL': 'EM300',
 *	'WS525-10A-CN': 'WS52X',
 *	'EM400-UDL-C050': 'EM400',
 *	'EM400_TLD_N03GL': 'EM400_NB'
 * }
 */
export declare const ModelPrefixMap: {
    [key: string]: string;
};
/**
 * 获取型号前缀/具体型号 -> SN前缀的映射
 * @param snModelMap - SN前缀 -> 型号的映射
 * @param pnModelMap - PN -> 型号的映射
 * @returns
 */
export declare function getModelSnMap(snModelMap: typeof SnModelMap, pnModelMap: typeof PnModelMap): {
    [key: string]: string;
};
/**
 * 获取具体型号 -> SN前缀的映射
 * @param snModelMap - SN前缀 -> 型号的映射
 * @returns
 */
export declare function getModelPrefixSnMap(snModelMap: typeof SnModelMap): {
    [key: string]: string;
};
/**
 * 获取具体型号 -> PN的映射
 * @param pnModelMap - PN -> 型号的映射
 * @returns
 */
export declare function getModelPnMap(pnModelMap: typeof PnModelMap): {
    [key: string]: string;
};
/**
 * 获取具体型号 -> 型号前缀的映射
 * @param pnModelMap - PN -> 型号的映射
 * @returns
 */
export declare function getModelPrefixMap(pnModelMap: typeof PnModelMap): {
    [key: string]: string;
};
/**
 * 获取设备型号
 * @param sn - 设备sn
 * @param model - 设备model（设备传过来的model带有频段）
 * @param pn - 设备pn
 * @param subModel - 设备型号频段
 * @returns - 设备型号(无频段)
 */
export declare function getDeviceModel(sn?: string, model?: string, pn?: string, subModel?: string): string | undefined;
/**
 * 仅根据前四位判断设备类型, 不校验SN完整性
 * @param sn
 */
export declare function getMainModelBySnPrefix(sn: string): string | undefined;
/**
 * 通过sn获取设备型号, 如果sn不符合规则返回undefined
 * @param sn
 * @param swallowError
 */
export declare function getModelBySN(sn: string, swallowError?: false): string;
export declare function getModelBySN(sn: string, swallowError: true): string | undefined;
/**
 * 获取设备型号系列
 * @param {string} model - 设备型号
 */
export declare const getModelSeries: ((model: any) => string) & _.MemoizedFunction;
/**
 * 传感器设备是否为中性版本
 * @param oem - 设备oem
 */
export declare const getDeviceIsNeutral: (oem?: string) => boolean;
/**
 * 获取设备分组的中性
 */
export declare const getNeutralDeviceModelGroup: (group: string, _oem?: string) => string;
/**
* 获取设备的中性型号
*/
export declare const getNeutralDeviceModel: (model: string, _oem?: string) => string;
/**
 * 判断型号或子型号是否包含频段信息
 * @param modelOrSubModel
 */
export declare const getIsIncludesFrequencyBand: (modelOrSubModel: string) => boolean;
//# sourceMappingURL=model.d.ts.map