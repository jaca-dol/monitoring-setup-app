import { IDeviceConfigService } from "./IDeviceConfigService";
import { Models } from "../";
/**
 * 设备配置服务管理器
 */
export declare class DeviceConfigManager {
    /**
     * 安全获取设备设置服务的实例
     * @param serviceName - 服务名称
     * @returns - 设备设置服务的实例 | undefined
     */
    private static getServiceSafely;
    /**
     * 获取设备设置服务的实例
     * @param model - 设备型号
     * @returns - 设备设置服务的实例 | undefined
     */
    static getDeviceConfigService(model: string): IDeviceConfigService | undefined;
    /**
     * 注册设备设置服务
     * @param models - 设备型号/系列
     * @returns - 设备设置服务的装饰器
     */
    static register(models: Models): ClassDecorator;
}
//# sourceMappingURL=DeviceConfigManager.d.ts.map