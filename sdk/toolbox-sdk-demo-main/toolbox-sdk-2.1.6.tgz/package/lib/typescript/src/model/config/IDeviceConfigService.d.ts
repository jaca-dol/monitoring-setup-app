import { DeviceInfo } from "../deviceInfo/DeviceInfo";
export interface ClassTypeOption {
    /**
     * 选项标签
     */
    label: 'ClassA' | 'ClassB' | 'ClassC' | 'ClassC to B';
    /**
     * 选项值
     * @example ClassA: 0, ClassB: 1, ClassC: 2, ClassC to B: 3
     */
    value: 0 | 1 | 2 | 3;
}
/**
 * 设备配置映射
 */
export interface SupportSettingMap {
    [key: string]: {
        supportModelSeries?: string[];
        supportModels?: string[];
        isSupport?: (model: string, modelSeries: string, deviceInfo: DeviceInfo) => boolean;
    };
}
export interface IDeviceConfigService {
    /**
     * 获取设备支持的配置映射
     */
    getSupportSettingMap(): SupportSettingMap | undefined;
    /**
     * 获取设备支持的ClassType选项
     */
    getClassTypeOptions?(): ClassTypeOption[] | undefined;
}
export declare abstract class BasicDeviceConfigService implements IDeviceConfigService {
    /**
     * 获取设备支持的配置映射
     */
    getSupportSettingMap(): SupportSettingMap | undefined;
    /**
     * 获取ClassType选项
     */
    getClassTypeOptions(): ClassTypeOption[] | undefined;
}
//# sourceMappingURL=IDeviceConfigService.d.ts.map