/**
 * D2D按键类型
 */
export interface D2DKey {
    id: number;
    /**
     * 是否启用
     */
    enable: boolean;
    labelTips?: string;
    /**
     * 控制命令(10进制)
     */
    command: number | string;
    /**
     * 触发按键类型
     * 0：短按、1：双击、2：长按
     */
    type?: 0 | 1 | 2;
    /**
     * 启用上行
     */
    enableUplink?: boolean;
    /**
     * 时间控制
     */
    enableCtrlTime?: boolean;
    /**
     * 控制时间
     */
    ctrlTime?: number;
    /**
     * 启用按键状态
     */
    enableStatus?: boolean;
    /**
     * 校验当前key是否开启
     * @param index
     * @param value
     * @returns
     */
    onKeyEnable?: (index: string, value: boolean) => {
        /**
         * 校验当前key项中的switch是否可以点击，（true：校验通过，false：校验未通过）
         */
        valid: boolean;
        /**
         * 当前key项中的switch值
         */
        nextValue: boolean;
    };
}
/**
 * D2D 主控设备的按键命令配置
 */
export type KeyD2D = D2DKey[];
//# sourceMappingURL=KeyD2D.d.ts.map