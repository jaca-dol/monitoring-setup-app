import { DeviceInfo } from '../deviceInfo/DeviceInfo';
import { DataModel } from './DataModel';
import { ModelData, TSLInfo, IAttribute, AttributeDefinition, TSLInfoKeys } from '../tsl';
export declare class TSLDataModel<Data extends ModelData = TSLInfo> extends DataModel<Data> {
    get<T = any>(name: TSLInfoKeys): T;
    fromDeviceInfo(deviceInfo: Partial<DeviceInfo>): void;
    /**
     * 获取已有注册的全局属性实例
     * @param key - 属性key
     */
    getGlobalAttribute({ key, path, direction, group }: {
        key?: string;
        path?: string;
        direction?: AttributeDefinition['direction'];
        group?: string | string[];
    }): IAttribute | undefined;
    protected getAttribute(key: string, direction: "up" | "down" | "both" | undefined, group: string | string[]): IAttribute | undefined;
}
//# sourceMappingURL=TSLDataModel.d.ts.map