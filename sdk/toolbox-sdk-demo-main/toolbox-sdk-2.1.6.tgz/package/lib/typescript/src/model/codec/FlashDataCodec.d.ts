import { FlashInfo } from '../deviceInfo/DeviceInfo';
import { DeviceData } from '../tsl';
import { IDeviceUtils } from '../DeviceUtils';
import { IDeviceDataCodec } from './types';
export declare class FlashDataCodec implements IDeviceDataCodec<FlashInfo> {
    type: "flash";
    codec: IDeviceUtils;
    constructor(codec: IDeviceUtils);
    getInfo(data: DeviceData): Promise<FlashInfo>;
    setInfo(settingData: any, deviceData: number[]): ReturnType<IDeviceDataCodec['setInfo']>;
    getHistoryInfo(data: DeviceData, model: string, firmwareVersion: string, hardwareVersion: string): Promise<{
        [key: string]: any;
        timestamp: number;
    }[]>;
}
//# sourceMappingURL=FlashDataCodec.d.ts.map