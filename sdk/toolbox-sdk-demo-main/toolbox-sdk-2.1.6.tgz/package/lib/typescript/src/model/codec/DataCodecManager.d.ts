import { IDeviceDataCodec, IDeviceDataCodecManager } from './types';
import { FlashDataCodec } from './FlashDataCodec';
import { IPSODataCodec } from './IPSODataCodec';
export interface DataCodecTypeMap {
    'flash': InstanceType<typeof FlashDataCodec>;
    'ipso': InstanceType<typeof IPSODataCodec>;
}
export declare class DeviceDataCodecManager implements IDeviceDataCodecManager {
    codecs: Map<string, IDeviceDataCodec<any>>;
    constructor();
    register<T>(name: IDeviceDataCodec['type'], codec: IDeviceDataCodec<T>): void;
    get<K extends IDeviceDataCodec['type']>(name: K): DataCodecTypeMap[K];
}
export declare const DataCodecManager: DeviceDataCodecManager;
//# sourceMappingURL=DataCodecManager.d.ts.map