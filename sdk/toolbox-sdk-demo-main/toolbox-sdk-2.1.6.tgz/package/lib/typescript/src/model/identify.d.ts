import _ from 'lodash';
import { MODEL_SERIES, MODELS } from './constants';
type DeviceModelPattern = string | RegExp;
/**
 * 根据sn和型号规则判断是否为同型号设备
 * @param sn 设备sn或设备型号
 * @param pattern 设备型号规则
 */
export declare function identifyByModelPattern(snOrModel: string, pattern: DeviceModelPattern | DeviceModelPattern[]): boolean;
/**
 * 鉴别设备类型函数
 */
export declare function identify(sn: string): ModelIdentifier;
export declare function identify(model: MODELS): ModelIdentifier;
/**
 * 记忆函数的identify
 */
export declare const memoIdentify: typeof identify & _.MemoizedFunction;
/**
 * 鉴别设备类型集合
 */
export declare const Identify: {
    /**
    * 是否为AM设备
    * @param sn
    */
    isAMDevice(snOrModel: string): boolean;
    /**
     * 是否为EM设备
     */
    isEMDevice(snOrModel: string): boolean;
    /**
    * 是否为NB设备
    */
    isNBDevice(snOrModel: string): boolean;
    /**
     * 是否为LoRa设备
     */
    isLoRaDevice(snOrModel: string): boolean;
    /**
    * 是否为UC50X
    */
    isUC50X(snOrModel: string): boolean;
    /**
    * 是否为UC50XNB
    */
    isUC50XNB(snOrModel: string): boolean;
    /**
     * 是否为UC50Xv2
     */
    isUC50Xv2(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为UC50Xv3
     */
    isUC50Xv3(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为UC51Xv4
     */
    isUC51Xv4(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为WTS气象站v2硬件及v1.2固件
     */
    isWTSv2(snOrModel: string, hardwareVersion: string, firmwareVersion: string): boolean;
    /**
     * 是否为WTS气象站v3硬件
     */
    isWTSv3(snOrModel: string, hardwareVersion: string, firmwareVersion: string): boolean;
    /**
     * 是否为TS30X
     */
    isTS30X(snOrModel: string): boolean;
    /**
     * 是否为TS60X美国版本（L0FNA）
     */
    isTS60XUSVersion(snOrModel: string): boolean;
    /**
     * 是否为TS601系列（包含L0DEU、L0FNA、L0DLA）
     */
    isTS601Model(snOrModel: string): boolean;
    /**
     * 是否为TS602系列（包含L0DEU、L0FNA、L0DLA）
     */
    isTS602Model(snOrModel: string): boolean;
    /**
     * 是否为TS602系列且传感器类型为SHT41（sensorType === 2）
     */
    isTS602SHT41(snOrModel: string, sensorType?: number | null): boolean;
    /**
     * 是否为EM41X
     */
    isEM41X(snOrModel: string): boolean;
    /**
     * 是否为WS50X EU/US 固件0102迭代
     */
    isWS50XEUUSV0102(snOrModel: string, firmwareVersion: string): boolean;
    /**
     * 是否为WS50X机械式
     */
    isWS50XMECH(snOrModel: string): boolean;
    isWS50XCN(model: string): boolean;
    /**
     * 是否为WS50X触控式V2及以上
     */
    isWS50XTouchV2(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为WS558v2版本
     */
    isWS558v2(sn: string): boolean;
    /**
     * 是否为AM3XXv2
     */
    isAM3XXv2(snOrModel: string, hardwareVersion: string): boolean;
    isAM319Model(snOrModel: string): boolean;
    /**
     * 是否为AM307/AM319.0000.0200.0104&AM308.0000.0200.0106迭代
     */
    isAMModelSeriesV0104(snOrModel: string, firmwareVersion: string, hardwareVersion: string): boolean | undefined;
    /**
     * 是否为EM5XXv2
     */
    isEM5XXv2(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为EM500_0200_0107迭代
     * */
    isEM500_0200_0107(snOrModel: string, hardwareVersion: string, firmwareVersion: string): boolean;
    /**
     * 是否为EM300-DI(-HALL)-v3
     */
    isEM300DIv3(snOrModel: string, firmwareVersion: string): boolean;
    /**
     * 是否为WS1X6系列
     */
    isWS1X6(snOrMode: string): boolean;
    /**
     * 是否为WT201v2
     */
    isWT201v2(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为WT211v2
     */
    isWT211v2(snOrModel: string, hardwareVersion: string): boolean;
    /**
     * 是否为EM320-TH认证版本（003/004），认证版本NFC写入时需要每次输入密码
     */
    isEM320THCert(sn: string): boolean;
    /**
     * 是否为中性设备型号
     */
    isNeutral(oem: string): boolean;
    /**
     * 比较两个型号是否通用
     * @param source 当前sn或型号
     * @param target 目标sn或型号
     */
    isEqualWith(source: string, target: string): boolean;
    /**
     * 型号数组中是否包含当前型号
     * @param sn sn
     * @param arr 型号/系列数组
     * @returns
     */
    includes(snOrModel: string, arr: Array<MODELS | MODEL_SERIES>): boolean;
    /**
     * 返回当前型号/型号系列最合适的值,如果没有则返回默认值
     * 如果型号和型号系列同时存在，优先选择型号
     * @param sn sn
     * @param specifics
     * @example
     * Identify.select('6217xxxxxx', {
     *   [MODELS['AM103']]: {
     *     backgroundColor: 'green'
     *   },
     *   [MODELS['AM307']]: {
     *     backgroundColor: 'red'
     *   },
     *   default: {
     *     backgroundColor: 'blue'
     *   }
     * })
     *
     * @returns
     */
    select<T>(snOrModel: string, specifics: {
        "-"?: T | undefined;
        "EM500-PAR"?: T | undefined;
        "EM500-PM25"?: T | undefined;
        "EM500-CO2"?: T | undefined;
        "EM500-LGT"?: T | undefined;
        "EM500-SMT-EC5"?: T | undefined;
        "EM500-SMTC-MEC20"?: T | undefined;
        "EM500-SMT-MT10"?: T | undefined;
        "EM500-SMT-MT05"?: T | undefined;
        "EM500-PT100-T050"?: T | undefined;
        "EM500-PT100-T200"?: T | undefined;
        "EM500-PT100-T500"?: T | undefined;
        "EM500-PT100-T800"?: T | undefined;
        "EM500-UDL-W050"?: T | undefined;
        "EM500-UDL-W100"?: T | undefined;
        "EM500-UDL-S050"?: T | undefined;
        "EM500-UDL-S100"?: T | undefined;
        "EM500-UDL-C020"?: T | undefined;
        "EM500-UDL-C050"?: T | undefined;
        "EM500-UDL-C100"?: T | undefined;
        "EM500-SWL-L003"?: T | undefined;
        "EM500-SWL-L005"?: T | undefined;
        "EM500-SWL-L010"?: T | undefined;
        "EM500-SWL-L050"?: T | undefined;
        "EM500-SWL-KZ"?: T | undefined;
        "EM500-PP-KZ"?: T | undefined;
        "EM500-PP-G1/2M-P300"?: T | undefined;
        "EM500-PP-G1/2M-1002"?: T | undefined;
        "EM500-PP-G1/2M-4780"?: T | undefined;
        "EM500-PP-G1/2M-4842"?: T | undefined;
        "EM500-CO"?: T | undefined;
        "EM500-H2S"?: T | undefined;
        "EM500-NH3"?: T | undefined;
        AM102?: T | undefined;
        AM102L?: T | undefined;
        AM103?: T | undefined;
        AM103L?: T | undefined;
        AM104?: T | undefined;
        AM107?: T | undefined;
        AM304L?: T | undefined;
        AM305L?: T | undefined;
        AM307?: T | undefined;
        AM307L?: T | undefined;
        AM308?: T | undefined;
        AM308L?: T | undefined;
        "AM319-HCHO"?: T | undefined;
        "AM319-HCHO-IR"?: T | undefined;
        "AM319L-HCHO-IR"?: T | undefined;
        "AM319-HCHO-IR-W"?: T | undefined;
        "AM319-O3"?: T | undefined;
        "AM319L-O3"?: T | undefined;
        "EM300-TH"?: T | undefined;
        "EM300-TH-N00CN"?: T | undefined;
        "EM300-WL"?: T | undefined;
        "EM300-ZLD"?: T | undefined;
        "EM300-ZLD-N00CN"?: T | undefined;
        "EM300-SLD"?: T | undefined;
        "EM300-SLD-N00CN"?: T | undefined;
        "EM300-MCS"?: T | undefined;
        "EM300-MCS-N00CN"?: T | undefined;
        "EM300-SW"?: T | undefined;
        "EM300-SW-N00CN"?: T | undefined;
        "EM300-DI"?: T | undefined;
        "EM300-DI-HALL"?: T | undefined;
        "EM300-CL"?: T | undefined;
        "EM300-MLD"?: T | undefined;
        "EM310-UDL"?: T | undefined;
        "EM310-TILT"?: T | undefined;
        "EM320-TILT"?: T | undefined;
        "EM320-TH"?: T | undefined;
        "EM400-TLD"?: T | undefined;
        "EM400-TLD-N03GL"?: T | undefined;
        "EM400-MUD-B045"?: T | undefined;
        "EM400-MUD-N03GL"?: T | undefined;
        "EM400-UDL-C050"?: T | undefined;
        "EM400-UDL-C100"?: T | undefined;
        "EM400-UDL-W050"?: T | undefined;
        "EM400-UDL-W100"?: T | undefined;
        "EM400-UDL-S050"?: T | undefined;
        "EM400-UDL-C050-N03GL"?: T | undefined;
        "EM400-UDL-C100-N03GL"?: T | undefined;
        "EM400-UDL-W050-N03GL"?: T | undefined;
        "EM400-UDL-W100-N03GL"?: T | undefined;
        "EM400-UDL-S050-N03GL"?: T | undefined;
        "EM410-RDL"?: T | undefined;
        "EM410-RDL-L0CEU"?: T | undefined;
        "EM411-RDL"?: T | undefined;
        UC501?: T | undefined;
        UC502?: T | undefined;
        UC50X?: T | undefined;
        "UC501-N03GL"?: T | undefined;
        UC501NB?: T | undefined;
        "UC501-L0ACN"?: T | undefined;
        "UC501-N04GL"?: T | undefined;
        "UC502-N03GL"?: T | undefined;
        "UC502-L0ACN"?: T | undefined;
        "UC502-N04GL"?: T | undefined;
        "UC501-L0CEU"?: T | undefined;
        "UC502-L0CEU"?: T | undefined;
        UC511?: T | undefined;
        "UC511-DI"?: T | undefined;
        "UC511-DI-L0ACN"?: T | undefined;
        UC521?: T | undefined;
        "UC521-L0ACN"?: T | undefined;
        UC512?: T | undefined;
        "UC512-DI"?: T | undefined;
        WS101?: T | undefined;
        WS201?: T | undefined;
        WS202?: T | undefined;
        WS203?: T | undefined;
        WS301?: T | undefined;
        WS302?: T | undefined;
        WS303?: T | undefined;
        "WS501-2W"?: T | undefined;
        "WS502-2W"?: T | undefined;
        "WS503-2W"?: T | undefined;
        "WS501-3W"?: T | undefined;
        "WS502-3W"?: T | undefined;
        "WS503-3W"?: T | undefined;
        WS501EU?: T | undefined;
        "WS501EU-3W"?: T | undefined;
        WS502EU?: T | undefined;
        "WS502EU-3W"?: T | undefined;
        WS503EU?: T | undefined;
        "WS503EU-3W"?: T | undefined;
        WS501US?: T | undefined;
        "WS501US-3W"?: T | undefined;
        WS502US?: T | undefined;
        "WS502US-3W"?: T | undefined;
        WS503US?: T | undefined;
        "WS503US-3W"?: T | undefined;
        WS501EUD?: T | undefined;
        "WS501EUD-2W"?: T | undefined;
        WS502EUD?: T | undefined;
        "WS502EUD-2W"?: T | undefined;
        WS503EUD?: T | undefined;
        "WS503EUD-2W"?: T | undefined;
        "WS501W-2W"?: T | undefined;
        "WS502W-2W"?: T | undefined;
        "WS503W-2W"?: T | undefined;
        "WS501W-3W"?: T | undefined;
        "WS502W-3W"?: T | undefined;
        "WS503W-3W"?: T | undefined;
        WS513?: T | undefined;
        WS515?: T | undefined;
        WS516?: T | undefined;
        WS525?: T | undefined;
        "WS525-10A-CN"?: T | undefined;
        "WS525-10A-AU"?: T | undefined;
        "WS525-10A-US"?: T | undefined;
        "WS522-10A-EU"?: T | undefined;
        "WS523-13A-UK"?: T | undefined;
        "WS523-15A-US"?: T | undefined;
        "WS523-16A-CN"?: T | undefined;
        "WS523-16A-EU"?: T | undefined;
        "WS523-16A-FR"?: T | undefined;
        "WS525-16A-EU"?: T | undefined;
        WS558?: T | undefined;
        WS136?: T | undefined;
        WS156?: T | undefined;
        "JT-GS101"?: T | undefined;
        GS301?: T | undefined;
        "WTS-305"?: T | undefined;
        "WTS-505"?: T | undefined;
        "WTS-506"?: T | undefined;
        VS330?: T | undefined;
        VS340?: T | undefined;
        VS341?: T | undefined;
        VS350?: T | undefined;
        VS351?: T | undefined;
        VS360?: T | undefined;
        VS370?: T | undefined;
        "VA05-T"?: T | undefined;
        DS3604?: T | undefined;
        SCT01?: T | undefined;
        TS101?: T | undefined;
        TS201?: T | undefined;
        TS301?: T | undefined;
        TS302?: T | undefined;
        "TS601-L0DEU"?: T | undefined;
        "TS602-L0DEU"?: T | undefined;
        "TS601-L0FNA"?: T | undefined;
        "TS602-L0FNA"?: T | undefined;
        "TS601-L0DLA"?: T | undefined;
        "TS602-L0DLA"?: T | undefined;
        AT101?: T | undefined;
        WT101?: T | undefined;
        WT102?: T | undefined;
        WT201?: T | undefined;
        WT211?: T | undefined;
        WT401?: T | undefined;
        WT303?: T | undefined;
        WT304?: T | undefined;
        "WT303-ZH"?: T | undefined;
        "WT304-ZH"?: T | undefined;
        GS601?: T | undefined;
        UC711?: T | undefined;
        VS321?: T | undefined;
        CTH01?: T | undefined;
    } & {
        AM102?: T | undefined;
        AM103?: T | undefined;
        AM104?: T | undefined;
        AM107?: T | undefined;
        AM300?: T | undefined;
        AM319?: T | undefined;
        UC500?: T | undefined;
        TS30X?: T | undefined;
        UC500NB?: T | undefined;
        UC50XCAT1?: T | undefined;
        UC51X?: T | undefined;
        "UC51X-CAT"?: T | undefined;
        UC521?: T | undefined;
        "EM500-CO2"?: T | undefined;
        "EM500-PAR"?: T | undefined;
        "EM500-LGT"?: T | undefined;
        "EM500-PT100"?: T | undefined;
        "EM500-SMT"?: T | undefined;
        "EM500-SMTC"?: T | undefined;
        "EM500-SWL"?: T | undefined;
        "EM500-UDL"?: T | undefined;
        "EM500-PP"?: T | undefined;
        "EM500-CO"?: T | undefined;
        "EM500-H2S"?: T | undefined;
        "EM500-NH3"?: T | undefined;
        "EM300-TH"?: T | undefined;
        "EM300-DI"?: T | undefined;
        "EM300-WL"?: T | undefined;
        "EM300-MCS"?: T | undefined;
        "EM300-ZLD"?: T | undefined;
        "EM300-SLD"?: T | undefined;
        "EM300-SW"?: T | undefined;
        "EM300-MLD"?: T | undefined;
        "EM300-CL"?: T | undefined;
        "EM310-UDL"?: T | undefined;
        "EM310-TILT"?: T | undefined;
        "EM320-TH"?: T | undefined;
        "EM320-TILT"?: T | undefined;
        "EM400-TLD"?: T | undefined;
        "EM400-UDL"?: T | undefined;
        "EM410-RDL"?: T | undefined;
        "EM411-RDL"?: T | undefined;
        "EM410-RDL-L0CEU"?: T | undefined;
        WS100?: T | undefined;
        WS130?: T | undefined;
        WS150?: T | undefined;
        WS200?: T | undefined;
        WS300?: T | undefined;
        WS500?: T | undefined;
        "WS50X-MECH"?: T | undefined;
        WS51X?: T | undefined;
        WS520?: T | undefined;
        WS550?: T | undefined;
        JX?: T | undefined;
        WTS?: T | undefined;
        GS30X?: T | undefined;
        VS?: T | undefined;
        AT?: T | undefined;
        DS?: T | undefined;
        TS?: T | undefined;
        TS60X?: T | undefined;
        SCT01?: T | undefined;
        WT101?: T | undefined;
        WT102?: T | undefined;
        WT?: T | undefined;
        WT2X1?: T | undefined;
        WT401?: T | undefined;
        UC711?: T | undefined;
        VA05?: T | undefined;
        WT30X?: T | undefined;
        WS50XW?: T | undefined;
        CTH01?: T | undefined;
    } & {
        default: T;
    }): T;
};
/**
 * 鉴别设备类型的工具对象封装
 */
export declare class ModelIdentifier {
    model: MODELS;
    sn: string;
    constructor(sn: string);
    /**
    * 是否为AM设备
    */
    isAMDevice(): boolean;
    /**
     * 是否为EM设备
     */
    isEMDevice(): boolean;
    /**
     * 是否为LoRa设备
     */
    isLoRaDevice(): boolean;
    /**
     * 是否为NB设备
     */
    isNBDevice(): boolean;
    /**
     * 是否为UC50X
     */
    isUC50X(): boolean;
    isTS30X(): boolean;
    /**
     * 是否为TS60X美国版本（L0FNA）
     */
    isTS60XUSVersion(): boolean;
    /**
     * 是否为TS601系列（包含L0DEU、L0FNA、L0DLA）
     */
    isTS601Model(): boolean;
    /**
     * 是否为TS602系列（包含L0DEU、L0FNA、L0DLA）
     */
    isTS602Model(): boolean;
    /**
     * 是否为TS602系列且传感器类型为SHT41（sensorType === 2）
     */
    isTS602SHT41(sensorType?: number | null): boolean;
    /**
     * 是否为EM41X
     */
    isEM41X(): boolean;
    /**
     * 是否为UC50XNB
     */
    isUC50XNB(): boolean;
    /**
     * 是否为UC50Xv2
     */
    isUC50Xv2(hardwareVersion: string): boolean;
    /**
     * 是否为UC50Xv3
     */
    isUC50Xv3(hardwareVersion: string): boolean;
    /**
     * 是否为UC51Xv4
     */
    isUC51Xv4(hardwareVersion: string): boolean;
    /**
     * 是否为WTS气象站v2硬件及v1.2固件
     */
    isWTSv2(hardwareVersion: string, firmwareVersion: string): boolean;
    /**
     * 是否为WTS气象站v3硬件
     */
    isWTSv3(hardwareVersion: string, firmwareVersion: string): boolean;
    /**
     * 是否为WS50X EU/US 固件0102迭代
     */
    isWS50XEUUSV0102(firmwareVersion: string): boolean;
    /**
     * 是否为WS50X机械式
     */
    isWS50XMECH(): boolean;
    /**
     * 是否为WS50X触控式V2及以上
     */
    isWS50XTouchV2(hardwareVersion: string): boolean;
    /**
     * 是否为WS558v2版本
     */
    isWS558v2(): boolean;
    /**
     * 是否为AM3XXv2
     */
    isAM3XXv2(hardwareVersion: string): boolean;
    /**
     * 是否为AM319系列
     */
    isAM319Model(): boolean;
    /**
     * 是否为AM307/AM319.0000.0200.0104&AM308.0000.0200.0106迭代
     */
    isAMModelSeriesV0104(firmwareVersion: string, hardwareVersion: string): boolean | undefined;
    /**
     * 是否为EM300-DI(-HALL)-v3
     */
    isEM300DIv3(firmwareVersion: string): boolean;
    /**
     * 是否为EM5XXv2
     */
    isEM5XXv2(hardwareVersion: string): boolean;
    /**
    * 是否为WS1X6系列
    */
    isWS1X6(): boolean;
    /**
    * 是否为EM500_0200_0107迭代
    */
    isEM500_0200_0107(hardwareVersion: string, firmwareVersion: string): boolean;
    /**
     * 是否为WT201v2
     */
    isWT201v2(hardwareVersion: string): boolean;
    isWT211v2(hardwareVersion: string): boolean;
    /**
     * 是否为EM320-TH认证版本（003/004）
     */
    isEM320THCert(): boolean;
    /**
     * 是否为中性设备型号
     */
    isNeutral(oem: string): boolean;
    /**
     * 比较当前型号与目标型号是否相同
     * @param target 目标sn或型号
     */
    isEqualWith(target: string): boolean;
    /**
     * 型号数组中是否包含当前型号
     * @param sn sn
     * @param arr 型号/系列数组
     * @returns
     */
    includes(arr: Array<MODELS | MODEL_SERIES>): boolean;
    /**
     * 从集合中选择当前型号/型号系列最合适的值, 如果没有则返回默认值
     * 如果型号和型号系列同时存在，优先选择型号
     * @param specifics 型号/系列集合
     * @example
     * identify.select({
     *	[MODELS['AM103']]: "setting.buttonLight.am.label",
     *	[MODEL_SERIES['WS100']]: "setting.buttonLight.ws100.label",
     *	default: 'setting.buttonLight.default.label'
     * })
     */
    select<T>(specifics: {
        [m in MODELS]?: T;
    } & {
        [ms in MODEL_SERIES]?: T;
    } & {
        default: T;
    }): T;
}
export {};
//# sourceMappingURL=identify.d.ts.map