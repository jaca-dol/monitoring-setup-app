interface IpsoTuple {
    converter?: (value: any) => any;
    dataType: string;
    id: number;
    sensorType: string;
    unit?: string;
}
declare const DATA_TYPE: {
    Int8: string;
    UInt8: string;
    Int16: string;
    UInt16: string;
    Int32: string;
    UInt32: string;
};
declare const IPSO_ID_MAP: {
    [id: number]: IpsoTuple;
};
export { IPSO_ID_MAP, DATA_TYPE };
//# sourceMappingURL=ipso-definition.d.ts.map