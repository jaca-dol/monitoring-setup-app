import { DeviceInfo, FlashInfo } from '../deviceInfo/DeviceInfo';
import { Status } from '../deviceInfo/StatusDeviceInfo';
import { ModelData } from '../tsl';
import { DataModel } from './DataModel';
export declare class FlashDataModel<Data extends ModelData = Partial<FlashInfo>> extends DataModel<Data> {
    init(data: Data): void;
    fromDeviceInfo(deviceInfo: Partial<DeviceInfo>): void;
    toDeviceInfo(options?: {
        status: boolean;
    }): DeviceInfo;
    toDeviceInfoStatus(deviceInfo: DeviceInfo): Status[];
    toDeviceHistoryInfo(historyInfo: {
        history: Array<{
            [key: string]: any;
        }>;
    } & ModelData): Array<{
        [key: string]: any;
    }>;
}
//# sourceMappingURL=FlashDataModel.d.ts.map