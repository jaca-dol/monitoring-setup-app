/// <reference types="node" />
import { Buffer } from 'buffer';
export declare class BufferReader {
    constructor(buffer: Buffer);
    byteAt(index: number): number | undefined;
    firstByte(): number;
    getBuffer(): Buffer;
    getOffset(): number;
    hasNextByte(): boolean;
    lastByte(): number;
    moveOffset(plus: number): void;
    readBit(bits: number): number[];
    readBuffer(length: number): Buffer;
    readFloatLE(): number;
    readHex(length: number): string;
    readInt16LE(): number;
    readInt32LE(): number;
    readInt8(): number;
    readString(size: number): string;
    readUInt16LE(): number;
    readUInt32LE(): number;
    readUInt8(): number;
    setOffset(offset: number): void;
    private readonly buffer;
    private offset;
}
//# sourceMappingURL=buffer-reader.d.ts.map