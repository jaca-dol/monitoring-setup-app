export declare function timeToS(time: number, unit?: string): number;
export declare function array<T = undefined>(length: number, filledWith?: T): T[];
export declare function fixFloat(float: number | string, fractionDigits?: number): number;
export declare function safeValue(currentValue: any, defaultValue: any): any;
//# sourceMappingURL=util.d.ts.map