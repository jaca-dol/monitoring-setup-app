import { AttributeConstructor, AttributeDefinition, IAttribute } from '../tsl';
export declare class AttributeFactory {
    /**
     * 默认的 attribute 定义分组
     */
    static defaultAttributeDefinitionGroup: string;
    /**
     * 按照分组来缓存attribute定义
     */
    private static groupAttributeDefinitionCache;
    /**
     * Attribute构造函数缓存
     */
    private static attributeConstructorCache;
    /**
     * Attribute路径到Attribute key的索引
     */
    private static attributePathToKeyIndex;
    /**
     * 注册Attribute构造函数
     * @param key - attribute的key
     */
    static register(key: string): (target: any) => void;
    /**
     * 删除Attribute定义
     * @param key - attribute的key
     * @param group - 要删除的分组，如果不指定则删除所有分组中的该定义
     */
    static removeDefinition(key: string, group?: string | string[]): void;
    /**
     * 清理路径索引
     * @param key - attribute key
     * @param group - 分组名
     * @param definition - 定义对象
     */
    private static removePathIndex;
    /**
     * 注册Attribute定义
     * @param key - key
     * @param definition - Attribute的定义
     */
    static definition(key: string, definition: AttributeDefinition): void;
    /**
     * 根据Attribute的key获取Attribute的构造函数
     */
    static getConstructor(key: string): AttributeConstructor | undefined;
    /**
     * 获取Attribute的定义
     * @param key - attribute key
     * @param group - attribute group
     * @param fallbackGroup - 如果group不存在，则使用fallbackGroup
     */
    static getDefinition(key: string, group: string | string[], fallbackGroup?: string): AttributeDefinition<any> | undefined;
    /**
     * 根据查询条件获取Attribute定义
     * @param query - 查询条件
     */
    static getDefinitionBy(query: {
        key?: string;
        path?: string;
        direction?: AttributeDefinition['direction'];
        group?: string | string[];
    }): AttributeDefinition | undefined;
    /**
     * 加载一个Attribute实例
     * @param definition
     * @param device
     */
    static load<T extends IAttribute = IAttribute>(key: string, definition?: AttributeDefinition): T;
}
//# sourceMappingURL=AttributeFactory.d.ts.map