/**
 * 升级文件数据
 */
export interface UpgradeFileData {
    /**
     * 设备型号
     * 旧字段，兼容保留
     */
    model?: string;
    /**
     * 设备型号
     * 新字段，由原model字段改为name
     */
    name?: string;
    /**
     * 设备PN
     */
    pn?: string;
    /**
     * 设备ODM
     */
    odm?: string;
    /**
     * 差分文件最大的大小
     */
    maxSize: number;
    /**
     * 目标升级硬件版本
     */
    targetHardwareVersion?: string;
    /**
     * 目标升级固件版本
     */
    targetFirmwareVersion?: string;
    /**
     * 全量升级文件
     */
    fullUpgradeFile: {
        /**
         * 文件名
         */
        name: string;
        /**
         * 文件路径
         */
        path: string;
        /**
         * 文件数据Map
         * 因为 Hermes 有大小限制（196607），所以这里使用 Map 存储数据
         * @link https://github.com/facebook/hermes/issues/139#issuecomment-1186700954
         */
        dataMap: Map<'data', number[]>;
        /**
         * 文件版本
         * 1: 旧的全量升级文件
         * 2: 新的全量升级文件（包含全量升级文件和差分升级文件）
         */
        version: 1 | 2;
    }[];
    /**
     * 所有的差分升级计划
     */
    patchUpgradePlan?: Array<{
        /**
         * 硬件版本
         */
        hardwareVersion: string;
        /**
         * 固件版本
         */
        firmwareVersion: string;
        /**
         * 差分升级文件
         */
        files: Array<{
            name: string;
            path: string;
        }>;
    }>;
    /**
     * 所有的差分升级文件
     */
    patchUpgradeFiles?: Array<{
        /**
         * 文件名
         */
        name: string;
        /**
         * 文件路径
         */
        path: string;
        /**
         * 文件版本
         * 1: 旧的差分升级文件
         * 2: 新的差分升级文件
         */
        version: 1 | 2;
    }>;
    /**
     * 固件升级检查参数
     */
    checkFirmwareParams?: Record<string, Array<any>>;
    /**
     * 子模块升级文件
     */
    submoduleUpgradeFiles?: string[];
    /**
     * 升级方式
     * 1: 新的升级方式
     * 目前只有1，其它值以后扩展
     */
    upgradeMethod?: number;
    /**
     * 原始数据
     * upgrade_plan.json的数据
     */
    rawData?: Record<string, any>;
}
/**
 * 升级计划文件数据（upgrade_plan.json）
 */
export interface UpgradePlanData {
    /**
     * 设备型号
     * 旧字段，兼容保留
     */
    model?: string;
    /**
     * 设备型号
     * 新字段，由原model字段改为name
     */
    name?: string;
    /**
     * 设备PN
     */
    pn: string;
    /**
     * 设备ODM
     */
    odm: string;
    /**
     * 硬件版本
     */
    hardwareVersion: string;
    /**
     * 固件版本
     */
    firmwareVersion: string;
    /**
     * 差分文件最大大小
     */
    maxSize: number;
    /**
     * 所有升级文件
     */
    upgradeFiles: string[];
    /**
     * 升级方式
     * 目前只有1或者没有这个值，其它值以后扩展
     * 为1，需要把upgrade_plan.json数据发送给设备
     */
    upgradeMethod?: number;
    /**
     * 差分升级计划
     */
    upgradePlan?: Array<{
        hardwareVersion: string;
        firmwareVersion: string;
        files: string[];
    }>;
    /**
     * 子模块升级文件
     */
    submoduleUpgradeFiles?: string[];
    /**
     * 固件升级检查参数
     * @example
     * {
     *  "model": ["EM300"],
     *  "subModel1": ["TH"],
     *  "subModel2": ["915M"],
     *  "subModel3": [],
     *  "subModel4": [],
     *  "pn1": [],
     *  "pn2": [],
     *  "pn3": [],
     *  "pn4": [],
     * }
     */
    checkFirmwareParams?: Record<string, Array<any>>;
}
/**
 * 升级计划
 */
export interface UpgradePlan {
    /**
     * 升级方式
     * full: 全量升级
     * patch：差分升级（支持多次差分升级）
     * oldPatch: 旧的差分升级（只支持一次差分升级）
     * patchSubmodule: 差分升级（支持子模块升级）
     */
    type: 'full' | 'patch' | 'oldPatch' | 'patchSubmodule';
    /**
     * 升级文件信息映射，key为文件名，value为文件数据
     * 全量升级：N个解密后的全量镜像
     * 旧的差分升级：1个差分镜像
     * 新差分升级：N个差分镜像
     */
    files: Map<string, number[]>;
    /**
     * 使用升级计划的原因
     */
    reason: string;
    /**
     * 是否包含子模块
     */
    hasSubmodule?: boolean;
}
//# sourceMappingURL=UpgradeFiles.d.ts.map