/**
 * 电磁阀规则条件
 */
export interface SolenoidRuleCondition {
    /**
     * 0: 无
     * 1: 时间
     * 2: D2D
     * 3: 脉冲时间上报
     * 4: 脉冲计量上报
     * 5: 压力到阈值
     */
    type: 0 | 1 | 2 | 3 | 4 | 5;
    /**
     * 时间配置
     */
    time?: {
        /**
         * 开始时间
         * 年月日时分转时间戳，0秒
         */
        startTime: number;
        /**
         * 结束时间
         * 年月日时分转时间戳，0秒
         */
        endTime: number;
        /**
         * 启用循环
         */
        cycleEnable: boolean;
        /**
         * 循环模式
         * 0: 月
         * 1: 日
         * 2: 周
         */
        cycleMode: 0 | 1 | 2;
        /**
         * 循环周期
         */
        cycleTime: number;
        /**
         * 循环星期
         * 1 - 7：周一 - 周日
         */
        repeat?: number[];
    };
    /**
     * D2D配置
     */
    d2d?: {
        cmd: number;
    };
    /**
     * 脉冲水表持续时间内水量超过阈值上报
     */
    pulsePerTime?: {
        /**
         * 脉冲索引
         */
        source: 1 | 2;
        /**
         * 持续时间（min）
         */
        time: number;
        /**
         * 出水量
         */
        value: number;
    };
    /**
     * 灌溉期间首次测压延时
     */
    firstPressureMeasurementDelay?: number;
    /**
     * 脉冲水表出水量每次超过阈值后上报
     */
    pulsePerCount?: {
        /**
         * 脉冲索引
         */
        source: 1 | 2;
        /**
         * 出水量
         */
        value: number;
    };
    /**
     * 压力阈值
     */
    pressureThreshold?: {
        /**
         * 触发来源
         * 0、每次变化
         * 1、阀1开启
         * 2、阀2开启
         * 3、阀1或阀2开启
         */
        source: 0 | 1 | 2 | 3;
        /**
         * 模式
         * 0、无
         * 1、小于
         * 2、大于
         * 3、介于
         * 4、不介于
         */
        mode: 0 | 1 | 2 | 3 | 4;
        min: number;
        max: number;
        pressure_source?: 1 | 2;
    };
}
/**
 * 电磁阀规则动作
 */
export interface SolenoidRuleAction {
    /**
     * 0：无
     * 1：强制任务
     * 2：通常任务
     * 3：上报
     */
    type: 0 | 1 | 2 | 3;
    /**
     * 任务
     */
    task?: {
        /**
         * 控制对象
         * 1：电磁阀1
         * 2：电磁阀2
         */
        target: 1 | 2;
        /**
         * 控制状态
         * 0: 关
         * 1: 开
         */
        startState: 0 | 1;
        /**
         * 控制状态
         * 两通阀：0-100开度
         * 三通阀：0-100为左开度 101-200为右开度
         */
        openState?: number;
        /**
         * 启用时间任务
         */
        timeWork: boolean;
        /**
         * 持续时间(s)
         */
        continueTime: number;
        /**
         * 启用计数任务
         */
        counterWork: boolean;
        /**
         * 持续次数
         */
        continueCounter: number;
    };
    /**
     *上报
     */
    report?: {
        /**
         * 上报类型
         * 0: 无
         * 1：通道1 上报
         * 2：通道2 上报
         * 3: 自定义内容上报
         * 4: 阈值报警
         */
        type: 0 | 1 | 2 | 3 | 4;
        /**
         * 自定义内容
         */
        msg?: string;
        /**
         * 持续次数(UC51X-CAT)
         */
        continueCount?: number;
        /**
         * 解除报警(UC51X-CAT)
         */
        releaseEnable?: boolean;
    };
}
/**
 * 电磁阀规则
 */
export interface SolenoidRule {
    id: number;
    /**
     * 是否启用
     */
    enable: boolean;
    /**
     * 条件
     */
    condition: SolenoidRuleCondition[];
    /**
     * 动作
     */
    action: SolenoidRuleAction[];
}
/**
 * 电磁阀规则表单值
 * 这里值表单保存获取的值\
 * 后面会转换成SolenoidRule
 */
export interface SolenoidRuleFormValues {
    condition: {
        type: SolenoidRuleCondition['type'];
        time?: SolenoidRuleCondition['time'];
        d2d?: {
            cmd: string;
        };
        pulsePerTime?: SolenoidRuleCondition['pulsePerTime'];
        pulsePerCount?: SolenoidRuleCondition['pulsePerCount'];
    };
    action: {
        type: SolenoidRuleAction['type'];
        task?: {
            target: 1 | 2;
            startState: 0 | 1;
            continueTime: number | string;
            continueCounter: number | string;
        };
        report?: {
            /**
             * 1: 水表1计数值及阀门开关上报
             * 2: 水表2计数值及阀门开关上报
             * 3: 自定义内容上报
             */
            type: 1 | 2 | 3;
            message?: string;
        };
    };
}
export interface FormattedSolenoidRule extends SolenoidRule {
    /**
     * 规则总结文案
     */
    tip: {
        /**
         * 条件总结文案
         */
        conditionTip: string;
        /**
         * 动作总结文案
         */
        actionTip: string;
        /**
         * 规则总结文案
         */
        tips: string;
    };
    /**
     * 是否禁用
     */
    disabled: boolean;
}
//# sourceMappingURL=SolenoidRulesEngine.d.ts.map