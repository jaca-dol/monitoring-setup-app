export interface CTH01TSLInfo {
    /**
     * 温度
     * @class_type 属性
     * @max_value 100
     * @min_value -20
     * @decimal_digits 1
     */
    temperature: number;
    /**
     * 电压三相不平衡度
     * @class_type 属性
     * @max_value 100
     * @min_value 0
     * @decimal_digits 2
     */
    voltage_three_phase_imbalcance?: number;
    /**
     * THDi
     * @class_type 属性
     * @array_length 12
     */
    thdi: {
        /**
         * THDi
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 2
         */
        value: number;
    }[];
    /**
     * THDv
     * @class_type 属性
     * @array_length 3
     */
    thdv: {
        /**
         * THDv
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 2
         */
        value: number;
    }[];
    /**
     * 电流有效值
     * @class_type 属性
     * @array_length 12
     */
    current: {
        /**
         * 电流有效值
         * @default 0
         * @class_type 属性
         * @max_value 4000
         * @min_value 0
         * @decimal_digits 2
         */
        value: any;
    }[];
    /**
     * 电压有效值
     * @class_type 属性
     * @array_length 3
     */
    voltage: {
        /**
         * 电压有效值
         * @default 0
         * @class_type 属性
         * @max_value 500
         * @min_value 0
         * @decimal_digits 2
         */
        value: number;
    }[];
    /**
     * 功率因数
     * @class_type 属性
     */
    power_factor?: {
        /**
         * 功率因数
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 功率因数
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 功率因数
         * @class_type 属性
         * @is_one_of
         */
        mask3?: number;
        /**
         * 功率因数
         * @class_type 属性
         * @is_one_of
         */
        mask4?: number;
        /**
         * 功率因数a
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 2
         */
        group1_value?: number;
        /**
         * 功率因数
         * @class_type 属性
         */
        group1?: {
            /**
             * 功率因数1
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan1: number;
            /**
             * 功率因数2
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan2: number;
            /**
             * 功率因数3
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan3: number;
        };
        /**
         * 功率因数b
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 2
         */
        group2_value?: number;
        /**
         * 功率因数
         * @class_type 属性
         */
        group2?: {
            /**
             * 功率因数4
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan1: number;
            /**
             * 功率因数5
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan2: number;
            /**
             * 功率因数6
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan3: number;
        };
        /**
         * 功率因数c
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 2
         */
        group3_value?: number;
        /**
         * 功率因数
         * @class_type 属性
         */
        group3?: {
            /**
             * 功率因数7
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan1: number;
            /**
             * 功率因数8
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan2: number;
            /**
             * 功率因数9
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan3: number;
        };
        /**
         * 功率因数d
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value 0
         * @decimal_digits 2
         */
        group4_value?: number;
        /**
         * 功率因数
         * @class_type 属性
         */
        group4?: {
            /**
             * 功率因数10
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan1: number;
            /**
             * 功率因数11
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan2: number;
            /**
             * 功率因数12
             * @default 0
             * @class_type 属性
             * @max_value 100
             * @min_value 0
             * @decimal_digits 2
             */
            chan3: number;
        };
    };
    /**
     * 有功功率
     * @class_type 属性
     */
    active_power1?: {
        /**
         * 有功功率
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 有功功率
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 有功功率a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 有功功率
         * @class_type 属性
         */
        group1?: {
            /**
             * 有功功率1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 有功功率2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 有功功率3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 有功功率b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 有功功率
         * @class_type 属性
         */
        group2?: {
            /**
             * 有功功率4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 有功功率5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 有功功率6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 有功功率
     * @class_type 属性
     */
    active_power2?: {
        /**
         * 有功功率
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 有功功率
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 有功功率c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 有功功率
         * @class_type 属性
         */
        group1?: {
            /**
             * 有功功率7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 有功功率8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 有功功率9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 有功功率d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 有功功率
         * @class_type 属性
         */
        group2?: {
            /**
             * 有功功率10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 有功功率11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 有功功率12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 无功功率
     * @class_type 属性
     */
    reactive_power1?: {
        /**
         * 无功功率
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 无功功率
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 无功功率a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 无功功率
         * @class_type 属性
         */
        group1?: {
            /**
             * 无功功率1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 无功功率2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 无功功率3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 无功功率b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 无功功率
         * @class_type 属性
         */
        group2?: {
            /**
             * 无功功率4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 无功功率5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 无功功率6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 无功功率
     * @class_type 属性
     */
    reactive_power2?: {
        /**
         * 无功功率
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 无功功率
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 无功功率c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 无功功率
         * @class_type 属性
         */
        group1?: {
            /**
             * 无功功率7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 无功功率8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 无功功率9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 无功功率d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 无功功率
         * @class_type 属性
         */
        group2?: {
            /**
             * 无功功率10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 无功功率11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 无功功率12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 视在功率
     * @class_type 属性
     */
    apparent_power1?: {
        /**
         * 视在功率
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 视在功率
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 视在功率a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 视在功率
         * @class_type 属性
         */
        group1?: {
            /**
             * 视在功率1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在功率2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在功率3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 视在功率b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 视在功率
         * @class_type 属性
         */
        group2?: {
            /**
             * 视在功率4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在功率5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在功率6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 视在功率
     * @class_type 属性
     */
    apparent_power2?: {
        /**
         * 视在功率
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 视在功率
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 视在功率c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 视在功率
         * @class_type 属性
         */
        group1?: {
            /**
             * 视在功率7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在功率8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在功率9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 视在功率d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 视在功率
         * @class_type 属性
         */
        group2?: {
            /**
             * 视在功率10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在功率11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在功率12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 正向有功电能
     * @class_type 属性
     */
    forward_active_energy1?: {
        /**
         * 正向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 正向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 正向有功电能a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 正向有功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 正向有功电能1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向有功电能2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向有功电能3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 正向有功电能b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 正向有功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 正向有功电能4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向有功电能5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向有功电能6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 正向有功电能
     * @class_type 属性
     */
    forward_active_energy2?: {
        /**
         * 正向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 正向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 正向有功电能c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 正向有功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 正向有功电能7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向有功电能8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向有功电能9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 正向有功电能d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 正向有功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 正向有功电能10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向有功电能11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向有功电能12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 反向有功电能
     * @class_type 属性
     */
    reverse_active_energy1?: {
        /**
         * 反向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 反向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 反向有功电能a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 反向有功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 反向有功电能1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向有功电能2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向有功电能3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 反向有功电能b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 反向有功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 反向有功电能4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向有功电能5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向有功电能6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 反向有功电能
     * @class_type 属性
     */
    reverse_active_energy2?: {
        /**
         * 反向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 反向有功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 反向有功电能c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 反向有功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 反向有功电能7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向有功电能8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向有功电能9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 反向有功电能d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 反向有功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 反向有功电能10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向有功电能11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向有功电能12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 正向无功电能
     * @class_type 属性
     */
    forward_reactive_energy1?: {
        /**
         * 正向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 正向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 正向无功电能a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 正向无功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 正向无功电能1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向无功电能2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向无功电能3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 正向无功电能b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 正向无功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 正向无功电能4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向无功电能5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向无功电能6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 正向无功电能
     * @class_type 属性
     */
    forward_reactive_energy2?: {
        /**
         * 正向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 正向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 正向无功电能c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 正向无功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 正向无功电能7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向无功电能8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向无功电能9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 正向无功电能d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 正向无功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 正向无功电能10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 正向无功电能11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 正向无功电能12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 反向无功电能
     * @class_type 属性
     */
    reverse_reactive_energy1?: {
        /**
         * 反向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 反向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 反向无功电能a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 反向无功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 反向无功电能1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向无功电能2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向无功电能3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 反向无功电能b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 反向无功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 反向无功电能4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向无功电能5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向无功电能6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 反向无功电能
     * @class_type 属性
     */
    reverse_reactive_energy2?: {
        /**
         * 反向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 反向无功电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 反向无功电能c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 反向无功电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 反向无功电能7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向无功电能8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向无功电能9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 反向无功电能d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 反向无功电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 反向无功电能10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 反向无功电能11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 反向无功电能12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 视在电能
     * @class_type 属性
     */
    apparent_energy1?: {
        /**
         * 视在电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 视在电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 视在电能a
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 视在电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 视在电能1
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在电能2
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在电能3
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 视在电能b
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 视在电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 视在电能4
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在电能5
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在电能6
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 视在电能
     * @class_type 属性
     */
    apparent_energy2?: {
        /**
         * 视在电能
         * @class_type 属性
         * @is_one_of
         */
        mask1?: number;
        /**
         * 视在电能
         * @class_type 属性
         * @is_one_of
         */
        mask2?: number;
        /**
         * 视在电能c
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group1_value?: number;
        /**
         * 视在电能
         * @class_type 属性
         */
        group1?: {
            /**
             * 视在电能7
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在电能8
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在电能9
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
        /**
         * 视在电能d
         * @default 0
         * @class_type 属性
         * @decimal_digits 3
         */
        group2_value?: number;
        /**
         * 视在电能
         * @class_type 属性
         */
        group2?: {
            /**
             * 视在电能10
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan1: number;
            /**
             * 视在电能11
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan2: number;
            /**
             * 视在电能12
             * @default 0
             * @class_type 属性
             * @decimal_digits 3
             */
            chan3: number;
        };
    };
    /**
     * 历史数据类型
     * @class_type 属性
     */
    history_type: {
        /**
         * 历史数据类型 - 1:月度能耗 2:月度最小 3:月度最大
         * @default 1
         * @class_type 属性
         */
        type?: 1 | 2 | 3;
    };
    /**
     * 温度阈值告警
     * @class_type 事件
     */
    temperature_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;
        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         * @class_type 参数
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         * @class_type 参数
         */
        over_range_error?: Record<string, any>;
        /**
         * 无数据
         * @class_type 参数
         */
        no_data?: Record<string, any>;
        /**
         * 温度值小于阈值告警解除
         * @class_type 参数
         */
        lower_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值小于阈值告警
         * @class_type 参数
         */
        lower_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值大于阈值告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值大于阈值告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值介于阈值告警解除
         * @class_type 参数
         */
        within_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值介于告警
         * @class_type 参数
         */
        within_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值之外阈值告警解除
         * @class_type 参数
         */
        exceed_range_alarm_deactivation?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
        /**
         * 温度值之外阈值告警
         * @class_type 参数
         */
        exceed_range_alarm_trigger?: {
            /**
             * 温度
             * @class_type 参数
             * @max_value 100
             * @min_value -20
             * @decimal_digits 1
             */
            temperature?: number;
        };
    };
    /**
     * 电流阈值告警
     * @class_type 事件
     */
    current_alarm?: {
        /**
         * 告警通道
         * @class_type 参数
         * @max_value 11
         * @min_value 0
         */
        channel?: number;
        /**
         * 电流阈值告警信息
         * @class_type 参数
         */
        info?: {
            /**
             * 告警类型
             * @class_type 参数
             * @is_one_of
             */
            type?: number;
            /**
             * 采集错误
             * @class_type 参数
             */
            collection_error?: Record<string, any>;
            /**
             * 超量程下限
             * @class_type 参数
             */
            lower_range_error?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 超量程上限
             * @class_type 参数
             */
            over_range_error?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 无数据
             * @class_type 参数
             */
            no_data?: Record<string, any>;
            /**
             * 超量程解除
             * @class_type 参数
             */
            over_range_release?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流值小于阈值告警解除
             * @class_type 参数
             */
            lower_range_alarm_deactivation?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流值小于阈值告警
             * @class_type 参数
             */
            lower_range_alarm_trigger?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流值大于阈值告警解除
             * @class_type 参数
             */
            over_range_alarm_deactivation?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流值大于阈值告警
             * @class_type 参数
             */
            over_range_alarm_trigger?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流区间内阈值告警解除
             * @class_type 参数
             */
            within_range_alarm_deactivation?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流区间内告警
             * @class_type 参数
             */
            within_range_alarm_trigger?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流区间外阈值告警解除
             * @class_type 参数
             */
            exceed_range_alarm_deactivation?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
            /**
             * 电流区间外阈值告警
             * @class_type 参数
             */
            exceed_range_alarm_trigger?: {
                /**
                 * 电流
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                current?: any;
            };
        };
    };
    /**
     * 电压阈值告警
     * @class_type 事件
     */
    voltage_alarm?: {
        /**
         * 告警通道
         * @class_type 参数
         * @max_value 11
         * @min_value 0
         */
        channel?: number;
        /**
         * 电压阈值告警信息
         * @class_type 参数
         */
        info?: {
            /**
             * 告警类型
             * @class_type 参数
             * @is_one_of
             */
            type?: number;
            /**
             * 采集错误
             * @class_type 参数
             */
            collection_error?: Record<string, any>;
            /**
             * 超量程下限
             * @class_type 参数
             */
            lower_range_error?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 超量程上限
             * @class_type 参数
             */
            over_range_error?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 无数据
             * @class_type 参数
             */
            no_data?: Record<string, any>;
            /**
             * 超量程解除
             * @class_type 参数
             */
            over_range_release?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压值小于阈值告警解除
             * @class_type 参数
             */
            lower_range_alarm_deactivation?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压值小于阈值告警
             * @class_type 参数
             */
            lower_range_alarm_trigger?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压值大于阈值告警解除
             * @class_type 参数
             */
            over_range_alarm_deactivation?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压值大于阈值告警
             * @class_type 参数
             */
            over_range_alarm_trigger?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压区间内阈值告警解除
             * @class_type 参数
             */
            within_range_alarm_deactivation?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压区间内告警
             * @class_type 参数
             */
            within_range_alarm_trigger?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压区间外阈值告警解除
             * @class_type 参数
             */
            exceed_range_alarm_deactivation?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
            /**
             * 电压区间外阈值告警
             * @class_type 参数
             */
            exceed_range_alarm_trigger?: {
                /**
                 * 电压
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                voltage?: number;
            };
        };
    };
    /**
     * THDi阈值告警
     * @class_type 事件
     */
    thdi_alarm?: {
        /**
         * 告警通道
         * @class_type 参数
         * @max_value 11
         * @min_value 0
         */
        channel?: number;
        /**
         * THDi阈值告警信息
         * @class_type 参数
         */
        info?: {
            /**
             * 告警类型
             * @class_type 参数
             * @is_one_of
             */
            type?: number;
            /**
             * 采集错误
             * @class_type 参数
             */
            collection_error?: Record<string, any>;
            /**
             * THDi值大于阈值告警解除
             * @class_type 参数
             */
            over_range_alarm_deactivation?: {
                /**
                 * THDi
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                thdi?: number;
            };
            /**
             * THDi值大于阈值告警
             * @class_type 参数
             */
            over_range_alarm_trigger?: {
                /**
                 * THDi
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                thdi?: number;
            };
        };
    };
    /**
     * THDv阈值告警
     * @class_type 事件
     */
    thdv_alarm?: {
        /**
         * 告警通道
         * @class_type 参数
         * @max_value 11
         * @min_value 0
         */
        channel?: number;
        /**
         * THDv阈值告警信息
         * @class_type 参数
         */
        info?: {
            /**
             * 告警类型
             * @class_type 参数
             * @is_one_of
             */
            type?: number;
            /**
             * 采集错误
             * @class_type 参数
             */
            collection_error?: Record<string, any>;
            /**
             * THDv值大于阈值告警解除
             * @class_type 参数
             */
            over_range_alarm_deactivation?: {
                /**
                 * THDv
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                thdv?: number;
            };
            /**
             * THDv值大于阈值告警
             * @class_type 参数
             */
            over_range_alarm_trigger?: {
                /**
                 * THDv
                 * @class_type 参数
                 * @decimal_digits 2
                 */
                thdv?: number;
            };
        };
    };
    /**
     * 电压三相不平衡度阈值告警
     * @class_type 事件
     */
    voltage_unbalance_alarm?: {
        /**
         * 告警类型
         * @class_type 参数
         * @is_one_of
         */
        type?: number;
        /**
         * 采集错误
         * @class_type 参数
         */
        collection_error?: Record<string, any>;
        /**
         * 电压三相不平衡度值大于阈值告警解除
         * @class_type 参数
         */
        over_range_alarm_deactivation?: {
            /**
             * 电压三相不平衡度
             * @class_type 参数
             * @decimal_digits 2
             */
            voltage_unbalance?: number;
        };
        /**
         * 电压三相不平衡度值大于阈值告警
         * @class_type 参数
         */
        over_range_alarm_trigger?: {
            /**
             * 电压三相不平衡度
             * @class_type 参数
             * @decimal_digits 2
             */
            voltage_unbalance?: number;
        };
    };
    /**
     * 断电告警
     * @class_type 事件
     */
    power_loss_alarm?: Record<string, any>;
    /**
     * 采集周期
     * @class_type 属性
     */
    collection_interval: {
        /**
         * 采集周期单位 - 0：秒 1：分
         * @default 0
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;
        /**
         * 采集周期
         * @default 30
         * @class_type 属性
         * @max_value 64800
         * @min_value 10
         */
        seconds_of_time?: number;
        /**
         * 采集周期
         * @default 1
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        minutes_of_time?: number;
    };
    /**
     * 上报周期
     * @class_type 属性
     */
    reporting_interval: {
        /**
         * 上报周期单位 - 0：秒 1：分
         * @default 1
         * @class_type 属性
         * @is_one_of
         */
        unit: 0 | 1;
        /**
         * 上报周期
         * @default 600
         * @class_type 属性
         * @max_value 64800
         * @min_value 10
         */
        seconds_of_time?: number;
        /**
         * 上报周期
         * @default 10
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        minutes_of_time?: number;
    };
    /**
     * 设备状态 - 0：关机 1：开机
     * @default 0
     * @class_type 属性
     */
    device_status?: 0 | 1;
    /**
     * 温度单位 - 0：℃ 1：℉
     * @default 0
     * @class_type 属性
     */
    temperature_unit: 0 | 1;
    /**
     * 蓝牙名称
     * @class_type 属性
     */
    bluetooth_name: {
        /**
         * 长度
         * @default 13
         * @class_type 属性
         * @max_value 13
         * @min_value 1
         */
        length: number;
        /**
         * 蓝牙名称
         * @class_type 属性
         * @array_length 13
         * @character_encoding utf8
         */
        content: string;
    };
    /**
     * 数据存储设置
     * @class_type 属性
     */
    data_storage_settings: {
        /**
         * 子命令
         * @default 0
         * @class_type 属性
         */
        command?: number;
        /**
         * 存储使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 重传使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        retransmission_enable: 0 | 1;
        /**
         * 重传周期
         * @default 600
         * @class_type 属性
         * @max_value 1200
         * @min_value 120
         */
        retransmission_interval: number;
        /**
         * 回传周期
         * @default 120
         * @class_type 属性
         * @max_value 1200
         * @min_value 120
         */
        retrieval_interval?: number;
    };
    /**
     * 电压通道 - 0：三相四线 1：三相三线
     * @default 0
     * @class_type 属性
     */
    voltage_interface: 0 | 1;
    /**
     * 组a
     * @class_type 属性
     */
    current_interface1: {
        /**
         * 电路类型a - 0：单相 1：三相
         * @default 0
         * @class_type 属性
         */
        type: 0 | 1;
        /**
         * 电流通道配置
         * @class_type 属性
         * @array_length 3
         */
        config: {
            /**
             * 电流方向 - 0：正向 1：反向
             * @default 0
             * @class_type 属性
             */
            direction: 0 | 1;
            /**
             * 通道量程 - 0：NONE 1：100A 2：300A 3：500A 4：1000A 5：4000A
             * @default 0
             * @class_type 属性
             */
            range: 0 | 1 | 2 | 3 | 4 | 5;
        }[];
    };
    /**
     * 组b
     * @class_type 属性
     */
    current_interface2: {
        /**
         * 电路类型b - 0：单相 1：三相
         * @default 0
         * @class_type 属性
         */
        type: 0 | 1;
        /**
         * 电流通道配置
         * @class_type 属性
         * @array_length 3
         */
        config: {
            /**
             * 电流方向 - 0：正向 1：反向
             * @default 0
             * @class_type 属性
             */
            direction: 0 | 1;
            /**
             * 通道量程 - 0：NONE 1：100A 2：300A 3：500A 4：1000A 5：4000A
             * @default 0
             * @class_type 属性
             */
            range: 0 | 1 | 2 | 3 | 4 | 5;
        }[];
    };
    /**
     * 组c
     * @class_type 属性
     */
    current_interface3: {
        /**
         * 电路类型c - 0：单相 1：三相
         * @default 0
         * @class_type 属性
         */
        type: 0 | 1;
        /**
         * 电流通道配置
         * @class_type 属性
         * @array_length 3
         */
        config: {
            /**
             * 电流方向 - 0：正向 1：反向
             * @default 0
             * @class_type 属性
             */
            direction: 0 | 1;
            /**
             * 通道量程 - 0：NONE 1：100A 2：300A 3：500A 4：1000A 5：4000A
             * @default 0
             * @class_type 属性
             */
            range: 0 | 1 | 2 | 3 | 4 | 5;
        }[];
    };
    /**
     * 组d
     * @class_type 属性
     */
    current_interface4: {
        /**
         * 电路类型d - 0：单相 1：三相
         * @default 0
         * @class_type 属性
         */
        type: 0 | 1;
        /**
         * 电流通道配置
         * @class_type 属性
         * @array_length 3
         */
        config: {
            /**
             * 电流方向 - 0：正向 1：反向
             * @default 0
             * @class_type 属性
             */
            direction: 0 | 1;
            /**
             * 通道量程 - 0：NONE 1：100A 2：300A 3：500A 4：1000A 5：4000A
             * @default 0
             * @class_type 属性
             */
            range: 0 | 1 | 2 | 3 | 4 | 5;
        }[];
    };
    /**
     * 温度校准设置
     * @class_type 属性
     */
    temperature_calibration_settings: {
        /**
         * 温度校准 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 校准值
         * @default 0
         * @class_type 属性
         * @max_value 120
         * @min_value -120
         * @decimal_digits 2
         */
        calibration_value: number;
    };
    /**
     * 时区 - -720：UTC-12(IDLW) -660：UTC-11(SST) -600：UTC-10(HST) -570：UTC-9:30(MIT) -540：UTC-9(AKST) -480：UTC-8(PST) -420：UTC-7(MST) -360：UTC-6(CST) -300：UTC-5(EST) -240：UTC-4(AST) -210：UTC-3:30(NST) -180：UTC-3(BRT) -120：UTC-2(FNT) -60：UTC-1(CVT) 0：UTC(WET) 60：UTC+1(CET) 120：UTC+2(EET) 180：UTC+3(MSK) 210：UTC+3:30(IRST) 240：UTC+4(GST) 270：UTC+4:30(AFT) 300：UTC+5(PKT) 330：UTC+5:30(IST) 345：UTC+5:45(NPT) 360：UTC+6(BHT) 390：UTC+6:30(MMT) 420：UTC+7(ICT) 480：UTC+8(CT/CST) 540：UTC+9(JST) 570：UTC+9:30(ACST) 600：UTC+10(AEST) 630：UTC+10:30(LHST) 660：UTC+11(VUT) 720：UTC+12(NZST) 765：UTC+12:45(CHAST) 780：UTC+13(PHOT) 840：UTC+14(LINT)
     * @default 0
     * @class_type 属性
     */
    time_zone: number;
    /**
     * 夏令时
     * @class_type 属性
     */
    daylight_saving_time: {
        /**
         * 夏令时 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 偏移时间
         * @default 60
         * @class_type 属性
         * @max_value 120
         * @min_value 1
         */
        daylight_saving_time_offset: number;
        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月
         * @default 1
         * @class_type 属性
         */
        start_month: number;
        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        start_week_num: 1 | 2 | 3 | 4 | 5;
        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 1
         * @class_type 属性
         */
        start_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;
        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        start_hour_min: number;
        /**
         * 月份 - 1: 一月 2: 二月 3: 三月 4: 四月  5: 五月 6: 六月 7: 七月 8: 八月 9: 九月  10: 十月 11: 十一月 12: 十二月
         * @default 1
         * @class_type 属性
         */
        end_month: number;
        /**
         * 周数 - 1：首个 2：第二个 3：第三个 4：第四个 5：末个
         * @default 1
         * @class_type 属性
         */
        end_week_num: 1 | 2 | 3 | 4 | 5;
        /**
         * 星期 - 1：星期一 2：星期二  3：星期三 4：星期四  5：星期五 6：星期六 7：星期日
         * @default 1
         * @class_type 属性
         */
        end_week_day: 1 | 2 | 3 | 4 | 5 | 6 | 7;
        /**
         * 时间 - 0：00:00 60：01:00 120：02:00 180：03:00 240：04:00 300：05:00 360：06:00 420：07:00 480：08:00 540：09:00 600：10:00 660：11:00 720：12:00 780：13:00 840：14:00 900：15:00 960：16:00 1020：17:00 1080：18:00 1140：19:00 1200：20:00 1260：21:00 1320：22:00 1380：23:00
         * @default 0
         * @class_type 属性
         */
        end_hour_min: number;
    };
    /**
     * 温度阈值告警设置
     * @class_type 属性
     */
    temperature_alarm_settings: {
        /**
         * 阈值告警使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 阈值模式 - 1:条件：x<A 2:条件：x>B 3:条件：A≤x≤B 4:条件：x<A或x>B
         * @default 2
         * @class_type 属性
         */
        threshold_condition: 1 | 2 | 3 | 4;
        /**
         * 值A
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value -20
         * @decimal_digits 2
         */
        threshold_min: number;
        /**
         * 值B
         * @default 0
         * @class_type 属性
         * @max_value 100
         * @min_value -20
         * @decimal_digits 2
         */
        threshold_max: number;
    };
    /**
     * 电流阈值告警设置
     * @class_type 属性
     * @array_length 12
     */
    current_alarm_settings: {
        /**
         * 阈值告警通道
         * @default 0
         * @class_type 属性
         */
        channel: number;
        /**
         * 阈值告警使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 阈值模式 - 1:条件：x<A 2:条件：x>B 3:条件：A≤x≤B 4:条件：x<A或x>B
         * @default 2
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         * @default 1
         * @class_type 属性
         * @max_value 4000
         * @min_value 1
         */
        threshold_min: number;
        /**
         * 值B
         * @default 1
         * @class_type 属性
         * @max_value 4000
         * @min_value 1
         */
        threshold_max: number;
    }[];
    /**
     * 电压阈值告警设置
     * @class_type 属性
     * @array_length 3
     */
    voltage_alarm_settings: {
        /**
         * 阈值告警通道
         * @default 0
         * @class_type 属性
         */
        channel: number;
        /**
         * 阈值告警使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 阈值模式 - 1:条件：x<A 2:条件：x>B 3:条件：A≤x≤B 4:条件：x<A或x>B
         * @default 2
         * @class_type 属性
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         * @default 1
         * @class_type 属性
         * @max_value 500
         * @min_value 1
         */
        threshold_min: number;
        /**
         * 值B
         * @default 1
         * @class_type 属性
         * @max_value 500
         * @min_value 1
         */
        threshold_max: number;
    }[];
    /**
     * THDi阈值告警设置
     * @class_type 属性
     * @array_length 12
     */
    thdi_alarm_settings: {
        /**
         * 阈值告警通道
         * @default 0
         * @class_type 属性
         */
        channel: number;
        /**
         * 阈值告警使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 阈值模式 - 2:条件：x>B
         * @default 2
         * @class_type 属性
         */
        threshold_condition: 2;
        /**
         * 值A
         * @default 1
         * @class_type 属性
         * @max_value 100
         * @min_value 1
         */
        threshold_min: number;
        /**
         * 值B
         * @default 8
         * @class_type 属性
         * @max_value 100
         * @min_value 1
         */
        threshold_max: number;
    }[];
    /**
     * THDv阈值告警设置
     * @class_type 属性
     * @array_length 3
     */
    thdv_alarm_settings: {
        /**
         * 阈值告警通道
         * @default 0
         * @class_type 属性
         */
        channel: number;
        /**
         * 阈值告警使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 阈值模式 - 2:条件：x>B
         * @default 2
         * @class_type 属性
         */
        threshold_condition: 2;
        /**
         * 值A
         * @default 1
         * @class_type 属性
         * @max_value 100
         * @min_value 1
         */
        threshold_min: number;
        /**
         * 值B
         * @default 5
         * @class_type 属性
         * @max_value 100
         * @min_value 1
         */
        threshold_max: number;
    }[];
    /**
     * 电压三相不平衡度告警设置
     * @class_type 属性
     */
    voltage_unbalance_alarm_settings: {
        /**
         * 阈值告警使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        enable: 0 | 1;
        /**
         * 阈值模式 - 2:条件：x>B
         * @default 2
         * @class_type 属性
         */
        threshold_condition: 2;
        /**
         * 值A
         * @default 1
         * @class_type 属性
         * @max_value 100
         * @min_value 1
         */
        threshold_min: number;
        /**
         * 值B
         * @default 3
         * @class_type 属性
         * @max_value 100
         * @min_value 1
         */
        threshold_max: number;
    };
    /**
     * 阈值告警全局设置
     * @class_type 属性
     */
    alarm_global_settings: {
        /**
         * 告警间隔
         * @default 5
         * @class_type 属性
         * @max_value 1440
         * @min_value 1
         */
        interval: number;
        /**
         * 告警次数
         * @default 3
         * @class_type 属性
         * @max_value 1000
         * @min_value 1
         */
        times: number;
        /**
         * 阈值解除上报使能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        release_enable: 0 | 1;
    };
    /**
     * 月度统计时间
     * @class_type 属性
     */
    month_statistics_settings: {
        /**
         * 日
         * @default 1
         * @class_type 属性
         * @max_value 28
         * @min_value 1
         */
        day: number;
        /**
         * 时
         * @default 0
         * @class_type 属性
         * @max_value 23
         * @min_value 0
         */
        hour: number;
        /**
         * 分
         * @default 0
         * @class_type 属性
         * @max_value 59
         * @min_value 0
         */
        minute: number;
    };
    /**
     * 上报参数
     * @class_type 属性
     */
    report_enable: {
        /**
         * 温度 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        temperature: 0 | 1;
        /**
         * 电流有效值 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        current: 0 | 1;
        /**
         * 电压有效值 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        voltage: 0 | 1;
        /**
         * 功率因数 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        power_factor: 0 | 1;
        /**
         * 有功功率 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        active_power: 0 | 1;
        /**
         * 无功功率 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        reactive_power: 0 | 1;
        /**
         * 视在功率 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        apparent_power: 0 | 1;
        /**
         * 正向有功电能 - 0：禁用 1：启用
         * @default 1
         * @class_type 属性
         */
        forward_active_energy: 0 | 1;
        /**
         * 反向有功电能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        reverse_active_energy: 0 | 1;
        /**
         * 正向无功电能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        forward_reactive_energy: 0 | 1;
        /**
         * 反向无功电能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        reverse_reactive_energy: 0 | 1;
        /**
         * 视在电能 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        apparent_energy: 0 | 1;
        /**
         * THDi - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        thdi: 0 | 1;
        /**
         * THDv - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        thdv: 0 | 1;
        /**
         * 电压三相不平衡度 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        voltage_unbalance: 0 | 1;
        /**
         * 预留 - 0：禁用 1：启用
         * @default 0
         * @class_type 属性
         */
        reserved: 0 | 1;
    };
    /**
     * 重置
     * @class_type 服务
     */
    reset?: Record<string, any>;
    /**
     * 重启
     * @class_type 服务
     */
    reboot?: Record<string, any>;
    /**
     * 停止查询回传
     * @class_type 服务
     */
    stop_historical_data_retrieval?: {
        /**
         * 类型 - 0：告警数据 1：周期数据 2：月度能耗数据 3：月度最值数据
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3;
    };
    /**
     * 回传某个时间点的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time?: {
        /**
         * 类型 - 0：告警数据 1：周期数据 2：月度能耗数据 3：月度最值数据
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3;
        /**
         * 时间点
         * @class_type 参数
         */
        time?: number;
    };
    /**
     * 回传某个时间段的历史数据
     * @class_type 服务
     */
    retrieve_historical_data_by_time_range?: {
        /**
         * 类型 - 0：告警数据 1：周期数据 2：月度能耗数据 3：月度最值数据
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3;
        /**
         * 起始时间
         * @class_type 参数
         */
        start_time?: number;
        /**
         * 结束时间
         * @class_type 参数
         */
        end_time?: number;
    };
    /**
     * 查询设备状态
     * @class_type 服务
     */
    query_device_status?: Record<string, any>;
    /**
     * 时间同步
     * @class_type 服务
     */
    synchronize_time?: Record<string, any>;
    /**
     * 时间同步
     * @class_type 服务
     */
    set_time?: {
        /**
         * 时间戳
         * @class_type 参数
         */
        timestamp?: number;
    };
    /**
     * 重新连接网络
     * @class_type 服务
     */
    reconnect?: Record<string, any>;
    /**
     * 清除累计电能
     * @class_type 服务
     */
    reset_energy?: {
        /**
         * 通道序号
         * @default 0
         * @class_type 参数
         * @max_value 12
         * @min_value 0
         */
        channel?: number;
    };
    /**
     * 清除历史记录
     * @class_type 服务
     */
    clear_data?: {
        /**
         * 类型 - 0：告警数据 1：周期数据 2：月度能耗数据 3：月度最值数据
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3;
    };
    /**
     * 查询存储设置
     * @class_type 服务
     */
    query_history_set?: Record<string, any>;
    /**
     * 查询阈值配置
     * @class_type 服务
     */
    query_alarm_set?: {
        /**
         * 阈值类型 - 0：温度阈值 1：电流阈值 2：电压阈值 3：电流总谐波失真 4：电压总谐波失真 5：三相不平衡
         * @default 0
         * @class_type 参数
         */
        type?: 0 | 1 | 2 | 3 | 4 | 5;
    };
}
//# sourceMappingURL=CTH01TSLInfo.d.ts.map