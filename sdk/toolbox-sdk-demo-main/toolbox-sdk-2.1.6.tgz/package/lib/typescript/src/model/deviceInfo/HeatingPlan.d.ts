/**
 * 供暖规则
 */
export interface HeatRule {
    /**
     * 启用
     */
    enable: boolean;
    /**
     * 模式
     * 0: 温度自动控制、1: 阀门开度控制
     */
    mode: 0 | 1;
    /**
     * 目标温度 | 阀门开度
     */
    value: number;
    /**
     * 上报间隔分钟
     */
    period: number;
    /**
     * 分钟数
     */
    time: number;
    /**
     * 1 - 7 表示星期一到星期日
     */
    mask: number[];
}
/**
 * 供暖日期
 */
export interface HeatPeriod {
    enable: boolean;
    period: number;
    startDate: {
        month: number;
        day: number;
    };
    endDate: {
        month: number;
        day: number;
    };
}
/**
 * 供暖计划
 */
export interface HeatingPlan {
    /**
     * 供暖日期
     */
    heatPeriod: HeatPeriod;
    /**
     * 供暖规则
     */
    heatRules: Array<HeatRule>;
}
//# sourceMappingURL=HeatingPlan.d.ts.map