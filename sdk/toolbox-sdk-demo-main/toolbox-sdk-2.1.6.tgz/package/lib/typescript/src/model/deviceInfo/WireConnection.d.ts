export interface Wire {
    rc: number;
    rh: number;
    y1: number;
    gh: number;
    ob: number;
    ob_on_cool: number;
    w1: number;
    em: number;
    pek: number;
    di: number;
    gm: number;
    w2_aux: number;
    y2_gl: number;
    ntc: number;
}
export interface WireConnection {
    wire: Wire;
    wxCfg: {
        sys: number;
        fan: number;
    };
    auxTimeout: {
        enable: boolean;
        time: number;
    };
    comprProtection: {
        enable: boolean;
        time: number;
    };
    ntc: {
        collectInterval: number;
    };
    emCfg: {
        emTimeout: {
            enable: boolean;
            time: number;
        };
        frostProtection: {
            enable: boolean;
            threshold: number;
        };
    };
    roomCard: {
        enable: boolean;
        object: number;
    };
    reversingValve: {
        /** 换向阀模式 - 0：制冷模式 1：制热模式 2：保持配置 */
        mode: 0 | 1 | 2;
    };
}
export declare const DefaultWireConnection: {
    readonly wire: {
        readonly rc: 1;
        readonly rh: 0;
        readonly y1: 0;
        readonly gh: 0;
        readonly ob: 0;
        readonly ob_on_cool: 0;
        readonly w1: 0;
        readonly em: 0;
        readonly pek: 0;
        readonly di: 0;
        readonly w2_aux: 0;
        readonly y2_gl: 0;
        readonly gm: 0;
        readonly ntc: 0;
    };
    readonly wxCfg: {
        readonly sys: 0;
        readonly fan: 1;
    };
    readonly auxTimeout: {
        readonly enable: false;
        readonly time: 15;
    };
    readonly comprProtection: {
        readonly enable: false;
        readonly time: 3;
    };
    readonly emCfg: {
        readonly emTimeout: {
            readonly enable: false;
            readonly time: 5;
        };
        readonly frostProtection: {
            readonly enable: false;
            readonly threshold: 37.4;
        };
    };
    readonly roomCard: {
        readonly enable: false;
        readonly object: 0;
    };
    /** 换向阀 */
    readonly reversingValve: {
        /** 换向阀模式 - 0：制冷模式 1：制热模式 2：保持配置 */
        readonly mode: 2;
    };
    readonly ntc: {
        readonly collectInterval: 30;
    };
};
//# sourceMappingURL=WireConnection.d.ts.map