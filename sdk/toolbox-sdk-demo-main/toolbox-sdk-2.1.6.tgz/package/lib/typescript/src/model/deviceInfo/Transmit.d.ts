export interface Transmit {
    /**
     * 应用模式
     * 1: UDP
     * 2: TCP
     * 3: AWS
     * 4: MQTT
     * 5: IoT Cloud
     * 6: Developer MQTT
     * 7: Developer DTLS
     */
    model: number;
    mqtt?: MqttConfig;
    tcpServers?: Array<TcpServer>;
    udpServers?: Array<UdpServer>;
    tcp?: TcpConfig & ProtocolServerGroup;
    udp?: UdpConfig & ProtocolServerGroup;
    aws?: AwsConfig;
    iotCloud?: ServerStatus;
    developerMqtt?: ServerStatus;
    developerDtls?: DeveloperDtls;
}
export interface DeveloperDtls extends ServerStatus {
    /**
     * 0:不需要确认包 1：需要确认包
     */
    ack: number;
}
export interface ServerStatus {
    /**
     * 0:未连接1:已连接
     */
    serverStatus: number;
}
export interface TcpServer extends ServerStatus {
    /**
     * 序号
     */
    id?: number;
    /**
     * 开关
     */
    enable: boolean;
    /**
     * TCP重连间隔
     */
    retryInterval: number;
    /**
     * TCP重连次数
     */
    retryTimes: number;
    /**
     * TCP保活间隔，单位：秒
     */
    keepInterval: number;
    /**
     * 服务器地址
     */
    serverIp: string;
    /**
     * 服务器端口
     */
    serverPort: number;
}
export interface UdpServer {
    /**
     * 序号
     */
    id?: number;
    /**
     * 开关
     */
    enable: boolean;
    /**
     * 服务器地址
     */
    serverIp: string;
    /**
     * 服务器端口
     */
    serverPort: number;
    /**
     * 0:未连接1:已连接
     */
    serverStatus?: number;
}
export interface ProtocolGroup {
    /**
     * 协议 1：UDP;2：TCP;3：AWS;4：MQTT;5：IoT Cloud
     */
    protocol?: number;
    /**
     * 串口分帧长度
     */
    frameLength?: number;
    /**
     * 串口分帧间隔  单位ms
     */
    frameInterval?: number;
    /**
     * TCP相关配置
     * 旧接口（目前仅UC50XNB支持）
     */
    tcp?: ProtocolServerGroup;
    /**
     * TCP相关配置
     * 新接口，相关配置建议以此为准
     */
    tcpServers?: Array<TcpServer>;
    /**
     * UDP相关配置
     * 旧接口（目前仅UC50XNB支持）
     */
    udp?: ProtocolServerGroup;
    /**
     * UDP相关配置
     * 新接口，相关配置建议以此为准
     */
    udpServers?: Array<UdpServer>;
}
interface MqttConfig extends ServerStatus {
    serverPort: number;
    serverIp: string;
    receiptEnable: boolean;
    name: string;
    password: string;
    clientId: string;
    tlsEnable: boolean;
    tlsProtocol: string;
    rootCert: boolean;
    clientCert: boolean;
    clientKey: boolean;
    upLinkTopic?: string;
    downLinkTopic?: string;
    upLinkQos?: number;
    downLinkQos?: number;
    serialPassthroughUpTopic?: string;
    serialPassthroughDownTopic?: string;
    serialPassthroughUpQos?: number;
    serialPassthroughDownQos?: number;
    /**
     * 证书内容(预配置设备/模板使用)
     */
    rootCertContent?: string;
    clientCertContent?: string;
    clientKeyContent?: string;
    /**
     * 证书校验数据(预配置设备/模板使用)
     */
    rootCertCheckData?: string;
    clientCertCheckData?: string;
    clientKeyCheckData?: string;
    /**
     * 证书文件名(预配置设备/模板使用)
     */
    rootCertFileName?: string;
    clientCertFileName?: string;
    clientKeyFileName?: string;
    /**
     * 以下为UC50XCAT1（物模型）后新用的配置
     * 与serialPassthroughUpTopic等配置类似，只是新的配置将其拆分为rs485和rs232两个配置
     * 新旧接口只会同时存在一种
     */
    rs485PassthroughUpTopic?: string;
    rs485PassthroughDownTopic?: string;
    rs485PassthroughUpQos?: number;
    rs485PassthroughDownQos?: number;
    rs232PassthroughUpTopic?: string;
    rs232PassthroughDownTopic?: string;
    rs232PassthroughUpQos?: number;
    rs232PassthroughDownQos?: number;
    sdiPassthroughUpTopic?: string;
    sdiPassthroughDownTopic?: string;
    sdiPassthroughUpQos?: number;
    sdiPassthroughDownQos?: number;
}
interface TcpConfig {
    serverPort: number;
    serverIp: string;
}
interface UdpConfig {
    serverPort: number;
    serverIp: string;
}
interface AwsConfig extends ServerStatus {
    serverIp: string;
    serverPort: number;
    keepInterval: number;
    rootCert: boolean;
    clientCert: boolean;
    clientKey: boolean;
    /**
     * 证书内容(预配置设备/模板使用)
     */
    rootCertContent?: string;
    clientCertContent?: string;
    clientKeyContent?: string;
    /**
     * 证书校验数据(预配置设备/模板使用)
     */
    rootCertCheckData?: string;
    clientCertCheckData?: string;
    clientKeyCheckData?: string;
    /**
     * 证书文件名(预配置设备/模板使用)
     */
    rootCertFileName?: string;
    clientCertFileName?: string;
    clientKeyFileName?: string;
}
interface ProtocolServerGroup {
    serverEnable1: boolean;
    serverIp1: string;
    serverPort1: number;
    serverEnable2: boolean;
    serverIp2: string;
    serverPort2: number;
    serverStatus1?: number;
    serverStatus2?: number;
    /**
     * 保活间隔  单位s
     */
    keepInterval?: number;
    /**
     * 重连间隔  单位s
     */
    retryInterval?: number;
    /**
     * 重连次数
     */
    retryTimes?: number;
}
export {};
//# sourceMappingURL=Transmit.d.ts.map