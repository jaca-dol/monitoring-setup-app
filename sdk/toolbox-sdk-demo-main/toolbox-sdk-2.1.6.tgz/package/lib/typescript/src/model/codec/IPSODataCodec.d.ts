import { DeviceData } from '../tsl';
import { PartialTSLInfo } from '../tsl';
import { IIPSOService } from '../../service/ipso';
import { IDeviceDataCodec } from './types';
export declare class IPSODataCodec implements IDeviceDataCodec<PartialTSLInfo> {
    type: "ipso";
    codec: IIPSOService;
    /**
     * 需要在下发时进行分帧发送的tsl字段
     * 某些字段下所占用的字节数较大（例如：蜂窝设置、规则引擎设置等），如果全部集中在一帧内是发送不完的
     * 需要筛选出这些字段，分段处理，方便发送时可以进行分帧发送
     */
    private segmentedTSLKeys;
    constructor(codec: IIPSOService);
    getInfo(data: DeviceData): Promise<{
        tsl_version?: string | undefined;
        product_name?: string | undefined;
        product_pn?: string | undefined;
        product_sn?: string | undefined;
        version?: {
            hardware_version?: string | undefined;
            firmware_version?: string | undefined;
        } | undefined;
        oem_id?: string | undefined;
        device_info?: {
            model?: string | undefined;
            submodel_1?: string | undefined;
            submodel_2?: string | undefined;
            submodel_3?: string | undefined;
            submodel_4?: string | undefined;
            pn_1?: string | undefined;
            pn_2?: string | undefined;
            pn_3?: string | undefined;
            pn_4?: string | undefined;
        } | undefined;
        product_frequency_band?: string | undefined;
        device_time?: {
            current_time?: number | undefined;
            running_time?: number | undefined;
            power_on_time?: number | undefined;
        } | undefined;
        battery?: number | undefined;
        battery_info?: {
            battery_capacity?: number | undefined;
            battery_consumption?: number | undefined;
            battery_left?: number | undefined;
            battery_voltage?: number | undefined;
            current_battery_status?: string | undefined;
        } | undefined;
        random_key?: number | undefined;
        device_status?: 0 | 1 | undefined;
        reporting_interval?: {
            unit?: 0 | 1 | undefined;
            seconds_of_time?: number | undefined;
            minutes_of_time?: number | undefined;
        } | undefined;
        collection_interval?: {
            unit?: 0 | 1 | undefined;
            seconds_of_time?: number | undefined;
            minutes_of_time?: number | undefined;
        } | undefined;
        time_zone?: number | undefined;
        daylight_saving_time?: {
            enable?: 0 | 1 | undefined;
            daylight_saving_time_offset?: number | undefined;
            start_month?: number | undefined;
            start_week_num?: number | undefined;
            start_week_day?: number | undefined;
            start_hour_min?: number | undefined;
            end_month?: number | undefined;
            end_week_num?: number | undefined;
            end_week_day?: number | undefined;
            end_hour_min?: number | undefined;
        } | undefined;
        data_storage_settings?: {
            command?: number | undefined;
            enable?: 0 | 1 | undefined;
            retransmission_enable?: 0 | 1 | undefined;
            retransmission_interval?: number | undefined;
            retrieval_interval?: number | undefined;
        } | undefined;
        timestamp?: number | undefined;
        cumulative_times?: number | undefined;
        button_lock?: {
            enable?: 0 | 1 | undefined;
            lock_type?: 0 | 1 | 2 | undefined;
        } | undefined;
        work_mode?: 0 | 3 | undefined;
        history?: Record<string, any>[] | undefined;
        sub_version?: {
            patch_enable?: 0 | 1 | undefined;
            sub_id?: number | undefined;
            version?: string | undefined;
        } | undefined;
        lorawan_status?: {
            command?: string | undefined;
            eui?: string | undefined;
            join_status?: 0 | 1 | undefined;
            signal?: {
                rssi?: number | undefined;
                snr?: number | undefined;
            } | undefined;
            channel_mask?: string | undefined;
            frame_counter?: {
                uplink?: number | undefined;
                downlink?: number | undefined;
            } | undefined;
        } | undefined;
        lorawan_configuration_settings?: {
            command?: string | undefined;
            mode?: 0 | 1 | 2 | undefined;
            join_type?: 0 | 1 | undefined;
            adr_mode?: 0 | 1 | undefined;
            netid?: string | undefined;
            devaddr?: string | undefined;
            deveui?: string | undefined;
            appeui?: string | undefined;
            nwkskey?: string | undefined;
            appskey?: string | undefined;
            appkey?: string | undefined;
            rx1_open_delay?: number | undefined;
            rx2_open_delay?: number | undefined;
            join_rx1_open_delay?: number | undefined;
            join_rx2_open_delay?: number | undefined;
            tx_power?: 0 | 1 | 2 | 3 | 7 | 4 | 5 | 6 | undefined;
            app_port?: number | undefined;
            confirmed_mode?: 0 | 1 | undefined;
            channel_mask?: string | undefined;
            channels_settings?: {
                enable: 0 | 1;
                index: number;
                frequency: number;
                data_rate_min: number;
                data_rate_max: number;
            }[] | undefined;
            tx_data_rate?: 0 | 1 | 2 | 3 | 4 | 5 | undefined;
            rx2_frequency?: number | undefined;
            rx2_data_rate?: 0 | 1 | 2 | 3 | 4 | 5 | undefined;
            duty_cycle?: number | undefined;
            duty_cycle_enable?: 0 | 1 | undefined;
            ack_retry_times?: number | undefined;
            frequency_band?: 0 | 2 | 3 | 7 | 4 | 5 | 10 | 6 | undefined;
            version?: 1 | 2 | 3 | undefined;
            number_of_link_detection_signals?: number | undefined;
            rejoin_mode_enable?: 0 | 1 | undefined;
            AS923_frequency_band_in_use?: 0 | 1 | 2 | 3 | undefined;
            pingslot_periodicity?: 0 | 1 | 2 | 3 | 7 | 4 | 5 | 6 | undefined;
            d2d_key?: string | undefined;
            multicast_group_settings?: {
                command?: string | undefined;
                group_1_enable?: 0 | 1 | undefined;
                group_1_pingslot_periodicity?: number | undefined;
                group_1_data_rate?: number | undefined;
                group_1_frequency?: number | undefined;
                group_1_devaddr?: string | undefined;
                group_1_nwkskey?: string | undefined;
                group_1_appskey?: string | undefined;
                group_2_enable?: 0 | 1 | undefined;
                group_2_pingslot_periodicity?: number | undefined;
                group_2_data_rate?: number | undefined;
                group_2_frequency?: number | undefined;
                group_2_devaddr?: string | undefined;
                group_2_nwkskey?: string | undefined;
                group_2_appskey?: string | undefined;
                group_3_enable?: 0 | 1 | undefined;
                group_3_pingslot_periodicity?: number | undefined;
                group_3_data_rate?: number | undefined;
                group_3_frequency?: number | undefined;
                group_3_devaddr?: string | undefined;
                group_3_nwkskey?: string | undefined;
                group_3_appskey?: string | undefined;
                group_4_enable?: 0 | 1 | undefined;
                group_4_pingslot_periodicity?: number | undefined;
                group_4_data_rate?: number | undefined;
                group_4_frequency?: number | undefined;
                group_4_devaddr?: string | undefined;
                group_4_nwkskey?: string | undefined;
                group_4_appskey?: string | undefined;
            } | undefined;
        } | undefined;
        d2d_pairing_enable?: 0 | 1 | undefined;
        d2d_pairing_settings?: {
            index: number;
            type?: number | undefined;
            enable: 0 | 1;
            deveui: string;
            name_first: string;
            name_last: string;
        }[] | undefined;
        d2d_master_enable?: 0 | 1 | undefined;
        d2d_slave_enable?: 0 | 1 | undefined;
        cellular_status?: {
            command?: number | undefined;
            register_status?: 0 | 1 | undefined;
            sim_status?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | undefined;
            imei?: string | undefined;
            imsi?: string | undefined;
            iccid?: string | undefined;
            csq?: number | undefined;
            connected_status?: 0 | 1 | undefined;
            milesight_mqtt_status?: 0 | 1 | undefined;
            milesight_dtls_status?: 0 | 1 | undefined;
        } | undefined;
        cellular_settings?: {
            command?: number | undefined;
            work_mode?: 0 | 3 | undefined;
            transport_type?: 1 | 2 | 3 | 7 | 4 | 6 | undefined;
            network?: {
                command?: number | undefined;
                apn?: string | undefined;
                auth_mode?: 0 | 1 | 2 | undefined;
                auth_username?: string | undefined;
                password?: string | undefined;
                pin?: string | undefined;
                type?: 0 | 1 | 2 | undefined;
            } | undefined;
            mqtt_settings?: {
                command?: number | undefined;
                server_address?: string | undefined;
                server_port?: number | undefined;
                keepalive_interval?: number | undefined;
                client_id?: string | undefined;
                auth_enable?: 0 | 1 | undefined;
                auth_username?: string | undefined;
                auth_password?: string | undefined;
                enable_tls?: 0 | 1 | undefined;
                enable_ca_certificate?: 0 | 1 | undefined;
                ca_certificate_length?: number | undefined;
                ca_certificate?: string | undefined;
                enable_client_certificate?: 0 | 1 | undefined;
                client_certificate_length?: number | undefined;
                client_certificate?: string | undefined;
                enable_key_certificate?: 0 | 1 | undefined;
                key_certificate_length?: number | undefined;
                key_certificate?: string | undefined;
                uplink_topic?: string | undefined;
                uplink_qos?: 0 | 1 | 2 | undefined;
                downlink_topic?: string | undefined;
                downlink_qos?: 0 | 1 | 2 | undefined;
                rs485_uplink_topic?: string | undefined;
                rs485_uplink_qos?: 0 | 1 | 2 | undefined;
                rs485_downlink_topic?: string | undefined;
                rs485_downlink_qos?: 0 | 1 | 2 | undefined;
                rs232_uplink_topic?: string | undefined;
                rs232_uplink_qos?: 0 | 1 | 2 | undefined;
                rs232_downlink_topic?: string | undefined;
                rs232_downlink_qos?: 0 | 1 | 2 | undefined;
                sdi_uplink_topic?: string | undefined;
                sdi_uplink_qos?: 0 | 1 | 2 | undefined;
                sdi_downlink_topic?: string | undefined;
                sdi_downlink_qos?: 0 | 1 | 2 | undefined;
                mqtt_status?: 0 | 1 | undefined;
            } | undefined;
            aws_settings?: {
                command?: number | undefined;
                server_address?: string | undefined;
                server_port?: number | undefined;
                keepalive_interval?: number | undefined;
                enable_ca_certificate?: 0 | 1 | undefined;
                ca_certificate_length?: number | undefined;
                ca_certificate?: string | undefined;
                enable_client_certificate?: 0 | 1 | undefined;
                client_certificate_length?: number | undefined;
                client_certificate?: string | undefined;
                enable_key_certificate?: 0 | 1 | undefined;
                key_certificate_length?: number | undefined;
                key_certificate?: string | undefined;
                aws_status?: 0 | 1 | undefined;
            } | undefined;
            tcp_settings?: {
                id: number;
                command?: number | undefined;
                enable: 0 | 1;
                server_address: string;
                server_port: number;
                retry_count: number;
                retry_interval: number;
                keepalive_interval: number;
                tcp_status?: 0 | 1 | undefined;
            }[] | undefined;
            udp_settings?: {
                id: number;
                command?: number | undefined;
                enable: 0 | 1;
                server_address: string;
                server_port: number;
                udp_status?: 0 | 1 | undefined;
            }[] | undefined;
            milesight_mqtt_settings?: {
                command?: number | undefined;
                status?: 0 | 1 | undefined;
            } | undefined;
            milesight_dtls_settings?: {
                command?: number | undefined;
                status?: 0 | 1 | undefined;
            } | undefined;
        } | undefined;
        request_root_file_transfer?: {
            operate_type?: 0 | 1 | undefined;
            cert_type?: 3 | 4 | undefined;
            length?: number | undefined;
            data?: string | undefined;
        } | undefined;
        request_dev_file_transfer?: {
            operate_type?: 0 | 1 | undefined;
            cert_type?: 3 | 4 | undefined;
            length?: number | undefined;
            data?: string | undefined;
        } | undefined;
        request_private_file_transfer?: {
            operate_type?: 0 | 1 | undefined;
            cert_type?: 3 | 4 | undefined;
            length?: number | undefined;
            data?: string | undefined;
        } | undefined;
        request_check_sequence_number?: {
            sequence_number?: number | undefined;
        } | undefined;
        check_sequence_number_reply?: {
            sequence_number?: number | undefined;
        } | undefined;
        request_check_order?: {
            order?: number | undefined;
        } | undefined;
        check_order_reply?: {
            order?: number | undefined;
        } | undefined;
        request_password_check?: {
            password?: string | undefined;
        } | undefined;
        password_check_reply?: {
            result?: 0 | 1 | undefined;
        } | undefined;
        request_password_change?: {
            new_password?: string | undefined;
        } | undefined;
        password_change_reply?: {
            result?: 0 | 1 | undefined;
        } | undefined;
        request_security_password_check?: {
            length?: number | undefined;
            password?: string | undefined;
        } | undefined;
        security_password_check_reply?: {
            result?: 0 | 1 | undefined;
            successful_message?: {
                [x: string]: any;
            } | undefined;
            failed_message?: {
                locked_time?: number | undefined;
            } | undefined;
        } | undefined;
        request_security_password_change?: {
            length?: number | undefined;
            new_password?: string | undefined;
        } | undefined;
        security_password_change_reply?: {
            result?: 0 | 1 | 2 | undefined;
        } | undefined;
        request_firmware_upgrade?: {
            start_upgrade?: {
                type?: 0 | 1 | 2 | undefined;
                length?: number | undefined;
                check_data?: number[] | undefined;
            } | undefined;
            transmission?: {
                length?: number | undefined;
                data?: number[] | undefined;
            } | undefined;
            end_upgrade?: number | undefined;
            continue_upgrade?: number | undefined;
            completion_check?: {
                length?: number | undefined;
                data?: any[] | undefined;
            } | undefined;
        } | undefined;
        firmware_upgrade_reply?: {
            start_upgrade?: {
                result?: 0 | 1 | 2 | undefined;
                length?: number | undefined;
            } | undefined;
            transmission?: {
                result?: 0 | 1 | undefined;
            } | undefined;
            end_upgrade?: {
                result?: 0 | 1 | 2 | undefined;
            } | undefined;
            continue_upgrade?: {
                result?: 0 | 1 | undefined;
            } | undefined;
            completion_check?: {
                result?: 0 | 1 | undefined;
            } | undefined;
        } | undefined;
        req?: string[] | undefined;
        request_command_queries?: {
            query_information?: number | undefined;
            length?: number | undefined;
            object_command?: string | undefined;
        } | undefined;
        command_queries_reply?: {
            result?: 0 | 1 | 2 | 3 | 7 | 4 | 5 | 8 | 9 | 6 | undefined;
            length?: number | undefined;
            the_command_in_reply?: string | undefined;
        } | undefined;
        request_query_all_configurations?: number | undefined;
        all_configurations_request_by_device?: number | undefined;
        reset?: number | undefined;
        reboot?: number | undefined;
        clear_historical_data?: number | undefined;
        stop_historical_data_retrieval?: number | undefined;
        retrieve_historical_data_by_time?: {
            time?: number | undefined;
        } | undefined;
        request_historical_data_export?: {
            command?: number | undefined;
            start_exporting?: {
                start_timestamp?: number | undefined;
                end_timestamp?: number | undefined;
                current_timestamp?: number | undefined;
            } | undefined;
            exported_data?: {
                [x: string]: any;
            } | undefined;
            end_exporting?: {
                [x: string]: any;
            } | undefined;
            exported_all_data?: {
                [x: string]: any;
            } | undefined;
            start_exporting_with_type?: {
                type?: number | undefined;
                start_timestamp?: number | undefined;
                end_timestamp?: number | undefined;
                current_timestamp?: number | undefined;
            } | undefined;
        } | undefined;
        historical_data_export_reply?: {
            command?: number | undefined;
            start_exporting?: {
                quantity_of_data?: number | undefined;
                length?: number | undefined;
                max_length?: number | undefined;
            } | undefined;
            exported_data?: {
                length?: number | undefined;
                data?: any[] | undefined;
            } | undefined;
            end_exporting?: {
                result?: 0 | 1 | undefined;
            } | undefined;
            exported_all_data?: {
                [x: string]: any;
            } | undefined;
            start_exporting_with_type?: {
                quantity_of_data?: number | undefined;
                length?: number | undefined;
                max_length?: number | undefined;
            } | undefined;
        } | undefined;
        query_device_status?: number | undefined;
        synchronize_time?: number | undefined;
        set_time?: {
            timestamp?: number | undefined;
        } | undefined;
        reconnect?: number | undefined;
        gpio_1_debug?: {
            command?: number | undefined;
            start_count?: {
                [x: string]: any;
            } | undefined;
            stop_count?: {
                [x: string]: any;
            } | undefined;
            config_count?: number | undefined;
            switch_state?: {
                [x: string]: any;
            } | undefined;
        } | undefined;
        gpio_2_debug?: {
            command?: number | undefined;
            start_count?: {
                [x: string]: any;
            } | undefined;
            stop_count?: {
                [x: string]: any;
            } | undefined;
            config_count?: number | undefined;
            switch_state?: {
                [x: string]: any;
            } | undefined;
        } | undefined;
        upload_certificate?: {
            [x: string]: any;
        } | undefined;
        collect_all_modbus_channels?: number | undefined;
        req_read_single_modbus?: number | undefined;
        collect_all_sdi_channels?: number | undefined;
        collect_single_sdi_channels?: {
            channel_id?: number | undefined;
        } | undefined;
        collect_ai1?: number | undefined;
        collect_ai2?: number | undefined;
        device_status_control?: {
            state?: 0 | 1 | undefined;
        } | undefined;
        ble_pair_info?: {
            addr_type?: 0 | 1 | undefined;
            address?: string | undefined;
            name?: string | undefined;
        } | undefined;
        ble_phone_name?: {
            length?: number | undefined;
            value?: string | undefined;
        } | undefined;
        submodule_info?: {
            version_1?: {
                context?: {
                    patch_enable?: 0 | 1 | undefined;
                    version?: string | undefined;
                } | undefined;
            } | undefined;
            version_2?: {
                length?: number | undefined;
                context?: {
                    patch_enable: 0 | 1;
                    version: string;
                }[] | undefined;
            } | undefined;
        } | undefined;
        reset_energy?: {
            channel?: number | undefined;
        } | undefined;
        clear_data?: {
            type?: 0 | 1 | 2 | 3 | undefined;
        } | undefined;
        vaping_index?: number | undefined;
        vaping_index_alarm?: {
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            alarm_deactivation?: {
                vaping_index?: number | undefined;
            } | undefined;
            alarm_trigger?: {
                vaping_index?: number | undefined;
            } | undefined;
            interference_alarm_deactivation?: {
                [x: string]: any;
            } | undefined;
            interference_alarm_trigger?: {
                [x: string]: any;
            } | undefined;
        } | undefined;
        pm1_0?: number | undefined;
        pm1_0_alarm?: {
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            alarm_deactivation?: {
                pm1_0?: number | undefined;
            } | undefined;
            alarm_trigger?: {
                pm1_0?: number | undefined;
            } | undefined;
        } | undefined;
        pm2_5?: number | undefined;
        pm2_5_alarm?: {
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            alarm_deactivation?: {
                pm2_5?: number | undefined;
            } | undefined;
            alarm_trigger?: {
                pm2_5?: number | undefined;
            } | undefined;
        } | undefined;
        pm10?: number | undefined;
        pm10_alarm?: {
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            alarm_deactivation?: {
                pm10?: number | undefined;
            } | undefined;
            alarm_trigger?: {
                pm10?: number | undefined;
            } | undefined;
        } | undefined;
        temperature?: number | undefined;
        temperature_alarm?: {
            type?: number | undefined;
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            no_data?: {
                [x: string]: any;
            } | undefined;
            alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            burning_alarm_deactivation?: {
                [x: string]: any;
            } | undefined;
            burning_alarm_trigger?: {
                [x: string]: any;
            } | undefined;
            lower_range_alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            lower_range_alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            over_range_alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            over_range_alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            within_range_alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            within_range_alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            exceed_range_alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            exceed_range_alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            persistent_low_temperature_alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            persistent_low_temperature_alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            persistent_high_alarm_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            persistent_high_alarm_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            anti_freeze_protection_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            anti_freeze_protection_trigger?: {
                temperature?: number | undefined;
            } | undefined;
            window_status_detection_deactivation?: {
                temperature?: number | undefined;
            } | undefined;
            window_status_detection_trigger?: {
                temperature?: number | undefined;
            } | undefined;
        } | undefined;
        high_temperature_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            difference_in_temperature?: number | undefined;
            duration?: number | undefined;
        } | undefined;
        low_temperature_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            difference_in_temperature?: number | undefined;
            duration?: number | undefined;
        } | undefined;
        humidity?: number | undefined;
        humidity_alarm?: {
            type?: number | undefined;
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            no_data?: {
                [x: string]: any;
            } | undefined;
            lower_range_alarm_deactivation?: {
                humidity?: number | undefined;
            } | undefined;
            lower_range_alarm_trigger?: {
                humidity?: number | undefined;
            } | undefined;
            over_range_alarm_deactivation?: {
                humidity?: number | undefined;
            } | undefined;
            over_range_alarm_trigger?: {
                humidity?: number | undefined;
            } | undefined;
            within_range_alarm_deactivation?: {
                humidity?: number | undefined;
            } | undefined;
            within_range_alarm_trigger?: {
                humidity?: number | undefined;
            } | undefined;
            exceed_range_alarm_deactivation?: {
                humidity?: number | undefined;
            } | undefined;
            exceed_range_alarm_trigger?: {
                humidity?: number | undefined;
            } | undefined;
            mutation_alarm_trigger_no_mutation?: {
                humidity?: number | undefined;
            } | undefined;
            mutation_alarm_trigger?: {
                humidity?: number | undefined;
                saltation?: number | undefined;
            } | undefined;
        } | undefined;
        tvoc?: number | undefined;
        tvoc_alarm?: {
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            alarm_deactivation?: {
                tvoc?: number | undefined;
            } | undefined;
            alarm_trigger?: {
                tvoc?: number | undefined;
            } | undefined;
        } | undefined;
        tamper_status?: 0 | 1 | undefined;
        tamper_status_alarm?: {
            normal?: {
                [x: string]: any;
            } | undefined;
            trigger?: {
                [x: string]: any;
            } | undefined;
        } | undefined;
        tvoc_raw_data_1?: {
            rmox_0?: number | undefined;
            rmox_1?: number | undefined;
        } | undefined;
        tvoc_raw_data_2?: {
            rmox_2?: number | undefined;
            rmox_3?: number | undefined;
        } | undefined;
        tvoc_raw_data_3?: {
            rmox_4?: number | undefined;
            rmox_5?: number | undefined;
        } | undefined;
        tvoc_raw_data_4?: {
            rmox_6?: number | undefined;
            rmox_7?: number | undefined;
        } | undefined;
        tvoc_raw_data_5?: {
            rmox_8?: number | undefined;
            rmox_9?: number | undefined;
        } | undefined;
        tvoc_raw_data_6?: {
            rmox_10?: number | undefined;
            rmox_11?: number | undefined;
        } | undefined;
        tvoc_raw_data_7?: {
            rmox_12?: number | undefined;
            zmod4510_rmox3?: number | undefined;
        } | undefined;
        tvoc_raw_data_8?: {
            log_rcda?: number | undefined;
            rhtr?: number | undefined;
        } | undefined;
        tvoc_raw_data_9?: {
            temperature?: number | undefined;
            iaq?: number | undefined;
        } | undefined;
        tvoc_raw_data_10?: {
            tvoc?: number | undefined;
            etoh?: number | undefined;
        } | undefined;
        tvoc_raw_data_11?: {
            co2?: number | undefined;
            rel_iaq?: number | undefined;
        } | undefined;
        temperature_unit?: 0 | 1 | undefined;
        tvoc_raw_reporting_enable?: 0 | 1 | undefined;
        temperature_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        humidity_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        pm1_0_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        pm2_5_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        pm10_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        tvoc_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        vaping_index_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_min?: number | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        alarm_reporting_times?: number | undefined;
        alarm_deactivation_enable?: 0 | 1 | undefined;
        temperature_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        humidity_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        pm1_0_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        pm2_5_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        pm10_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        tvoc_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        vaping_index_calibration_settings?: {
            enable?: 0 | 1 | undefined;
            calibration_value?: number | undefined;
        } | undefined;
        execute_tvoc_self_clean?: number | undefined;
        set_retrieval_initial_surface?: {
            operation?: 0 | 1 | undefined;
        } | undefined;
        debugging_commands?: {
            length?: number | undefined;
            content?: string | undefined;
        } | undefined;
        set_zero_calibration?: {
            operation?: 0 | 1 | undefined;
        } | undefined;
        sensor_id?: {
            type?: 0 | 1 | 2 | undefined;
            id?: string | undefined;
        } | undefined;
        calibrate_motor?: number | undefined;
        tilt_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_max?: number | undefined;
            duration?: number | undefined;
        } | undefined;
        tilt_alarm?: {
            type?: number | undefined;
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            no_data?: {
                [x: string]: any;
            } | undefined;
            threshold_alarm_deactivation?: {
                [x: string]: any;
            } | undefined;
            threshold_alarm_trigger?: {
                [x: string]: any;
            } | undefined;
            falling_alarm_trigger?: {
                [x: string]: any;
            } | undefined;
        } | undefined;
        light_alarm?: {
            type?: number | undefined;
            collection_error?: {
                [x: string]: any;
            } | undefined;
            lower_range_error?: {
                [x: string]: any;
            } | undefined;
            over_range_error?: {
                [x: string]: any;
            } | undefined;
            no_data?: {
                [x: string]: any;
            } | undefined;
            threshold_alarm_deactivation?: {
                [x: string]: any;
            } | undefined;
            threshold_alarm_trigger?: {
                [x: string]: any;
            } | undefined;
        } | undefined;
        light_alarm_settings?: {
            enable?: 0 | 1 | undefined;
            threshold_condition?: 0 | 1 | 2 | 3 | 4 | undefined;
            threshold_max?: number | undefined;
        } | undefined;
        light_collection_interval?: {
            unit?: 0 | 1 | undefined;
            seconds_of_time?: number | undefined;
            minutes_of_time?: number | undefined;
        } | undefined;
        light_tolerance_value?: number | undefined;
        falling_alarm_settings?: {
            enable?: 0 | 1 | undefined;
        } | undefined;
        falling_threshold_alarm_settings?: {
            threshold_level?: 0 | 1 | 2 | 3 | 7 | 4 | 5 | 6 | undefined;
            time_level?: number | undefined;
        } | undefined;
    }>;
    setInfo(writeTslInfo: PartialTSLInfo, ipsoData: number[], writeContext?: PartialTSLInfo): ReturnType<IDeviceDataCodec['setInfo']>;
    getHistoryInfo(data: DeviceData, _model: string, _firmwareVersion: string, _hardwareVersion: string): Promise<any>;
    /**
     * 设置编解码器上下文，加载设备解析资源
     * 避免在没读设备时要做编解码，无法解析的问题
     * @param model - 设备型号
     * @param tslVersion - 物模型版本
     */
    setCodecContext({ model, tslVersion }: {
        model: string;
        tslVersion: string;
    }): void;
    /**
     * 处理要写入的TSL信息
     * @param writeTslInfo - 要写入的TSL信息
     * @param ipsoData - 读取的原始ipso数据
     * @param writeContext - 写入上下文
     */
    private handleWriteTslInfo;
}
//# sourceMappingURL=IPSODataCodec.d.ts.map