import { Interface2Output } from './InterfaceOutput';
import { ProtocolGroup } from './Transmit';
/**
 * RS485设置
 * UC50X、UC50XNB、UC50XNB-CAT1...
 */
export interface RS485Setting extends OldInterface2Output, Interface2Output, ProtocolGroup {
    /**
     * 是否启用
     */
    enable: boolean;
    /**
     * Modbus协议主动透传开关
     */
    throughEnable?: boolean;
    /**
     * 波特率
     */
    baud: number;
    /**
     * 数据位
     */
    dataBits: number;
    /**
     * 停止位
     */
    stopBits: number;
    /**
     * 校验位
     * 0: 无校验 1: 奇校验 2: 偶校验
     */
    parity: number;
    /**
     * 命令执行时间间隔
     */
    executionInterval: number;
    /**
     * 最大响应时间
     */
    maxRespTime: number;
    /**
     * 最大重试次数
     */
    maxRetryTimes: number;
    /**
     * RS485连接LoRaWAN
     * 仅LoRa设备支持
     */
    bridgeLoraWan?: boolean;
    /**
     * 透传模式
     * 仅LoRa设备支持
     */
    throughMode?: number;
    /**
     * 透传端口
     * 仅LoRa设备支持
     */
    port?: number;
}
/**
 * 仅在UC50X设备中使用
 */
interface OldInterface2Output {
    /**
     * interface 1(Pin 1) 5/9/12V输出
     *
     * 已废弃：不再推荐使用此字段。
     */
    interface1Output?: boolean;
    /**
     * interface 1(Pin 1) 5/9/12V输出 采集前供电时间
     *
     * 已废弃：不再推荐使用此字段。
     */
    powerOutputTime?: number;
    /**
     * interface 1(Pin 2) 3.3v输出
     * 新版本(V1.0 1.17, V2.0 1.10)UC50X特有
     *
     * 已废弃：不再推荐使用此字段。
     */
    interface1v3Output?: boolean;
    /**
     * interface 1(Pin 2) 3.3v 供电方式
     * 0: 持续供电、1: 可配置供电时间
     * 新版本(V1.0 1.17, V2.0 1.10)UC50X特有
     *
     * 已废弃:不再推荐使用此字段。
     */
    interface1v3OutputType?: number;
    /**
     * interface 1(Pin 2) 3.3v 采集前供电时间
     * 新版本(V1.0 1.17, V2.0 1.10)UC50X特有
     *
     * 已废弃:不再推荐使用此字段。
     */
    interface1v3OutputTime?: number;
    /**
     * 供电电流
     *
     * 已废弃：不再推荐使用此字段。
     */
    interface1v3Current?: number;
    interface1v12Current?: number;
}
export {};
//# sourceMappingURL=RS485Setting.d.ts.map