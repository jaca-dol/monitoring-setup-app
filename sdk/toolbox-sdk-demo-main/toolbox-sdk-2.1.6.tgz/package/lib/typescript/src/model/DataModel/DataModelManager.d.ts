import "reflect-metadata";
import { DeviceInfo } from '../deviceInfo/DeviceInfo';
import { DataType, ModelData, IDeviceDataModel, IDeviceDataModelManager, DataModelConstructor } from '../tsl';
declare class DeviceDataModelManager implements IDeviceDataModelManager {
    dataModels: Map<string, DataModelConstructor>;
    constructor();
    register(name: string, constructor: DataModelConstructor): void;
    get(name: string): IDeviceDataModel;
    load(data: ModelData, dataType: DataType, context?: Record<string, any>): IDeviceDataModel;
    loadDeviceInfo(deviceInfo: DeviceInfo, dataType: DataType, context?: Record<string, any>): IDeviceDataModel;
}
export declare const DataModelManager: DeviceDataModelManager;
export {};
//# sourceMappingURL=DataModelManager.d.ts.map