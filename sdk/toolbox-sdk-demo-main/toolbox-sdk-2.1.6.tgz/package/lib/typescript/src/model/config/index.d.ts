export * from './DeviceConfigManager';
//# sourceMappingURL=index.d.ts.map