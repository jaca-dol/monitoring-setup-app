import { StatusDeviceInfo } from './StatusDeviceInfo';
import { GeneralDeviceInfo, StrictGeneralDeviceInfo } from './GeneralDeviceInfo';
import { SensorDeviceInfo } from './SensorDeviceInfo';
/**
 * 设备特定的配置信息\
 * 可以通过模块扩展的方式来动态增加设备特定的配置信息
 */
export interface DeviceSpecificInfo {
}
/**
 * 用于扩展支持设置项的接口\
 * 主要用于 DeviceSettingService类中去扩展设备特定支持的设置项，通过模块扩展的方式扩展支持设置项
 */
export interface DeviceSettingServiceExtendSupportSettingKey {
}
/**
 * 设备信息（状态数据和通用数据和传感器数据的集合）
 * FlashInfo的超集(扩展了一些 App 业务需要使用到的设备信息)
 * @group 设备信息
 */
export type DeviceInfo = StatusDeviceInfo & GeneralDeviceInfo & SensorDeviceInfo & DeviceSpecificInfo;
export type StrictDeviceInfo = StatusDeviceInfo & StrictGeneralDeviceInfo & SensorDeviceInfo & DeviceSpecificInfo;
/**
 * 设备信息
 * 将设备信息中的可选属性变为必选属性
 */
export type RequiredDeviceInfo = Required<DeviceInfo>;
/**
 * 可选设备信息
 */
export type PartialDeviceInfo = Partial<RemoveIndexSignature<DeviceInfo>>;
/**
 * 从一个类型 T 中移除所有的索引签名 (index signatures)，只保留那些显式声明的属性
 */
type RemoveIndexSignature<T> = {
    [K in keyof T as string extends K ? never : number extends K ? never : K]: T[K];
};
/**
 * 设备设置信息
 */
export type DeviceSettingInfo = Omit<RemoveIndexSignature<DeviceInfo>, 'status' | 'battery' | 'deviceEui' | 'channelMask' | 'downLinkFrameCounter' | 'hardwareVersion' | 'firmwareVersion' | 'joinStatus' | 'statusModel' | 'sn' | 'rssi' | 'snr' | 'upLinkFrameCounter' | 'updateTime'>;
/**
 * 设备最基本的信息，所有设备都有的
 */
export type BasicDeviceInfo = Pick<GeneralDeviceInfo, 'status' | 'sn' | 'model' | 'oem' | 'firmwareVersion' | 'hardwareVersion' | 'deviceState' | 'reportingInterval' | 'deviceTime' | 'password'>;
/**
 * 设备产品信息
 */
export type DeviceProductInfo = Pick<DeviceInfo, 'model' | 'sn' | 'pn' | 'oem' | 'firmwareVersion' | 'hardwareVersion' | 'status' | 'deviceState' | 'deviceInformation' | 'subVersion'> & {
    /**
     * 是否支持差分升级\
     * 在 application 下默认返回 true，在 bootloader 可能会因为差分镜像还原失败返回 false
     * @default true
     */
    canPatchUpgrade: boolean;
    submoduleInfo?: string[];
};
/**
 * 设备Flash信息
 * 解析库解析设备数据后返回的Flash信息
 */
export type FlashInfo = Omit<RemoveIndexSignature<DeviceInfo>, 'statusModel' | 'modelSeries' | 'updateTime' | 'applyFromTemplate' | 'readMode' | 'readSignal'>;
export {};
//# sourceMappingURL=DeviceInfo.d.ts.map