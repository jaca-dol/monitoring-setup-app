import { SensorData } from "./SensorDeviceInfo";
import { CollectMetricDataType } from './MetricType';
/**
 * 传感器指标设置
 */
export interface SensorMetricSettings {
    enable: SensorData['enable'];
    unit: SensorData['unit'];
    report: SensorData['report'];
    globalCollectInterval: SensorData['globalCollectInterval'];
    calibration: SensorData['calibration'];
    threshold: SensorData['threshold'];
}
export type MetricSettings = SensorMetricSettings | Record<string, any>;
export interface CollectMetricSettings extends SensorMetricSettings {
    dataType: CollectMetricDataType;
}
//# sourceMappingURL=MetricSettings.d.ts.map