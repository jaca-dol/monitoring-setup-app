import { DeviceInfo } from '../deviceInfo/DeviceInfo';
import { AttributeDefinition, IAttribute, IDeviceDataModel, ModelData } from '../tsl';
export declare class DataModel<Data extends ModelData = ModelData> implements IDeviceDataModel<Data> {
    attributes: IAttribute[];
    data: Data;
    attributeGroup?: string | string[];
    context: Record<string, any>;
    constructor(attributeDefinitions?: AttributeDefinition[]);
    init(data: Data): void;
    getData(): Data;
    get<T = any>(name: string): T;
    getContext(): Record<string, any>;
    set(name: string, value: any): void;
    /**
     * 设置属性分组
     */
    setAttributeGroup(group: string): void;
    /**
     * 上下文数据
     * @param context - 上下文数据
     */
    setContext(context: Record<string, any>): void;
    fromDeviceInfo(deviceInfo: Partial<DeviceInfo>): void;
    toDeviceInfo(options?: {
        status?: boolean;
        data?: ModelData;
    }): DeviceInfo;
    toDeviceHistoryInfo(historyInfo: {
        history: Array<{
            [key: string]: any;
        }>;
    } & ModelData): Array<{
        [key: string]: any;
    }>;
    /**
     * 转换设备信息状态
     */
    protected toDeviceInfoStatus(deviceInfo: DeviceInfo): DeviceInfo['status'];
    /***
     * 获取属性
     */
    protected getAttribute(key: string, direction: "up" | "down" | "both" | undefined, group: string | string[]): IAttribute | undefined;
    toJSON(): string;
    toDeviceInfoJSON(): string;
    /**
     * 从模型数据中获取Attribute分组
     */
    protected getGroupFromData(data: ModelData): string | string[];
    /**
     * 从设备信息中获取Attribute分组
     */
    protected getGroupFromDeviceInfo(deviceInfo: Partial<DeviceInfo>): string | string[];
    /**
 * 按层级逐层处理数据
 * @param data - 要处理的数据
 * @param handler - 处理函数
 * @param handledKeys - 已处理的键集合
 * @param parentKey - 当前层级（用于递归）
 */
    protected processDataByLevel(data: any, handler: (value: any, key: string) => void, handledKeys: Set<string>, parentKey?: string): void;
    /**
     * 处理数据
     * @param data - 数据
     * @param processCallback - 处理回调
     */
    protected processData(
    /**
     * 要处理的数据
     */
    data: ModelData | Partial<DeviceInfo>, 
    /**
     * 数据处理回调
     * @param value - 值
     * @param key - 键
     * @returns 处理过的key或者undefined
     */
    processCallback: (value: any, key: string) => string | void): void;
}
//# sourceMappingURL=DataModel.d.ts.map