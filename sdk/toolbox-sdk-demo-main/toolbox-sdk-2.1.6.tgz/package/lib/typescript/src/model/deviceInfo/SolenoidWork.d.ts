/**
 * UC51X 电磁阀计划任务配置
*/
export interface SolenoidWork {
    /**
     * 区分数组对象
     */
    id: number;
    /**
     * 启用任务
     */
    enable: boolean;
    /**
     * 工作状态
     */
    workState: 0 | 1;
    /**
     * 控制阀门
     */
    controlObject: 0 | 1 | 2 | 3;
    /**
     * 周期几
     * 周一周二为[1,2] 全部为[1,2,3,4,5,6,7]
     */
    repeat: number[];
    /**
     * 起始时间-时
     */
    startHour: number;
    /**
     * 起始时间-分
     */
    startMin: number;
    /**
     * 结束时间-时
     */
    endHour: number;
    /**
     * 结束时间-分
     */
    endMin: number;
    /**
     * 持续流量
     */
    continueCounter: number | string;
}
//# sourceMappingURL=SolenoidWork.d.ts.map