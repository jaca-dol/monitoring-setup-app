import { CTH01TSLInfo } from './CTH01TSLInfo';
import { GS601TSLInfo } from './GS601TSLInfo';
import { TS60XTSLInfo } from './TS60XTSLInfo';
import { UC50XCAT1TSLInfo } from './UC50XCAT1TSLInfo';
import { UC711TSLInfo } from './UC711TSLInfo';
import { WT102TSLInfo } from './WT102TSLInfo';
import { WT30XTSLInfo } from './WT30XTSLInfo';
import { WT401TSLInfo } from './WT401TSLInfo';
/**
 * 设备特定的TSL信息
 */
export interface DeviceSpecificTSLInfo {
    'GS601': GS601TSLInfo;
    'UC711': UC711TSLInfo;
    'WT401': WT401TSLInfo;
    'WT30X': WT30XTSLInfo;
    'TS60X': TS60XTSLInfo;
    'UC50XCAT1': UC50XCAT1TSLInfo;
    'WT102': WT102TSLInfo;
    'CTH01': CTH01TSLInfo;
}
export type DeviceTSLInfoKeys = keyof DeviceSpecificTSLInfo | 'all';
export type DeviceTSLInfo<K extends keyof DeviceSpecificTSLInfo> = DeviceSpecificTSLInfo[K];
//# sourceMappingURL=DeviceSpecificTSLInfo.d.ts.map