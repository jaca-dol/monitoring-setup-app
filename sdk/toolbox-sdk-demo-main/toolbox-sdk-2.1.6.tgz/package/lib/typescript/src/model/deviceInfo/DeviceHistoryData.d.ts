/**
 * 主要用于去扩展设备特定支持的历史数据，通过模块扩展的方式扩展设备支持历史数据
 */
export interface DeviceSettingServiceExtendSupportHistoryData {
}
/**
 * 设备历史数据
 */
export interface DeviceHistoryData extends DeviceSettingServiceExtendSupportHistoryData {
    /**
     * 时间戳
     */
    timestamp: string;
    /**
     * 温度
     */
    temperature?: string;
    /**
     * 湿度
     */
    humidity?: string;
    /**
     * 活跃度（PIR）
     */
    activity?: string;
    /**
     * 光照强度
     */
    illumination?: string;
    /**
     * 二氧化碳
     */
    co2concentration?: string;
    /**
     * TVOC
     */
    tvoc?: string;
    /**
     * TVOC 单位IAQ
     */
    tvoc_iaq?: string;
    /**
     * TVOC 单位UGM
     */
    tvoc_ugm?: string;
    /**
     * 大气压
     */
    atmosphericpressure?: string;
    /**
     * 气压
     */
    'atmospheric Pressure'?: string;
    /**
     * PM2.5
     */
    pm25?: string;
    /**
     * PM10
     */
    pm10?: string;
    /**
     * 电池
     */
    battery?: string;
    /**
     * 甲醛
     */
    hcho?: string;
    /**
     * 臭氧
     */
    o3?: string;
    /**
     * 计数器1
     */
    counter1?: number;
    /**
     * 计数器2
     */
    counter2?: number;
    /**
     * 事件
     * 1: 设备报警
     * 2: 设备报警解除
     * 3: 设备故障
     * 4: 设备故障恢复
     * 5: 设备掉电
     * 6: 设备上电
     * 7: 设备失效
     */
    event?: 1 | 2 | 3 | 4 | 5 | 6 | 7;
    /**
     * 风速
     */
    windSpeed?: string;
    /**
     * 风向
     */
    windDirection?: string;
    /**
     * 雨量
     */
    rainfall?: string;
    /**
     * 倾斜状态
     *
     * 0:正常
     *
     * 1:倾斜
     */
    tiltStatus?: string;
    /**
     * 突变值
     */
    mutationValue?: string;
    /**
     * 液位高度突变值
     */
    mutationValue2?: string;
    /**
     * 场景模式
     */
    caseMode?: number;
    /**
     * 储罐模式液位高度
     */
    distance2?: string;
    /**
     * 突变报警
     * 0:解除
     * 1:触发
     */
    mutationAlarm?: string;
    /**
     * 液位高度突变报警
     * 0:解除
     * 1:触发
     */
    mutationAlarm2?: string;
    /**
     * 盲区报警
     * 0:解除
     * 1:触发
     */
    blindAlarm?: string;
    /**
     * 阈值报警
     * 0:解除
     * 1:触发
     */
    thresholdAlarm?: string;
    /**
     * 液位高度阈值报警
     * 0:解除
     * 1:触发
     */
    thresholdAlarm2?: string;
    /**
     * DI模式
     */
    diMode?: number;
    /**
     * 数字量
     */
    diLevel?: number;
    /**
     * 第一根探针
     * */
    ch1?: string;
    /**
    * 第二根探针
    * */
    ch2?: string;
    /**
    * CH1上报类型 //1:周期上报;2:阈值上报;3:阈值解除上报
    * */
    ch1ReportMode?: 1 | 2 | 3;
    /**
    * CH2上报类型 //1:周期上报;2:阈值上报;3:阈值解除上报
    * */
    ch2ReportMode?: 1 | 2 | 3;
    /**
    * 上报类型 //1:周期上报;2:阈值上报;3:阈值解除上报;4:采集异常;5:超量程
    * */
    reportMode?: 1 | 2 | 3 | 4 | 5;
    /**
     * 计数值
     */
    diCount?: number;
    /**
     * 开关状态
     */
    magnetStatus?: string;
    /**
     * 漏水状态
     */
    leakageStatus?: string;
    /**
     * 电磁阀1
     */
    solenoidState1?: string;
    /**
     * 电磁阀2
     */
    solenoidState2?: string;
    /**
     * 反馈1
     */
    feedBack1?: string;
    /**
     * 反馈2
     */
    feedBack2?: string;
    /**
     * 当前用水量
     * */
    waterCount?: string;
    /**
     * 转换比例
     * */
    conversionRatio?: string;
    /**
     * 报警状态
     * */
    alarmState?: string;
    /**
     * 脉冲计数1
     */
    pulseCount1?: string;
    /**
     * 脉冲计数2
     */
    pulseCount2?: string;
    /**
     * 经度
     */
    longitude?: string;
    /**
     * 纬度
     */
    latitude?: string;
    /**
     * 海拔高度
     */
    altitude?: string;
    /**
     * 电导率
     */
    conductivity?: string;
    /**
     * 土壤湿度
     */
    soilmoisture?: string;
    /**
     * 液位
     */
    waterlevel?: string;
    /**
     * 压力
     */
    pressure?: string;
    /**
     * 距离
     */
    distance?: string;
    /**
     * 占用状态
     */
    pirStatus?: string;
    /**
        * 报警类型
        */
    trigType?: string;
    /**
     *	未使用
     */
    undefined?: any;
    /**
     *	GPIO1
     */
    gpio1Type?: number;
    /**
     *	采集值
     */
    gpio1Value?: number;
    /**
     *	GPIO2
     */
    gpio2Type?: number;
    /**
     *	采集值
     */
    gpio2Value?: number;
    /**
     *	模拟量1类型
     */
    ai1Type?: number;
    /**
     *	模拟量2类型
     */
    ai2Type?: number;
    /**
     *	模拟量输入1
     */
    ai1Value?: number;
    /**
     *	模拟量输入2
     */
    ai2Value?: number;
    /**
     *	rs485 16个通道数据
     */
    historyModbus?: {
        id: number;
        modbusType: number;
        modbusLen: number;
        modbusData: number;
    }[];
    /**
     *	sdi12 16个通道数据
     */
    historySdi?: {
        id: number;
        sdiData: string;
    }[];
    /**
     * 进入人数
     */
    inPeople?: number;
    /**
     * 离开人数
     */
    outPeople?: number;
    /**
     * 累计进入人数
     */
    accumulatedInPeople?: number;
    /**
     * 累计离开人数
     */
    accumulatedOutPeople?: number;
    /**
     * 温控系统开关
     */
    systemEnable?: boolean;
    /**
     * 环境温度
     */
    envTemp?: string;
    /**
     * 环境湿度
     */
    envHumi?: string;
    /**
     * 单目标温度下的目标温度（可能是制热/制冷）
     * 双目标温度下的制热目标温度
     */
    tarTemp?: string;
    /**
   * 双目标温度下的制冷目标温度
     */
    tarTemp2?: string;
    /**
     * 温度控制模式
     * 0制热 1紧急制热 2制冷 3自动
     */
    tempCtrlMode: 0 | 1 | 2 | 3;
    /**
     * 温度控制状态
     */
    tempCtrlState: number;
    /**
     * 风扇控制模式
     * 0自动 1常开 2通风 3 没有接风扇
     */
    fanCtrlMode: 0 | 1 | 2 | 3;
    /**
     * 风扇状态
     * 0表示关 1表示高速 2表示低速
     */
    fanState: 0 | 1 | 2;
    /**
     * 模拟量1当前电流
     */
    ai1CurA?: number;
    /**
     * 模拟量1最小电流
     */
    ai1MinA?: number;
    /**
     * 模拟量1最大电流
     */
    ai1MaxA?: number;
    /**
     * 模拟量1平均电流
     * */
    ai1AvgA?: number;
    /**
     * 模拟量1当前电压
     * */
    ai1CurV?: number;
    /**
     * 模拟量1最小电压
     * */
    ai1MinV?: number;
    /**
     * 模拟量1最大电压
     * */
    ai1MaxV?: number;
    /**
     * 模拟量1平均电压
     * */
    ai1AvgV?: number;
    /**
     * 模拟量2当前电流
     * */
    ai2CurA?: number;
    /**
     * 模拟量2最小电流
     * */
    ai2MinA?: number;
    /**
     * 模拟量2最大电流
     * */
    ai2MaxA?: number;
    /**
     * 模拟量2平均电流
     */
    ai2AvgA?: number;
    /**
     * 模拟量2当前电压
     * */
    ai2CurV?: number;
    /**
     * 模拟量2最小电压
     * */
    ai2MinV?: number;
    /**
     * 模拟量2最大电压
     */
    ai2MaxV?: number;
    /**
     * 模拟量2平均电压
     *
     * */
    ai2AvgV?: number;
    /**
     * 上报类型
     */
    reportType?: string;
    /**
     * 总人数
     */
    totalPeople?: number;
    /**
     * 甲醛（ppm）
     */
    hcho_ppm?: string;
    /**
     * 光照值（Lux）
     * */
    Lux?: number | string;
    /**
     * PIR累计次数
     */
    pirTriggerCount?: number;
    /**
     * 参数类型
     */
    parameterType?: string;
    /**
     * 历史类型
     */
    historyType?: number;
    /**
     * 电流有效值
     */
    currentIntensity?: {
        value: number;
        name: string;
    }[];
    /**
     * 电压有效值
     */
    voltageIntensity?: {
        value: number;
        name: string;
    }[];
    /**
     * 正向有功能耗
     */
    forwardActiveEnergy?: {
        value: number;
        name: string;
    }[];
    /**
     * 反向有功能耗
     */
    reverseActiveEnergy?: {
        value: number;
        name: string;
    }[];
    /**
     * 正向无功能耗
     */
    forwardReactiveEnergy?: {
        value: number;
        name: string;
    }[];
    /**
     * 反向无功能耗
     */
    reverseReactiveEnergy?: {
        value: number;
        name: string;
    }[];
    /**
     * 视在能耗
     */
    apparentEnergy?: {
        value: number;
        name: string;
    }[];
    /**
     * 功率因数
     */
    powerFactorIntensity?: {
        value: number;
        name: string;
    }[];
    /**
     * 有功功率
     */
    activePower?: {
        value: number;
        name: string;
    }[];
    /**
     * 无功功率
     */
    reactivePower?: {
        value: number;
        name: string;
    }[];
    /**
     * 视在功率
     */
    apparentPower?: {
        value: number;
        name: string;
    }[];
    /**
     * 电压三相不平衡
     */
    voltageThreePhaseImbalance?: string;
    /**
     * 电流总谐波失真度
     */
    currentHarmonicDistortion?: {
        value: number;
        name: string;
    }[];
    /**
     * 电压总谐波失真度
     */
    voltageHarmonicDistortion?: {
        value: number;
        name: string;
    }[];
}
/**
 * 设备导出历史数据记录
 * @ignore
 */
export interface ExportHistoryDataRecord {
    id: string;
    fileName: string;
    filePath: string;
    createTime?: string;
}
export interface HistoryTableData {
    tableData: string[][];
    headers: {
        label: string;
        value: string;
    }[];
    formattedHistoryData: DeviceHistoryData[];
    widthArr: number[];
}
export type HistoryDataKey = keyof DeviceHistoryData;
export type HistoryDataConfig = Partial<Record<HistoryDataKey, {
    label: string;
    width: number;
    order?: number;
    unit?: string;
    /**
     * 是否对空值处理
     *
     * @type {boolean}
     */
    nullFormat?: boolean;
    format?: (v: string | number, data: DeviceHistoryData) => string | number;
    valueMap?: Record<any, any>;
    /**
     * 当没有对应的值时（deviceHistoryData[key] == null），显示的占位符
     * @default - 默认显示'/'
     */
    placeholder?: string;
}>>;
//# sourceMappingURL=DeviceHistoryData.d.ts.map