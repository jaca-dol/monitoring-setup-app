import { SensorDeviceInfo } from './SensorDeviceInfo';
import { DeviceData } from './DeviceData';
export declare const GeneralSettingsKeys: readonly ["reportingInterval", "password"];
export declare const LoRaSettingsKeys: readonly ["deviceEui", "joinStatus", "rssi", "snr", "appEUI", "port", "joinType", "deviceAddress", "applicationKey", "networkSessionKey", "applicationSessionKey", "supportFreq", "freqRegion", "freqs", "channelPlan", "classType", "pingSlotPeriod", "gwSpecific", "window2Dr", "window2Freq", "txPower", "enableFreqIndex", "regularReport", "confirmPackages", "adr", "loraVersion", "multicast", "d2dCfg", "keyd2d", "d2dSlave"];
export declare const NBSettingsKeys: readonly ["applicationMode", "apn", "apnUser", "apnPassword", "CSQ", "registerNetworkTime"];
/**
 * 通用设备配置
 */
export type GeneralSettings = Partial<Pick<DeviceData, typeof GeneralSettingsKeys[number]>> & {
    [other: string]: any;
};
/**
 * LoRa配置
 */
export type LoRaSettings = Pick<DeviceData, typeof LoRaSettingsKeys[number]>;
/**
 * NB配置
 */
export type NBSettings = Pick<DeviceData, typeof NBSettingsKeys[number]>;
/**
 * 传感器配置
 */
export type SensorSettings = SensorDeviceInfo;
export interface DeviceSettings {
    general: GeneralSettings;
    lora?: LoRaSettings;
    nb?: NBSettings;
    sensor?: SensorSettings;
    [other: string]: any;
}
//# sourceMappingURL=DeviceSettings.d.ts.map