/**
 * 通道配置
 */
export interface Channel {
    /**
     * 通道ID
     */
    id: number;
    /**
     * 通道名称
     */
    name: string;
    /**
     * 从设备地址
     */
    slaveId: number;
    /**
     * 读取寄存器起始地址
     */
    address: number;
    /**
     * 寄存器数量
     */
    quantity: number;
    /**
     * 数据类型
     */
    type: number;
    /**
     * 是否带符号
     */
    signed: boolean;
    /**
     * 通道采集值
     */
    value?: number | string;
}
/**
 * 读取通道时的数据类型
 * 这里用string，主要是为了方便用fetch_result[fetchChannelDataType].value来获取数据
 */
export type FetchChannelDataType = 'bool' | 'int16' | 'uint16' | 'int32' | 'uint32' | 'float' | 'int64' | 'uint64' | 'double';
//# sourceMappingURL=Channel.d.ts.map