import { Models } from '..';
import { IDeviceConfigService } from './IDeviceConfigService';
/**
 * 设备配置管理器
 */
export interface IDeviceConfigManager {
    /**
     * 注册设备配置服务
     * @param models - 设备型号/系列
     */
    register(models: Models): void;
    /**
     * 获取设备配置服务实例
     * @param model - 设备型号
     * @param deviceInfo - 设备信息
     */
    getDeviceConfigService(model: string): IDeviceConfigService;
}
//# sourceMappingURL=IDeviceSettingManager.d.ts.map