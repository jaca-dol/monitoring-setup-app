import type { MODEL } from '@ursalink-cloud/core-sdk/lib/device';
export interface Data {
    config: ConfigData;
    context?: PayloadContext;
    [channel: number]: ChannelData;
}
export interface PayloadContext {
    firmware?: string;
    hardware?: string;
    model?: MODEL;
    sn?: string;
    version?: string;
}
export interface ChannelData {
    channel: number;
    type: string;
    unit?: string;
    value: any;
}
export interface ConfigData {
    alarm?: {
        current?: number;
        greaterThan?: number;
        id: number;
        lessThan?: number;
        mode: string;
    };
    alarmConfig?: {
        continueTime?: number;
        continueTimeUnit?: string;
        greaterThan?: number;
        id: number;
        lessThan?: number;
        lockoutTime?: number;
        lockoutTimeUnit?: string;
        mode: string;
    };
    channelData?: ({
        channelId: number;
        dataLength: number;
        dataType: string;
        raw: string;
        value: number;
    } | undefined)[];
    channelEnableConfigList?: {
        enabled: boolean;
        index: number;
    }[];
    collectFailedChannelIds?: number[];
    conversion?: {
        index: number;
        type: "mA" | "V" | string;
        [key: string]: any;
    }[];
    debugLevel?: string;
    firmware?: string;
    hardware?: string;
    intelligenceReport?: number;
    interval?: number;
    loRaChanMask?: {
        id: number;
        value: number;
    };
    period?: number;
    powerOff?: boolean;
    powerOn?: boolean;
    response?: {
        alarm?: boolean;
        regularReport?: boolean;
    };
    sn?: string;
    text?: string;
    version?: string;
}
//# sourceMappingURL=types.d.ts.map