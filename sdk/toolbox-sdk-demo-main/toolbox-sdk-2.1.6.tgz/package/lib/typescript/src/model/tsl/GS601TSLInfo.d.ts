/**
 * GS601自定义的物模型信息
 */
export interface GS601TSLInfo {
    /**
     * 电子烟指数
     */
    vaping_index: number;
    /**
     * 电子烟告警
     */
    vaping_index_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
        /**
         * 阈值告警解除
         */
        alarm_deactivation?: {
            /**
             * 电子烟指数
             */
            vaping_index: number;
        };
        /**
         * 阈值告警触发
         */
        alarm_trigger?: {
            /**
             * 电子烟指数
             */
            vaping_index: number;
        };
        /**
         * 水汽干扰告警解除
         */
        interference_alarm_deactivation?: Record<string, any>;
        /**
         * 水汽干扰告警触发
         */
        interference_alarm_trigger?: Record<string, any>;
    };
    /**
     * PM1.0
     */
    pm1_0: number;
    /**
     * PM1.0告警
     */
    pm1_0_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
        /**
         * PM1.0阈值告警解除
         */
        alarm_deactivation?: {
            /**
             * PM1.0
             */
            pm1_0: number;
        };
        /**
         * PM1.0阈值告警触发
         */
        alarm_trigger?: {
            /**
             * PM1.0
             */
            pm1_0: number;
        };
    };
    /**
     * PM2.5
     */
    pm2_5: number;
    /**
     * PM2.5告警
     */
    pm2_5_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
        /**
         * PM2.5阈值告警解除
         */
        alarm_deactivation?: {
            /**
             * PM2.5
             */
            pm2_5: number;
        };
        /**
         * PM2.5阈值告警触发
         */
        alarm_trigger?: {
            /**
             * PM2.5
             */
            pm2_5: number;
        };
    };
    /**
     * PM10
     */
    pm10: number;
    /**
     * PM10告警
     */
    pm10_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
        /**
         * PM10阈值告警解除
         */
        alarm_deactivation?: {
            /**
             * PM10
             */
            pm10: number;
        };
        /**
         * PM10阈值告警触发
         */
        alarm_trigger?: {
            /**
             * PM10
             */
            pm10: number;
        };
    };
    /**
     * 温度
     */
    temperature: number;
    /**
     * 温度告警
     */
    temperature_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
        /**
         * 温度阈值告警解除
         */
        alarm_deactivation?: {
            /**
             * 温度
             */
            temperature: number;
        };
        /**
         * 温度阈值告警触发
         */
        alarm_trigger?: {
            /**
             * 温度
             */
            temperature: number;
        };
        /**
         * 燃烧告警解除
         */
        burning_alarm_deactivation?: Record<string, any>;
        /**
         * 燃烧告警触发
         */
        burning_alarm_trigger?: Record<string, any>;
    };
    /**
     * 湿度
     */
    humidity: number;
    /**
     * 湿度告警
     */
    humidity_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
    };
    /**
     * TVOC
     */
    tvoc: number;
    /**
     * TVOC告警
     */
    tvoc_alarm: {
        /**
         * 采集错误
         */
        collection_error?: Record<string, any>;
        /**
         * 超量程下限
         */
        lower_range_error?: Record<string, any>;
        /**
         * 超量程上限
         */
        over_range_error?: Record<string, any>;
        /**
         * TVOC阈值告警
         */
        alarm_deactivation?: {
            /**
             * TVOC
             */
            tvoc: number;
        };
        /**
         * TVOC阈值告警触发
         */
        alarm_trigger?: {
            /**
             * TVOC
             */
            tvoc: number;
        };
    };
    /**
     * 篡改状态
     */
    tamper_status: 0 | 1;
    /**
     * 篡改状态告警
     */
    tamper_status_alarm: {
        /**
         * 正常
         */
        normal?: Record<string, any>;
        /**
         * 触发
         */
        trigger?: Record<string, any>;
    };
    /**
     * 蜂鸣器
     * 0: 不鸣叫
     * 1: 鸣叫
     */
    buzzer: 0 | 1;
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_1: {
        rmox_0: number;
        rmox_1: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_2: {
        rmox_2: number;
        rmox_3: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_3: {
        rmox_4: number;
        rmox_5: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_4: {
        rmox_6: number;
        rmox_7: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_5: {
        rmox_8: number;
        rmox_9: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_6: {
        rmox_10: number;
        rmox_11: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_7: {
        rmox_12: number;
        zmod4510_rmox3: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_8: {
        log_rcda: number;
        rhtr: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_9: {
        temperature: number;
        iaq: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_10: {
        tvoc: number;
        etoh: number;
    };
    /**
     * TVOC原始数据
     */
    tvoc_raw_data_11: {
        co2: number;
        rel_iaq: number;
    };
    /**
     * 温度单位
     * 0: ℃
     * 1: ℉
     */
    temperature_unit: 0 | 1;
    /**
     * 指示灯
     * 0: 禁用
     * 1: 启用
     */
    led_status: 0 | 1;
    /**
     * 蜂鸣器
     * 0: 禁用
     * 1: 启用
     */
    buzzer_enable: 0 | 1;
    /**
     * 蜂鸣器休眠时间
     */
    buzzer_sleep: {
        /**
         * 休眠时间1
         */
        item_1: {
            /**
             * 启用
             */
            enable: number;
            /**
             * 开始时间（分钟数）
             */
            start_time: number;
            /**
             * 结束时间（分钟数）
             */
            end_time: number;
        };
        /**
         * 休眠时间2
         */
        item_2: {
            /**
             * 启用
             */
            enable: number;
            /**
             * 开始时间（分钟数）
             */
            start_time: number;
            /**
             * 结束时间（分钟数）
             */
            end_time: number;
        };
    };
    /**
     * 蜂鸣器按键中止
     * 0: 禁用
     * 1: 启用
     */
    buzzer_button_stop_enable: 0 | 1;
    /**
     * 蜂鸣器静默时间
     */
    buzzer_silent_time: number;
    /**
     * 篡改报警使能
     * 0: 禁用
     * 1: 启用
     */
    tamper_alarm_enable: 0 | 1;
    /**
     * TVOC原始数据上报
     * 0: 禁用
     * 1: 启用
     */
    tvoc_raw_reporting_enable: 0 | 1;
    /**
     * 温度阈值告警
     */
    temperature_alarm_settings: {
        /**
         * 温度阈值告警
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 阈值条件
         * 0: 无用
         * 1: 条件：x<A
         * 2: 条件：x>B
         * 3: 条件：A<x<B
         * 4: 条件：x<A或x>B
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         */
        threshold_min: number;
        /**
         * 值B
         */
        threshold_max: number;
    };
    /**
     * PM1.0阈值告警
     */
    pm1_0_alarm_settings: {
        /**
         * PM1.0阈值告警
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 阈值条件
         * 0: 无用
         * 1: 条件：x<A
         * 2: 条件：x>B
         * 3: 条件：A<x<B
         * 4: 条件：x<A或x>B
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         */
        threshold_min: number;
        /**
         * 值B
         */
        threshold_max: number;
    };
    /**
     * PM2.5阈值告警
     */
    pm2_5_alarm_settings: {
        /**
         * PM2.5阈值告警
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 阈值条件
         * 0: 无用
         * 1: 条件：x<A
         * 2: 条件：x>B
         * 3: 条件：A<x<B
         * 4: 条件：x<A或x>B
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         */
        threshold_min: number;
        /**
         * 值B
         */
        threshold_max: number;
    };
    /**
     * PM10阈值告警
     */
    pm10_alarm_settings: {
        /**
         * PM10阈值告警
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 阈值条件
         * 0: 无用
         * 1: 条件：x<A
         * 2: 条件：x>B
         * 3: 条件：A<x<B
         * 4: 条件：x<A或x>B
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         */
        threshold_min: number;
        /**
         * 值B
         */
        threshold_max: number;
    };
    /**
     * TVOC阈值告警
     */
    tvoc_alarm_settings: {
        /**
         * TVOC阈值告警
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 阈值条件
         * 0: 无用
         * 1: 条件：x<A
         * 2: 条件：x>B
         * 3: 条件：A<x<B
         * 4: 条件：x<A或x>B
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         */
        threshold_min: number;
        /**
         * 值B
         */
        threshold_max: number;
    };
    /**
     * 电子烟阈值告警
     */
    vaping_index_alarm_settings: {
        /**
         * 电子烟阈值告警
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 阈值条件
         * 0: 无用
         * 1: 条件：x<A
         * 2: 条件：x>B
         * 3: 条件：A<x<B
         * 4: 条件：x<A或x>B
         */
        threshold_condition: 0 | 1 | 2 | 3 | 4;
        /**
         * 值A
         */
        threshold_min: number;
        /**
         * 值B
         */
        threshold_max: number;
    };
    /**
     * 阈值告警次数
     */
    alarm_reporting_times: number;
    /**
     * 阈值解除告警使能
     * 0: 禁用
     * 1: 启用
     */
    alarm_deactivation_enable: 0 | 1;
    /**
     * 温度校准设置
     */
    temperature_calibration_settings: {
        /**
         * 温度
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * 湿度校准设置
     */
    humidity_calibration_settings: {
        /**
         * 湿度
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * PM1.0校准设置
     */
    pm1_0_calibration_settings: {
        /**
         * PM1.0
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * PM2.5校准设置
     */
    pm2_5_calibration_settings: {
        /**
         * PM2.5
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * PM10校准设置
     */
    pm10_calibration_settings: {
        /**
         * PM10
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * TVOC校准设置
     */
    tvoc_calibration_settings: {
        /**
         * TVOC
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * 电子烟指数校准设置
     */
    vaping_index_calibration_settings: {
        /**
         * 电子烟指数
         * 0: 禁用
         * 1: 启用
         */
        enable: 0 | 1;
        /**
         * 校准值
         */
        calibration_value: number;
    };
    /**
     * 中断蜂鸣器报警
     */
    stop_buzzer_alarm: number;
    /**
     * TVOC自清洁
     */
    execute_tvoc_self_clean: number;
}
//# sourceMappingURL=GS601TSLInfo.d.ts.map