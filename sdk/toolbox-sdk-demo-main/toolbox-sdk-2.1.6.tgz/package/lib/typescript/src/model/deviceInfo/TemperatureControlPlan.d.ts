/**
 * 温度控制计划
 * WT201
 */
export interface TemperatureControlPlan {
    id: number;
    index?: number;
    name?: string;
    /**
     * 风扇模式
     * 13 Off 0自动 1常开 2通风 3低 4中 5高
     */
    fanMode: 10 | 0 | 1 | 2 | 3 | 4 | 5;
    tarTemp: number;
    error?: number;
    mode?: 13 | 10 | 0 | 1 | 2 | 3;
    timeList: TemperatureControlPlanTimeSetting[];
    autoTempTarget?: number;
    /**
     * 双设定目标温度设置
     */
    doubleSetPoint?: {
        heatTarget: number;
        emergencyHeatingTarget?: number;
        heatTargetError: number;
        coolTarget: number;
        coolTargetError: number;
        heatTempAuto?: number;
        heatTempAutoError?: number;
        coolTempAuto?: number;
        coolTempAutoError?: number;
    };
    /**
     * WT201固件2.0新增
     */
    contrlError?: number;
    targetError?: number;
    canDelete?: boolean;
    insertStopTime?: number;
}
/**
 * 温度控制计划时间设置
 */
export interface TemperatureControlPlanTimeSetting {
    enable: boolean;
    time: number;
    mask: number[];
}
export declare enum TargetTempCtrlMode {
    single = 0,
    double = 1
}
export declare enum TempCtrlSource {
    NTC = 0,
    LoRa = 1,
    D2D = 2,
    WT401 = 3
}
export interface WT30XTemperatureControlPlanTimeSetting extends TemperatureControlPlanTimeSetting {
    id: number;
}
/**
 * WT30X温度控制计划
 */
export interface WT30XTemperatureControlPlan {
    id: number;
    /**
     * 计划名称
     */
    name: string;
    /**
     * 风扇模式
     */
    fanMode: 0 | 1 | 2 | 3;
    /**
     * 制热目标温度
     * 可以为空
     */
    heatTargetTemp: number | string;
    /**
     * 制冷目标温度
     * 可以为空
     */
    coolTargetTemp: number | string;
    /**
     * 目标温度允差
     * 可以为空
     */
    targetTempTolerance: number | string;
    /**
     * 时间设置
     */
    timeList: Array<WT30XTemperatureControlPlanTimeSetting>;
}
//# sourceMappingURL=TemperatureControlPlan.d.ts.map