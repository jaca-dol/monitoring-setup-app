import { DeviceInfo } from '../deviceInfo/DeviceInfo';
import { IAttribute } from './IAttribute';
/**
 * 设备数据
 */
export type DeviceData = number[];
/**
 * 设备数据模型
 */
export type DataType = 'tsl' | 'flash';
/**
 * 模型数据
 */
export type ModelData = Record<string, any>;
/**
 * 设备数据模型
 * 提供数据相互转换的功能(ModelData -> DeviceInfo)
 */
export interface IDeviceDataModel<Data extends ModelData = ModelData, Info extends DeviceInfo = DeviceInfo> {
    /**
     * 模型属性
     */
    attributes: Array<IAttribute>;
    /**
     * 初始化模型数据
     */
    init(data: Data): void;
    /**
     * 获取模型数据
     */
    getData(): Data;
    /**
     * 获取属性值
     */
    get(name: string): any;
    /**
     * 获取上下文数据
     */
    getContext(): Record<string, any>;
    /**
     * 设置属性值
     */
    set(name: string, value: any): void;
    /**
     * 设置属性分组
     */
    setAttributeGroup(group: string): void;
    /**
     * 设置上下文数据
     * @param context - 上下文数据
     */
    setContext(context: Record<string, any>): void;
    /**
     * 从设备信息中加载，转换为模型数据
     */
    fromDeviceInfo(deviceInfo: Info): void;
    /**
     * 将模型数据转换为设备信息
     * @param options - 转换选项
     * @param options.status - 是否需要包含状态信息
     * @param options.data - 指定要转换的模型数据，不指定则默认使用当前模型数据(this.data)进行转换
     */
    toDeviceInfo(options?: {
        status?: boolean;
        data?: ModelData;
    }): Info;
    /**
     * 将模型数据转换为设备历史信息
     * @param historyInfo - 模型数据+历史数据
     */
    toDeviceHistoryInfo(historyInfo: {
        history: Array<{
            [key: string]: any;
        }>;
    } & ModelData): Array<{
        [key: string]: any;
    }>;
    /**
     * 将模型数据转换为JSON字符串
     */
    toJSON(): string;
    /**
     * 将设备信息转换为JSON字符串
     */
    toDeviceInfoJSON(): string;
}
//# sourceMappingURL=IDeviceDataModel.d.ts.map