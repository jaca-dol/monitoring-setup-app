/// <reference types="node" />
import { Buffer } from 'buffer';
import { ConfigData, Data, PayloadContext } from './types';
export declare function convertBase64ToObject(payload: string, context?: PayloadContext): Data;
export declare function convertObjectToBase64(json: ConfigData): string;
export declare function convertObjectToBase64Array(json: ConfigData): string[];
export declare function convertObjectToBuffers(json: ConfigData): Buffer[];
//# sourceMappingURL=ipso-converter.d.ts.map