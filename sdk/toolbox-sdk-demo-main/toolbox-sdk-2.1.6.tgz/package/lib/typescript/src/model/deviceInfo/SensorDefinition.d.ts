import { SENSORS } from '../constants';
/**
 * 传感器定义(暂未使用)
 */
export interface SensorDefinition {
    /**
     * 传感器类型
     */
    type: SENSORS;
    /**
     * 单位（标准单位）
     */
    unit: string;
    /**
    * 范围（量程）
    */
    range: [number, number];
    /**
    * 小数位数
    */
    decimalPlaces: number;
    /**
     * 支持的单位
     */
    unitOptions?: Array<{
        /**
         * 单位
         */
        text: string;
        /**
     * 标准单位到目标单位的转换系数
     */
        coefficient: number;
    }>;
}
//# sourceMappingURL=SensorDefinition.d.ts.map