/**
 * 夏令时配置
 */
export interface DaylightSaveTime {
    /**
     * 是否启用夏令时
     */
    enable: boolean;
    /**
     * 偏移量
     */
    offset: number;
    /**
     * 开始时间
     */
    start: DaylightItemTime;
    /**
     * 结束时间
     */
    end: DaylightItemTime;
}
/**
 * 夏令时时间Item项
 */
export interface DaylightItemTime {
    month: number;
    weekNum: number;
    weekDay: number;
    minute: number;
}
/**
 * 默认的夏令时开始时间和结束时间
 */
export declare const DefaultDaylightTime: {
    startTime: {
        month: number;
        weekNum: number;
        weekDay: number;
        minute: number;
    };
    endTime: {
        month: number;
        weekNum: number;
        weekDay: number;
        minute: number;
    };
};
//# sourceMappingURL=DaylightSaveTime.d.ts.map